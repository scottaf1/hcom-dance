# This automation is invoked via EventBridge Cron and uses aws api to invoke cross account Run Documents that collect and push custom metrics. 
# mode = 1 is for Tychon
# pass in variables: mode, doc (Run Documen title), key (what to filter), value (list of values), tenant (1=single, 0=all), account(for single), region
# v.7 Last modified on 7/28/2023 Developed by tom.moore@gdit.com

import boto3
import sys, os
import hcom
from botocore.exceptions import ClientError
from botocore.parsers import ResponseParser


def lambda_handler(event, context):
    Mode = 0
    ThisRegion = event.get('region', os.environ['AWS_REGION'])
    ThisRegion1 = hcom.get_region_name(ThisRegion)
    #EastRegion = 'us-gov-east-1'   
    Mode = int(event.get('mode'))
    TargetTenant = int(event.get('tenant', '0')) # set default value if tenant not passed
    # Create  connections
    ssm0 = boto3.client('ssm', region_name=ThisRegion)
    ##### end create SNS client connection ######
    #################### End: create client connections ##############################
    ####### Initialize Configuration #######
    hcom.core_initializer(ThisRegion) # Initilaize platform configuration
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    #hcom.cw_initializer(hcom.setDBcon))

    ####### End Initialize Configuration #######
    tenants = hcom.setTenants
    setCrossAccountARN = hcom.setIAM.get("Cross-Account")
    #ThisARN = ThisARN.replace('centralaccount', Account)
    #################### Start: main flow control section ############################
    value = []
    key = event.get('key') # set target filter
    temp = event.get('value').split(',') # set target filter value
    metricname = event.get('metricname', '')
    metricpath = event.get('metricpath', '')
    metricnamespace = event.get('metricnamespace', '')
    for i in range(len(temp)):
        value.append(temp[i])

    doc = event.get('doc') # set which Run Document
    #if Mode == 1 and key != '' and value != '' and doc != '':
    if Mode == 1 and key != '' and doc != '':
        if TargetTenant == 0: #if all
            for x, y in tenants.items(): # loop through all the tenants
                ThisARN = setCrossAccountARN.replace('tenantaccount', y) # used to assume role in cross accounts for alarm creation based on metrics in cross accounts
                response = invoke_run_doc(ThisARN, doc, key, value, ThisRegion, metricname, metricpath, metricnamespace )
                print(__name__, '--- ', x, ' ---')
                print(response)
        elif TargetTenant == 1 and event.get('account') != '': # only one tenant
            account = event.get('account')
            ThisARN = setCrossAccountARN.replace('tenantaccount', account) # used to assume role in cross accounts for alarm creation based on metrics in cross accounts
            response = invoke_run_doc(account,setCrossAccountARN, doc, key, value, ThisRegion, metricname, metricpath, metricnamespace )
            print(__name__, '--- ', account, ' ---')
            print(response)
    else:
        print(__name__, 'Nothing to do. Parameters passed did not invoke functionality.')
def invoke_run_doc(Account,ThisARN, doc, key, value, ThisRegion, metricname, metricpath, metricnamespace):
    
    print(__name__, 'doc:', doc, 'key:', key, 'value:',value)
    temp = ["*"]
    #################### Start: create client connections ##############################
    ## Assume cross account role to get credentials for client connections
    ssm1 = hcom.get_ssm_connection(Account,ThisRegion,ThisARN)
    if metricname != '': # check for metricname being passed

        try:
            response = ssm1.send_command(
                Targets=[{
                    'Key': key,
                    'Values': value
                }],
                DocumentName = doc,
                DocumentVersion='$LATEST',
                MaxErrors = '100%',
                Parameters={
                    'metricname': [metricname],
                    'metricpath': [metricpath],
                    'metricnamespace': [metricnamespace]
                }
            )
            print(__name__, 'raw response:', response)
        except ClientError as error:
            print(__name__, 'Run Command ran into an error.', error)
            return error
    else: # if not passing metricname, assume run document is specifying the metric name
        try:
            response = ssm1.send_command(
                Targets=[{
                    'Key': key,
                    'Values': value
                }],
                DocumentName = doc,
                DocumentVersion='$LATEST',
                MaxErrors = '100%'
            )
            print(__name__, 'raw response:', response)
        except ClientError as error:
            print(__name__, 'Run Command ran into an error.', error)
            return error