# This automation audits the CloudWatch Alarms in "ALARM" state for CW Agent and audits Insufficient_state alarms. 
# mode = 1 will toggle alarm state for amazon-cloudwatch-agent. This will trigger an attempt to restart the agent process by the auto responder
# ***** NOTE **** when doing development, comment out the delete alarms calls (2) until testing is complete. Otherwise you may delete alarms you don't intend to.
# assumes primary execution/deployment is from West Region
# v.25 Last modified on 8/27/2023. Developed by tom.moore@gdit.com. 
import boto3
import ast, datetime, json,os, sys, time, uuid
import hcom
from botocore.exceptions import ClientError
from botocore.parsers import ResponseParser

test = 0 #  1 = don't delete alarms, 0 = yes, delete orphaned alarms
DeleteTheseAlarms = []

def lambda_handler(event, context):
    global DeleteTheseAlarms
    
    alarmReport = ''
    counter = 0
    print(__name__, 'event:', event)
    if(type(event) != dict):
        print(__name__, 'reformatting')
        event = ast.literal_eval(event)
    ThisRegion = event.get("region", os.environ['AWS_REGION'])
    targets = event.get("tenant", "")
    Mode = int(event.get('mode', '1'))
    sendReport = event.get('report', '')
    print(__name__, 'mode:', Mode, 'Tenant:', targets, 'reset:',event.get('resetcount') )
    #ThisRegion = event.get('region', os.environ['AWS_REGION']) # assumed to be running from region 1
    
    ####### Initialize Configuration #######
    hcom.core_initializer(ThisRegion) # Initilaize platform configuration
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    hcom.cw_initializer(hcom.setDBcon, table)
    
    
    setBucket = hcom.setS3.get("Reports")
    setBucketReg = hcom.setS3.get("Reports-region")
    processevent = 0
    
    ####### End Initialize Configuration #######   
   #environs = hcom.setTenantsEnv
    #environs = hcom.get_tenant_account_attribute(thisTenant,settings['account'],'Environments')
    ThisMessage = ''
    theseAccounts = []
    # Create  connections
    sns = boto3.client('sns', region_name=ThisRegion)
    ssm0 = boto3.client('ssm', region_name=ThisRegion)
    ##### end create SNS client connection ######
    #################### End: create client connections ##############################
    print(__name__, 'Mode:', Mode)
    #################### Start: main flow control section ############################
    if Mode == 1: # mode 1 is for amazon-cloudwatch-agent audit
        print(__name__, '--- core tenants:', hcom.setTenants)
        print(__name__, '--- core regions:', hcom.setReportRegions)
        #print(__name__, '--- core environment:', environs)
        #alarmReport = '----- West Region -----\n'
        #for key,   in hcom.setTenants.items(): # loop through Tenants
        for thisTenant, accounts in hcom.setTenants.items(): # loop through Tenants
            #environments = environs.get(thisTenant)
            tenant  = thisTenant
            
            for settings in accounts: # loop through accounts for tenant
                print(__name__, '--- ', settings, ' ---')
                tenantRegions = hcom.get_tenant_account_attribute(thisTenant,settings['account'],'Regions')
                AccountName = hcom.get_tenant_account_attribute(thisTenant,settings['account'],'acctname')
                activestatus = hcom.get_tenant_account_attribute(thisTenant,settings['account'],'Active')
                isvalid = hcom.is_valid_account(settings['account'])
                if activestatus == False or isvalid == False: # if not active or fake account
                    continue
                for region in tenantRegions: # Loop through each region
                    ThisRegion = region
                    rname = hcom.get_region_name(region)
                    cloudwatch = boto3.client('cloudwatch', region_name=ThisRegion)
                    try:
                        #print(__name__, 'environment:', len(environments), environments)
                        environments = hcom.get_tenant_account_attribute(thisTenant,settings['account'],'Environments')
                        if len(environments) > 0: # make sure we have environments to loop through
                            for env in environments: # loop through each environment
                                results = audit_alarms(cloudwatch, tenant,settings['account'],event, ThisRegion, env, rname, AccountName)
                                alarmReport = alarmReport + results + '\n'

                    except ClientError as error:
                        print(__name__, 'Unexpected error occurred... could not parse environments. ', error)
                        continue
                        pass
        if event.get('resetcount') == 'yes':
            ########### report automations invoked ###########
            
            for region in hcom.setReportRegions:
                region = region['S']
                print(__name__, 'region:', region)
                rname = hcom.get_region_name(region)
                ssm0 = boto3.client('ssm', region_name=region)
                automationCount = reset_counts(event, region)
                alarmReport = alarmReport + automationCount

    elif Mode == 2: # specify target tenants, single tenant audit
        #targets = event.get('tenants')
        processevent = 1
        loop = 0
        #tenants = targets.split(',')
        print(__name__,'tenant: {}'.format(targets))
        #rows = len(tenants)
        #for i in range(rows): # loop through Tenants
        #thisTenant  = tenants[i]
        thisTenant = targets
        #value = hcom.setTenants.get(tenants[i])
        theseAccounts = hcom.get_tenant_accounts(thisTenant,True) # only audit active accounts
        #environments = hcom.get_environs(environs, tenants[i])
        #environments = environs.get(tenants[i])
        #for Account in value: # loop through accounts for tenant
        print(__name__,'number of accounts: {} | {}'.format(len(theseAccounts), theseAccounts))
        for accountnum in theseAccounts: # loop through accounts for tenant

            tenantRegions = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Regions')
            AccountName = hcom.get_tenant_account_attribute(thisTenant,accountnum,'acctname')
            activestatus = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Active')
            isvalid = hcom.is_valid_account(accountnum)
            if activestatus == False or isvalid == False: # if not active or fake account
                continue
            print(__name__,' number of regions: {} | {}'.format(len(tenantRegions),tenantRegions))
            for region in tenantRegions: # Loop through each region
                ThisRegion = region
                rname = hcom.get_region_name(region)
                cloudwatch = boto3.client('cloudwatch', region_name=ThisRegion)
                try:
                    environments = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Environments')
                    print(__name__,'number of environemnts within regions: {} | {}'.format(len(environments),environments))
                    if len(environments) > 0: # make sure we have environments to loop through
                        for env in environments: # loop through each environment
                            print(__name__,'alarm audit check: loop: {} | {} | {} | {} | {} | {} | {} | {}'.format(loop,thisTenant,accountnum, event, ThisRegion, env, rname, AccountName))
                            results = audit_alarms(cloudwatch, thisTenant,accountnum,event, ThisRegion, env, rname, AccountName)
                            #print(__name__, 'filter:', filterAlarms)
                            alarmReport = alarmReport + results + '\n'
                            #sys.exit()
                            loop = loop + 1
                            if loop > 20:
                                sys.exit()
                except ClientError as error:
                    print(__name__, 'Unexpected error occurred... could not parse environments. ', error)
                    continue
                    pass
        ########### report automations invoked ###########
        if event.get('resetcount') != 'no':
            
            for region in hcom.setReportRegions:
                region = region['S']
                print(__name__, 'region:', region)
                rname = hcom.get_region_name(region)
                #ssm0 = boto3.client('ssm', region_name=region)
                automationCount = reset_counts(event, region)
                alarmReport = alarmReport + automationCount
    elif Mode == 3: # reset counters button in dashboard used.
        automationCount = reset_counts(event, ThisRegion)
        return {'statusCode': 200,'message':'Dashboard Counter Reset.'}   
    elif Mode == 4: # used for daily audit report. puts requests for each tenant in queue
        print(__name__,'TargetTenant is none')
        #for key, value in hcom.setTenants.items(): # loop through all tenants pulled from config file
        for thisTenant, accounts in hcom.setTenants.items(): # loop through all tenants pulled from config file
            print(__name__, ' key:', thisTenant, ' value:', accounts) # value is now a list
            #for accountnum in accounts:
            item = 'responses'
            itemValue = 1
            msg_body = str({ "Function": 'cwalarm_audit', "mode": 2, "tenant": thisTenant, "report": 'yes', 'resetcount': 'no'})
            hcom.update_central_queque(msg_body,hcom.setSQS.get("HCOM-PlatformAutomation"))
    else:
        # catchall 
        print(__name__, 'nothing to do, you did not provide valid parameters')
 
    ###### Email Audit Report ######
    #print(__name__, 'Total rows updated:', counter)
    # alarmReport = alarmReport + 'Total rows updated: ' + str(counter) +'\n'
    if Mode in [1,2]:
        print(__name__, 'alarms to delete:', len(DeleteTheseAlarms), DeleteTheseAlarms)
        response2 = hcom.delete_alarms(cloudwatch, DeleteTheseAlarms)
        ThisMessage = alarmReport # 'This message was generated by the HCOM-Alarm-Audit Lambda automation.'
        ThisSubject = 'CloudWatch Alarm Audit and Lifecycle Management Report' #+ ThisRegion1
        nothing = ''
        if sendReport != 'no':
            centralAlerts = hcom.convert_arn(hcom.setCentralSNS,hcom.setCentralRegion,hcom.setCentralAccount,hcom.setPartition,nothing,nothing)
            try:
                #send_sns_message(sns, ThisSNSHelpDesk, ThisSubject, ThisMessage )
                hcom.send_sns_message(sns, centralAlerts, ThisSubject, ThisMessage )
                #hcom.send_sns_message(sns, hcom.setTestARN, ThisSubject, ThisMessage )
                print(__name__, 'Successfully emailed Alarm Report.')
            except ClientError as error:
                print(__name__, 'Error trying to send email to topic', error)
                pass
            ###### End Audit Report #######
            ### write file to S3
            ThisTime =  datetime.datetime.now()
            reportname = hcom.setCWConfigurations.get("AuditReport").split('.')
            path = reportname[0] + '/' + str(ThisTime.year) + '/' + ThisTime.strftime("%B") + '/'
            
            filename = hcom.setCWConfigurations.get("AuditReport")
            results = hcom.upload_report(ThisMessage, setBucket, setBucketReg, path, filename)
            ### create HCOM Event in AWS EB
            if processevent == 1:
                etype = 'cw-event'
                ename = 'audit'
                etarget = 'StateChange'
                eventFormat = hcom.get_hcom_event(etype,ename,etarget)

                #### log event in EventBridge
                eventFormat['Detail']['tenant'] = targets
                eventFormat['Detail']['account'] = theseAccounts
                eventFormat['Detail']['state'] = 'completed'
                eventFormat['Detail']['category'] = 'cwalarm'
                source = 'hcom.audit'
                eventresponse = hcom.put_hcom_event(source,json.dumps(eventFormat['Detail']),'Audit-Report-Ran-Notification')
        return {
            'statusCode': 200,
            'Update Alarms': ThisMessage,
            'Upload Report Results': results,
        }
    #################### End: main flow control section ############################

def audit_alarms(cloudwatch, prefix, Account, event, ThisRegion, env, rname,AccountName):
    global DeleteTheseAlarms 

    env = env.replace(' ', '')
    print(__name__, '------------ Start ', prefix, AccountName, env, ThisRegion, ' Section -------------')
    ThisReport = '------------ Start ' + prefix + ' ' + AccountName + ' ' + env + ' ' + ThisRegion + ' Section -------------\n'
    ######## section for In Alarm ########
    state = 'ALARM'
    tenantAlarms = 0
    inAlarm_details = []
    ThisInstanceId = ''
    cwauditList = []
    
    filterAlarms = prefix + '-' + AccountName + '-'  +rname + '-'  + env
    ThisConnect = hcom.get_ec2_resource_connection(Account,ThisRegion,hcom.setIAM.get("Cross-Account"))
    ThisSSMConnect = hcom.get_ssm_connection(Account,ThisRegion, hcom.setIAM.get("Cross-Account"))
    paginator = cloudwatch.get_paginator('describe_alarms')
    response_iterator = paginator.paginate(
        AlarmNamePrefix = filterAlarms,
        AlarmTypes = ['MetricAlarm'],
        StateValue = state,
        MaxRecords = 100
        )
    print(__name__,'criteria - Filter: {} StateValue:{}'.format(filterAlarms,state)) # for testing and debuggin
    #names = [alarm['AlarmName'] for alarm in response['MetricAlarms']] ## use for testing and debugging
    for x in response_iterator:
        print(__name__, ' number of rows of in ALARM:',len(x['MetricAlarms'])) ## use for testing and debugging
        print(__name__, 'results', x['MetricAlarms']) ## use for testing and debugging
        
        if len(x['MetricAlarms']) < 1:
            print ()
        else:
            try:
                for r in x['MetricAlarms']: #response['MetricAlarms']:
                    print(__name__,'--- count alarm: {}'.format(r))
                    tenantAlarms = tenantAlarms + 1
                    inAlarm_details.append(r['AlarmName']) # add alarm name to audit list
                    #tenantAlarms_details.append()
                    if r['AlarmName'].find('amazon-cloudwatch-agent') > -1:
                        for y in r['Metrics']:
                            #print(__name__, 'Metric:',y['MetricStat']['Metric']['Dimensions'])## use for testing and debugging
                            try:
                                for j in range(4): # contains all the metadata for each volume
                                    if y['MetricStat']['Metric']['Dimensions'][j]['Name'] == 'InstanceId' or y['MetricStat']['Metric']['Dimensions'][j]['Name'] == 'Instance': # dimension for most alarms
                                        ThisInstanceId = y['MetricStat']['Metric']['Dimensions'][j]['Value']

                            except IndexError as error:
                                print(__name__, 'Error querying for Instance ID:', error)
                                pass
                        cwauditList.append(ThisInstanceId) # add instance ID to potential CW Agent issue
                        alarmName = r['AlarmName']
                        print(__name__,'238 - pre try for check_ec2_exists. Alarm Name:'.format(alarmName))
                        try:
                            if ThisInstanceId.find('mi-') == -1: # this is EC2 not OnPrem
                                ec2instance = ThisConnect.Instance(ThisInstanceId)
                                print(__name__, ' 227 - ec2instance:', ec2instance)#, 'state:',ec2instance.state["Name"]) ## use for testing and debugging
                            ec2_check = check_ec2_exists(Account, prefix, ThisInstanceId, ThisRegion)
                            
                        except ClientError as error:
                            print(__name__,'246 - check:',str(ec2_check), error)
                        if ec2_check[0] == 'exists' and ThisInstanceId.find('mi-') == -1: # this is EC2 not OnPrem
                            state = ec2instance.state["Name"]
                        elif ThisInstanceId.find('mi-') > -1 and len(ec2_check)==2:
                            state = ec2_check[1]
                        else:
                            state = 'instance no longer exists'
                            print(__name__, 'Attribute Error, instance has no state since it does not exist') ## use for testing and debugging
                            ThisReport = ThisReport + 'Alarm: ' + r['AlarmName'] + ' InstanceId: ' + ThisInstanceId + ' State: '+ state + ' - deleted orphaned alarms\n'
                            print(__name__,'deleting alarms for terminated instance:', alarmName)
                            print(__name__,'256 - pre try for delete_terminated_alarms')
                            try:
                                delete_terminated_alarms(cloudwatch, alarmName, ThisRegion)
                                item = 'deleted'
                                itemValue = 1
                                ThisRegion1 = hcom.get_region_name(ThisRegion)
                            except ClientError as error:
                                print(__name__,'263 - check:',ec2_check, error)
                            print(__name__,'264 - pre try for hcom.update_queue')
                            try:
                                hcom.update_queue(prefix, Account, item, itemValue, hcom.setSQS.get("HCOM-StateChange"), ThisInstanceId, ThisRegion1,ThisRegion)
                                print(__name__, 'attempt to delete alarm', alarmName, ThisRegion)
                            except ClientError as error:
                                print(__name__,'244 - check:',ec2_check, error)
                            print(__name__, ' 237 - Alarm:', r['AlarmName'], ' InstanceId:', ThisInstanceId, 'State:', state)

                        if state == 'running' or state == 'Online': # reset state so automation will kick-in and try and install CW agent and push config
                            response5 = hcom.change_alarm_state(cloudwatch, r['AlarmName'], 'INSUFFICIENT_DATA')
                            ThisReport = ThisReport + 'Updated alarm state to trigger automation to attempt to reinstall and configure CW agent on:' + ThisInstanceId + '\n'
                            print(__name__, 'Updated Alarm State to trigger automation or ',r['AlarmName']) 
            except ClientError as error:
                print(__name__, 'Error trying to assess Alarms that are In-Alarm state:', error)
                return error
    print(prefix + ' ' + AccountName + ' In-Alarm:', tenantAlarms)
    aname = "In Alarm"
    results = hcom.update_ops_stats(prefix, Account, rname, env, aname, tenantAlarms, inAlarm_details,mode=1)
    ThisReport = ThisReport + prefix + ' ' + AccountName + ' In-Alarm: ' + str(tenantAlarms) + '\n'
    ######## section for Insufficient Data ########
    state = 'INSUFFICIENT_DATA'
    ThisReport = ThisReport + '------- Begin investigation of Insufficient_Data alarms -------\n'
    print(__name__, '------- Begin investigation of Insufficient_Data alarms -------')
    tenantAlarms = 0
    inSufficient_details = [] # store alarm names for insufficient count
    disableAlarms = 0
    runningState = 0
    investigate_details = [] # store instances for investigate count
    stoppedState = 0
    ThisInstanceId = ''
    isManaged = ''
    auditList = [] # used for insufficient data instances
    numprocessed = 0
    ThisHostName = ''
   
    ThisDeviceName = ''
    paginator = cloudwatch.get_paginator('describe_alarms')
    #page_iterator = paginator.paginate()
    response_iterator = paginator.paginate(
    #response_iterator = page_iterator.search(
        AlarmNamePrefix = filterAlarms,
        AlarmTypes = ['MetricAlarm'],
        StateValue = state,
        MaxRecords = 100

        )
    for x in response_iterator:
        print(__name__, ' number of rows of INSUFFICIENT_DATA:',len(x['MetricAlarms'])) ## use for testing and debugging
        #if env == 'STG': # used for testing
        #    sys.exit() # for testing
        if len(x['MetricAlarms']) < 1:
            print ()
        else:
            numprocessed = numprocessed + 1 # for testing
            #if numprocessed == 2: # for testing
            #    sys.exit() # for testing
            print(__name__, '--- process alarm number: ', numprocessed, ' ----')
            try:
                for r in x['MetricAlarms']: #response['MetricAlarms']:
                    tenantAlarms = tenantAlarms + 1
                    ThisMetricName = r['Metrics'][0]['MetricStat']['Metric']['MetricName']
                    print(__name__, 'r raw',r) ## use for testing and debugging
                    #print(__name__, 'Metric Name', r['Metrics'][0]['MetricStat']['Metric']['MetricName']) ## use for testing and debugging
                    if r['ActionsEnabled'] == False: # alarms action is disabled so instance should be off and ok to be insufficient
                        disableAlarms = disableAlarms + 1
                    else: # alarms enabled so instance should be running
                        inSufficient_details.append(r['AlarmName']) # add alarm name to audit list
                        for y in r['Metrics']:
                            #print(__name__, 'how many:', len(y['MetricStat']['Metric']['Dimensions'])) # find out how many dimensions
                            ThisNameSpace = y['MetricStat']['Metric']['Namespace']
                            ThisMetName = y['MetricStat']['Metric']['MetricName']
                            #print(__name__, 'Metric:',ThisMetricName, 'Namespace:', ThisNameSpace)
                            ThisVolume = ''
                            ThisDeviceName = ''
                            try:
                                for j in range(len(y['MetricStat']['Metric']['Dimensions'])): # replaced 4 with len, contains all the dimensions for each alarm
                                    if y['MetricStat']['Metric']['Dimensions'][j]['Name'] == 'InstanceId':
                                        ThisInstanceId = y['MetricStat']['Metric']['Dimensions'][j]['Value']
                                    elif y['MetricStat']['Metric']['Dimensions'][j]['Name'] == 'path' or y['MetricStat']['Metric']['Dimensions'][j]['Name'] == 'instance':
                                        ThisVolume = y['MetricStat']['Metric']['Dimensions'][j]['Value']
                                    elif y['MetricStat']['Metric']['Dimensions'][j]['Name'] == 'ImageId':
                                        ThisImageId = y['MetricStat']['Metric']['Dimensions'][j]['Value']
                                    elif y['MetricStat']['Metric']['Dimensions'][j]['Name'] == 'InstanceType':
                                        ThisInstanceType = y['MetricStat']['Metric']['Dimensions'][j]['Value']
                                    elif y['MetricStat']['Metric']['Dimensions'][j]['Name'] == 'device':
                                        ThisDeviceName = y['MetricStat']['Metric']['Dimensions'][j]['Value']
                                    elif y['MetricStat']['Metric']['Dimensions'][j]['Name'] == 'Instance': # used for Custom metrics
                                        ThisInstanceId = y['MetricStat']['Metric']['Dimensions'][j]['Value']
                                    elif y['MetricStat']['Metric']['Dimensions'][j]['Name'] == 'host': # used for OnPrem Host
                                        ThisHostName = y['MetricStat']['Metric']['Dimensions'][j]['Value']
                                
                            except IndexError as error:
                                #print(__name__, 'Error querying for Instance ID:', error, ThisInstanceId)
                                pass
                            try: ##### Check EC2 status
                                if ThisInstanceId.find('mi-') == -1:
                                    ec2instance = ThisConnect.Instance(ThisInstanceId) #get EC2 resource information
                                    if ec2instance: # did we find the instance?
                                        state = ec2instance.state["Name"] # assign state
                                    else: # if not it must be terminated
                                        state = 'terminated'
                                else:
                                    state = ''
                            except Exception as error:
                                print(__name__, '365 - Error querying for Instance status', error, ThisInstanceId)
                                state = 'terminated'
                                pass
                            alarmName = r['AlarmName']
                            if (ThisInstanceId not in auditList) and (ThisInstanceId not in cwauditList):
                                ### new
                                #ec2instance = ThisConnect.Instance(ThisInstanceId) # moved to earlier in the review process
                                #Account = hcom.name_to_account(prefix, hcom.setTenants)
                                print(__name__, '373 - ThisInstanceId:', ThisInstanceId, ThisRegion, Account, prefix) ## used for testing
                                ec2_check = check_ec2_exists(Account, prefix, ThisInstanceId, ThisRegion)
                                
                                if ec2_check[0] == 'exists' and ThisInstanceId.find('mi-') == -1: # EC2 not OnPrem
                                    state = ec2instance.state["Name"]
                                    print(__name__, '378 - Instance exists') ## used for testing
                                elif ThisInstanceId.find('mi-') > -1: # this is OnPrem
                                    state = ec2_check[1]
                                    print(__name__, '381 - set status for onprem')
                                else:
                                    state = 'instance no longer exists'
                                    print(__name__, '384 - Attribute Error, instance has no state since it does not exist') ## use for testing and debugging
                                    delete_terminated_alarms(cloudwatch, alarmName, ThisRegion)
                                    item = 'deleted'
                                    itemValue = 1
                                    ThisRegion1 = hcom.get_region_name(ThisRegion)
                                    hcom.update_queue(prefix, Account, item, itemValue, hcom.setSQS.get("HCOM-StateChange"), ThisInstanceId, ThisRegion1,ThisRegion)
                                    ThisReport = ThisReport + 'Alarm: ' + r['AlarmName'] + ' InstanceId: ' + ThisInstanceId + ' State: '+ state + ' - deleted orphaned alarms\n'
                                print(__name__, '391 - Alarm:', r['AlarmName'], ' InstanceId:', ThisInstanceId, 'State:', state)
                                ## original below

                                if state == 'running' or state =='Online':
                                    print(__name__,'--- count running state: {}'.format(ThisInstanceId))
                                    runningState = runningState + 1
                                    if ThisHostName != '':
                                        investname = ThisInstanceId + ' | ' +  ThisHostName
                                    else:
                                        dashes = alarmName.count('-')
                                        HostName = alarmName.split('-',1)
                                        print(__name__,' new hostname after split: {}'.format(HostName))
                                        ThisHostName = HostName
                                    investigate_details.append(investname) # add instance id for investigate count
                                    isManaged = managed_instance_check(ThisSSMConnect, ThisInstanceId)
                                    if isManaged == 'Yes' and ThisNameSpace != 'Custom':
                                        ThisReport = ThisReport + 'InstanceId: ' + ThisInstanceId + ' State: '+ state + ' SSM: ' + isManaged +' Check CloudWatch Agent on this Instance.\n'
                                    elif isManaged == 'Yes' and ThisNameSpace == 'Custom':
                                        ThisReport = ThisReport + 'InstanceId: ' + ThisInstanceId + ' State: '+ state + ' SSM: ' + isManaged +' Check Custom Metric Collector for ' + ThisMetName + '\n'
                                    else:
                                        ThisReport = ThisReport + 'InstanceId: ' + ThisInstanceId + ' State: '+ state + ' SSM: ' + isManaged +' Check SSM & CloudWatch Agent on this Instance.\n'
                                    
                                elif state == 'stopped':
                                    stoppedState = stoppedState + 1
                                else:
                                    ThisReport = ThisReport + 'Alarm: ' + r['AlarmName'] + ' InstanceId: ' + ThisInstanceId + ' State: '+ state + '\n'
                                #print(__name__, 'Alarm:', r['AlarmName'], ' InstanceId:', ThisInstanceId,'State:', state, 'SSM:', isManaged)
                                auditList.append(ThisInstanceId)
                                #print(__name__, 'auditList', auditList)
                                if ThisMetricName == 'LogicalDisk % Free Space' or ThisMetricName == 'disk_used_percent' and state == 'running':
                                    if ThisMetricName == 'LogicalDisk % Free Space':
                                        ThisPlatform = 'Windows'
                                    else:
                                        ThisPlatform = 'Linux'
                                    Account1 = hcom.name_to_account(prefix, hcom.setTenants)
                                    Account = Account1[0]
                                    cloudwatch2 = hcom.get_cloudwatch_connection(Account, hcom.setIAM.get("Cross-Account"))
                                    timecheck = 7
                                    print(__name__, 'check', ThisPlatform, ThisMetricName, ThisInstanceId, ThisImageId, ThisInstanceType, ThisVolume, ThisDeviceName) ## used for testing
                                    lastStat = check_metric(cloudwatch2,ThisPlatform, ThisMetricName, ThisInstanceId, ThisImageId, ThisInstanceType, ThisVolume, ThisDeviceName, timecheck)
                                    dataPoints = len(lastStat['MetricDataResults'][0]['Timestamps'])
                                    #print(__name__, 'output', lastStat) ## used for testing
                                    #print(__name__, 'data points', dataPoints) ## used for testing
                                    if dataPoints == 0:
                                        
                                        TheseAlarms = hcom.get_alarms(cloudwatch,r['AlarmName'])
                                        if len(TheseAlarms) > 0:
                                            print(__name__, 'alarm name:', TheseAlarms, ' converted to string:',str(TheseAlarms))
                                            #sys.exit()
                                            DeleteTheseAlarms.append(str(TheseAlarms))
                                            #### Update deleted counter
                                            ThisRegion1 = hcom.get_region_name(ThisRegion)
                                            if test != 1:
                                                item = 'deleted'
                                                itemValue = len(TheseAlarms)
                                                #hcom.update_counter(item, itemValue, ThisRegion, hcom.setCWConfigurations.get("Lifecycle"))
                                                hcom.update_queue(prefix, Account, item, itemValue, hcom.setSQS.get("HCOM-StateChange"), ThisInstanceId, ThisRegion1,ThisRegion) 
                                            ThisReport = ThisReport + ThisInstanceId + '----Volume Audit for: ' +ThisVolume + ' CloudWatch metric data points in the last ' +  str(timecheck) + ' days: ' + str(dataPoints)   + ' This Alarm has now been deleted.\n'
                                    else:
                                        ThisReport = ThisReport + ThisInstanceId + '----Volume Audit for: ' +ThisVolume + ' CloudWatch metric data points in the last ' +  str(timecheck) + ' days: ' + str(dataPoints)   + '\n'
                                #sys.exit()
                            else:
                                #print(__name__, 'instance already investigated')
                                print()
                            ### if disk monitor, check for metric history

            except IndexError as error:
                print(__name__, 'Error querying for alarm details', error)
                return error
    #sys.exit()

    finalAlarms = tenantAlarms - disableAlarms
    results = hcom.update_ops_stats(prefix, Account, rname, env, "Insufficient Data", finalAlarms, inSufficient_details,mode=1) # update ops stats in parameter store
    results = hcom.update_ops_stats(prefix, Account, rname, env, "Investigate", runningState, investigate_details,mode=1) # update ops stats in parameter store
    print(prefix + ' INSUFFICIENT_DATA:', tenantAlarms, 'Alarms Disabled:',disableAlarms, ' Instances Running:',runningState, 'Instances Stopped:', stoppedState)
    ThisReport = ThisReport + prefix + ' INSUFFICIENT_DATA: ' + str(tenantAlarms) + ' Disabled: ' + str(disableAlarms) + ' Stopped: ' + str(stoppedState) + ' Running: ' + str(runningState) + ' (Investigate)\n'
    return ThisReport
def reset_counts(event, ThisRegion):
    ############## Get daily automation counts #############
    ThisDailyCount = {}
    ThisReport = '\n\n------- CloudWatch Lifecycle Automation Report for the past 24 hours in  ' + ThisRegion + '-------\n'
    ThisReport = ThisReport + '------- EC2 State changes detected  -------\n'
    config = hcom.setCWConfigurations.get('Lifecycle') + '-' + ThisRegion
    print(__name__, 'param: ',config, ThisRegion)
    #dbcon = boto3.resource('dynamodb')
    #table = dbcon.Table(hcom.setDBcon)
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    try:
        dailyCount1 = table.get_item(Key={'msptype': 'cw', 'mspname': config})
        dailyCount = dailyCount1['Item']
        print(__name__,'results:', type(dailyCount), dailyCount)
        #dailyCount = ssm0.get_parameter(Name=hcom.setCWConfigurations.get('Lifecycle'))
    except Exception as error:
        
        print(__name__, 'no lifecycle file was found',config, ThisRegion )
        pass
    if dailyCount !="":
        #ThisDailyCount2 = dailyCount['Parameter']['Value']
        #ThisDailyCount = ast.literal_eval(ThisDailyCount2)
        #print(__name__, 'ThisDailyCount', ThisDailyCount.get('reboot'), ThisDailyCount.get('terminated'))
        ThisReport = ThisReport + 'Reboots: ' + str(dailyCount['reboot']) + '\n'
        #ThisReport = ThisReport + 'Running: ' + str(dailyCount['running']) + '\n'
        ThisReport = ThisReport + 'Stopped: ' + str(dailyCount['stopped']) + '\n'
        ThisReport = ThisReport + 'Terminated: ' + str(dailyCount['terminatedd']) + '\n'
        ThisReport = ThisReport + '------- CloudWatch Alarms -------\n'
        ThisReport = ThisReport + 'Created: ' + str(dailyCount['created']) + '\n'
        #ThisReport = ThisReport + 'Enabled: ' + str(dailyCount['enabled']) + '\n'
        ThisReport = ThisReport + 'Suppressed: ' + str(dailyCount['suppressed']) + '\n'
        ThisReport = ThisReport + 'Deleted: ' + str(dailyCount['deleted']) + '\n'
        ThisReport = ThisReport + 'Responses: ' + str(dailyCount['responses']) + '\n'
           
        try: # update lifecycle count in DynamoDB
            response2 = table.update_item(
                Key={'msptype': dailyCount['msptype'], 'mspname': config},
                UpdateExpression='SET reboot = :val1, stopped = :val1, terminatedd = :val1, created = :val1, enabled = :val1, suppressed = :val1, deleted = :val1, responses = :val1, responseslist = :list',
                ExpressionAttributeValues={':val1' : '0', ':list': []}
            )
            print(__name__,'updated! ', response2)
        except ClientError as error:
            print(__name__, 'Could not update counts.', error)
            response = 'error'
    
    return ThisReport

def managed_instance_check(ssm1, ThisInstanceID):
    AgentVersion = ''
    try:
        print(__name__,'486 - describe instance ',ThisInstanceID)
        ssmresponse = ssm1.describe_instance_information( # query Systems Manager for OS details
            Filters=[{'Key':'InstanceIds' , 'Values':[ThisInstanceID]}])

        for ssminstance in ssmresponse.get('InstanceInformationList'): # will only find results if SSM is installed
            #print(__name__, 'ssm raw', ssminstance)
            Thisos = ssminstance['PlatformName'] # this is the actual OS of the EC2 instance
            ssminstancename = ssminstance['ComputerName'].strip()
            AgentVersion = ssminstance['AgentVersion']
            PingStatus = ssminstance['PingStatus'] #### values: Online, ConnectionLost
    except ClientError as error:
        print(__name__, 'This instance is likely not SSM managed.', error)
        pass

    if AgentVersion == '':
        managedInstance = 'No'
    else:
        managedInstance = 'Yes'
    return managedInstance

def check_metric(cloudwatch2,ThisPlatform, ThisMetricName, ThisInstanceId, ThisImageId, ThisInstanceType, ThisVolume, ThisDeviceName, timecheck):
    now = datetime.datetime.now()
    then = now - datetime.timedelta(days=timecheck)
    if ThisPlatform == 'Linux':
        response = cloudwatch2.get_metric_data(
            MetricDataQueries =[
                {
                    'Id': 'm1',
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'CWAgent',
                            'MetricName': ThisMetricName,
                            'Dimensions': [
                                {
                                    'Name': 'path',
                                    'Value': ThisVolume
                                },
                                {
                                    'Name': 'InstanceId',
                                    'Value': ThisInstanceId
                                },
                                {
                                    'Name': 'ImageId',
                                    'Value': ThisImageId
                                },
                                {
                                    'Name': 'InstanceType',
                                    'Value': ThisInstanceType
                                },
                                {
                                    'Name': 'fstype',
                                    'Value': 'xfs'
                                },
                                {
                                    'Name': 'device',
                                    'Value': ThisDeviceName
                                }
                            ]

                        },
                        'Period': 300,
                        'Stat': 'Average',
                        'Unit': 'Percent'
                    },
                    'ReturnData': True
                },
            ],
            StartTime = then,
            EndTime = now
        )
    else: # Windows Disk volume Metric
        print(__name__, 'windows')
        response = cloudwatch2.get_metric_data(
            MetricDataQueries =[
                {
                    'Id': 'm1',
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'CWAgent',
                            'MetricName': ThisMetricName,
                            'Dimensions': [
                                {
                                    'Name': 'InstanceId',
                                    'Value': ThisInstanceId
                                },
                                {
                                    'Name': 'ImageId',
                                    'Value': ThisImageId
                                },
                                {
                                    'Name': 'InstanceType',
                                    'Value': ThisInstanceType
                                },
                                {
                                    'Name': 'instance',
                                    'Value': ThisVolume
                                },
                                {
                                    'Name': 'objectname',
                                    'Value': 'LogicalDisk'
                                }
                            ]

                        },
                        'Period': 300,
                        'Stat': 'Average'
                    },

                },
            ],
            StartTime = then,
            EndTime = now
        )
    return response

def check_ec2_exists(Account, prefix, InstanceId, ThisRegion):
    ThisARN = hcom.setIAM.get("Cross-Account").replace('tenantaccount', Account) # used to assume role in cross accounts for alarm creation based on metrics in cross accounts
    print(__name__, '-- check_ec2_exists -- InstanceID:', InstanceId,' Account', Account, 'name:', prefix, 'Region', ThisRegion, 'ARN:', ThisARN)
    outcome = []
    outcome.append('exists') 
    print(__name__, '-- check_ec2_exists -- eval instance ID', InstanceId.find('mi-'))
    if InstanceId.find('mi-') > -1: # onprem instance
        onprem = 1
    else: # its an EC2 instance
        onprem = 0
    if onprem == 0: # check EC2 instance
        #################### Start: create client connections ##############################
        ## Assume cross account role
        
        ec3 = hcom.get_ec2_client_connection(Account, ThisRegion, ThisARN)
        ###### previous code used client instead of resource
        print(__name__,'636 - pre try for describe_instance')
        try: # get EC2 status https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/ec2/client/describe_instance_status.html
            print(__name__,'-- check_ec2_exists --  627 - checking ec2 for:',InstanceId)
            ec2_exists = ec3.describe_instance_status(
                InstanceIds= [InstanceId],
                IncludeAllInstances = True
            )
            print(__name__, '643 -- check_ec2_exists -- instance check:', ec2_exists)
            
        except ClientError as error:
            print(__name__, '646-- check_ec2_exists -- Unexpected error occurred... could not query to see if instance is terminated', error)
            outcome.clear()
            outcome.append('terminated')
            pass
    else: # check OnPrem Instance
        ssm1 = hcom.get_ssm_connection(Account, ThisRegion, ThisARN)
        setting='Tags'
        setEnvTag = hcom.get_account_setting(Account,setting,'environment')
        envtag = 'tag:' + setEnvTag
        RunningState = 'ConnectionLost'
        try:
            print(__name__,'-- check_ec2_exists -- 655 - describe instance ',InstanceId)
            responses = ssm1.describe_instance_information(Filters=[{'Key': 'InstanceIds', 'Values': [InstanceId]},{'Key': 'ResourceType', 'Values': ['ManagedInstance']}]) # get all managed instances that are not  EC2
            print(__name__, '-- check_ec2_exists --  657 checking onPrem for:', InstanceId,' Found Instances:', len(responses['InstanceInformationList']))
            if len(responses['InstanceInformationList']) > 0:
                for i in responses['InstanceInformationList']:
                    RunningState = i['PingStatus']
                    print(__name__,'-- check_ec2_exists -- State:', RunningState, '|',responses['InstanceInformationList'][0]['PingStatus'] )
                
            if RunningState == 'Inactive': # instance is not 'Online' or 'ConnectionLost' so likely terminated
                outcome.clear()
                outcome.append('terminated')

            outcome.append(RunningState)
        except ClientError as error:
            print(__name__, '-- check_ec2_exists -- 667 Unexpected error occurred... could not query onprem instance for PingStatus.', error)
            #pass
    print(__name__,'-- check_ec2_exists -- 669 outcome:', str(outcome))
    return outcome
def delete_terminated_alarms(cloudwatch, alarmName,ThisRegion):
    #### begin delete alarms ####
    global DeleteTheseAlarms
    test = 0
    x = alarmName.split("-", 6)
    BaseAlarmName = x[0] + '-'+ x[1] + '-' + x[2] + '-' + x[3] + '-' + x[4] + '-' + x[5]
    TheseAlarms = hcom.get_alarms(cloudwatch, BaseAlarmName)
    print(__name__, 'base alarmname', BaseAlarmName)
    print(__name__, '# alarms:', len(TheseAlarms))
    config = hcom.setCWConfigurations.get('Lifecycle') + '-' + ThisRegion
    #sys.exit()
    if len(TheseAlarms) > 0:
        #DeleteTheseAlarms.update(TheseAlarms)
        response2 = hcom.delete_alarms(cloudwatch, TheseAlarms)
        #ThisMessage = ThisMessage + '\n CloudWatch Alarms (' + str(len(TheseAlarms)) + ') have been deleted.\n'