### Runs the Backup audit to check for a backup within the specified time period
# v.16 Last modified on 9/5/2023. Developed by tom.moore@gdit.com
import boto3
import ast, datetime, os, sys, uuid
import hcom
from botocore.exceptions import ClientError
from botocore.parsers import ResponseParser

unprotectec2 = 0
unprotectec2_details = []
unprotectefs = 0
unprotectefs_details = []
unprotectonprem = 0
unprotectonprem_details = []
unprotectdynamodb = 0
unprotectdynamodb_details = []
unprotectrds = 0
unprotectrds_details = []

def lambda_handler(event, context):
    """
    This automation is invoked when backup and restore job state changes are detected and emails a report to help desk. 
    mode = 1 will email help desk when backup job state is: EXPIRED, FAILED, COMPLETED. Restore Job state change: FAILED
    mode = 2 for restore reports
    mode = 3 for daily backup audit reports to find instances missing backups
    assumes primary execution/deployment is from West Region

    Args:
        event (dictionary): parameters being passed in from triggering event
        region (string): passed or detected from environment variable
        resourcetype (string): EC2 or EFS
        context (_type_): _description_

    Returns:
        statuscode (integer): standard error code, usually 200
        Update Alarms (String): Core message formulated during execution and output in the emailed report

    """
    global unprotectefs, unprotectec2, unprotectonprem, unprotectec2_details, unprotectefs_details, unprotectonprem_details, unprotectdynamodb, unprotectdynamodb_details, unprotectrds, unprotectrds_details
    #Mode = 0
    print(__name__,'event: {} | {}'.format(type(event),event))
    if type(event)  == str:
        event = ast.literal_eval(event)

    ThisRegion = event.get('region',os.environ['AWS_REGION'])
    ThisTime =  datetime.datetime.now()
    
    print(__name__, 'incoming values:',event.get('tenant'), '|', event.get('resourcetype'), '|', event.get('account'), '|', event.get('job'), '|', event.get('resourcearn'), '|', event.get('resourcetype'), '|', event.get('state'), '|', event.get('statusMessage')) ## for troubleshooting
    ####### Initialize Configuration #######
    hcom.core_initializer(ThisRegion) # Initilaize platform configuration
    hcom.backup_initializer(hcom.setDBcon)
    ####### End Initialize Configuration #######
    #print(__name__,'Backup Config:', hcom.setBKConfigurations)
    ThisRegion1 = hcom.get_region_name(ThisRegion)
    ThisMessage = ''
    
    Mode = int(event.get('mode', 0))
    print(__name__, 'Mode:', Mode) ## for troubleshooting
    TargetTenant = event.get('tenant') # set default value if tenant not passed
    Modes = {1,2,3}
    # Create  connections
    sns = boto3.client('sns', region_name=ThisRegion)
    ssm0 = boto3.client('ssm', region_name=ThisRegion)
    
    ##### end create SNS client connection ######
    #################### End: create client connections ##############################

    #################### Start: main flow control section ############################
    if Mode == 1 and event.get('resourcetype') == 'EC2': # mode 1 is for backup job state change: EXPIRED, FAILED
        eAccount = event.get('account')
        ejob = event.get('job')
        eRegion = event.get('region')
        eArn = event.get('resourcearn')
        eType = event.get('resourcetype')
        eState = event.get('state')
        eStatus = event.get('statusMessage')
        Environment = ''
        Tenant = hcom.account_to_name(eAccount, hcom.setTenants) # translate account number to tenant name
        AccountName = hcom.get_tenant_account_attribute(Tenant,eAccount,'acctname')  
        #### process job details
        eArn = eArn.split('/')
        Instance = eArn[1] # set instance id
        ### get EC2 details
        ec2 = hcom.get_connection(eAccount,eRegion,hcom.setIAM.get("Cross-Account"))
        ThisInstance = ec2.Instance(Instance)
        try:
            InstanceState = ThisInstance.state["Name"]
            for tags in ThisInstance.tags:
                if tags["Key"] == hcom.setEnvName:
                    Environment = tags["Value"]
        except Exception as error:
            print(__name__, 'Error trying to get instance state. It may not exist', error)
            InstanceState = 'Terminated - (check for and remove any static resource assignments in the backup plan)' 
            Environment = 'N/A'
            pass

        #AccountName = hcom.account_to_name(eAccount, hcom.setTenants) # set friendly tenant name

        ### set email message
        ThisMessage = ThisMessage + 'Account: ' + AccountName + ' (' + eAccount + ')\n'
        ThisMessage = ThisMessage + 'Backup Job #: ' + ejob + '\n'
        if eStatus != '':
            ThisMessage = ThisMessage + 'Job Status: ' + eStatus + '\n'
        ThisMessage = ThisMessage + 'State: ' + eState + '\n'
        ThisMessage = ThisMessage + 'EC2 Instance Id: ' + Instance + '\n'
        ThisMessage = ThisMessage + 'EC2 Instance State: ' + InstanceState + '\n'
        ThisMessage = ThisMessage + 'EC2 Instance Environment (tag): ' + Environment + '\n\n'
        ##### set variables for S3 report
        
        ThisGUID = str(uuid.uuid4())
        today = datetime.datetime.now()
        #path = 'Backup-Reports/Events/'
        path = hcom.setBKConfigurations.get("BackupEventsPath") + str(ThisTime.year) + '/' + ThisTime.strftime("%B") + '/'# 'Backup-Reports/Daily-Audit/'
        filename = AccountName + '-' + Instance +'-'+ eState +'.txt'
        thistime = today.strftime("%m") + '-' + today.strftime("%d") + '-' + today.strftime("%Y")
        filename = filename.split('.')
        Thisfilename = path+ filename[0] + '-' + thistime + '-' + ThisGUID[30:35] + '.' + filename[1]
        ThisMessage = ThisMessage + 'This report can be found in S3 at: '+hcom.setBucket + '/' + Thisfilename + '\n\n'
        auditReport = ThisMessage
    elif Mode == 2 and event.get('resourcetype') == 'EC2': # mode 2 is for Restore job state change: FAILED
        eAccount = event.get('account')
        ejob = event.get('job')
        eRegion = event.get('region')
        eArn = event.get('resourcearn')
        eType = event.get('resourcetype')
        eState = event.get('state')
        eStatus = event.get('statusMessage')
        Environment = ''
        #### process job details
        eArn = eArn.split('/')
        Instance = eArn[1] # set instance id
        ### get EC2 details
        Tenant = hcom.account_to_name(eAccount, hcom.setTenants) # translate account number to tenant name
        AccountName = hcom.get_tenant_account_attribute(Tenant,eAccount,'acctname')  
        activestatus = hcom.get_tenant_account_attribute(Tenant,eAccount,'Active')
        isvalid = hcom.is_valid_account(eAccount)
        if activestatus == False or isvalid == False: # if not active or fake account
            print(__name__,'---- skipping invalid or disabled account: {} ----'.format(eAccount))
            return {'statusCode': 500, 'statusmessage': 'Invalid Account Number'}
        ec2 = hcom.get_connection(eAccount,eRegion)
        ThisInstance = ec2.Instance(Instance)
        try:
            InstanceState = ThisInstance.state["Name"]
            for tags in ThisInstance.tags:
                if tags["Key"] == hcom.setEnvName:
                    Environment = tags["Value"]
        except Exception as error:
            print(__name__, 'Error trying to get instance state. It may not exist', error)
            InstanceState = 'Terminated'
            Environment = 'N/A'
            pass

        #AccountName = hcom.account_to_name(eAccount) # set friendly tenant name
        ### set email message
        ThisMessage = ThisMessage + 'Account: ' + AccountName + ' (' + eAccount + ')\n'
        ThisMessage = ThisMessage + 'Restore Job #: ' + ejob + '\n'
        if eStatus != '':
            ThisMessage = ThisMessage + 'Job Status: ' + eStatus + '\n'
        ThisMessage = ThisMessage + 'State: ' + eState + '\n'
        ThisMessage = ThisMessage + 'AMI Id: ' + Instance + '\n'
        ThisMessage = ThisMessage + 'EC2 Instance State: ' + InstanceState + '\n'
        ThisMessage = ThisMessage + 'EC2 Instance Environment (tag): ' + Environment + '\n'

        ##### set variables for S3 report
        path = 'Restore-Reports/'
        path = hcom.setBKConfigurations.get("RestoreEventsPath") + str(ThisTime.year) + '/' + ThisTime.strftime("%B") + '/'# 'Backup-Reports/Daily-Audit/'
        filename = AccountName + '-' + Instance +'-'+ eState +'.txt'
        Thisfilename = path+ filename[0] + '-' + thistime + '-' + ThisGUID[30:35] + '.' + filename[1]
    elif Mode == 3: # mode 3 for EC2 reconciliation with protected resources. validates all instances are getting backed up
        auditReport = ''
        auditReport = auditReport + 'This report checks that all EC2 instances and EFS file systems are protected (has at least 1 backup within the last ' + str(hcom.setConfigurations.get("Most Recent Backup")) + ' hours specified in configuration file) that are designated to have a hcom.\n'
        auditReport = auditReport + 'All EC2 instances must be properly tagged with the standard environment tag to be evaluated. Instances with no backup history are listed as "not protected" while instances with backups older than ' + str(hcom.setConfigurations.get("Most Recent Backup")) + ' hours will display the date of the last hcom.\n\n'
        #ThisSubject = 'AWS Backup Audit'
        ThisSubject = 'AWS Backup Audit for ' + str(TargetTenant)
        #filename = 'AWS Backup Audit.txt'
        filename = hcom.setBKConfigurations.get("AuditReport")
        setCrossAccountARN = hcom.setIAM.get("Cross-Account") # used to assume role in cross accounts
        #environs = hcom.setTenantsEnv
        if TargetTenant != "": #if all
            thisTenant = TargetTenant
            theseAccounts = hcom.get_tenant_accounts(thisTenant,True)#only audit Active Accounts
            if len(theseAccounts) > 0: # we have at least one account to loop through
                for accountnum in theseAccounts: # loop through accounts for tenant
                    tenantRegions = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Regions')
                    AccountName = hcom.get_tenant_account_attribute(thisTenant,accountnum,'acctname')
                    activestatus = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Active')
                    isvalid = hcom.is_valid_account(accountnum)
                    setting = 'Features'
                    backupFeature = hcom.get_tenant_account_setting(thisTenant,accountnum,setting,'AWSBackup')
                    if activestatus == False or isvalid == False: # if not active or fake account
                        print(__name__,'---- skipping invalid or disabled account: {} ----'.format(accountnum))
                        continue
                    if backupFeature == True: # is AWS Backup feature enabled for account?
                        ThisARN = setCrossAccountARN.replace('tenantaccount', accountnum)
                        ThisARN = ThisARN.replace('partition', hcom.setPartition)
                        setting = 'Backup'
                        attribute = 'Most Recent Backup'
                        backupwindow = hcom.get_account_setting(accountnum,setting,attribute)
                        #for rname, region in hcom.setRegions.items(): # Loop through each region
                        #for region in hcom.setReportRegions:
                        for region in tenantRegions: # Loop through each region
                            ThisRegion = region
                            rname = hcom.get_region_name(region)
                            #region = region['S']
                            print(__name__, '-- start region: {}'.format(region))
                            try:
                                environments = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Environments')
                                #environments = environs.get(key)
                                print(__name__, 'environment:', len(environments), environments)
                                if len(environments) > 0: # make sure we have environments to loop through
                                    for env in environments: # loop through each environment
                                        ## reset detail vars with new env
                                        unprotectec2_details = []
                                        unprotectefs_details = []
                                        unprotectonprem_details = []
                                        print(__name__, '--- begin env: {} | {} | {} Region | env: {}'.format(thisTenant, accountnum, rname,env))
                                        if hcom.setBKConfigurations.get("Audit EC2") ==  "Yes": # validate feature
                                            print(__name__,'check vars: {} | {} | {} | {} | {} | {} | {}'.format(accountnum, ThisARN,thisTenant, AccountName, region, env, backupwindow))
                                            report = check_ec2_backups(accountnum, ThisARN,thisTenant, AccountName, region, env, backupwindow)
                                            auditReport = auditReport + report
                                            print(__name__, 'updated ops stats: {} | {} | EC2: {} | env: {}'.format(thisTenant, region, unprotectec2, env)) # used for testing
                                            results = hcom.update_ops_stats(thisTenant, accountnum, rname, env, "EC2 Unprotected", unprotectec2, unprotectec2_details, mode=1) # update ops stats in parameter store
                                            print(__name__,'--- EC2 Audit results --- {}'.format(results))
                                            unprotectec2 = 0
                                        if hcom.setBKConfigurations.get("Audit EFS") ==  "Yes": # validate feature
                                            report = check_efs_backups(accountnum, ThisARN, thisTenant, AccountName, region, env, backupwindow)
                                            auditReport = auditReport + report
                                            results = hcom.update_ops_stats(thisTenant, accountnum, rname, env, "EFS Unprotected", unprotectefs, unprotectefs_details,mode=1) # update ops stats in parameter store
                                            print(__name__,'--- EFS Audit results --- {}'.format(results))
                                            unprotectefs = 0
                                        #print(__name__,'check onprem?',hcom.setBKConfigurations.get("Audit OnPrem"))
                                        
                                        if hcom.setBKConfigurations.get("Audit OnPrem") ==  "Yes": # validate feature
                                            report = check_onprem_backups(accountnum, ThisARN, thisTenant, AccountName, region,env, backupwindow)
                                            auditReport = auditReport + report
                                            results = hcom.update_ops_stats(thisTenant, accountnum, rname, env, "OnPrem Unprotected", unprotectonprem, unprotectonprem_details,mode=1) # update ops stats in parameter store
                                            print(__name__,'--- OnPrem Audit results --- {}'.format(results))
                                            unprotectonprem = 0

                                        if hcom.setBKConfigurations.get("Audit DynamoDB") ==  "Yes": # validate feature
                                            report = check_dynamodb_backups(accountnum, ThisARN, thisTenant, AccountName, region, env, backupwindow)
                                            auditReport += report
                                            print(__name__, 'updated ops stats: {} | {} | EC2: {} | env: {}'.format(thisTenant, region, unprotectdynamodb, env)) # used for testing
                                            results = hcom.update_ops_stats(thisTenant, accountnum, rname, env, "DynamoDB Unprotected", unprotectdynamodb, unprotectdynamodb_details, mode=1) # update ops stats in parameter store
                                            print(__name__,'--- DynamoDB Audit results --- account: {} | region: {} | env: {} | results: {}'.format(AccountName, ThisRegion, env, results))
                                            unprotectdynamodb = 0
                                            unprotectdynamodb_details = []
                                        
                                        if hcom.setBKConfigurations.get("Audit RDS") ==  "Yes": # validate feature
                                            report = check_rds_backups(accountnum, ThisARN,thisTenant, AccountName, region, env, backupwindow)
                                            auditReport +=  report
                                            print(__name__, 'updated ops stats: {} | {} | EC2: {} | env: {}'.format(thisTenant, region, unprotectrds, env)) # used for testing
                                            results = hcom.update_ops_stats(thisTenant, accountnum, rname, env, "RDS Unprotected", unprotectrds, unprotectrds_details, mode=1) # update ops stats in parameter store
                                            print(__name__,'--- Auror/RDS Audit results --- account: {} | region: {} | env: {} | results: {}'.format(AccountName, ThisRegion, env, results))
                                            unprotectrds = 0
                                            unprotectrds_details = []
                                else:
                                    print(__name__,' no environments for this region: {}'.format(region))
                            except ClientError as error:
                                print(__name__, 'Unexpected error occurred while auditing... could not parse environments. ', error)
                                #continue
                                pass
        ####### set S3 information 
        ThisGUID = str(uuid.uuid4())
        today = datetime.datetime.now()
        path = hcom.setBKConfigurations.get("AuditReportPath") + str(ThisTime.year) + '/' + ThisTime.strftime("%B") + '/'# 'Backup-Reports/Daily-Audit/'
        thistime = today.strftime("%m") + '-' + today.strftime("%d") + '-' + today.strftime("%Y")
        filename = filename.split('.')
        Thisfilename = path+ filename[0] + '-' + thistime + '-' + ThisGUID[30:35] + '.' + filename[1]
        auditReport = auditReport + '\n\nThis report can be found in S3 at: ' + hcom.setS3.get("Reports") + '/' + Thisfilename + '\n\n'       
        ##### final settings
        ThisMessage = auditReport
    elif Mode == 4: # generate audit requests for each tenant and put in SQS queue for processing
        #for key, value in hcom.setTenants.items(): # loop through all tenants pulled from config file
        for thisTenant, accounts in hcom.setTenants.items(): # loop through all tenants pulled from config file
            print(__name__, ' key:', thisTenant, ' value:', accounts) # value is now a list
            #for accountnum in accounts:
            for settings in accounts:
                print(__name__, ' active account:', settings)
                accountnum = settings['account']
                tenantRegions = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Regions')
                activestatus = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Active')
                isvalid = hcom.is_valid_account(accountnum)
                print(__name__,'account active: {} is valid account: {}'.format(activestatus,isvalid))
                if activestatus == False or isvalid == False: # if not active or fake account
                    print(__name__,'---- skipping invalid account: {} ----'.format(accountnum))
                    continue
                msg_body = str({ "Function": 'backup_audit', "mode": 3, "tenant": thisTenant, "report": 'yes'})
                hcom.update_central_queque(msg_body,hcom.setSQS.get("HCOM-PlatformAutomation"))
        return {"stateCode": 200, "message": "Backup Update requests submitted for processing to SQS."}
    else:
        print(__name__, 'There is an issue with the parameters being passed.')
        return {'statusCode': 400,'message': 'There is an issue with the parameters being passed.'}
    #print(__name__, 'report:', auditReport)
    #### end main logic and begin email and report upload
    if Mode in [1,2]:
        ThisSubject = 'Backup ' + eState + ' for ' + AccountName + ' - ' + ThisRegion1 + ' - ' + Instance + ' ' + Environment
    nothing = ''
    centralAlerts = hcom.convert_arn(hcom.setCentralSNS,hcom.setCentralRegion,hcom.setCentralAccount,hcom.setPartition,nothing,nothing)
    setting = 'Topics'
    tenantSNS = hcom.get_tenant_account_setting(thisTenant,accountnum,setting,'HelpDesk')
    tenantAlerts = hcom.convert_arn(tenantSNS,hcom.setCentralRegion,hcom.setCentralAccount,hcom.setPartition,nothing,nothing)
    try:
        if Mode in Modes:
            hcom.send_sns_message(sns, tenantAlerts, ThisSubject, ThisMessage)
            #hcom.send_sns_message(sns, hcom.setTestARN, ThisSubject, ThisMessage)
        ### email central email
        #if Mode ==3 and event.get('report') == 'yes':
        hcom.send_sns_message(sns,centralAlerts, ThisSubject, ThisMessage)
        print(__name__, 'Successfully emailed Backup Report.')
    except ClientError as error:
        print(__name__, 'Error trying to send email to topic', error)
        pass
       ###### End Audit Report #######
    ### write file to S3
    results = hcom.upload_report2(ThisMessage, hcom.setBucket, hcom.setBucketReg, Thisfilename)
    return {
        'statusCode': 200,
        'Update Alarms': ThisMessage,
    }
def check_ec2_backups(Account, ThisARN, Tenant, AccountName, ThisRegion, env, backupwindow):
    """
    audit for recent EC2 backup

    Args:
        Account (string): AWS Account number for EC2 instance
        ThisARN (string): pointer/url
        AccountName (string): Friendly name in AWS Account number
        ThisRegion (string): format us-gov-west-1 either passed or os environment variable
        env (string): represents the environment of the EC2 like test, dev, production

    Returns:
        output for audit report for specific EC2 checked
    """

    global unprotectec2, unprotectec2_details
    counter = 0
    report2 = '-------- ' + Tenant + ' ' + AccountName + ' ' + env + ' ' + ThisRegion + ' -------\n'
    #################### Start: create client connections ##############################
    ## Assume cross account role
    #ec2 = hcom.get_ec2_client_connection(Account, ThisRegion, ThisARN)
    awsservice = 'ec2'
    connectiontype = 'client'
    ec2 = hcom.get_service_connection(Account,ThisRegion, ThisARN,awsservice,connectiontype)
    #response = hcom.assume_role(ThisARN, ThisRegion)
    setting = 'Tags'
    attribute = 'environment'
    standardtag = hcom.get_account_setting(Account,setting,attribute)
    #environments = hcom.get_tenant_account_attribute(Tenant,Account,'Environments')
    envtag = 'tag:' + standardtag
    ### create backup client
    try:
        awsservice = 'backup'
        connectiontype = 'client'
        backupconn = hcom.get_service_connection(Account,ThisRegion, ThisARN,awsservice,connectiontype)
        #backupconn = boto3.client('backup', region_name = ThisRegion,aws_access_key_id=response['Credentials']['AccessKeyId'],aws_secret_access_key=response['Credentials']['SecretAccessKey'],aws_session_token=response['Credentials']['SessionToken'])
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create EC2 cross account client on trusting account', error)
        return error

    ############# query EC2
    print(__name__,'query for tag/value: {}/{}'.format(envtag,env))
    
    try:
        responses = ec2.describe_instances(Filters = [{'Name': envtag,'Values': [env]},{'Name':'instance-state-name', 'Values': ['running', 'stopping', 'stopped','pending']}]) # Find instances 
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create EC2 cross account query', error)
        return error
    counter = 0
    ### begin count
    print(__name__,' # EC2 instances found: {} show instances: {}'.format(len(responses['Reservations']),env))
    for r in responses['Reservations']:
        print(__name__, '# instances: ',len(r['Instances'])) # used for testing
        hostname = 'unknown'
        for i in r['Instances']:
            counter = counter + 1
            skip = 0
            try: # check for tags in review for exempt tags
                for tags in i['Tags']:

                    if tags["Key"] == hcom.setBKTags.get("EC2ExemptTag"): 
                        if tags["Value"] == hcom.setBKTags.get("EC2ExemptTagValue"): 
                            skip = 1 # don't include in audit
                            break
                    elif tags["Key"] == 'Name':
                        hostname = tags["Value"]

                        
                if skip == 0: # don't skip so audit this one
                    arn = 'arn:' + hcom.setPartition + ':ec2:'+ThisRegion+':' + Account + ':instance/' + i['InstanceId']
                    # print(__name__, 'arn:',arn) # used for testing
                    ############# query backup for protected resources
                    resourceType = 'EC2'
                    resourceId = i['InstanceId']
                    checkreport = check_if_protected(backupconn, ThisARN,ThisRegion,resourceType, resourceId, arn, backupwindow,hostname)
                    report2 = report2 + checkreport
            except KeyError as error:
                print(__name__, 'This instance likely has no tags', error)
                pass

    return report2

def check_efs_backups(Account, ThisARN, Tenant, AccountName, ThisRegion, env, backupwindow):
    """
    audit for recent EFS backup

    Args:
        Account (_type_): _description_
        ThisARN (_type_): _description_
        AccountName (_type_): _description_
        ThisRegion (_type_): _description_

    Returns:
        _type_: _description_
    """
    print(__name__, '--- Checking EFS Backups ----')
    ## Assume cross account role
    report = '-------- ' + Tenant + ' ' + AccountName + ' ' + env + ' ' + ThisRegion + ' -------\n'
    response = hcom.assume_role(ThisARN, ThisRegion)
    ###Create EFS client
    try:
        efs = boto3.client('efs', 
                                  region_name = ThisRegion,
                                  aws_access_key_id=response['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                                  aws_session_token=response['Credentials']['SessionToken']
                                  )
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create EFS cross account client on trusting account', error)
        return error
    ### create backup client
    try:
        backupconn = boto3.client('backup', 
                                  region_name = ThisRegion,
                                  aws_access_key_id=response['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                                  aws_session_token=response['Credentials']['SessionToken']
                                  )
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create backup cross account client on trusting account', error)
        return error
    ############# query EFS
    try:
        responses = efs.describe_file_systems() # Find instances 
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not query EFS file systems using cross account query', error)
        return error
    counter = 0
    ### begin count
    for i in responses['FileSystems']:
        # print(__name__, '# instances: ',len(i['FileSystemId'])) # used for testing
        #print(__name__, 'response: ', responses) # used for testing
        #sys.exit()
        resourcename = i['Name']
        counter = counter + 1
        skip = 0
        try: # check for tags in review for exempt tags
            for tags in i['Tags']:

                if tags["Key"] == hcom.setBKTags.get("EC2ExemptTag"):
                    if tags["Value"] == hcom.setBKTags.get("EC2ExemptTagValue"):
                        skip = 1 # don't include in audit
                        break
                
            if skip == 0: # don't skip so audit this one
                #arn = 'arn:aws-us-gov:elasticfilesystem:'+ThisRegion+':' + Account + ':file-system/' + i['FileSystemId']
                arn = i['FileSystemArn']
                # print(__name__, 'arn:',arn) # used for testing
                ############# query backup for protected resources
                resourceType = 'EFS'
                resourceId = i['FileSystemId']
                checkreport = check_if_protected(backupconn, ThisARN, ThisRegion, resourceType, resourceId, arn,backupwindow,resourcename)
                report = report + checkreport
        except KeyError as error:
            print(__name__, 'This instance likely has no tags', error)
            pass

    return report

def check_if_protected(backupconn, ThisARN, ThisRegion,resourceType, resourceId, arn,backupwindow, resourcename):
    """
    This function takes either and instance ID or EFS ID and checks to see if there has been a recent backup
    based on the timeframe setting in the configuration in parameter store.

    Args:
        backupconn (connection): _description_
        resourceType (_type_): _description_
        resourceId (_type_): _description_
        arn (_type_): _description_

    Returns:
        _type_: _description_
    """
    global unprotectec2, unprotectec2_details, unprotectdynamodb, unprotectdynamodb_details, unprotectrds, unprotectrds_details
    global unprotectefs, unprotectefs_details
    global unprotectonprem, unprotectonprem_details
    report=''
    resourceName = resourceId + ' | ' + resourcename
    print(__name__,'--- begin check if protected for {} | {} ---'.format(resourceType,resourceId))
    print(__name__,'--- current counts ec2: {} | efs: {} | onprem: {}'.format(unprotectec2,unprotectefs,unprotectonprem))
    print(__name__,'--- current counts ec2 details: {} | efs details: {} | onprem details: {}'.format(unprotectec2_details,unprotectefs_details,unprotectonprem_details))
    try:
        recoverypoints = backupconn.describe_protected_resource(ResourceArn=arn) # Find instances 
        print(__name__, 'recoverpoint last backup: {} for {}'.format( recoverypoints['LastBackupTime'],resourceId)) # used for testing
        lastbackup = str(recoverypoints['LastBackupTime'])
        lastbackup = lastbackup.replace(".", "+")
        print(__name__, 'updated: ', lastbackup) # used for testing
        if lastbackup.find("+") != -1: # most common scenario
            temp = lastbackup.split('+') 
        elif lastbackup.find(".") != -1: # additional anomaly found
            temp = lastbackup.split('.') 
        templast = temp[0]
        print(__name__, 'final time: ', templast) # used for testing
        last = datetime.datetime.strptime(templast,'%Y-%m-%d %H:%M:%S' )
        #lasttime = datetime.datetime(templast)
        lastyear= int(last.strftime("%Y"))
        lastmonth= int(last.strftime("%m"))
        lastday= int(last.strftime("%d"))
        lasttime = datetime.datetime(lastyear,lastmonth,lastday)
        #lasttime = datetime.datetime.strptime(templast,'%Y-%m-%dT%H:%M:%SZ' )
        now = datetime.datetime.now()
        target = datetime.timedelta(hours=int(backupwindow))
        then = now - target # must be within the last XX hours (see config file for setting HCOM-Backup-Configuration)
        print(__name__, 'last backup:',last, ' must be more recent than: ', then) # used for testing
        if last > then:
            #print(__name__, 'resource type:' + resourceType + ' instance:',resourceId, ' has a good backup good') 
            if resourceType == 'EC2' or resourceType == "OnPrem": # update compliance for EC2 and OnPrem
                complianceType = 'Custom:Backup'
                severity = 'UNSPECIFIED' # not applicable since its compliant
                status = 'COMPLIANT'
                response = update_compliance(ThisARN,ThisRegion,complianceType, resourceId, lasttime,severity,status)
            print(__name__,'this backup is compliant for {}'.format(resourceId))
        else:
            print(__name__, 'resource type:' + resourceType + ' instance:',resourceId, ' has a bad backup good') # used for testing
            report = report + 'Resource Type: ' + resourceType + ' Instance: ' + resourceId + ' has not had a good backup since: ' + last.strftime("%c") +'\n'
            if resourceType == 'EC2':
                unprotectec2 = unprotectec2 + 1
                unprotectec2_details.append(resourceId)
                complianceType = 'Custom:Backup'
                severity = 'MEDIUM'
                status = 'NON_COMPLIANT'
                response = update_compliance(ThisARN,ThisRegion,complianceType, resourceId, lasttime,severity,status)
            elif resourceType == "EFS":
                unprotectefs = unprotectefs + 1
                unprotectefs_details.append(resourceId)
            elif resourceType == "OnPrem":
                unprotectonprem = unprotectonprem + 1
                unprotectonprem_details.append(resourceName)
                complianceType = 'Custom:Backup'
                severity = 'MEDIUM'
                status = 'NON_COMPLIANT'
                response = update_compliance(ThisARN,ThisRegion,complianceType, resourceId, lasttime,severity,status)
            elif resourceType == "DynamoDB":
                unprotectdynamodb = unprotectonprem + 1
                unprotectdynamodb_details.append(resourceId)
                print(__name__,'adding {} to non-compliant backup'.format(resourceId))
                """
                complianceType = 'Custom:Backup'
                severity = 'MEDIUM'
                status = 'NON_COMPLIANT'
                response = update_compliance(ThisARN,ThisRegion,complianceType, resourceId, lasttime,severity,status)
                """
            elif resourceType == "RDS":
                unprotectrds +=  1
                unprotectrds_details.append(resourceId)
                print(__name__,'adding {} to non-compliant backup'.format(resourceId))
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not find protected resource: {} | {} '.format(resourceId, error))
        report = report + 'Resource Type: ' + resourceType +' Instance: ' + resourceId + ' is not protected\n'
        lasttime = datetime.datetime.now()
        if resourceType == 'EC2':
            unprotectec2 = unprotectec2 + 1
            unprotectec2_details.append(resourceName)
            complianceType = 'Custom:Backup'
            severity = 'HIGH'
            status = 'NON_COMPLIANT'
            response = update_compliance(ThisARN,ThisRegion,complianceType, resourceId, lasttime,severity,status)
        elif resourceType == "EFS":
            unprotectefs = unprotectefs + 1
            unprotectefs_details.append(resourceName)
        elif resourceType == "OnPrem":
            unprotectonprem = unprotectonprem + 1
            unprotectonprem_details.append(resourceName)
            complianceType = 'Custom:Backup'
            severity = 'HIGH'
            status = 'NON_COMPLIANT'
            response = update_compliance(ThisARN,ThisRegion,complianceType, resourceId, lasttime,severity,status)
        elif resourceType == 'DynamoDB':
            unprotectdynamodb = unprotectdynamodb + 1
            unprotectdynamodb_details.append(resourceName)
            # DynamoDB is not a SSM ManagedInstance so can't add to SSM compliance dashboard
        elif resourceType == 'RDS':
            unprotectrds += 1
            unprotectrds_details.append(resourceId)
        print(__name__,'adding {} to non-compliant backup'.format(resourceName))
        pass
    print(__name__,'--- final counts ec2: {} | efs: {} | onprem: {} | DynamoDB: {}'.format(unprotectec2,unprotectefs,unprotectonprem, unprotectdynamodb))
    print(__name__,'--- final counts ec2 details: {} | efs details: {} | onprem details: {} | dynamodb details: {}'.format(unprotectec2_details,unprotectefs_details,unprotectonprem_details, unprotectdynamodb_details))
    print(__name__,'audit report for {} | {}'.format(resourceId,report))
    return report

def check_onprem_backups(Account, ThisARN, Tenant, AccountName, ThisRegion, env,backupwindow):
    """
    audit for recent EC2 backup

    Args:
        Account (string): AWS Account number for EC2 instance
        ThisARN (string): pointer/url
        AccountName (string): Friendly name in AWS Account number
        ThisRegion (string): format us-gov-west-1 either passed or os environment variable
        env (string): represents the environment of the EC2 like test, dev, production

    Returns:
        output for audit report for specific EC2 checked
    """
    print(__name__, '--- Checking OnPrem Backups ----')
    global unprotectec2
    counter = 0
    report2 = '-------- ' + Tenant + ' ' + AccountName + ' ' + env + ' ' + ThisRegion + ' -------\n'
    #################### Start: create client connections ##############################
    ## Assume cross account role
    #ec2 = hcom.get_ec2_client_connection(Account, ThisRegion, ThisARN)
    print(__name__,'--- check on-prem backups for Tenant: {} | Account: {} | Environment: {} | region: {}'.format(Tenant,Account,env,ThisRegion))
    response = hcom.assume_role(ThisARN, ThisRegion)
    ssm1 = hcom.get_ssm_connection(Account, ThisRegion, ThisARN)
    setting = 'Tags'
    attribute = 'environment'
    envtt = hcom.get_account_setting(Account,setting,attribute)
    envtag = 'tag:' + envtt
    ### create backup client
    try:
        backupconn = boto3.client('backup', 
                                  region_name = ThisRegion,
                                  aws_access_key_id=response['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                                  aws_session_token=response['Credentials']['SessionToken']
                                  )
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create EC2 cross account client on trusting account', error)
        return error

    ############# query onprem managed instances
    try:
        tag = 'tag:' + envtt
        tagvalue = env
        responses = ssm1.describe_instance_information(Filters=[{'Key':tag, 'Values': [tagvalue]}])
        #responses = ssm1.describe_instance_information(Filters=[{'Key':'PingStatus', 'Values': ['Online']} ])
        """
        responses = ec2.describe_instances(
            Filters = [{'Name': envtag,
            'Values': [env]}]
        ) # Find instances 
        """
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not get onprem instances', error)
        return error
    counter = 0
    ### begin count
    print(__name__,'onprem instances found: {} for {}'.format(len(responses['InstanceInformationList']),env))
    for i in responses['InstanceInformationList']:
        print(__name__, '# instances: {}'.format(i)) # used for testing
        
        if i['InstanceId'].find('mi-') == -1: # skip EC2 instances. only process onprem with mi- instance ids
            print(__name__,'--- skipping EC2 within OnPrem: {}'.format(i['InstanceId']))
            continue
        counter = counter + 1
        skip = 0
        resourcename = i['Name']
        try: # check for tags in review for exempt tags
            isexmpt = is_onprem_exempt(ssm1,i['InstanceId'])
            if isexmpt == 'Yes':
                skip = 1 # don't include in audit
                print(__name__,'-- instance is exempt --')
                continue
                
            if skip == 0: # don't skip so audit this one
                arn = 'arn:' + hcom.setPartition + ':ec2:'+ThisRegion+':' + Account + ':instance/' + i['InstanceId']
                # print(__name__, 'arn:',arn) # used for testing
                ############# query backup for protected resources
                resourceType = 'OnPrem'
                resourceId = i['InstanceId']
                checkreport = check_if_protected(backupconn, ThisARN,ThisRegion, resourceType, resourceId, arn,backupwindow, resourcename)
                report2 = report2 + checkreport
        except KeyError as error:
            print(__name__, 'This instance likely has no tags. {} | {}'.format(i['InstanceId'],error))
            pass

    return report2

def is_onprem_exempt(ssm1,InstanceId):
    """Checks to see if OnPrem instance has the exempt tag excluding it from the backup audit

    Args:
        ssm1 (Conn): SSM connection
        InstanceId (String): Instance Id for OnPrem instance

    Returns:
        String: return results - Yes or No
    """    
    tags = ssm1.list_tags_for_resource(ResourceType='ManagedInstance',ResourceId=InstanceId)
    onpremExempt = 'No'
    print(__name__, 'tags', tags)
    for tag in tags['TagList']:
        print(__name__, 'tag',tag)
        if tag['Key'] == hcom.setBKTags.get("EC2ExemptTag"):
            if tag['Value'] == hcom.setBKTags.get("EC2ExemptTagValue"):
                onpremExempt = 'Yes'
                return onpremExempt
    return onpremExempt

def update_compliance(ThisARN,ThisRegion,complianceType, resourceId, lasttime,severity,status):
    print(__name__,'---- updating backup compliance in {} for: {} lasttime: {} severity: {} status: {}'. format(ThisRegion,resourceId,lasttime,severity,status))
    response = hcom.assume_role(ThisARN, ThisRegion)
    ##### create SSM client
    try:
        ssmconn = boto3.client('ssm', 
                                  region_name = ThisRegion,
                                  aws_access_key_id=response['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                                  aws_session_token=response['Credentials']['SessionToken']
                                  )
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create SSM cross account client on trusting account', error)
        return error
    try:
        response = ssmconn.put_compliance_items(
            ResourceId=resourceId,
            ResourceType='ManagedInstance',
            ComplianceType=complianceType,
            ExecutionSummary={'ExecutionTime': lasttime, 'ExecutionId': '','ExecutionType':''},
            Items=[{'Id': 'Version2.0','Title': 'BackupInstance', 'Severity': severity,'Status': status}]
        )
    except ClientError as error:
        print(__name__, 'Error, could not put compliance status for {} | error: {}'.format( resourceId,error))
        pass
def check_dynamodb_backups(Account, ThisARN, Tenant, AccountName, ThisRegion, env, backupwindow):
    """
    audit for recent dynamodb backup

    Args:
        Account (string): AWS Account number for EC2 instance
        ThisARN (string): pointer/url
        AccountName (string): Friendly name in AWS Account number
        ThisRegion (string): format us-gov-west-1 either passed or os environment variable
        env (string): represents the environment of the EC2 like test, dev, production

    Returns:
        output for audit report for specific EC2 checked
    """

    global unprotectdynamodb, unprotectdynamo_details
    counter = 0
    report2 = '-------- start check_dynamodb_backups ' + Tenant + ' ' + AccountName + ' ' + env + ' ' + ThisRegion + ' -------\n'
    #################### Start: create client connections ##############################
    ## Assume cross account role
    ec2 = hcom.get_dynamodb_client_connection(Account, ThisRegion, ThisARN)
    response = hcom.assume_role(ThisARN, ThisRegion)
    setting = 'Tags'
    attribute = 'environment'
    standardtag = hcom.get_account_setting(Account,setting,attribute)
    #environments = hcom.get_tenant_account_attribute(Tenant,Account,'Environments')
    #envtag = 'tag:' + standardtag
    ### create backup client
    try:
        dbconn = boto3.client('backup', 
                                  region_name = ThisRegion,
                                  aws_access_key_id=response['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                                  aws_session_token=response['Credentials']['SessionToken']
                                  )
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create backup cross account client on trusting account', error)
        return error

    ############# query DynamoDB
    print(__name__,'query for tag/value: {}/{}'.format(standardtag,env))
    
    try:
        responses = ec2.list_tables() # Find instances 
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not get/list DynamoDB cross account query', error)
        return error
    counter = 0
    ### begin count
    print(__name__,' # DynamoDB instances found: {} | env: {} | show tables: {}'.format(len(responses['TableNames']),env,responses['TableNames']))
    for r in responses['TableNames']:
        print(__name__, 'table instance: ',r) # used for testing
        
        counter = counter + 1
        skip = 0
        try: # check for tags in review for exempt tags
            arn = 'arn:' + hcom.setPartition + ':dynamodb:'+ThisRegion+':' + Account + ':table/' + r
            tags = ec2.list_tags_of_resource(ResourceArn=arn)
            print(__name__,' tags for table: {} | tags: {} | len: {}'.format(r,tags, len(tags['Tags'])))
            if len(tags['Tags']) > 0:
                for i in tags['Tags']:
                    print(__name__,'i[Key] = {} | env: {} i[Value] = {} | envvalue: {}'.format(i['Key'],standardtag,i['Value'],env))
                    if i['Key'] == standardtag and i['Value'] == env: # we found a table we need to audit for the current environment
                        print(__name__, 'matched - calling check if protected for {}'.format(arn)) # used for testing
                        ############# query backup for protected resources
                        resourceType = 'DynamoDB'
                        resourceId = r
                        checkreport = check_if_protected(dbconn, ThisARN,ThisRegion,resourceType, resourceId, arn, backupwindow,'N/A')
                        report2 = report2 + checkreport
                    else:
                        print(__name__,'skipped {} as its not in this environment {}'.format(r,env))
        except KeyError as error:
            print(__name__, 'This instance has an issue.', error)
            pass

    return report2

def check_rds_backups(Account, ThisARN, Tenant, AccountName, ThisRegion, env, backupwindow):
    """
    audit for recent EC2 backup

    Args:
        Account (string): AWS Account number for EC2 instance
        ThisARN (string): pointer/url
        AccountName (string): Friendly name in AWS Account number
        ThisRegion (string): format us-gov-west-1 either passed or os environment variable
        env (string): represents the environment of the EC2 like test, dev, production

    Returns:
        output for audit report for specific EC2 checked
    """

    global unprotectec2, unprotectec2_details
    counter = 0
    report2 = '-------- ' + Tenant + ' ' + AccountName + ' ' + env + ' ' + ThisRegion + ' -------\n'
    #################### Start: create client connections ##############################
    ## Assume cross account role
    rds = hcom.get_rds_client_connection(ThisRegion, ThisARN)
    response = hcom.assume_role(ThisARN, ThisRegion)
    setting = 'Tags'
    attribute = 'environment'
    standardtag = hcom.get_account_setting(Account,setting,attribute)
    #environments = hcom.get_tenant_account_attribute(Tenant,Account,'Environments')
    envtag = 'tag:' + standardtag
    ### create backup client
    try:
        backupconn = boto3.client('backup', 
                                  region_name = ThisRegion,
                                  aws_access_key_id=response['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                                  aws_session_token=response['Credentials']['SessionToken']
                                  )
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create EC2 cross account client on trusting account', error)
        return error

    ############# query EC2
    print(__name__,'query for tag/value: {}/{}'.format(envtag,env))
    
    try:
        responses = rds.describe_db_instances() # Find instances 
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create EC2 cross account query', error)
        return error
    counter = 0
    ### begin count
    print(__name__,' # rds instances found: {} show instances: {} | env: {}'.format(len(responses['DBInstances']),responses['DBInstances'],env))
    for r in responses['DBInstances']:
        #print(__name__, '# instances: ',len(r['Instances'])) # used for testing
        hostname = 'N/A'
        
        counter = counter + 1
        skip = 0
        try: # check for tags in review for exempt tags
            for tags in r['TagList']:
                if tags["Key"] == standardtag and tags["Value"] == env:
                    if tags["Key"] == hcom.setBKTags.get("EC2ExemptTag") and hcom.setBKTags.get("EC2ExemptTagValue"): 
                        skip = 1 # don't include in audit
                        break
                elif tags["Key"] == standardtag and tags["Value"] != env:
                    print(__name__,'--skip instance since its not in this environment: {}'.format(env))
                    skip = 1
                    break
            if skip == 0: # don't skip so audit this one
                #arn = 'arn:' + hcom.setPartition + ':ec2:'+ThisRegion+':' + Account + ':instance/' + i['InstanceId']
                # print(__name__, 'arn:',arn) # used for testing
                ############# query backup for protected resources
                print(__name__,'now auditing rds instance: {}'.format(r['DBInstanceIdentifier']))
                arn = r['DBInstanceArn']
                resourceType = 'RDS'
                resourceId = r['DBInstanceIdentifier']
                checkreport = check_if_protected(backupconn, ThisARN,ThisRegion,resourceType, resourceId, arn, backupwindow,hostname)
                report2 = report2 + checkreport
        except KeyError as error:
            print(__name__, 'This RDS instance likely has no tags', error)
            pass

    return report2
