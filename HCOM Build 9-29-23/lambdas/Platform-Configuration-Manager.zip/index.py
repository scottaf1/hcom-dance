# Provides management of core platform capabilities such as account management. HCOM-Platform-Configuration-Manager (deployed as index.py)
# v.17 Last modified on 9/14/2023. Developed by tom.moore@gdit.com

import boto3
import ast, datetime, json, os, sys, time, uuid
import hcom
from botocore.exceptions import ClientError
from functools import lru_cache
# -*- coding: utf-8 -*-

def lambda_handler(event, context):
    """Provide Hive platform configuration capabilities, supported by SSM Runbook docs and GUI.
    Functions:
    -Tenant - process and manage Tenant settings
    -Core - process and manage core configuration settings which there are 13 sub categories

    Args:
        event (_type_): _description_
        context (_type_): _description_

    Returns:
        _type_: _description_
    """    
    if event['widgetContext']['forms']['all'].get('Tenant') :
        Tenant = event.get('Tenant', event['widgetContext']['forms']['all'].get('Tenant'))
    elif event.get('Tenant'):
        Tenant = event.get('Tenant') 
    Account = event.get('Account', '')
    Accounts = event.get('Accounts', '') # used for adding new tenant
    Environments = event.get('Environments', '') # used for adding new tenant
    Action = event.get('Action')
    AccountNumber = event.get('AccountNumber')
    Function = event.get('Function','')
    Item = event.get('Item','')
    ItemValue = event.get('ItemValue','')

    ThisRegion = event.get('region', os.environ['AWS_REGION'])
    results = 0
    error = '' # setup error var to be used during exception
    print(__name__,'show all form params:{}'.format(event))
    ####### Initialize Configuration #######
    hcom.core_initializer(ThisRegion) # Initilaize platform configuration
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    hcom.cw_initializer(hcom.setDBcon,table)
    path = hcom.setConfigurations.get('TemplatePath') # path in S3 bucket to CF templates
    guiCoreItems = hcom.setGUI # get template from platform config
    ThisPartition = hcom.setPartition
    updateValues = {}
    opscat = ["Availability","Cost", "Performance", "Recovery", "Security"]
    opsseverity = {1:"Critical",2: "High",3: "Medium",4: "Low"}
    page = get_style()
    ##### Main execution
    print(__name__,'Function:', Function, 'Tenant:', Tenant, 'Action:', Action, 'Item:', Item, 'ItemValue:', ItemValue)
    if Function !='': # and Tenant != '' and Item != '' and ItemValue !='': #verify we have values to try to execute
        if Function == 'Tenants': # update Account
            if Item == 'environment' or Item == 'region' or Item == 'account': # update environment
                results = set_account(table,Function,Tenant, Item,ItemValue, Action)
                print(__name__,'environment results:', results)
            elif Action == 'Add' and Item == 'Tenant':
                results = add_account(table,Function,ItemValue, Accounts,Regions, Environments)
            print(__name__,'add tenant results:', results)
        elif Function == 'Core' and Action == 'Update':
            if Item == 'centralaccount':
                Account = event['widgetContext']['forms']['all'].get('Account')
                #Tenant = event['widgetContext']['forms']['all'].get('Tenant')
                print(__name__, 'attempting to update centralaccount',Account, Tenant,event.get('Region'))
                results = update_core_centralaccount(table, Account, event.get('Region'), Tenant)
                print(__name__, 'results:',results)
                if results != 200:
                    error = 'Did not provide valid parameters. The account number and/or region are not correct for the tenant specified.'

        elif Function == 'CW':
            didupdate= 0
            nextalarmid = 0
            targetAlarmId = event.get('alarmid')
            profiletype = event.get('profiletype','')
            ThisMetricCategory = event.get('metriccategory')
            resourcetype = event.get('resourcetype',hcom.get_cw_resource_type(profiletype))
            print(__name__,' Tenant: {} | Account: {} | Region: {} | profiletype: {} | resourcetype: {}'.format(Tenant, Account, ThisRegion, profiletype, resourcetype))
            if Action == 'Update': # update alarm in DB
                try:
                    metname = event['widgetContext']['forms']['all'].get('metricname').split('-') # remove namespace from form passed metric name
                    print(__name__,'split:{} | {} | {}'.format(metname, metname[0],metname[1]))
                    metname = str(metname[0])
                    nsname = event.get('namespace')
                    print(__name__,'params for udpate: formfield: {} | metname: {} | namespace: {}'.format(event['widgetContext']['forms']['all'].get('metricname'),metname,metname[1]))
                    revision = {"metriccategory": ThisMetricCategory,"datapoints": event['widgetContext']['forms']['all'].get('datapoints'),"evaluationperiods": event['widgetContext']['forms']['all'].get('evalperiod'),"metricname": metname,"namespace": nsname,"operator": event['widgetContext']['forms']['all'].get('operator'),"opsitemcategory": event['widgetContext']['forms']['all'].get('oicategory'),"opsitempriority": event['widgetContext']['forms']['all'].get('oiseverity'),"period": event['widgetContext']['forms']['all'].get('thisperiod'),"threshold": event['widgetContext']['forms']['all'].get('threshold'),"TreatMissingData": event['widgetContext']['forms']['all'].get('missingdata')}
                    #revision['namespace'] = metname[1]
                    if event['widgetContext']['forms']['all'].get('alarmpath'):
                        revision['option'] = event['widgetContext']['forms']['all'].get('alarmpath')
                        revision['optionname'] = event.get('optionname')
                    if metname in ['procstat_lookup_pid_count', 'procstat_lookup pid_count'] and event['widgetContext']['forms']['all'].get('processname','') != '': # if monitoring process, set process name
                        revision['name'] = event['widgetContext']['forms']['all'].get('processname')
                    if event['widgetContext']['forms']['all'].get('responsetype'): # if response, then set response type and name
                        revision['ResponseType'] = event['widgetContext']['forms']['all'].get('responsetype')
                        revision['ResponseName'] = event['widgetContext']['forms']['all'].get('responsename')
                        if revision['ResponseType'] in ['Stop', 'Reboot','Terminate']: # if stop or reboot, set response name
                            revision['ResponseName'] = 'EC2 state change'
                    if event['widgetContext']['forms']['all'].get('responsesettings'):
                        revision['ResponseSetting'] = event['widgetContext']['forms']['all'].get('responsesettings')
                    print('update value:{}'.format(revision))
                    response = table.update_item(Key={'msptype': resourcetype, 'mspname': event.get('profile')},
                    UpdateExpression='SET #alm.#row = :revisedrow',
                    ExpressionAttributeNames={'#alm': 'alarms',"#row": str(event.get('alarmid')) },
                    ExpressionAttributeValues={':revisedrow': revision})
                    #print(__name__,'results:{}'.format(response))
                    #return response
                    didupdate = 1
                    targetAlarmId = '0'
                    page += 'Update to alarm was successful.'
                except ClientError as error:
                    print(__name__, 'Could not update alarm. {}'.format(error))
                    response = 'error'
                    #hcom.update_cwagent_configuration(table,Account, ThisRegion, event.get('profile'),profiletype)
            elif Action == 'Delete': # delete alarm row
                try:
                    #revision = {"datapoints": event['widgetContext']['forms']['all'].get('datapoints'),"evaluationperiods": event['widgetContext']['forms']['all'].get('evalperiod'),"metricname": event['widgetContext']['forms']['all'].get('metricname'),"operator": event['widgetContext']['forms']['all'].get('operator'),"opsitemcategory": event['widgetContext']['forms']['all'].get('oicategory'),"opsitempriority": event['widgetContext']['forms']['all'].get('oiseverity'),"period": event['widgetContext']['forms']['all'].get('thisperiod'),"threshold": event['widgetContext']['forms']['all'].get('threshold'),"TreatMissingData": event['widgetContext']['forms']['all'].get('missingdata')}
                    response = table.update_item(Key={'msptype': resourcetype, 'mspname': event.get('profile')},
                    UpdateExpression='REMOVE #alm.#row',
                    ExpressionAttributeNames={'#alm': 'alarms',"#row": str(event.get('alarmid')) })
                    #print(__name__,'results:{}'.format(response))
                    #return response
                    didupdate = 1
                    targetAlarmId = '0'
                    page += 'Alarm id ' + str(event.get('alarmid')) +' was successfully deleted.'
                except ClientError as error:
                    print(__name__, 'Could not update alarm. {}'.format(error))
                    response = 'error'
            elif Action == 'Duplicate': # duplicate alarm row
                try:
                    ### get row to duplicate
                    alarms = table.get_item(Key={'msptype': resourcetype, 'mspname': str(event.get('profile'))})
                    print(__name__,'results:',alarms)
                    revision = alarms['Item']['alarms'][event.get('alarmid')]
                    print(__name__,'target alarm:{}'.format(revision))
                    ### add new row
                    alarmid = int(event.get('nextalarmid')) + 1
                    response = table.update_item(Key={'msptype': resourcetype, 'mspname': event.get('profile')},
                    UpdateExpression='SET #alm.#row = :revisedrow',
                    ExpressionAttributeNames={'#alm': 'alarms',"#row": str(alarmid) },
                    ExpressionAttributeValues={':revisedrow': revision})
                    #print(__name__,'results:{}'.format(response))
                    #return response
                    didupdate = 1
                    targetAlarmId = str(alarmid)
                    
                    page += 'Alarm was successful duplicated as alarm id ' + str(alarmid) +'.'
                except ClientError as error:
                    print(__name__, 'Could not update alarm. {}'.format(error))
                    response = 'error'
            if didupdate == 1 and resourcetype == 'cw-profile':
                    #### update CloudWatch Agent Configuration in Parameter store
                    update_message = {'Function': 'cw_config', 'Action': 'add','Account': Account, 'Region': ThisRegion, 'Profile': event.get('profile'), 'ProfileType': profiletype}
                    hcom.update_central_queque(update_message, hcom.setSQS.get("HCOM-PlatformAutomation"))
            if Action == 'Modify' or didupdate == 1:
                if Item == 'profile' and resourcetype != '':
                    #### show table for selected CloudWatch Profile
                    print(__name__,'widget:',event['widgetContext'])
                    print(__name__,'widget:',event)
                    setmetrics = {}
                    Profile = event.get('profile')
                    resourcetype = event.get('resourcetype')
                    NameSpace = event.get('namespace')
                    ProfileType = profiletype
                    setmetrics = hcom.get_target_metrics(resourcetype,ProfileType,NameSpace,ThisMetricCategory)
                    if setmetrics.get('statusCode') == 400 or setmetrics == {}:
                        return {'statusmessage': 'There was a problem getting metrics.'}
                    print(__name__,'profile: {} | ProfileType: {} | metric list: {}'.format( Profile, ProfileType, setmetrics))
                    page = page+ '<table >'
                    page = page+ '<tr ><th colspan="3" style="text-align:left">CloudWatch Profile ' + Profile + '</th><th colspan="2"> alarm # ' + str(event.get('alarmid')) + '&nbsp;|&nbsp; Profile Type: ' + ProfileType + '</th> <th colspan="11" style="text-align: left;"> <a class="btn2">Return to Profile List</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets" display="widget"> { "widget": "4","mode": "3", "Item": "profile", "Profile": "' + str(Profile) + '", "profiletype":"' + profiletype + '", "resourcetype":"' + resourcetype + '","Tenant": "' + Tenant + '","Account": "' + Account + '","region": "' + ThisRegion + '" } </cwdb-action></th></tr>'
                    page = page + '<tr ><th >Alarm Id </th><th >Options </th> <th >Category - Metric Name | Namespace</th><th >Process Name </th><th >Alarm Options </th><th >Threshold </th><th >Operator </th><th >Data Points </th> <th >Eval Period </th><th >Polling Period </th><th >Treat Missing Data</th><th >OpsItem Category </th><th >OpsItem Severity </th><th >Action Type</th><th >Action Name</th><th >Action Settings</th></tr>\n'
                    if Profile != '':
                        optionname = ''
                        alarms = table.get_item(Key={'msptype': resourcetype, 'mspname': str(Profile)})
                        print(__name__,'results:',alarms)
                        region = alarms['Item']['Region']
                        Tenant = alarms['Item']['Tenant']
                        Account = alarms['Item']['Account']
                        alarmdef1 = alarms['Item']['alarms']
                        alarmdef = dict(sorted(alarmdef1.items()))
                        rows = len(alarmdef)
                        for key, value in alarmdef.items():
                            if int(key) > nextalarmid:
                                nextalarmid = int(key)
                        print(__name__, 'alarm rows: {} | keys: {} | alarms: {}'.format( rows, alarmdef.keys(),alarmdef))
                        for key, value in alarmdef.items(): # loop through alarm definitions
                            #print(__name__,'key', key)
                            #print(__name__,'value', value)
                            ThisId = key
                            #value = ast.literal_eval(value)
                            print(__name__, 'alarm row:', ThisId, value)
                            OI=0 #reset
                            OISeverity = ''
                            OICategory = ''
                            processName = ''
                            #counter = counter + 1
                            #alarmType = varName
                            alarmPath = ''
                            ThisResponseType = ''
                            ThisResponseName = ''
                            ThisResponseSetting = ''
                            processSelected = 'readonly'
                            dataselected = 'readonly'
                            rtypeselected = 'readonly'
                            alarmSelected = 'readonly'
                            missingselected = ''
                            ThisMetric = value.get('metricname')
                            ThisMetricCategory = value.get('metriccategory')
                            ThisOperator = value.get('operator')
                            ThisThreshold = int(value.get('threshold'))
                            ThisEvalPeriod = int(value.get('evaluationperiods'))
                            ThisDataPoints = int(value.get('datapoints'))
                            ThisPeriod = int(value.get('period'))
                            ThisData = value.get('TreatMissingData')
                            if value.get('option'):
                                alarmPath = value.get('option')
                            #elif value.get('type'): # switched to option in db
                            #    alarmPath = value.get('type')
                            if value.get('namespace'):
                                ThisNameSpace = value.get('namespace')
                            if value.get('opsitempriority'):
                                OISeverity = int(value.get('opsitempriority'))
                                OI = 1
                            if value.get('opsitemcategory'):
                                OICategory = (value.get('opsitemcategory'))
                                OI = 1
                            if value.get('name'):
                                processName = value.get('name')
                                OI = 1
                            if value.get('ResponseName',''):
                                ThisResponseName = value.get('ResponseName')
                            if value.get('ResponseSetting',''):
                                ThisResponseSetting = value.get('ResponseSetting','')
                            if value.get('ResponseType',''):
                                ThisResponseType = value.get('ResponseType')
                                if ThisResponseType == 'Stop': ### check for alarm action automations to invoke EC2 state changes
                                    ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + Account +':action/actions/AWS_EC2.InstanceId.Stop/1.0'
                                elif ThisResponseType == 'Reboot':
                                    ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + Account +':action/actions/AWS_EC2.InstanceId.Reboot/1.0'
                                else:
                                    ec2Action = ''
                            else:
                                ec2Action = ''
                            print(__name__,'metric:{} | ThisId: {} | targetAlarmId: {}'.format(ThisMetric,ThisId, targetAlarmId))
                            if ThisId == targetAlarmId: # is this the current alarm being modified?
                                alarmoptions = []
                                setMetOpt = ''
                                ### parse metric name
                                metricname = '<select id="metricname" name="metricname">'
                                for nspace, metrics in setmetrics.items(): # Metric Name
                                    #metrics.sort()
                                    for metric in metrics: # loop through list of metrics for namespace
                                        print(__name__,'metric dropdown: type: {} | metric: {} | metrics: {} | nspace: {}'.format(type(metric),metric,metrics,nspace))
                                        if type(metric) == str:
                                            checkmetric = metric + '-' + nspace
                                            print(__name__,'checkmetric: {} | {}'.format(checkmetric, ThisMetric))
                                            if metric == ThisMetric:
                                                selected = 'selected'
                                            else:
                                                selected = ''
                                            metricname += '<option value="' + checkmetric + '" ' + selected + '>' + metric + ' | ' + nspace + '</option>'
                                        else: # get metric options if exist
                                            if metric.get('metric') == ThisMetric:
                                                optionname = metric.get('optionname')
                                                alarmoptions += metric.get('options')
                                                print(__name__,'alarm options:{}'.format(alarmoptions))
                                                ### parse opsitems
                                                setMetOpt = '<select id="alarmpath" name="alarmpath">'
                                                for opt in alarmoptions: # alarm options
                                                    print(__name__,'option:{}'.format(opt))
                                                    if opt == alarmPath:
                                                        selected = 'selected'
                                                    else:
                                                        selected = ''
                                                    setMetOpt +=  '<option value="' + opt + '" ' + selected + '>' + opt + '</option>'
                                                setMetOpt +=  '</select>'
                                metricname +=  '</select>'
                                ### parse opsitems
                                setOpsCat = '<select id="oicategory" name="oicategory">'
                                for cat in opscat: # OpsItem Category
                                    if cat == OICategory:
                                        selected = 'selected'
                                    else:
                                        selected = ''
                                    setOpsCat = setOpsCat + '<option value="' + cat + '" ' + selected + '>' + cat + '</option>'
                                setOpsCat = setOpsCat + '</select>'
                                setOpsSeverity = '<select id="oiseverity" name="oiseverity">'
                                for cat, value in opsseverity.items():
                                    if cat == OISeverity:
                                        selected = 'selected'
                                    else:
                                        selected = ''
                                    setOpsSeverity = setOpsSeverity + '<option value="' + str(cat) + '" ' + selected + '>' + value + '</option>'
                                setOpsSeverity = setOpsSeverity + '</select>'
                                ### parse alarm action response types
                                setResponseType = '<select id="responsetype" name="responsetype"><option value="">Select</option>'
                                for responsetype in hcom.setAlarmActions:
                                    print(__name__,'*** formatting response type: does: {} = {}'.format(responsetype,ThisResponseType))
                                    if responsetype == ThisResponseType:
                                        print(__name__,'*** we have a match')
                                        rtypeselected = 'selected'
                                    else:
                                        rtypeselected = ''
                                    setResponseType += '<option value="' + responsetype + '" ' + rtypeselected + '>' + responsetype + '</option>'
                                setResponseType += '</select>'
                                ### parse missing data response types
                                setMissingData = '<select id="missingdata" name="missingdata"><option value="">Select</option>'
                                for datatype in hcom.setMissingData:
                                    print(__name__,'does {} = {} | current val:{}'.format(datatype,ThisData,missingselected))
                                    if datatype == ThisData:
                                        missingselected = 'selected'
                                        print(__name__,'this one selected.', missingselected)
                                    else:
                                        missingselected = ''
                                    setMissingData = setMissingData + '<option value="' + datatype + '" ' + missingselected + '>' + datatype + '</option>'
                                setMissingData = setMissingData + '</select>'
                                ### parse operator response types
                                setOperatorData = '<select id="operator" name="operator"><option value="">Select</option>'
                                for datatype1 in hcom.setMetricOperators:
                                    if datatype1 == ThisOperator:
                                        dataselected = 'selected'
                                    else:
                                        dataselected = ''
                                    setOperatorData = setOperatorData + '<option value="' + datatype1 + '" ' + dataselected + '>' + datatype1 + '</option>'
                                setOperatorData = setOperatorData + '</select>'
                                if ThisMetric == 'procstat_lookup_pid_count' or ThisMetric == 'procstat_lookup pid_count':
                                    processSelected = ''
                                if ThisMetric == "Processor % User Time" or ThisMetric == "PhysicalDisk % Disk Time" or ThisMetric == "LogicalDisk % Free Space" or ThisMetric == "cpu_usage_user" or ThisMetric == "swap_used_percent" or ThisMetric == "disk_used_percent" or ThisMetric == "cpu_usage_idle":
                                    alarmSelected = ''

                                page = page + '<form><tr >'
                                page = page + '<td >' + ThisId + '</td>'
                                page = page + '<td >' #<select id="action" name="action"><option value="">Select Option</option><option value="Update" selected>Update</option><option value="Duplicate">Duplicate</option><option value="Delete">Delete</option></select>\n'
                                page += '<a class="btn2">Delete</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-Platform-Configuration-Manager" confirmation="Are you sure you want to delete this alarm? Any existing CloudWatch alarms created from this defined alarm will be orphaned." display="widget"> { "Function": "CW","Action": "Delete", "Item": "profile", "alarmid": "' + str(ThisId) + '","profile": "' + str(Profile) + '", "profiletype": "' + ProfileType + '", "resourcetype": "' + resourcetype + '","namespace": "' + ThisNameSpace + '","Tenant": "' + Tenant + '","Account": "' + Account + '","region": "' + ThisRegion + '" } </cwdb-action>&nbsp;'
                                page += '<a class="btn2">Update</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-Platform-Configuration-Manager" display="widget"> { "Function": "CW","Action": "Update", "Item": "profile", "alarmid": "' + ThisId + '","profile": "' + str(Profile) + '", "profiletype": "' + ProfileType + '", "resourcetype": "' + resourcetype + '","namespace": "' + ThisNameSpace + '","optionname": "' + optionname + '","Tenant": "' + Tenant + '","Account": "' + Account + '","region": "' + ThisRegion + '","metriccategory": "' + str(ThisMetricCategory) + '" } </cwdb-action>&nbsp;'
                                page += '<a class="btn2">Duplicate</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-Platform-Configuration-Manager" display="widget"> { "Function": "CW","Action": "Duplicate", "Item": "profile", "alarmid": "' + str(ThisId) + '","profile": "' + str(Profile) + '", "nextalarmid": "' + str(nextalarmid) + '", "profiletype": "' + ProfileType + '", "resourcetype": "' + resourcetype + '","namespace": "' + ThisNameSpace + '","Tenant": "' + Tenant + '","Account": "' + Account + '","region": "' + ThisRegion + '","metriccategory": "' + str(ThisMetricCategory) + '" } </cwdb-action>  </td>' 
                                
                                page = page + '<td >' + metricname + ' </td>'
                                page = page + '<td ><input type="text" id="processname" name="processname" value="' + str(processName) + '" ' + processSelected + '> </td>'
                                if setMetOpt == '':
                                    page = page + '<td ><input type="text" id="alarmpath" name="alarmpath" value="' + str(alarmPath) + '" ' + alarmSelected + '> </td>'
                                else:
                                    page = page + '<td >' + setMetOpt + ' </td>'
                                page = page + '<td ><input type="text" id="threshold" name="threshold" size="5" maxlength="6" value="' + str(ThisThreshold) + '"> </td>'
                                page = page + '<td >' + setOperatorData + ' </td>'
                                page = page + '<td ><input type="text" id="datapoints" size="4" maxlength="4" name="datapoints" value="' + str(ThisDataPoints) + '"> </td>'
                                page = page + '<td ><input type="text" id="evalperiod" size="4" maxlength="4" name="evalperiod" value="' + str(ThisEvalPeriod) + '"> </td>'
                                page = page + '<td ><input type="text" id="thisperiod" size="5" maxlength="5" name="thisperiod" value="' + str(ThisPeriod) + '"> </td>'
                                page = page + '<td >' + setMissingData + ' </td>'
                                page = page + '<td >' + setOpsCat + ' </td>'
                                page = page + '<td >' + setOpsSeverity + ' </td>'
                                page = page + '<td >' + setResponseType + ' </td>'
                                page = page + '<td ><input type="text" id="responsename" name="responsename" size="15" maxlength="30" value="' + str(ThisResponseName) + '"> </td>'
                                page = page + '<td ><input type="text" id="responsesettings" name="responsesettings" size="15" maxlength="500" value="' + str(ThisResponseSetting) + '"> </td>'
                                #page += '<input type="hidden" id="metriccategory" name="metriccategory" value="' + str(ThisMetricCategory) + '">'
                                page = page + '</form></tr>'
                            
                            
                            else:
                                
                                page = page + '<tr >'
                                page = page + '<td >' + ThisId + '</td><td >'
                                page = page + '<a class="btn2">Delete</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-Platform-Configuration-Manager" confirmation="Are you sure you want to delete this alarm? Any existing CloudWatch alarms created from this defined alarm will be orphaned." display="widget"> { "Function": "CW","Action": "Delete", "Item": "profile", "alarmid": "' + str(ThisId) + '","profile": "' + str(Profile) + '", "profiletype": "' + ProfileType + '", "resourcetype": "' + resourcetype + '","namespace": "' + ThisNameSpace + '","Tenant": "' + Tenant + '","Account": "' + Account + '","region": "' + ThisRegion + '" } </cwdb-action>&nbsp;'
                                page = page + '<a class="btn2">Modify</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-Platform-Configuration-Manager" display="widget"> { "Function": "CW","Action": "Modify", "Item": "profile", "alarmid": "' + str(ThisId) + '","profile": "' + str(Profile) + '", "profiletype": "' + ProfileType + '", "resourcetype": "' + resourcetype + '","namespace": "' + ThisNameSpace + '","Tenant": "' + Tenant + '","Account": "' + Account + '","region": "' + ThisRegion + '","metriccategory": "' + str(ThisMetricCategory) + '" } </cwdb-action>&nbsp;'
                                page = page + '<a class="btn2">Duplicate</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-Platform-Configuration-Manager" display="widget"> { "Function": "CW","Action": "Duplicate", "Item": "profile", "alarmid": "' + str(ThisId) + '","profile": "' + str(Profile) + '", "nextalarmid": "' + str(nextalarmid) + '", "profiletype": "' + ProfileType + '", "resourcetype": "' + resourcetype + '","namespace": "' + ThisNameSpace + '","Tenant": "' + Tenant + '","Account": "' + Account + '","region": "' + ThisRegion + '","metriccategory": "' + str(ThisMetricCategory) + '" } </cwdb-action>  </td>' 
                                page = page + '<td >' + str(ThisMetricCategory) + ' | ' + str(ThisMetric) + ' | ' + ThisNameSpace + ' </td>'
                                page = page + '<td >' + str(processName) + ' </td>'
                                page = page + '<td >' + str(alarmPath) + ' </td>'
                                page = page + '<td >' + str(ThisThreshold) + ' </td>'
                                page = page + '<td >' + str(ThisOperator) + ' </td>'
                                page = page + '<td >' + str(ThisDataPoints) + ' </td>'
                                page = page + '<td >' + str(ThisEvalPeriod) + ' </td>'
                                page = page + '<td >' + str(ThisPeriod) + ' </td>'
                                page = page + '<td >' + str(ThisData) + ' </td>'
                                page = page + '<td >' + OICategory + ' </td>'
                                page = page + '<td >' + opsseverity.get(OISeverity) + ' </td>'
                                page = page + '<td >' + str(ThisResponseType) + '</td>'
                                page = page + '<td >' + str(ThisResponseName) + ' </td> '
                                page = page + '<td >' + str(ThisResponseSetting) + ' </td>  </tr>\n'

                    page = page + '</table>'
                    page = page + 'Adding a new alarm to the profile will not automatically create CloudWatch alarms for instances. You must use the Alarm Creator tool. Alternatively, you can also wait for the next reboot which will automatically recreate all alarms defined in the profile for an instance.'
                    return page
    else: # we don't have valid values to do any processing
        return {
            'statusCode': 400,
            'Message': 'Did not provide valid parameters to MSP. __name__',
        }
    #### Standard response section
    if results == 200:
        message = 'Update completed successfully.'
    else:
        message = 'The attempt to update failed. ' + error
    return {'statusCode': results,'Message': message}

def get_style():
    page = '<span class="cwdb-no-default-styles"></span>' # turn off default style
    ### manage styles
    page += '<style>\n'
    page += 'table {  border-collapse: collapse; margin-left: auto; margin-right: auto; border: 1px solid black;}\n' #style="border: 1px solid black;margin-left:auto;margin-right:auto;
    #page += "table,th,td { border: 1px solid black;}" # style="background-color:' + bgcolor + ';text-align:center"
    page += "thead { background-color: #bccad6;}\n"
    page += "tr { padding: 5px;}\n"
    page += "th { background-color: #bccad6; text-align: center; padding:5px; border: 1px solid LightGray; font-family: Arial, Helvetica, sans-serif; font-size: 12px;}\n"
    page += "td { text-align: center; padding: 5px; border: 1px solid LightGray; font-family: Arial, Helvetica, sans-serif; font-size: 12px;}\n"
    
    page +=".button1 { box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);}"
    page += ".btn-primary:hover { border-radius: 2px; box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);}"
    page += ".btn {background-color: #E07941; /* dark orange */ border-radius: 4px; border: none; color: white; padding: 10px 15px; text-align: center; text-decoration: none; display: inline-block; font-size: 14px; font-weight: bold; font-family: Arial, Helvetica, sans-serif; margin: 4px 2px; cursor: pointer; -webkit-transition-duration: 0.4s; /* Safari */ transition-duration: 0.4s;}"
    page += ".btn:hover { border-radius: 2px; box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);}"
    page += ".btn2 {background-color: #E07941; /* dark orange */ border-radius: 2px; border: none; color: white; padding: 5px 8px; text-align: center; text-decoration: none; display: inline-block; font-size: 8px; font-weight: bold; font-family: Arial, Helvetica, sans-serif; margin: 2px 1px; cursor: pointer; -webkit-transition-duration: 0.4s; /* Safari */ transition-duration: 0.4s;}"
    page += ".btn2:hover { border-radius: 1px; box-shadow: 0 6px 8px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);}"
    page += "p { font-family: Arial, Helvetica, sans-serif;}"

    #page += "tbody tr:nth-child(odd) { background: #ffffff;}"
    #page += "tbody tr:nth-child(even) { background: #f4f4f4;}"
    #page += "a { font-family: Arial, sans-serif; font-size:12px; padding: 8px}\n"
    page += '</style>\n'
    return page

def add_account(table,Function,ItemValue, Accounts,Regions, Environments):
    """Create a new Tenant with AWS accounts, regions, and environments

    Args:
        table (conn): DynamoDB connection 
        Function (String): Specifys which platform component to manage
        ItemValue (String): target name for new Tenant
        Accounts (string): multiple aws account numbers, comma separated
        Regions (String): multiple aws regions, comma separated
        Environments (String): multiple environments, comma separated

    Returns:
        int: result status code
    """    
    envs = {'msptype': 'tenant', 'mspname': ItemValue, 'Accounts': [], 'Environments': [], 'Regions': []}

    ##### set accounts
    setAccounts = Accounts.split(',')
    for account in setAccounts:
        envs['Accounts'].append(account)
    ##### set regions
    setRegions = Regions.split(',')
    for region in setRegions:
        envs['Regions'].append(region)
    #### set environments
    setEnvs = Environments.split(',')
    for environ in setEnvs:
        envs['Environments'].append(environ)

    print(__name__,'--- pre add ---\n', envs)
    results = table.put_item(Item=envs)
    print(__name__,' mod results:', results['ResponseMetadata']['HTTPStatusCode'],results)
    return results['ResponseMetadata']['HTTPStatusCode']

def is_valid_tenant_info(Tenant,Account, Region):
    if Tenant in hcom.setTenants:

        if Account in hcom.setTenantAccounts:
            return 'yes'
        else:
            return 'no'

    else:
        return 'no'

def set_account(table,Function,Tenant, Item,ItemValue, Action):
    """Update Account attributes - Add, Update, Delete attributes

    Args:
        table (conn): DynamoDB table connection
        Function (_type_): Which function to manage - starting with Accounts
        Tenant (_type_): Tenant friendly name
        Item (_type_): Which attribute is being updated
        ItemValue (_type_): What value is the target attribute being updated
        Action (_type_): What is the requested action - Add, Delete

    Returns:
        Int: status code from update action
    """    
    mod = 0
    envs1 = table.get_item(Key={'msptype': 'tenant', 'mspname': Tenant})
    envs = envs1['Item']
    print(__name__,'--- pre mod ---\n', envs)
    if Item == 'environment':
        if Action == 'Delete':
            envs['Environments'].remove(ItemValue)
            mod = 1
        elif Action == 'Add':
            envs['Environments'].append(ItemValue)
            mod = 1
    if Item == 'region':
        if Action == 'Delete':
            envs['Regions'].remove(ItemValue)
            mod = 1
        elif Action == 'Add':
            envs['Regions'].append(ItemValue)
            mod = 1
    if Item == 'account':
        if Action == 'Delete':
            envs['Accounts'].remove(ItemValue)
            mod = 1
        elif Action == 'Add':
            envs['Accounts'].append(ItemValue)
            mod = 1
    if mod == 1:
        print(__name__,'--- post mod ---\n', envs)
        results = table.put_item(Item=envs)
        print(__name__,' mod results:', results['ResponseMetadata']['HTTPStatusCode'],results)
        return results['ResponseMetadata']['HTTPStatusCode']

def get_runbook_template(templatename, path, spaces):
    file = str(hcom.download_file(hcom.setSoftwareBucket, hcom.setBucketReg, path, templatename))
    file = file.replace("{arn}", ThisARN)
    #file = file.replace("{GUID}", ssmGUID)
    content = get_tenants(14)
    content2 = get_accounts(14)
    file = file.replace("{AccountNames}", content2[1])
    file = file.replace("{DefaultAccount}", content2[0])
    file = file.replace("{TenantNames}", content[1])
    file = file.replace("{DefaultTenant}", content[0])
    file = file.replace("{CloudWatch Profile Tag}", hcom.setCWTags.get('profile'))
    foundone = 1 # process template
    return file

def update_core_centralaccount(table, Account, Region, Tenant):
    """Update the core - centralaccount configuration setting item in DynamoDB

    Args:
        table (conn): DynamoDB resource connection to table
        Account (_type_): AWS Account number
        Region (_type_): AwS region
        Tenant (_type_): Tenant friendly name
    """    
    check = is_valid_tenant_info(Tenant,Account, Region)
    print(__name__,' check:',check)
    if check == 'yes':

        updateValues = {'msptype': 'core', 'mspname': 'centralaccount', 'account': '', 'tenant': '', 'region': ''}
        updateValues['account'] = Account 
        updateValues['region'] = Region 
        updateValues['tenant'] = Tenant 
        try:
            results = table.put_item(Item=updateValues)
            print(__name__,' mod results:', results['ResponseMetadata']['HTTPStatusCode'],results)
            results = results['ResponseMetadata']['HTTPStatusCode']
            return 200
        except Exception as error:
            print('Update did not work.', error)
            return 400
    else: # not a valide account or region for tenant
        return 400

