# CloudWatch Custom Metric Processor that updates alarm status in the parameter store
# v.4 Last modified on 7/28/2023. Developed by tom.moore@gdit.com
#from subprocess import getstatusoutput
import ast, boto3, datetime, os, sys
#from re import X
import hcom
from botocore.exceptions import ClientError

          
def lambda_handler(event, context):
    ThisRegion = event.get('region', os.environ['AWS_REGION'])
    ####### Initialize Configuration #######
    hcom.core_initializer(ThisRegion) # Initilaize platform configuration
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    hcom.cw_initializer(hcom.setDBcon, table)

    ####### End Initialize Configuration #######
    ####### End: Get Configuration #################          
    results = 0
    totOK = 0 
    totALARM = 0
    totNoData= 0
    
    instances = {}
    ssm0 = boto3.client('ssm')
    #Mode = int(event.get('mode', '0'))
    #ThisInstanceID = event.get('instance').strip()
    alarmname = event.get('alarmname').strip() # passed by State Change Rule
    instance = event.get('instance') # passed by State Change Rule
    region = event.get('region').strip() # passed by State Change Rule
    current = event.get('current').strip() # passed by State Change Rule
    previous = event.get('previous').strip() # passed by State Change Rule
    metricname = event.get('metricname').strip() # passed by State Change Rule
    namespace = event.get('namespace').strip() # passed by State Change Rule
    print(__name__, 'settings:', alarmname, instance, region, current, previous, metricname, namespace)
    logname = str(hcom.setCWConfigurations.get('CustomMetricLog').replace('XX', metricname))
    logname = logname.replace('YY', namespace)
    today = datetime.datetime.now()
    alarmDetails = alarmname.split('-')
    tenant = str(alarmDetails[0])
    rname = str(alarmDetails[1])
    env = str(alarmDetails[2])
    print(__name__, 'split', alarmDetails)
    instances['Tenant'] = tenant
    instances['Region'] = region
    instances['Hostname'] = str(alarmDetails[3])
    instances['InstanceId'] = instance
    instances['AlarmName'] = alarmname
    appname = get_resource(ssm0, metricname,hcom.setCWConfigurations.get('CustomMetricsConfiguration'))
    instances['Resource'] = appname
    instances['Date'] = today.strftime("%c")
    thistime = today.strftime("%m") + '-' + today.strftime("%d") + '-' + today.strftime("%Y")
    count = 1
    if previous == 'ALARM' and current == 'OK': # remove alarm from log
        print(__name__, 'alarm:', alarmname, 'logfile:', logname)
        results = remove_alarm(ssm0,alarmname,logname)
        results2 = hcom.update_ops_stats(tenant, rname, env, metricname, count, mode=3)

    if current == 'ALARM': # add alarm to log
        print(__name__, 'alarm:', alarmname, 'logfile:', logname, 'tenant:', tenant, 'region:', rname, 'env:', env)
        try:
            ThisLog = get_alarms(ssm0, logname) # get current alarms
        except ClientError as error:
            print(__name__, 'No existing log.', error)
            ThisLog = ''
            pass
        ThisLog = ThisLog + str(instances) +';\n'
        results = add_alarm(ssm0, ThisLog, logname) # add alarm to log parameter
        mode = 2
        results2 = hcom.update_ops_stats(tenant, rname, env, metricname, count, mode)
    print(__name__, 'log results', results)
    print(__name__, 'update ops stats', results2)
    

def remove_alarm(ssm0, alarmname, logname):
    newlog = ''
    response = get_alarms(ssm0, logname) # get current log
    split_config = response.split(';')
    rows = len(split_config) - 1 # skip eof row
    for i in range(rows):
        thisListItem = split_config[i]
        varName = ast.literal_eval(thisListItem)
        print(__name__, 'comparison',varName.get('AlarmName'), alarmname )
        if varName.get('AlarmName') == alarmname:
            continue
            print(__name__, 'alarm matched so skipping to remove it.')
        else:
            newlog = newlog + str(varName) + ';\n'
    if len(newlog) >= 1:
        try:
            results = ssm0.put_parameter(Name=logname,
                Value = str(newlog),
                Type = 'String',
                Overwrite=True,
                Tier='Intelligent-Tiering')
        except Exception as error:
            print(__name__, 'Unexpected error occurred making updates to the log file in parameter store', error)
            pass
    else: # delete log file
        results = ssm0.delete_parameter(Name=logname)
    return results


def add_alarm(ssm0, LogData, logname):
    results = ssm0.put_parameter(Name=logname,
        Value = str(LogData),
        Type = 'String',
        Overwrite=True,
        Tier='Intelligent-Tiering')
    return results

def get_alarms(ssm0, logname):
    response = ssm0.get_parameter(Name=logname)
    results = response['Parameter']['Value']
    return results

def get_resource(ssm0, metricname, metrics):
    response = ssm0.get_parameter(Name=metrics)
    ThisResponse= response['Parameter']['Value']
    split_config = ThisResponse.split(';')
    print(__name__, 'param:',metrics)
    rows = len(split_config) - 1 # skip eof row
    for i in range(rows):
        varName = ast.literal_eval(split_config[i].strip())
        print(__name__, 'varName:',varName)

        print(varName.get('Metric'),varName.get('Resource'),metricname)
        if varName.get('Metric') == metricname:
            return varName.get('Resource')