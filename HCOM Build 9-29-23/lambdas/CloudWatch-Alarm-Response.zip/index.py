#Provides automation in response to CloudWatch Alarms.
### mode = 1 for restarting CloudWatch Agent Process if instance is running
### mode = 2 TBD
### mode = 3 TBD
# v.8 Last modified on 8/26/2023. Developed by tom.moore@gdit.com

import boto3
import sys
import os
import time
import datetime
import hcom
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    ThisMessage = ''
    SendMessage = 0
    print(__name__, 'event: ', event)# for testing. need to see that all vars are getting passed in
    ThisRegion = os.environ.get('AWS_REGION')
    metricname = event['Trigger']['Metrics'][0]['MetricStat']['Metric']['MetricName']
    for i in event['Trigger']['Metrics'][0]['MetricStat']['Metric']['Dimensions']:
        print(__name__,'found tag: {} | value: {}'.format(i['name'],i['value']))
        if i['name'] == 'InstanceId':
            ThisInstanceID = i['value']
        elif i['name'] == 'AlarmId':
            AlarmId = i['value']
    preregion = event.get('AlarmArn').split(':')
    InstanceRegion = preregion[3]
    tenant = event.get('AlarmName').split('-')
    Tenant = tenant[0]
    AccountName = tenant[1]
    AlarmName = event.get('AlarmName')
    Account = event.get('AWSAccountId')



    #InstanceRegion = event.get('region',os.environ.get('AWS_REGION'))
    print(__name__, 'running region: ', ThisRegion, ' Instance region: ', InstanceRegion) # for testing
    
    ####### Initialize Configuration #######
    hcom.core_initializer(ThisRegion) # Initilaize platform configuration
    ####### End Initialize Configuration #######
    #if hcom.setFeatures.get("CloudWatch") == "Yes": # Cloudwatch is on
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    hcom.cw_initializer(hcom.setDBcon, table)
    
    #print(event['account'], event['region'], event['instance'], event['rule'])
    #Account = ''
    ThisMode = int(event.get('mode','1'))
    #ThisInstanceID = event.get('InstanceId').strip()
    #ThisRegion = event['region']
    ThisConfigId = ''
    ThisProfile = ''
    Config = ''
    cwAlarmName = ''
    ssmAlarmName = ''
    AlarmSuppress = ''
    #AlarmName = event['alarmName']
    AlarmAlert = AlarmName.split('-')
    ThisAlarmName = AlarmAlert[0]
    
    ThisRegion1 = hcom.get_region_name(ThisRegion)
    #print(__name__, 'this alarm name:', ThisAlarmName)
    #Account = hcom.name_to_account(ThisAlarmName, hcom.setTenants)
    if Account == '':
        print(__name__, 'A valid AWS Account number was not detected')
        sys.exit()
    BaseARN = hcom.setIAM.get("Cross-Account")
    ThisARN = BaseARN.replace('tenantaccount', Account)
    ThisARN = ThisARN.replace("partition", hcom.setPartition)

    #################### Start: create client connections ##############################
    ## Assume cross account role
    sts_client = boto3.client('sts')
        
    try:
        response = sts_client.assume_role(
            RoleArn = ThisARN,
            RoleSessionName='assume_role_session'
        )
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not assume role', error)
        return error
    
    #Create EC2 client connection in cross account
    try:
        ec3 = boto3.resource('ec2',  region_name=InstanceRegion,
                                  aws_access_key_id=response['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                                  aws_session_token=response['Credentials']['SessionToken']
                                  )
        
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create EC3 cross acount client on trusting account', error)
        return error
    # Create SSM Client connect
    try:
        ssm1 = boto3.client('ssm',  region_name=InstanceRegion,
                                  aws_access_key_id=response['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                                  aws_session_token=response['Credentials']['SessionToken']
                                  )
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create SSM Client connection', error)
        return error
    # Create SNS Client connect
    sns = boto3.client('sns')
    ssm0 = boto3.client('ssm')
    ##### end create SNS client connection ######
    # Create CloudWatch connection
    try:
        cloudwatch = boto3.client('cloudwatch')
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create SSM Client connection', error)
        return error
    #################### End: create client connections ##############################

    ###### Control main logic ######
    #CheckEvent = event['alarmname'].find("amazon-cloudwatch-agent") # only used until I could get the eventbridge event pattern detecting the process name
    if ThisMode == 1: # Amazon Cloud Watch process restart mode, check if instance is running
        print(__name__, 'Mode:', ThisMode, 'instance:', ThisInstanceID, 'account: ', Account, 'region: ', InstanceRegion)
        #Get EC2 attributes 
        ThisSubject = 'Amazon CloudWatch Service Restart Initiated for:' + ThisInstanceID + ' ' + InstanceRegion
        try:
            ec2instance = ec3.Instance(ThisInstanceID)
            instancename = ''
            state = ec2instance.state["Name"]
            try:
                ThisPlatform = ec2instance.platform #  Windows
            except ClientError as error:
                ThisPlatform = 'Linux'
                pass
            #print(__name__, 'state: ', ec2instance.state["Name"])
            for tags in ec2instance.tags:
    
                if tags["Key"] == hcom.setCWTags.get("profile"):
                    ThisProfile = tags["Value"]
                #elif tags["Key"] == 'CSP_CW_Config': # old feature not in final solution
                #    Config = tags["Value"]
                elif tags["Key"] == hcom.setCWTags.get("suppress"):
                    AlarmSuppress = tags["Value"]
        except ClientError as error:
            print(__name__, 'Unexpected error occurred while review EC2 atributes', error)
            return error

        #if Config != '':
        #    ThisConfigId = Config
        #else:
        ThisConfigId = ThisProfile
        ThisConfig = hcom.setCWConfigurations.get("CWAgent") # 'CWAgent-Profile-' + ThisConfigId
        #ThisConfig = hcom.setIAM.get("Cross-Account") # used to assume role in cross accounts
        ThisConfig = ThisConfig.replace("XX", ThisConfigId)
        RunDocument = 'AmazonCloudWatch-ManageAgent'
        RunDocumentParam = 'optionalConfigurationLocation'
        if state == 'running':
            try:
                installresponse = hcom.install_cw_agent(ssm1, ThisInstanceID, ThisPlatform) ## Install CloudWatch Agent
                if installresponse == 'Success':
                        print(__name__, 'install Success')
                        ThisMessage = ThisMessage + 'CloudWatch Agent was successfully installed.\n'
                        ####### Push CloudWatch Agent configuration file and start agent
                        pushconfigstatus = hcom.execute_run_document(ssm1, ThisInstanceID, ThisConfig, RunDocument, RunDocumentParam)
                        if pushconfigstatus == 'Failed':
                            print(__name__, 'Push Config file failed.')
                            ThisMessage = ThisMessage + 'Attempt to Push Config file failed. Check that the target Profile is in the target AWS Account SSM Parameter Store.\n'
                        else:
                            print(__name__, 'Push Config file succeeded')
                            ThisMessage = ThisMessage + 'Attempt to Push Config file (' + ThisConfig + ') succeeded.\n'
                else:
                    print(__name__, 'install Failed')
                    ThisMessage = ThisMessage + 'Attempt to install CloudWatch Agent failed. Check that SSM agent is running and reporting as a "Managed Instance" and that it can access the installer download endpoint.\n'

                ThisMessage = ThisMessage + '-----------------------------\n'    
                print(__name__, 'Alarm Name:', AlarmName, ' Account:', Account, ' Pushed Config file to', ThisInstanceID, ' Profile: ', ThisConfig)
                ThisMessage = ThisMessage + 'Alarm Name ' + AlarmName + '\n Account: ' + Account + '\n'
                SendMessage = 1
            except ClientError as error:
                print(__name__, 'pushing CW Agent config file ran into an error', error)
                return error
        else:
            print(__name__, 'The Instance is not running so aborting restart for alarm:', AlarmName)
            hcom.disable_alarms(cloudwatch, AlarmName)
            ssmAlarmName = AlarmName.replace("cloudwatch", "ssm")
            hcom.disable_alarms(cloudwatch, ssmAlarmName)
            ThisMessage = ThisMessage + 'The Instance is not running so aborting restart for alarm:' + AlarmName +'\n'
            SendMessage = 1
        ################################# end Mode 1 section ###############################
    

        ########### End Report ######################
    else:
        print(__name__, 'Event data passed by AWS EventBridge that was triggerd by a CW Alarm status change did not match a defined MSP automation.')
        print(__name__, 'alarmname', event['alarmname'], ' instance: ', event['instance'], 'mode', event['mode'])
        #ThisMessage = ThisMessage + 'Alarm: ' + AlarmName + ' triggered but event data passed by AWS EventBridge did not match a defined MSP automation.\n'
        #ThisSubject = 'Alarm triggered for Instance ' + ThisInstanceID + ' but nothing matched to execute.'
    #print(__name__, 'did the pattern match?', event['alarmname'].find("amazon-cloudwatch-agent"))
    ########### Send Report ####################
    
    setting = 'Topics'
    if Tenant != '' and Account != '':
        getHelpDeskARN = hcom.get_tenant_account_setting(Tenant,Account,setting,'HelpDesk')
        setSNSGeneral = hcom.get_tenant_account_setting(Tenant,Account,setting,'General')
        setSNSHelpDesk = hcom.convert_arn(getHelpDeskARN,ThisRegion,hcom.setCentralAccount,hcom.setPartition,Tenant,AccountName)
        setSNSGeneral = hcom.convert_arn(setSNSGeneral,ThisRegion,hcom.setCentralAccount,hcom.setPartition,Tenant,AccountName)
        setCentralSNS = hcom.convert_arn(hcom.setCentralSNS,ThisRegion,hcom.setCentralAccount,hcom.setPartition,Tenant,AccountName)

    ThisMessage = ThisMessage + '\n This message was sent by the HCOM-CloudWatch-Alarm-Response (Lambda) automation and sent at: ' + str(datetime.datetime.now()) + '\n'
    try:
         
        hcom.send_sns_message(sns, setCentralSNS, ThisSubject, ThisMessage)
        hcom.send_sns_message(sns, setSNSHelpDesk, ThisSubject, ThisMessage)
        hcom.send_sns_message(sns, setSNSGeneral, ThisSubject, ThisMessage)
    except ClientError as error:
        print(__name__, 'SNS Send error.', error)
        return error
        
    ########### End Report ######################
    """
    ## Begin Webhook
    if hcom.setWebhooks.get('Active') == True: ### Central Platform setting
    print(__name__,'--- sending platform webhook ---')   
    targetmessage = ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion + ' triggered alarm response to restart the CloudWatch Agent.'
    try:
        sender = hcom.setPlatformName # set sender name
        #### PlatformOps Channel
        targetchannel = hcom.setWebhooks.get('PlatformOps') 
        targeturl = hcom.setWebhooks.get('PlatformOps-channel') 
        hcom.send_webhook(targetchannel, targeturl, targetmessage, sender)
    except Exception as error:
        print(__name__, 'error trying to send platform webook. {} | {} | {}'.format(targeturl,targetchannel,error))
        pass
    """