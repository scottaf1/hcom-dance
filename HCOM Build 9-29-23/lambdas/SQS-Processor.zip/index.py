# Automation is invoked as new SQS items are added to process the item and then remove it from the queue. HCOM-SQS-Processor (deployed as index.py)
# Logic: 
# v.16 Last modified on 9/6/2023. Developed by tom.moore@gdit.com

import boto3
import ast, datetime, json, os, sys, time, uuid
import hcom
from botocore.exceptions import ClientError

def lambda_handler (event, context):
    ThisSSMRegion = event.get('region', os.environ['AWS_REGION'])
    Mode = event.get('mode',1)
    myUUID = uuid.uuid4()
    print(__name__,'--- mode: {} | uid: {}'.format(Mode,str(myUUID)))
    #debug = # uncomment to tricker errors when testing dlqs
    ####### Initialize Configuration #######
    hcom.core_initializer(ThisSSMRegion) # Initilaize platform configuration
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    hcom.cw_initializer(hcom.setDBcon,table)
    numkeys = 0
    """
    if hcom.setFeatures.get("CloudWatch") == "Yes": # Cloudwatch is on
        print(__name__, 'load CW config:', hcom.setConfigurations.get("CloudWatch")) # read cloudwatch configuration
        hcom.initializer(hcom.setDBcon)
    else:
        print(__name__, 'CloudWatch is not enabled. Contact the MSP PlatformOps Team.')
        sys.ext()
    """
    if Mode == 1: # update counts, dynamically create CW Agent Configuration
        print(__name__, ' executing region: {} | raw record: {}'.format(os.environ['AWS_REGION'], event))
        ssm0 = boto3.client('ssm')
        for record in event['Records']:
            #print(__name__, "check")
            payload = record["body"]
            print(__name__,'-- payload: {} | {}'.format(type(payload),str(payload)))
                                    
            if type(payload) == str:
                payload = payload.replace("'", '"')
                ThisMessage = ast.literal_eval(payload) # convert to dictionary
                print(__name__,'type after 1st conversion: {}'.format(type(ThisMessage)))
            else:
                ThisMessage = payload
            if type(ThisMessage) == dict and ThisMessage.get('event','') != '': # check if event is in payload, if so load it as dictionary
                if type(ThisMessage['event']) == str:
                    ThisMessage = ast.literal_eval(ThisMessage['event']) # convert to dictionary
                    print(__name__,'type after event conversion: {}'.format(type(ThisMessage)))
                else:
                    ThisMessage = ThisMessage['event']
            if ThisMessage.get('UID') != '' or ThisMessage.get('UID') != None:
                myUUID = ThisMessage.get('UID')
            print(__name__,' is message dict yet? {} | {}'.format(type(ThisMessage), ThisMessage))
            if type(ThisMessage) == str: # if still not dictionary, likely due to 2 sets of outer quotes
                print(__name__,' still not dictionary {} | {}'.format(type(ThisMessage), ThisMessage))
                ThisMessage = ast.literal_eval(ThisMessage) # convert next layer to dictionary
                print(__name__,' is message dict yet? {} | {}'.format(type(ThisMessage), ThisMessage))
            #print(__name__, 'body:', ThisMessage)
            if type(ThisMessage) == dict:
                keys = ThisMessage.keys()
                numkeys = len(keys)
                print(__name__,'num keys: {} | keys: {}'.format(numkeys, keys))
            else:
                return {'stateCode': 400, 'message': 'There is an issue with the values. Please check the queue.'}
            if ThisMessage.get('Function',''):
                function = ThisMessage.get('Function')
            elif ThisMessage.get('Message',''):
                if ThisMessage.get('Message').find('AlarmName') > -1:
                    function = 'alarm_response'
            else:
                function = ''
            print(__name__,'--- Function = {} '.format(function))
            ##### detect automation type
            
            if function == 'cw_lifecycle':
                lname = 'HCOM-Lifecycle-Automation'
                itype = 'Event'
                ppload = ''
                if ThisMessage.get('resource') in ['ec2','onprem']:
                    ### update EC2/onprem alarms
                    ppload = "{'event': {'Function': 'cw_lifecycle','invoke': '" + lname + "','resource':'"+ThisMessage.get('resource')+"','account':'"+ThisMessage.get('account')+"','region':'"+ThisMessage.get('region')+"','instance':'" +ThisMessage.get('instance') + "','skipconfig':"+str(ThisMessage.get('skipconfig'))+",'reboot':'"+ThisMessage.get('reboot')+"','mode':" + str(ThisMessage.get('mode')) +",'UID':'" + str(myUUID) + "'}}"
                    print(__name__,'check payload: {}'.format(str(ppload)))
                    payload = json.dumps(ppload)
                    response2 = hcom.invoke_lambda(lname,itype, payload, hcom.setCentralRegion)
                    print(__name__,': invoked lifecycle lambda to manage cw alarms.', ThisMessage.get('region'), payload, itype,lname)
                elif ThisMessage.get('resource') == 'dynamodb' or ThisMessage.get('resource') == 'dynamodb-tag':
                    ### update dynamodb alarms
                    if ThisMessage.get('resource') == 'dynamodb-tag' and ThisMessage.get('tablearn2') != '':
                        table = ThisMessage.get('tablearn2').split('/')
                        if len(table) > 1:
                            tablename = table[1]
                        ppload = "{'event': {'invoke': '" + lname + "','Function': '" +function +"','account':'"+ThisMessage.get('account')+"','source':'"+ThisMessage.get('source')+"','region':'"+ThisMessage.get('region')+"','event':'"+ThisMessage.get('event')+"','tablename':'" +tablename + "','tablearn2':'"+str(ThisMessage.get('tablearn2'))+"','environment':'"+ThisMessage.get('environment')+"','profile':'"+ThisMessage.get('profile')+"','mode':" + str(ThisMessage.get('mode')) +"}}"
                    elif ThisMessage.get('tablename') != None:
                        print(__name__,'tablename is: {}'.format(ThisMessage.get('tablename')))
                        ppload = "{'event': {'invoke': '" + lname + "','Function': '" +function +"','account':'"+ThisMessage.get('account')+"','source':'"+ThisMessage.get('source')+"','region':'"+ThisMessage.get('region')+"','event':'"+ThisMessage.get('event')+"','tablename':'" +ThisMessage.get('tablename') + "','tablearn':'"+str(ThisMessage.get('tablearn'))+"','tablearn2':'"+ThisMessage.get('tablearn2')+"','mode':" + str(ThisMessage.get('mode')) +"}}"
                    print(__name__,'check payload: {}'.format(str(ppload)))
                    if ppload != '':
                        payload = json.dumps(ppload)
                        response2 = hcom.invoke_lambda(lname,itype, payload, hcom.setCentralRegion)
                        print(__name__,': invoked lifecycle lambda to manage cw alarms.', ThisMessage.get('region'), payload, itype,lname)
                elif ThisMessage.get('resource') == 'rds':
                    ### update rds alarms
                    ppload = "{'event': {'invoke': '" + lname + "','account':'"+ThisMessage.get('account')+"','source':'"+ThisMessage.get('source')+"','region':'"+ThisMessage.get('region')+"','event':'"+ThisMessage.get('event')+"','instancename':'" +ThisMessage.get('instancename') + "','instancearn':"+str(ThisMessage.get('instancearn'))+",'environment':'"+ThisMessage.get('environment')+"','profile':'"+ThisMessage.get('profile')+"','mode':" + str(ThisMessage.get('mode')) +"}}"
                    print(__name__,'check payload: {}'.format(str(ppload)))
                    payload = json.dumps(ppload)
                    response2 = hcom.invoke_lambda(lname,itype, payload, hcom.setCentralRegion)
                    print(__name__,': invoked lifecycle lambda to manage cw alarms.', ThisMessage.get('region'), payload, itype,lname)
                elif ThisMessage.get('resource') == 'rds-tag':
                    ### update rds alarms
                    ppload = "{'event': {'invoke': '" + lname + "','Function': '" +function +"','account':'"+ThisMessage.get('account')+"','source':'"+ThisMessage.get('source')+"','region':'"+ThisMessage.get('region')+"','service':'"+ThisMessage.get('service')+"','changed':" +str(ThisMessage.get('changed')) + ",'instancearn':"+str(ThisMessage.get('instancearn'))+",'environment':'"+ThisMessage.get('environment')+"','profile':'"+ThisMessage.get('profile')+"','mode':" + str(ThisMessage.get('mode')) +"}}"
                    print(__name__,'check payload: {}'.format(str(ppload)))
                    payload = json.dumps(ppload)
                    response2 = hcom.invoke_lambda(lname,itype, payload, hcom.setCentralRegion)
                    print(__name__,': invoked lifecycle lambda to manage cw alarms.', ThisMessage.get('region'), payload, itype,lname)
            elif function == 'ec2_audit':
                lname = 'HCOM-EC2-Detail-Report'
                itype = 'Event'
                ppload = {'invoke': lname,'Function': function,'tenants': ThisMessage.get('tenant'), 'account': ThisMessage.get('account'), 'report': ThisMessage.get('report')}
                #payload = message
                payload = json.dumps(ppload)
                response = hcom.invoke_lambda(lname,itype, payload, hcom.setCentralRegion)

                print(__name__, 'invoked Lambda: {}'.format(lname))
            elif function == 'cwalarm_audit':
                lname = 'HCOM-CloudWatch-Alarm-Audit'
                itype = 'Event'
                ppload = "{'invoke': '" + lname + "','Function': '" +function +"','mode': " + str(ThisMessage.get('mode')) + ", 'resetcount': '" + str(ThisMessage.get('resetcount')) + "', 'tenant':'" +ThisMessage.get('tenant') + "','report': '" + ThisMessage.get('report') + "'}"
                payload = json.dumps(ppload)
                response = hcom.invoke_lambda(lname,itype, payload, hcom.setCentralRegion)
                print(__name__,': invoked alarm audit to update Ops Stats for alarms.',payload, itype,lname)
            elif function == 'backup_audit':
                lname = 'HCOM-AWS-Backup-Audit'
                itype = 'Event'
                ppload = "{''invoke': '" + lname + "','Function': '" +function +"',mode': " + str(ThisMessage.get('mode')) + ", 'tenant':'" +ThisMessage.get('tenant') + "','report': '" + ThisMessage.get('report') + "'}"
                payload = json.dumps(ppload)
                response = hcom.invoke_lambda(lname,itype, payload, hcom.setCentralRegion)
                print(__name__,': invoked alarm audit to update Ops Stats for alarms.',payload, itype,lname)
            elif numkeys > 4 and numkeys < 8:
                if ThisMessage.get('Function') == 'cw_state': # update state change counters
                    print(__name__,'invoking state change: {}'.format(ThisMessage))
                    process_instance_statechange(ThisMessage)
                elif ThisMessage.get('Function') == 'cw_config': # update CloudWatch Agent Configuration
                    print(__name__,'invoking cw config change: {}'.format(ThisMessage))
                    process_cw_configs(ThisMessage)
                else:
                    return {'statusCode': 400, 'statusmessage': 'Nothing to do. Message did not match any defined functions.'}
                    sys.exit()
            elif function == 'alarm_response':
                print(__name__,'--- process alarm response:')
                ThisMessage['Message'] = ThisMessage['Message'].replace('true', '0')
                ThisMessage['Message'] = ThisMessage.get('Message').replace('false', '0')
                #ThisMessage.get('Message').replace('\\', '') 
                
                print(__name__,'processed message: {}'.format(ThisMessage.get('Message')))
                alarmMessage = ast.literal_eval(ThisMessage.get('Message'))

                print(__name__,'last processed alarmMessage: {}'.format(alarmMessage))
                process_alarm_response(alarmMessage)
            else:
                return {'statusCode': 400, 'message': 'something is missing'}
  
    elif Mode == 2: # reload from dead letter queue back to standard queue
        DLQ="HCOM-SQSDeadLetterQueue.fifo"
        ORIGINALQ="HCOM-StateChange.fifo"
        sqs = boto3.resource('sqs')
        DLqueue = sqs.get_queue_by_name(QueueName=DLQ)
        PrimaryQueue = sqs.get_queue_by_name(QueueName=ORIGINALQ)
        no_of_messages = DLqueue.attributes['ApproximateNumberOfMessages']
        while int(no_of_messages) > 0 :
            print ("Number of messages in DLQ: " + no_of_messages)
            for message in DLqueue.receive_messages(MaxNumberOfMessages=10):
                print("\n")
                print(__name__,'--- message: {}'.format(message.body))
                try:
                    response = PrimaryQueue.send_message(
                        QueueUrl=PrimaryQueue.url,
                        MessageBody=message.body,
                        MessageGroupId='retry')
                    print(__name__,'response code: {} | {}'.format(response['ResponseMetadata']['HTTPStatusCode'], response))
                    if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                        print("Message sent to primary queue, deleting from DLQ")
                        message.delete()
                except Exception as e:
                    print(e)
                    print("Failed to send message to primary queue")
                    exit(1)
            no_of_messages = DLqueue.attributes['ApproximateNumberOfMessages']


# process instance state change Counter
def process_instance_statechange(ThisMessage):
    """Process instance state change and impact on alarms. Updates counts in dashboard.

    Args:
        ThisMessage (Dict): message from quque
    """    
    item = ThisMessage.get("item")
    itemValue = ThisMessage.get("itemValue")
    if ThisMessage.get('Info',''):
        info = ThisMessage.get('Info')
    else:
        info = ''
    ThisRegion = ThisMessage.get("ThisRegion")
    Account = ThisMessage.get("Account")
    ThisInstanceId = ThisMessage.get("instance")
    if ThisInstanceId.find('mi-') > -1: # is onprem instance?
        onprem = 1 # yes onprem instance
    else:
        onprem = 0 # no this is EC2 instance
    #if item == 'running' or item == 'stopped':
    BaseARN = hcom.setIAM.get("Cross-Account")
    ThisARN = BaseARN.replace('tenantaccount', Account)
    
    #ThisEnv = hcom.get_this_ec2_environment(AccountName, AccountNum,  ThisARN, ThisInstanceId, ThisRegion,onprem)
    #ec2Status = hcom.get_ec2_environment_status(AccountNum, ThisARN, hcom.setTags.get("environment"), ThisEnv, ThisRegion)
    #paramname = hcom.setConfigurations.get("OpsDashboard").replace('XX', AccountName)
    #paramname = paramname.replace('YY', ThisEnv)
    #paramname = paramname.replace('region', RegionName)
    #print(__name__, 'queue data:', AccountName, AccountNum, ThisInstanceId, ThisARN, item, itemValue, paramname)
    config = hcom.setCWConfigurations.get("Lifecycle") + '-' + ThisRegion
    hcom.update_counts(hcom.setDBcon, item, itemValue, config, hcom.setCentralRegion,info)

### Alarm Response Runner automation
def process_alarm_response(message):
    """The Alarm Response Runner is the initial function that reads the Alarm Response SNS topic message from the SQS queue.
    It parses the message and then makes a call to the function that gets the actual alarm response details.

    Args:
        message (dict): SNS CloudWatch alarm triggered message sent to SQS

    Returns:
        dict: status code and message
    """    
    print(__name__,'type: {} | value: {}'.format(type(message),message))

    #account = message['AWSAccountId']
    a = len(message['Trigger']['Metrics'])
    a = a - 1 # figure out how many items in Metrics list, AccountId is last
    account = message['Trigger']['Metrics'][a]['AccountId'] 
    alarmName = message['AlarmName']
    tenant = alarmName.split('-')
    tenant = tenant[0]
    print(__name__,'trigger sections: {}'.format(len(message['Trigger'])))
    AlarmId = ''
    if len(message['Trigger']) == 13: # short format
        print(__name__,'fomrat is short format')
        metricname = message['Trigger']['MetricName']
        for i in message['Trigger']['Dimensions']:
            print(__name__,'found tag: {} | value: {}'.format(i['name'],i['value']))
            if i['name'] == 'InstanceId':
                InstanceId = i['value']
        preregion = message.get('AlarmArn').split(':')
        region = preregion[3]
    elif len(message['Trigger']) == 8: # long format
        print(__name__,'fomrat is long format')
        metricname = message['Trigger']['Metrics'][0]['MetricStat']['Metric']['MetricName']
        for i in message['Trigger']['Metrics'][0]['MetricStat']['Metric']['Dimensions']:
            print(__name__,'found tag: {} | value: {}'.format(i['name'],i['value']))
            if i['name'] == 'InstanceId':
                InstanceId = i['value']
            elif i['name'] == 'AlarmId':
                AlarmId = i['value']
        preregion = message.get('AlarmArn').split(':')
        region = preregion[3]
        tenant = message.get('AlarmName').split('-')
        tenant = tenant[0]
    
    print('account: {} | region: {} | instance: {} | alarm id: {} | alarmname: {} | metricname: {} | tenant: {}'.format(account,region,InstanceId, AlarmId, alarmName, metricname,tenant))
    
    cloudwatchprofile = hcom.get_ec2_tag(hcom.setCWTags['profile'],tenant,account,region,InstanceId)
    if cloudwatchprofile != '': # make sure we have a profile value
        print(__name__,'found cloudwatch profile: {} | {}'.format(InstanceId,str(cloudwatchprofile)))

        #### invoke automation
        ### set parameters for SSM connection
        role = hcom.setIAM.get("Cross-Account")
        ConfigAlarm = hcom.setCWConfigurations.get("Alarms").replace("XX", str(cloudwatchprofile))
        AWSRunDocConfig = hcom.setConfigurations.get("AWSRunDocs")
        ThisSSMConnect = hcom.get_ssm_connection(hcom.setCentralAccount, hcom.setCentralRegion, role)

        alarmResponseDetails = get_alarmResponse(AlarmId, InstanceId, cloudwatchprofile,  message, account, region,tenant)
        print(__name__, 'alarm Details:', alarmResponseDetails) ## for testing
        """
        if alarmResponseDetails is not None:
            if alarmResponseDetails["ResponseType"] == 'Lambda':
                lname = alarmResponseDetails["ResponseName"]
                itype = 'Event'
                ppload = ThisPayload
                payload = json.dumps(ppload)
                response = hcom.invoke_lambda(lname,itype, payload, ThisRegion)

                print(__name__, 'invoked Lambda: ',alarmResponseDetails["ResponseName"])
            elif alarmResponseDetails["ResponseType"] == 'SSM-Runbook':
                runbook = alarmResponseDetails["ResponseName"]
                runbookrole = alarmResponseDetails["ResponseExecutionRole"]
                ppload = ThisPayload
                payload = json.dumps(ppload)
                response = hcom.invoke_runbook(runbook, runbookrole, ThisPayload)
                print(__name__, 'invoked SSM Automation Runbook: ', alarmResponseDetails["ResponseName"])
            elif alarmResponseDetails["ResponseType"] == 'SSM-RunDoc':
                print(__name__, 'invoked SSM Run Document: ', alarmResponseDetails["ResponseName"], ' parameters:', alarmResponseDetails["ResponseParameters"])
                role = alarmResponseDetails["ResponseExecutionRole"]
                runbook = alarmResponseDetails["ResponseName"]
                parameters = alarmResponseDetails["ResponseParameters"]
                response = hcom.invoke_rundoc(InstanceId, runbook, parameters, ThisRegion)
                    
            else:
                print(__name__, 'No Alarm Response Type defined.')
        """
        #return {'statusCode': 200, 'statusmessage': 'finsihed processing'}
        return {'statusCode': 200, 'statusmessage': 'finsihed processing'}
    else:
        return {'statusCode': 400, 'statusmessage': 'No CW profile found so can not invoke automation.'}
def get_alarmResponse(AlarmId, InstanceId, ThisProfile,message, ThisAccount,ThisRegion,Tenant):
    """Query CloudWatch profile to get the defined alarm action response

    Args:
        table connection: connection to dynamodb
        ThisProfile integer: CloudWatch Profile number
        ThisMetric string: CloudWach Metric Name
        ThisMetricInstance string: which metric of this type has the alarm action
        ConfigAlarm string: name of parameter with CloudWatch Profile configuration
        AWSRunDocConfig string: name or parameter holding SSM Run Doc configurations
    Returns:
        Dict: return alarm action details
    """
    alarmResponseDetails = {} # set return variable to dictionary
    ResponseExecutionRole = '' # set execution role to null in case its not a Run Document
    ResponseParameter = '' # set parameters to null in case there are no parameters
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    ThisMessage = ''
    ##### Start: Get Alarm Definition from Parameter Store ########################################
    #print(__name__, 'getting param:', ConfigAlarm)
    try:
        #alarms = ThisSSMConnect.get_parameter(Name=ConfigAlarm)
        alarms = table.get_item(Key={'msptype': 'cw-profile', 'mspname': str(ThisProfile)})
        counter = 0
        alarmdef1 = alarms['Item']['alarms']
        alarmdef = dict(sorted(alarmdef1.items()))
        rows = len(alarmdef)
        print(__name__, 'rows: {} | profile: {}'.format(rows, alarmdef))
        for key, i in alarmdef.items(): # loop through alarm definitions
            if key != AlarmId: # if this not a match, skip to next
                continue
            curAlarm = i
            OI=0 #reset
            OISeverity = ''
            OICategory = ''
            counter = counter + 1
            #alarmType = varName
            alarmPath = ''
            ThisProcess = ''
            typename = ''
            ThisProcessName = ''
            ThisAlarmName2 = ''
            ThisResponseType = ''
            ThisOptionName = ''
            ThisResponseconfig = {}
            ThisMetric = curAlarm.get('metricname')
            ThisOperator = curAlarm.get('operator')
            ThisThreshold = int(curAlarm.get('threshold'))
            ThisEvalPeriod = int(curAlarm.get('evaluationperiods'))
            ThisDataPoints = int(curAlarm.get('datapoints'))
            ThisPeriod = int(curAlarm.get('period'))
            ThisData = curAlarm.get('TreatMissingData')
            if curAlarm.get('optionname'):
                ThisOptionName = curAlarm.get('optionname')
            if curAlarm.get('opsitempriority'):
                OISeverity = int(curAlarm.get('opsitempriority'))
                OI = 1
            if curAlarm.get('opsitemcategory'):
                OICategory = (curAlarm.get('opsitemcategory'))
                OI = 1
            if curAlarm.get('type'):
                alarmPath = curAlarm.get('type')
            if curAlarm.get('name'):
                processName = curAlarm.get('name')
                OI = 1
                tempconfig = str(ThisProfile) + ':' + processName
                ThisResponseconfig['Name'] = 'AlarmResponse'
                ThisResponseconfig['Value'] = str(tempconfig) # text for alarm response dimension
            if curAlarm.get('name'): # process name
                processName = curAlarm.get('name')
                #match = match + 1  
            if curAlarm.get('ResponseType'):
                ThisResponseType = curAlarm.get('ResponseType')
                if ThisResponseType == 'Stop': ### check for alarm action automations to invoke EC2 state changes
                    ec2Action = 'arn:'+ hcom.setPartition + ':swf:' + ThisRegion + ':' + ThisAccount +':action/actions/AWS_EC2.InstanceId.Stop/1.0'
                elif ThisResponseType == 'Reboot':
                    ec2Action = 'arn:'+ hcom.setPartition + ':swf:' + ThisRegion + ':' + ThisAccount +':action/actions/AWS_EC2.InstanceId.Reboot/1.0'
                elif ThisResponseType == 'Lambda':
                    ResponseName = curAlarm.get('ResponseName')
                    lname = ResponseName
                    itype = 'Event'
                    ppload = message
                    #payload = message
                    payload = json.dumps(ppload)
                    response = hcom.invoke_lambda(lname,itype, payload, ThisRegion)

                    print(__name__, 'invoked Lambda: ')
                elif ThisResponseType == 'SSM-Rundoc':
                    ResponseName = curAlarm.get('ResponseName')
                    #if curAlarm.get('ResponseExecutionRole'): # if SSM Run Document or Automation Runbook, check for ResponseExecutionRole
                    #    ResponseExecutionRole = curAlarm.get('ResponseExecutionRole')
                    if curAlarm.get('ResponseSetting'): # if SSM Run Document or Automation Runbook, check for ResponseExecutionRole
                        parameters = ast.literal_eval(curAlarm.get('ResponseSetting'))
                    #print(__name__, 'invoked SSM Run Document: ', alarmResponseDetails["ResponseName"], ' parameters:', alarmResponseDetails["ResponseParameters"])
                    #role = ResponseExecutionRole
                    runbook = ResponseName
                    #parameters = alarmResponseDetails["ResponseParameters"]
                    print(__name__,'show values passing to Rundoc: {} | {} | {} | {}'.format(InstanceId,ThisRegion, runbook, parameters))
                    response = hcom.invoke_rundoc(InstanceId, runbook, parameters, ThisRegion,ThisAccount)
                elif ThisResponseType == 'State Profile':
                    ResponseName = curAlarm.get('ResponseName')
                    #### initialize and load settings
                    #print(__name__,': load state config:', hcom.setStateMgmt) # read cloudwatch configuration
                    hcom.state_initializer()
                    #print(__name__,'state vars: {} | {}'.format(setStateTags, setStateConfigurations))
                    #### begin execution
                    #StateConfig = hcom.setConfigurations.get("Profiles")
                    ThisMessage += '\n\n---- Defined Configuration State settings are listed below ----\n'
                    print(__name__,'show values passing to run_state: {} | {} | {} | {}'.format(InstanceId,ThisRegion, ThisAccount, Tenant))
                    
                    try:
                        ThisConfig = hcom.run_state(InstanceId, ThisRegion, ThisAccount, Tenant)
                        
                        #if ThisConfig.get('STIG'):
                        #    ThisMessage = ThisMessage + 'STIG settings applied, level:' + str(ThisConfig.get('STIG')) + '\n'
                        if ThisConfig.get('State'):
                            ThisMessage +=  'State settings applied: ' + str(ThisConfig.get('State')) + '\n'
                    except ClientError as error:
                        print(__name__,': Error updating SSM Agent', error)
                elif ThisResponseType == 'SSM-Runbook':
                    ResponseName = curAlarm.get('ResponseName')
                    if curAlarm.get('ResponseExecutionRole'): # if SSM Run Document or Automation Runbook, check for ResponseExecutionRole
                        ResponseExecutionRole = curAlarm.get('ResponseExecutionRole')
            if curAlarm.get('onprem'): # is this an on-premise alarm
                onprem = curAlarm.get('onprem')
            else:
                onprem = 'no'
            """
            if match == 3: # we have a response type and name to evaluate
                print(__name__, 'metric instance:', ThisMetricInstance, ' process name:',processName, ' ResponseType:',ThisResponseType, 'ResponseName:', ResponseName)
                if ThisMetric == 'procstat_lookup_pid_count' or ThisMetric == 'procstat_lookup pid_count': # metric is process
                    if processName == ThisMetricInstance: # we have the right instance
                        alarmResponseDetails["ResponseType"] = ThisResponseType # add alarm response type from alarm profile
                        alarmResponseDetails["ResponseName"] = ResponseName # add alarm response name from alarm profile
                        alarmResponseDetails["ResponseExecutionRole"] = ResponseExecutionRole # add execution role for SSM Run Doc
                        #if ResponseParameter !='':
                        #    alarmResponseDetails["ResponseParameters"] = ResponseParameter # add parameters for SSM Run Doc

                        #return alarmResponseDetails # return to main code execution
                    else:
                        continue # process the next row in alarm definition
                else: # check Threshold
                    if ThisThreshold == threshold: # we have the right instance
                        alarmResponseDetails["ResponseType"] = ResponseType # add alarm response type from alarm profile
                        alarmResponseDetails["ResponseName"] = ResponseName # add alarm response name from alarm profile
                        alarmResponseDetails["ResponseExecutionRole"] = ResponseExecutionRole # add execution role for SSM Run Doc
                        alarmResponseDetails["ResponseParameters"] = ResponseParameters # add parameters for SSM Run Doc
                        #return alarmResponseDetails # return to main code execution
                if ThisResponseType == 'SSM-RunDoc':
                    params = get_rundoc_parameters(ThisSSMConnect, AWSRunDocConfig,ResponseName)
                    alarmResponseDetails["ResponseParameters"] = params
                    return alarmResponseDetails # return to main code execution
                else:
                    return alarmResponseDetails # return to main code execution
            else: # no matches, return empty var
                continue
            """
        ## Begin Webhook for Alarm Response
        ### Send Webhook ###
        print(__name__,'----- begin webhook section -----')
        setting = 'Features'
        setWebhooks = hcom.get_tenant_account_setting(Tenant,ThisAccount,setting,'Webhooks')
        if setWebhooks == True:  ### tenant/account specific setting
            print(__name__,'--- sending tenant webhook ---')   
            try:
                sender = hcom.setPlatformName # set sender name
                #### Tenant Channel
                setting = 'Webhook'
                attribute = 'channel-name'
                targetchannel = hcom.get_account_setting(ThisAccount,setting,attribute)
                attribute = 'channel-url'
                targeturl = hcom.get_account_setting(ThisAccount,setting,attribute)
                print(__name__,'pre send check: {} | {}'.format(targeturl,targetchannel))
                hcom.send_webhook(targetchannel, targeturl, targetmessage, sender)
            except Exception as error:
                print(__name__, 'error trying to send tenant webook. {} | '.format(error))
                pass
        ### Send to Central Webhook
        if hcom.setWebhooks.get('Active') == True: ### Central Platform setting
            print(__name__,'--- sending platform webhook ---')   
            targetmessage = ' Instance: ' + InstanceId + ' in ' + Tenant + ' ' + ThisAccount + ' ' + ThisRegion + ' triggered the following alarm response ' + ThisResponseType + ' ' + ResponseName + '.'
            try:
                sender = hcom.setPlatformName # set sender name
                #### PlatformOps Channel
                targetchannel = hcom.setWebhooks.get('PlatformOps') 
                targeturl = hcom.setWebhooks.get('PlatformOps-channel') 
                hcom.send_webhook(targetchannel, targeturl, targetmessage, sender)
            except Exception as error:
                print(__name__, 'error trying to send platform webook. {} | {} | {}'.format(targeturl,targetchannel,error))
            pass
        ## begin count response
        item = 'responses'
        itemValue = 1
        msg_body = str({ "Function": 'cw_state', "Account": ThisAccount, "item": item, "itemValue": itemValue, "instance": InstanceId, "ThisRegion": ThisRegion, "Info": targetmessage})
        hcom.update_central_queque(msg_body,hcom.setSQS.get("HCOM-PlatformAutomation")) 
    except ClientError as error:
        print(__name__, 'Error getting and processing alarm response. {}'.format(error))
        return error
    

def get_rundoc_parameters(ThisSSMConnect, AWSRunDocConfig, ssmdoc):
    """Get SSM Run Doc parameters from parameter store and pass back

    Args:
        ThisSSMConnect Connection: _description_
        AWSRunDocConfig (_type_): parameter store name for SSM Run Doc configuration
        ssmdoc String: name for specific SSM run doc to be invoked

    Returns:
        Dict: return specific Run Doc parameters
    """     
    try:
        ssmrundocs = ThisSSMConnect.get_parameter(Name=AWSRunDocConfig)
        #value = alarms['Parameter']['Value']
        ThisRunDoc = ssmrundocs['Parameter']['Value']
        #print(__name__, 'raw parameter', ThisAlarms) # used for testing
        #split_value =  ThisRunDoc.split(';')
        print(__name__, 'ThisRunDoc:', ThisRunDoc)
        ssmdoc_param = ast.literal_eval(ThisRunDoc)
        if ssmdoc in ssmdoc_param:
            params = ssmdoc_param.get(ssmdoc)
            print(__name__, "params:", params)
        #if ssmdoc == 'AWS-InstallWindowsUpdates':
        #    params = {'Action': ['Install'], 'AllowReboot': ['True']}
        else:
            params ={}
            print(__name__, 'Could not find ' + ssmdoc + ' SSM Run Doc configuration in Parameter Store. Make sure you have added the Run Doc parameters to the ' + AWSRunDocConfig + ' in parameters store.')
        return params
    except ClientError as error:
        print(__name__, 'Could not read SSM Run Doc configuration from Parameter Store. Make sure you have added the Run Doc parameters to the configuration in parameters store.', error)
        return error
    
## process cw configurations
def process_cw_configs(ThisMessage):
    """Process CloudWatch Agent configuration updates: add or delete from target account/region from automation queue

    Args:
        ThisMessage (dict): parameters
    """    
    etype = 'cw-event'
    ename = 'cwagent'
    etarget = 'StateChange'
    eventFormat = hcom.get_hcom_event(etype,ename,etarget)
    processevent = 0
    print(__name__,'event type is: {} | {}'.format(type(eventFormat),eventFormat))
    ######
    print(__name__,'len(ThisMessage): {}'.format(str(len(ThisMessage))))
    if ThisMessage.get('Action') == 'delete':
        print(__name__,' delete config:{}'.format(ThisMessage.get('Profile')))
        try:
            hcom.delete_cwagent_configuration(ThisMessage) #.get('Account'), ThisMessage.get('Region'), ThisMessage.get('Profile'))
            eventFormat['Detail']['state'] = 'deleted'
            processevent = 1
        except Exception as e:
            if str(e).find('ParameterNotFound') > -1:
                print(__name__,'profile {} already deleted'.format(ThisMessage.get('Profile')))
                pass
            else:
                print(__name__,'some other issues cause delete to fail: {}'.format(str(e)))
    elif len(ThisMessage) == 6:
        print(__name__,' add config:{} | region: {} | account: {} | profiletype: {}'.format(ThisMessage.get('Profile'),ThisMessage.get('Region'),ThisMessage.get('Account'),ThisMessage.get('ProfileType')))
        #hcom.update_cwagent_configuration(ThisMessage.get('Account'), ThisMessage.get('Region'), ThisMessage.get('Profile'),ThisMessage.get('ProfileType'))
        try:
            hcom.update_cwagent_configuration(ThisMessage)
            eventFormat['Detail']['state'] = 'created'
            processevent = 1
        except Exception as e:
            print(__name__,'There was a problem with creating CW Profile {}'.format(ThisMessage.get('Profile')))
    if processevent == 1:
        #### log event in EventBridge
        eventFormat['Detail']['profile-id'] = ThisMessage.get('Profile')
        eventFormat['Detail']['account'] = ThisMessage.get('Account')
        eventFormat['Detail']['region'] = ThisMessage.get('Region')
        eventFormat['Detail']['profiletype'] = ThisMessage.get('ProfileType')
        eventresponse = hcom.put_hcom_event(eventFormat['Source'],json.dumps(eventFormat['Detail']),eventFormat['DetailType'])
    return