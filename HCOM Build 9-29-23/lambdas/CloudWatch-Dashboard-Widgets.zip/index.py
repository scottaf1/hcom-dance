"""
Copyright 2023 General Dynamics Information Technology (GDIT). or its affiliates. All Rights Reserved.
Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
including the rights to use, copy, modify, merge, and to permit persons to whom the
Software is furnished to do so. GDIT does not grant permission 
to license, sublicense or resell this software, modified or unmodified.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
# CloudWatch Custom Widget that updates key ops metrics read from parameter store
# v.57 Last modified on 1/18/2024. Developed by tom.moore@gdit.com
# Mode = 0 (all), Mode = 1 (single, parameter)
#from subprocess import getstatusoutput

import ast, os
import boto3
import sys
import hcom
import markdown
import json
import random
from botocore.exceptions import ClientError
#from functools import lru_cache
from boto3.dynamodb.conditions import Key, Attr

          
def lambda_handler(event, context):
    """This function produces all the CloudWatch custom Widgets

    Args:
        event (_type_): _description_
        context (_type_): _description_

    Returns:
        String: HTMl or Markdown for displaying in the widget
    """ 
    #### check for request for describe parameter
    if 'describe' in event:
        DOCS = """
        Pass 3 possible parameters as listed below.
        -----------------------------------
        widget = 0 for Default Ops Widget
        -----------------------------------
        widget = 1 for Application Monitoring with custom metrics
        -----------------------------------
        widget = 2 for CloudWatch Lifecycle Status
        tenant = tenantname (will filter by tenant)
        -----------------------------------
        widget = 3 for Tenant Specific consolidated ops
        tenant = tenantname (will filter by tenant)
        -----------------------------------
        widget = 4 for Configuration Management
        one of the following:
        mode = 1 for Patch Profiles
        mode = 2 for State Profiles
        """
        #DOCS = markdown('''## Message here ''')
        return DOCS   
    ThisRegion = event.get('region', os.environ['AWS_REGION'])
    ####### Initialize Configuration #######
    hcom.core_initializer(ThisRegion) # Initilaize platform configuration
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    hcom.cw_initializer(hcom.setDBcon,table)
    
    ####### End Initialize Configuration #######
    ####### End: Get Configuration ################# 
    #environs = hcom.setTenantsEnv         
    
    Widget = int(event.get('widget', '0'))
    Mode = int(event.get('mode', '0'))
    Function = event.get('Function', '')
    Action = event.get('action', '')
    Item = event.get('Item', '')
    targetApplication = event.get('application', '') 
    targetMetricName = event.get('metricname', '')
    targetNameSpace = event.get('metricnamespace', 'Custom')
    targetTenant = event.get('tenant', '')
    targetMetrics = {}
    ssm0 = boto3.client('ssm')
    dbcon = boto3.client('dynamodb')
    
    ThisPartition = hcom.setPartition
    page = get_style()
    arn = hcom.setIAM.get('Cross-Account')
    ### manage styles
    
    print(__name__,'full event: {}'.format(event)) # used for debugging
    print(__name__, 'Widget:{} Mode:{}, Action:{}'.format(Widget,Mode,Action) )
    if Widget == 0: # default ops dashboard widget
        return {'statusCode': 500, 'message': 'Invalid parameters passed.', 'event': event}
    elif Widget == 1: # Application monitoring with custom metrics
        results = 0
        tot = 0
        count = 0
        #states = ["OK", "ALARM", "INSUFFICIENT_DATA"]
        ##### Begin Widget table
        page += '<table >'
        #page = page + '<caption> The following Instances have Custom Metrics in ALARM state.</caption>'
        #page = page + '<tr style="border: 1px solid black; background-color: black")><th colspan="3"></th><th colspan="3" style="text-align:center">Alarm State</th>  </tr>\n'
        page = page + '<tr style="border: 1px solid black"><th>Resource </th><th>Tenant </th><th>Region</th> <th> Hostname</th> <th style="text-align:center">Instance Id</th> <th style="text-align:center">When </th><th style="text-align:center">Alarm Name </th> </tr>\n'


        ####### Begin Main logic ########
        if Mode == 0: # get from config and do all
            print(__name__, 'loading Custom Metric Config: ',hcom.setCWConfigurations.get('CustomMetricsConfiguration'))
            response = ssm0.get_parameter(Name=hcom.setCWConfigurations.get('CustomMetricsConfiguration'))
            ThisResponse= response['Parameter']['Value']
            split_config = ThisResponse.split(';')
            rows = len(split_config) - 1 # skip eof row
            for i in range(rows):
                metric = ast.literal_eval(split_config[i])
                try:
                    response = get_alarm_logs(ssm0, metric.get('Metric'), metric.get('NameSpace'))
                    if response.get('count') != 0:
                        page = page + response.get('page')
                        tot = tot + response.get('count')
                    else: # no log for metric
                        continue
                except ClientError as error:
                    print(__name__, 'No existing log.', error)
                    pass
        elif Mode == 1 and targetApplication != '' and targetMetricName != '' and targetNameSpace != '': # params were passed
            response = get_alarm_logs(ssm0, targetMetricName, targetNameSpace)
            page = page + response.get('page')
            tot = tot + response.get('count')
        page = page + '<tr><th>TOTALS Resources</th><th>' + str(tot) + '</th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th></tr>'
        page = page + '</table>'
        return page
    elif Widget == 2: # CloudWatch Lifecycle status
        ### begin CW lifecycle table
        #bgcolor: String = '#bccad6'
        page += '<p> This Widget displays Instance lifecycle events and their impact on CloudWatch Alarms. State changes may take a few minutes to update stats. Stats are reset automatically at 8 am daily.</p> '
        page = page + '<br><table >'
        #page = page + '<caption> Shows total EC2 state changes detected and impact on CloudWatch Alarms since 8 am EST (Counters reset everyday at 8 am)</caption>'
        page = page + '<tr ><th>&nbsp;</th><th colspan="3" > EC2/OnPrem State Changes</th> <th colspan="5"  >CloudWatch Alarms </th>  </tr>\n'
        page = page + '<tr ><th >Region</><th >Start/Reboots </th><th >Stopped </th> <th >Terminated </th> <th >Suppressed</th><th >Created </th> <th >Deleted</th><th >Responses</th><th >Action</th> </tr>\n'
        leaderboard = '23px'
        for region in hcom.setReportRegions:
            region = region['S']
            print(__name__, 'region:', region)
            rname = hcom.get_region_name(region)
            results = 0
            config = hcom.setCWConfigurations.get('Lifecycle') + '-' + region
            try:
                dailyCount1 = table.get_item(Key={'msptype': 'cw', 'mspname': config})
                dailyCount = dailyCount1['Item']
                print(__name__,'results:', type(dailyCount), dailyCount)
                #dailyCount = ssm0.get_parameter(Name=hcom.setCWConfigurations.get('Lifecycle'))
                results = 1
            except Exception as error:
                
                print(__name__, 'no lifecycle file was found',hcom.setCWConfigurations.get('Lifecycle'), ThisRegion )
                pass

            if results ==1:
                page = page + '<tr><td>' + hcom.get_region_name(region) + '</td><td >' + str(dailyCount['reboot']) + '</td><td >' + str(dailyCount['stopped']) + '</td><td >' + str(dailyCount['terminatedd']) + '</td><td >' + str(dailyCount['suppressed']) + '</td><td >' + str(dailyCount['created']) + '</td><td >' + str(dailyCount['deleted']) + '</td>'
                if str(dailyCount['responseslist']) !=  [] and str(dailyCount['responseslist']) != None and int(dailyCount['responses']) > 0:
                    page = page + '<td style="text-align:center"><a class="btn2">' + str(dailyCount['responses']) + '</a><cwdb-action display="popup" event="click"><table><tr><th>Alarm Responses</th></tr>'
                    for t in dailyCount['responseslist']:
                        #j = t.split('|')
                        page = page + '<tr><td>' + t + '</td></tr>'
                    page = page + '</table></cwdb-action></td>'
                    page += '<td><a class="btn2">Reset Counters</a><cwdb-action action="call" confirmation="Are you sure" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Alarm-Audit" display="widget"> { "mode": "3", "resetcount": "yes", "tenant": "VDMS", "region": "' + region + '" } </cwdb-action></td></tr>'
                else:
                    page += '<td >' + str(dailyCount['responses']) + '</td><td><a class="btn2">Reset Counters</a><cwdb-action action="call" confirmation="Are you sure" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Alarm-Audit" display="widget"> { "mode": "3", "resetcount": "yes", "tenant": "VDMS", "region": "' + region + '" } </cwdb-action></td></tr>'
            else:
                page = page + '<tr><td>' + hcom.get_region_name(region) + '</td><td >' + str(results) + '</td><td >' + str(results) + '</td><td >' + str(results) + '</td><td >' + str(results) + '</td><td >' + str(results) + '</td><td >' + str(results) + '</td><td >' + str(results) + '</td><td > No Stats Yet</td></tr>'
        page = page + '<tr><td colspan="9" ><b>NOTE:</b> Reboots initiated from within the OS do not trigger an AWS API call and thus are not detected and counted.</td></tr>'
        page = page + '</table>'
        return page
    elif Widget == 3: # Tenant specific consolidated dashboard
        results = 0
        totRunning = 0 
        totStopped = 0
        totOnPremRunning = 0 
        totOnPremStopped = 0
        totOnPremInactive = 0
        totAlarm = 0
        totData = 0
        totInv = 0
        totEC2 = 0
        totEFS = 0
        totOnPrem = 0
        totrds = 0
        totddb = 0
        header = ''
        ##### begin account select form
        if event['widgetContext']['forms']['all'].get('Account'):
            Account = event['widgetContext']['forms']['all'].get('Account')
            print(__name__, 'Account assigned from form', Account)
        elif event.get('Account'):
            Account = event.get('Account','')
            print(__name__, 'Account assigned from event', Account)
        else:
            Account = ''
            print(__name__, 'Account assigned by default', Account)
        if event['widgetContext']['forms']['all'].get('Tenant'):
            Tenant = event['widgetContext']['forms']['all'].get('Tenant')
            print(__name__, 'Tenant assigned from form', Tenant)
            #targetTenant = event['widgetContext']['forms']['all'].get('tenant')
        elif event.get('Tenant'):
            Tenant = event.get('Tenant')
            print(__name__, 'Tenant assigned from event', Tenant)
        theseAccounts = hcom.get_tenant_accounts(Tenant,True) # only get active accounts
        AccountName = hcom.get_tenant_account_attribute(Tenant,Account,'acctname')
        print(__name__,'these accounts:', theseAccounts, Account)
        environs = hcom.get_tenant_account_attribute(Tenant,Account,'Environments')

        if Account == ''  or Account == 'Select' or len(theseAccounts) == 1 or Account not in theseAccounts:
            if theseAccounts != []:
                Account = theseAccounts[0]
                AccountName = hcom.get_tenant_account_attribute(Tenant,Account,'acctname')
                print(__name__, 'Account reassigned from first account number', Account)
        page = page + '<table ><tr><th>Tenants:</th>'
        page = page + '<td><form><select id="Tenant" name="Tenant">'
        page = page + '<option value="Select">Select</option>'
        for tenant in hcom.setTenants:
            if Tenant == tenant:
                selected = 'selected'
            else:
                selected = ''
            page = page + '<option value="' + tenant + '" ' + selected + '>' + tenant + '</option>'
        page = page + '</select></form></td>'
        page = page + '<td><a class="btn btn-primary">Select Tenant</a>'
        page = page + '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 3, "mode": 0 }</cwdb-action></td>'
        ### begin account number section
        page = page + '<td></form>'
        if theseAccounts != []:
            page += '<select id="Account" name="Account">'
            page = page + '<option value="Select">Select</option>'
            for acctnum in theseAccounts:
                activestatus = hcom.get_tenant_account_attribute(Tenant,acctnum,'Active')
                if Account != '' and activestatus == True:
                    acctname = hcom.get_tenant_account_attribute(Tenant,acctnum,'acctname')
                    if Account == acctnum:
                        selected = 'selected'
                    else:
                        selected = ''
                    page = page + '<option value="' + acctnum + '" ' + selected + '>' + acctnum + ' | ' + acctname +'</option>'
            page = page + '</td></form><td><a class="btn btn-primary">Select Managed Account / Refresh</a>'
            page = page + '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 3, "mode": 0, "Tenant": "' + Tenant + '" }</cwdb-action></td>'
        else: # this tenant has no active accounts
            page += '<td colspan="2"> No Active Accounts</td>'
        page += '</tr></table>'
        print(__name__,page)
        #CustomMetricsResults = ''
        if Tenant != '' and Mode == 0 and Account != 'all' and theseAccounts != []: ## add support for tenants having multiple accounts
            ##### Begin ops table
            CustomMetricsResults = get_custom_metrics(Tenant,Account)
            print(__name__, 'customemetric results:', CustomMetricsResults)

            #cmr = 1 # CustomMetricsResults.split(';')
            #cmrnum = len(cmr)-1
                
            #print ('num of metric:', cmrnum, cmr)
            #if cmrnum > 0:
            #    for i in range(cmrnum):
            tm = CustomMetricsResults
            bgcolor: String = '#bccad6'
            if 'Resource' in tm:
                header = header + '<th >' + tm.get('Resource') + '</th>'
            else: # no custom memtrics
                header = header + '<th >None in use </th>'
                tm = {}
                tm['Resource'] = ''
                tm['Metric'] = 'None'
            setting = 'Features'
            attribute = 'OnPrem'
            print(__name__,'pre onprem check:{}'.format(Account))
            isOnPrem = hcom.get_account_setting(Account,setting,attribute)
            page = page + '<table >'
            #page = page + '<caption> Information updates shortly after 8am EST daily</caption>'
            page = page + '<tr style="border: 1px solid black; background-color: #bccad6")><th colspan="3" >' + Account + ' / ' + AccountName + '</th>'
            if isOnPrem == True: # add columns for onprem servers
                page = page + '<th colspan="2" >EC Instances </th> <th colspan="3" >OnPrem VMs</th><th colspan="2" >VM Alarm State</th> <th ># of VMs to</th> <th colspan="5" >Backup Audit: Unprotected Resources</th></tr>\n' #<th colspan="1" >Custom Metrics in ALARM state </th></tr>\n'
                page = page + '<tr style="border: 1px solid black; background-color: #bccad6"><th >Tenant </th> <th >Environment </th><th > Region </th> <th >Running </th> <th >Stopped </th><th >Online </th> <th >ConnectionLost </th><th ">Inactive </th> <th >ALARM </th> <th >IN_SUFFICIENT</th><th >Investigate </th> <th >EC2</th> <th >EFS</th><th >OnPrem</th><th >DDB</th><th >A/RDS</th></tr>\n' #' + header + '</tr>\n'
            else: # don't show onprem server columns
                page = page + '<th colspan="2" >Virtual Machines </th> <th colspan="2" >VM Alarm State</th> <th ># of EC2s to</th> <th colspan="4" >Unprotected Resources</th></tr>\n' #<th colspan="1" >Custom Metrics in ALARM state </th></tr>\n'
                page = page + '<tr  style="border: 1px solid black; background-color: #bccad6"><th >Tenant </th> <th >Environment </th><th > Region </th> <th >Running </th> <th >Stopped </th> <th >ALARM </th> <th >IN_SUFFICIENT</th><th >Investigate </th> <th >EC2</th> <th >EFS</th><th >DDB</th><th >A/RDS</th></tr>\n' #' + header + '</tr>\n'
            print(__name__, ' setRegion:',type(hcom.setReportRegions),hcom.setReportRegions)
            environments = environs
            tenantRegions = hcom.get_tenant_account_attribute(Tenant,Account,'Regions')
            for region in tenantRegions: # Loop through each region
                print(__name__, ' region:', region, ' env list:', environments)
                rname = hcom.get_region_name(region)
                #environments = environ.get(tenant)
                try:
                    #environments = hcom.get_environs(environs, targetTenant)
                    #print(__name__, 'environment:', len(environments), environments, targetTenant)
                    environments = hcom.get_tenant_account_attribute(Tenant,Account,'Environments')
                    if environments !='': # make sure we have environments to loop through
                        for env in environments: # loop through each environment
                            try:
                                ThisConfig = hcom.get_consolidated_widget_stats(Tenant, Account, rname, env)
                                print(__name__, 'consolidated widget: {} | {} | {} | {} | {}'.format(Tenant,Account,rname,env,ThisConfig))
                                header = ''
                                #for i in range(cmrnum):
                                #    tm = ast.literal_eval(cmr[i])
                                
                                header = header + '<td style="text-align:center">' + str(tm.get('Metric')) + '</td>'
                                print(__name__,'OnPrem:',isOnPrem )
                                if isOnPrem == True: # add columns for onprem servers
                                    print(__name__,'--- processing running {}'.format(ThisConfig.get('running details','0')))
                                    page = page + '<tr><td>' + Tenant + '</td><td>' + env + '</td><td>' + rname + '</td>'
                                    if ThisConfig.get('running details') != [] and ThisConfig.get('running details') != None:
                                        #autodlqhtml = '<a class="btn2">' + autodlqnum + '</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 8, "mode": 2, "source": "' + autodlqarn + '", "destination": "' + autoarn + '", "region": "' + region + '" }</cwdb-action>'
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('running','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >Running Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>' 
                                        for t in ThisConfig.get('running details'):
                                            j = t.split('|')
                                            page = page + '<tr><td>' + j[0] + '</td><td>' + j[1] + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('running','0')) +  '</td>'
                                    #### stopped
                                    print(__name__,'--- processing stopped {}'.format(ThisConfig.get('stopped details','0')))
                                    if ThisConfig.get('stopped details') !=  [] and ThisConfig.get('stopped details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('stopped','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >Stopped Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                        for t in ThisConfig.get('stopped details'):
                                            j = t.split('|')
                                            page = page + '<tr><td>' + j[0] + '</td><td>' + j[1] + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('stopped','0')) +  '</td>'
                                    
                                    #### Online
                                    print(__name__,'--- processing Online {}'.format(ThisConfig.get('Online details')))
                                    #page = page + '<td style="text-align:center"><a>' + str(ThisConfig.get('Online','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >Online Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                    if ThisConfig.get('Online details') !=  [] and ThisConfig.get('Online details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('Online','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >Stopped Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                        for t in ThisConfig.get('Online details'):
                                            j = t.split('|')
                                            page = page + '<tr><td>' + j[0] + '</td><td>' + j[1] + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('Online','0')) +  '</td>'
                                    #### ConnectionLost
                                    #page = page + '<td style="text-align:center"><a>' + str(ThisConfig.get('ConnectionLost','0')) + '</a><cwdb-action display="popup" event="click">' + str(ThisConfig.get('ConnectionLost details')) + '</cwdb-action></td>' 
                                    print(__name__,'--- processing ConnectionLost {}'.format(ThisConfig.get('ConnectionLost details','0')))
                                    #page = page + '<td style="text-align:center"><a>' + str(ThisConfig.get('ConnectionLost','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >ConnectionLost Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                    if ThisConfig.get('ConnectionLost details') !=  [] and ThisConfig.get('ConnectionLost details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('ConnectionLost','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >Stopped Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                        for t in ThisConfig.get('ConnectionLost details'):
                                            j = t.split('|')
                                            page = page + '<tr><td>' + j[0] + '</td><td>' + j[1] + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('ConnectionLost','0')) +  '</td>'

                                    #### Inactive
                                    #page = page + '<td style="text-align:center"><a>' + str(ThisConfig.get('Inactive','0')) + '</a><cwdb-action display="popup" event="click">' + str(ThisConfig.get('Inactive details')) + '</cwdb-action></td>'
                                    print(__name__,'--- processing Inactive {}'.format(ThisConfig.get('Inactive details','0')))
                                    #page = page + '<td style="text-align:center"><a>' + str(ThisConfig.get('Inactive','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >"Inactive Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                    if ThisConfig.get('Inactive details') !=  [] and ThisConfig.get('Inactive details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('Inactive','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >Stopped Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                        for t in ThisConfig.get('Inactive details'):
                                            j = t.split('|')
                                            page = page + '<tr><td>' + j[0] + '</td><td>' + j[1] + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('Inactive','0')) +  '</td>'
                                    
                                    #### In Alarm
                                    print(__name__,'--- processing In Alarm {}'.format(ThisConfig.get('In Alarm details',[])))
                                    #page = page + '<td style="text-align:center"><a>' + str(ThisConfig.get('In Alarm','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >"In Alarm" Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                    if ThisConfig.get('In Alarm details') !=  [] and ThisConfig.get('In Alarm details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('In Alarm','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >Alarms</th></tr>'
                                        for t in ThisConfig.get('In Alarm details'):
                                            page = page + '<tr><td>' + t + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('In Alarm','0')) +  '</td>'
                                    
                                    #### Insufficient Data
                                    print(__name__,'--- processing Unsufficient Data {}'.format(ThisConfig.get('Insufficient Data details',[])))
                                    #page = page + '<td style="text-align:center"><a>' + str(ThisConfig.get('Insufficient Data')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >"Insufficient Data" Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                    if ThisConfig.get('Insufficient Data details') !=  [] and ThisConfig.get('Insufficient Data details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('Insufficient Data','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >Alarms</th></tr>'
                                        for t in ThisConfig.get('Insufficient Data details'):
                                            page = page + '<tr><td>' + t + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('Insufficient Data','0')) +  '</td>'
                                    
                                    #### Investigate
                                    print(__name__,'--- processing Investigate {}'.format(ThisConfig.get('Investigate details',[])))
                                    #page = page + '<td style="text-align:center"><a>' + str(ThisConfig.get('Investigate')) +  '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >"Investigate Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                    if ThisConfig.get('Investigate details') !=  [] and ThisConfig.get('Investigate details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('Investigate','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >Stopped Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                        for t in ThisConfig.get('Investigate details'):
                                            j = t.split('|')
                                            page = page + '<tr><td>' + j[0] + '</td><td>' + j[1] + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('Investigate')) +  '</td>'
                                    
                                    #### EC2 Unprotected
                                    print(__name__,'--- processing EC2 Unprotected {}'.format(ThisConfig.get('EC2 Unprotected details',[])))
                                    if ThisConfig.get('EC2 Unprotected details') !=  [] and ThisConfig.get('EC2 Unprotected details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">'+ str(ThisConfig.get('EC2 Unprotected','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >"EC2 Unprotected" Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                        for t in ThisConfig.get('EC2 Unprotected details'):
                                            j = t.split('|')
                                            if len(j) > 1:
                                                page = page + '<tr><td>' + j[0] + '</td><td>' + j[1] + '</td></tr>'
                                            else: # no hostname
                                                page = page + '<tr><td>' + j[0] + '</td><td>' + j[0] + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('EC2 Unprotected','0')) +  '</td>'
                                    
                                    #### EFS Unprotected
                                    print(__name__,'--- processing EFS Unprotected {}'.format(ThisConfig.get('EFS Unprotected details',[])))
                                    if ThisConfig.get('EFS Unprotected details') !=  [] and ThisConfig.get('EFS Unprotected details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('EFS Unprotected','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >"EFS Unprotected" Instances</th></tr><tr><th >Instance ID</th><th >Hostname</th></tr>'
                                        for t in ThisConfig.get('EFS Unprotected details'):
                                            j = t.split('|')
                                            page = page + '<tr><td>' + j[0] + '</td><td>' + j[1] + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('EFS Unprotected','0')) +  '</td>'
                                    
                                    #### OnPrem Unprotected
                                    print(__name__,'--- processing OnPrem Unprotected {}'.format(ThisConfig.get('OnPrem Unprotected details',[])))
                                    if ThisConfig.get('OnPrem Unprotected details') !=  [] and ThisConfig.get('OnPrem Unprotected details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('OnPrem Unprotected','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >"OnPrem Unprotected" Instances</th></tr><tr><th >Instance ID</th></tr>'
                                        for t in ThisConfig.get('OnPrem Unprotected details'):
                                            page = page + '<tr><td>' + t + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('OnPrem Unprotected','0')) +  '</td>'
                                    
                                    ### DynamoDB Unprotected
                                    print(__name__,'--- processing DynamoDB Unprotected {}'.format(ThisConfig.get('DynamoDB Unprotected details',[])))
                                    if ThisConfig.get('DynamoDB Unprotected details') !=  [] and ThisConfig.get('DynamoDB Unprotected details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('DynamoDB Unprotected','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >"DynamoDB Unprotected" Instances</th></tr><tr><th >Instance ID</th></tr>'
                                        for t in ThisConfig.get('DynamoDB Unprotected details'):
                                            page = page + '<tr><td>' + t + '</td></tr>'
                                        page = page + '</table></cwdb-action></td>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('DynamoDB Unprotected','0')) +  '</td>'

                                    ### Aurora/RDS Unprotected
                                    print(__name__,'--- processing Aurora/RDS Unprotected {}'.format(ThisConfig.get('RDS Unprotected details',[])))
                                    if ThisConfig.get('RDS Unprotected details') !=  [] and ThisConfig.get('RDS Unprotected details') != None:
                                        page = page + '<td style="text-align:center"><a class="btn2">' + str(ThisConfig.get('RDS Unprotected','0')) + '</a><cwdb-action display="popup" event="click"><table><tr><th colspan=2 >"Aurora/RDS Unprotected" Instances</th></tr><tr><th >Instance ID</th></tr>'
                                        for t in ThisConfig.get('RDS Unprotected details'):
                                            page = page + '<tr><td>' + t + '</td></tr>'
                                        page = page + '</table></cwdb-action></td></tr>'
                                    else:
                                        page = page + '<td style="text-align:center">' + str(ThisConfig.get('RDS Unprotected','0')) +  '</td></tr>'

                                    totOnPremRunning = totOnPremRunning + int(ThisConfig.get('Online'))
                                    totOnPremStopped = totOnPremStopped + int(ThisConfig.get('ConnectionLost'))   
                                    totOnPremInactive = totOnPremInactive + int(ThisConfig.get('Inactive'))
                                                          
                                else:
                                    page = page + '<tr><td>' + Tenant + '</td><td>' + env + '</td><td>' + rname + '</td><td style="text-align:center">' + str(ThisConfig.get('running')) + '</td><td style="text-align:center">' + str(ThisConfig.get('stopped')) + '</td><td style="text-align:center">' + str(ThisConfig.get('In Alarm')) + '</td><td style="text-align:center">' + str(ThisConfig.get('Insufficient Data')) + '</td><td style="text-align:center">' + str(ThisConfig.get('Investigate')) +  '</td><td style="text-align:center">'+ str(ThisConfig.get('EC2 Unprotected','0')) + '</td><td style="text-align:center">' + str(ThisConfig.get('EFS Unprotected','0')) + '</td><td style="text-align:center">' + str(ThisConfig.get('DynamoDB Unprotected','0')) + '</td><td style="text-align:center">' + str(ThisConfig.get('RDS Unprotected','0')) + '</td></tr>' # + header + '</tr>'
                                totRunning = totRunning + int(ThisConfig.get('running'))
                                totStopped = totStopped + int(ThisConfig.get('stopped'))
                                totAlarm = totAlarm + int(ThisConfig.get('In Alarm'))
                                totData = totData + int(ThisConfig.get('Insufficient Data'))
                                totInv = totInv + int(ThisConfig.get('Investigate','0'))
                                totEC2 = totEC2 + int(ThisConfig.get('EC2 Unprotected','0'))
                                totEFS = totEFS + int(ThisConfig.get('EFS Unprotected','0'))
                                totOnPrem = totOnPrem + int(ThisConfig.get('OnPrem Unprotected','0'))
                                totddb +=  int(ThisConfig.get('DynamoDB Unprotected','0'))
                                totrds += int(ThisConfig.get('RDS Unprotected','0'))
                                
                            except Exception as error:
                                print(__name__, 'Unexpected error occurred getting and outputting the consolidated ops stats', error)
                                return error, env
                except ClientError as error:
                    print(__name__, 'Unexpected error occurred getting this tenant\'s environment settings from the configuration in the parameter store.', error)
                    return error
            if isOnPrem == True: # add columns for onprem servers
                page = page + '<tr><th>TOTALS</th><th colspan="2"></th><th style="text-align:center">' + str(totRunning) + '</th><th style="text-align:center">' + str(totStopped) + '</th><th style="text-align:center">' + str(totOnPremRunning) + '</th><th style="text-align:center">' + str(totOnPremStopped) + '</th><th style="text-align:center">' + str(totOnPremInactive) + '</th><th style="text-align:center">' + str(totAlarm) + '</th><th style="text-align:center">' + str(totData) + '</th><th style="text-align:center">' + str(totInv) +  '</th><th style="text-align:center">'+ str(totEC2) + '</th><th style="text-align:center">' + str(totEFS) + '</th> <th style="text-align:center">' + str(totOnPrem) + '</th><th style="text-align:center">' + str(totddb) + '</th><th style="text-align:center">' + str(totrds) + '</th></tr>'
            else:
                page = page + '<tr><th>TOTALS</th><th colspan="2"></th><th style="text-align:center">' + str(totRunning) + '</th><th style="text-align:center">' + str(totStopped) + '</th><th style="text-align:center">' + str(totAlarm) + '</th><th style="text-align:center">' + str(totData) + '</th><th style="text-align:center">' + str(totInv) +  '</th><th style="text-align:center">'+ str(totEC2) + '</th><th style="text-align:center">' + str(totEFS) + '</th> <th style="text-align:center">' + str(totddb) + '</th><th style="text-align:center">' + str(totrds) + '</th></tr>'
            page = page + '</table>'
            print(__name__, 'made it through - returning')
        return page
    elif Widget == 4: # Configuration Management
        if Mode == 2: # State Profile
            pastprofile = 0
            Profile = ''
            Tenant = ''
            Account = ''
            ProfileId = ''
            ProfileType = 'state-profile'
            currentTargetname = 'State-Profile'
            if event.get('prime', 0) == 1:
                print(__name__,'Prime is triggering a reset!')
                event['widgetContext']['forms']['all'] = {}
                Tenant = event['widgetContext']['params'].get('Tenant')
                Account = event['widgetContext']['params'].get('Account')
                ProfileType = event['widgetContext']['params'].get('profiletype')
                ProfileId = event['widgetContext']['params'].get('Profile')
            elif event.get('action', '') == 'reset':
                print(__name__,'event:{}'.format(event))
                print(__name__,'pre-reset: Tenant:{}'.format(event['widgetContext']['forms']['all'].get('Tenant')))
                Tenant = event['widgetContext']['forms']['all'].get('Tenant')
                event['widgetContext']['forms']['all'] = {}
                print(__name__,'post-reset: Tenant:{}'.format(Tenant))

            dup=0
            delete = 0
            didaction = 0
            updatetenant = 0 # flag to track change in tenant assigned to aws account
            severities = ["LOW","MEDIUM", "HIGH", "CRITICAL"]
            targetTypes = ["tag:","tag-key","resource-groups:", "InstanceIds"]
            ## set rundocs details
            runDocs = {
            "AWS-ApplyAnsiblePlaybooks": {'description': 'Run Ansible Playbooks on Systems Manager managed instances w/Ansible agent installed.', 'link': 'https://docs.aws.amazon.com/systems-manager/latest/userguide/systems-manager-state-manager-ansible.html','parameters':{'SourceType': {'L': [{'S':'S3'}]},'SourceInfo':{'L': [{'S': ''}]},'InstallDependencies': {'L': [{'S':'True'}]},'PlaybookFile': {'L': [{'S':'playbook.yml'}]},'Check': {'L': [{'S':'True'}]},'TimeoutSeconds': {'L': [{'S':'180'}]},'Verbose': {'L': [{'S':'-v'}]},'ExtraVariables': {'L': [{'S':''}]}}},
            "AWS-ApplyChefRecipes": {'description': 'Run Chef recipes on AWS Systems Manager managed instances', 'link': '','parameters':{'SourceType': {'L': [{'S':'S3'}]},'SourceInfo': {'L': [{'S':'s3://bucket/templates/configuration.tar.gz'}]},'RunList': {'L': [{'S':'recipe[apply-chef-recipes-example-cookbook::default]'}]},'JsonAttributesContent': {'L': [{'S':''}]},'ChefClientVersion': {'L': [{'S':'14'}]},'ChefClientArguments': {'L': [{'S':''}]},'WhyRun': {'L': [{'S':'False'}]},'ComplianceSeverity': {'L': [{'S':'None'}]},'ComplianceType': {'L': [{'S':'Custom:Chef'}]},'ComplianceReportBucket': {'L': [{'S':''}]}}},
            "AWS-InstallPowerShellModule": {'description': '', 'link': 'https://github.com/awsdocs/aws-systems-manager-user-guide/blob/main/doc_source/walkthrough-powershell.md','parameters':{}},
            "AWS-InstallApplication": {'description': '', 'link': 'https://github.com/awsdocs/aws-systems-manager-user-guide/blob/main/doc_source/walkthrough-powershell.md','parameters':{}},
            "AWS-InstallWindowsUpdates": {'description': '', 'link': 'https://github.com/awsdocs/aws-systems-manager-user-guide/blob/main/doc_source/walkthrough-powershell.md','parameters':{}},
            "AWS-JoinDirectoryServiceDomain": {'description': '', 'link': 'https://github.com/awsdocs/aws-systems-manager-user-guide/blob/main/doc_source/walkthrough-powershell.md','parameters':{}},
            "AWS-RunSaltState": {'description': 'Run Salt States on Systems Manager managed instances w/Salt Agent installed.', 'link': 'https://aws.amazon.com/blogs/mt/running-salt-states-using-amazon-ec2-systems-manager/','parameters': {'state': {'L': [{'S':''}]},'pillars': {'L': [{'S':''}]},'stateurl': {'L': [{'S':'s3://bucket/templates/configuration.sls'}]},'test': {'L': [{'S':'False'}]}}},
            "AWSEC2-ConfigureSTIG": {'description': 'Pushes configuration hardening standards created by DISA on Systems Manager managed instances.', 'link': '','parameters':{'Level': {'L': [{'S':'Low'}]}}},
            "AWS-RunPatchBaseline": {'description': 'Scans for or installs patches from a patch baseline to Linux or Windows Systems Manager managed instances', 'link': 'https://docs.aws.amazon.com/systems-manager/latest/userguide/patch-manager-aws-runpatchbaseline.html','parameters':{'Operation': {'L': [{'S':'Scan'}]}, 'SnapshotId': {'L': [{'S': ''}]}, 'InstallOverrideList': {'L': [{'S':''}]}, 'BaselineOverride': {'L': [{'S': ''}]}, 'RebootOption': {'L': [{'S':'RebootIfNeeded'}]}}},
            "AWS-RunPatchBaselineWithHooks":{'description': 'Wrapper to compose more complex patch install scenarios for Systems Manager managed instances', 'link': 'https://docs.aws.amazon.com/systems-manager/latest/userguide/patch-manager-aws-runpatchbaselinewithhooks.html','parameters':{'Operation': {'L': [{'S':'Scan'}]}, 'SnapshotId': {'L': [{'S': ''}]}, 'PreInstallHookDocName': {'L': [{'S':''}]}, 'PostInstallHookDocName': {'L': [{'S': ''}]}, 'OnExitHookDocName': {'L': [{'S':''}]},'RebootOption': {'L': [{'S':'RebootIfNeeded'}]}}},
            "AWS-RunPatchBaselineAssociation": {'description': 'Scans for or installs patches from a patch baseline to Linux or Windows Systems Manager managed instances', 'link': 'https://docs.aws.amazon.com/systems-manager/latest/userguide/patch-manager-aws-runpatchbaselineassociation.html','parameters':{'Operation': {'L': [{'S':'Scan'}]}, 'AssociationId': {'L': [{'S': ''}]}, 'InstallOverrideList': {'L': [{'S':''}]}, 'BaselineTags': {'L': [{'S': ''}]}, 'RebootOption': {'L': [{'S':'RebootIfNeeded'}]}}},
            "AWS-RunPowerShellScript": {'description': 'Run a PowerShell script or specify the paths to scripts to run.', 'link': '','parameters':{'commands': {'L': [{'S':'command1,command2'}]},'workingDirectory': {'L': [{'S':''}]},'executionTimeout': {'L': [{'S':'3600'}]}}},
            "AWS-RunRemoteScript": {'description': 'Execute scripts stored in a remote location.', 'link': '','parameters':{'SourceType': {'L': [{'S':'S3'}]},'SourceInfo': {'L': [{'S':''}]},'commandLine': {'L': [{'S':''}]},'workingDirectory': {'L': [{'S':''}]},'executionTimeout': {'L': [{'S':'3600'}]}}},
            "AWS-RunShellScript": {'description': 'Run a shell script or specify the commands to run.', 'link': '','parameters':{'commands': {'L': [{'S':'command1;command2'}]},'workingDirectory': {'L': [{'S':''}]},'executionTimeout': {'L': [{'S':'3600'}]}}},
            "AWS-ConfigureAWSPackage": {'description': 'Install or uninstall a Distributor package. You can install the latest version, default version, or a version of the package.', 'link': 'https://docs.aws.amazon.com/systems-manager/latest/userguide/distributor-working-with-packages-deploy.html','parameters':{'action': {'L': [{'S':'Install'}]},'installationType': {'L': [{'S':'Uninstall and reinstall'}]},'name': {'L': [{'S':''}]},'version': {'L': [{'S':''}]},'additionalArguments': {'L': [{'S':''}]}}},
            "AWS-ConfigureCloudWatch": {'description': 'Export metrics and log files from your instances to Amazon CloudWatch', 'link': 'https://github.com/awsdocs/aws-systems-manager-user-guide/blob/main/doc_source/walkthrough-powershell.md','parameters':{'status': {'L': [{'S':'Enabled'}]},'properties': {'L': [{'S':''}]}}},
            "AWS-ConfigureWindowsUpdate": {'description': '', 'link': 'https://github.com/awsdocs/aws-systems-manager-user-guide/blob/main/doc_source/walkthrough-powershell.md','parameters':{}},
            "AWS-RunDocument": {'description': 'Execute composite or nested Systems Manager documents (SSM documents) stored in a remote location.', 'link': 'https://docs.aws.amazon.com/systems-manager/latest/userguide/documents-running-remote-github-s3.html','parameters':{'SourceType': {'L': [{'S':'SSMDocument'}]},'SourceInfo': {'L': [{'S':''}]},'documentParameters': {'L': [{'S':''}]}}},
            "AWS-RunInspecChecks": {'description': 'Run a single InSpec test or an InSpec profile on a group of managed instances.', 'link': 'https://docs.aws.amazon.com/systems-manager/latest/userguide/integration-chef-inspec.html','parameters':{'sourceType': {'L': [{'S':'S3'}]},'sourceInfo': {'L': [{'S':'{}'}]}}},
            "AWS-UpdateEC2Config": {'description': '', 'link': 'https://github.com/awsdocs/aws-systems-manager-user-guide/blob/main/doc_source/walkthrough-powershell.md','parameters':{}}
            }
            
            STIG = ["None","Low", "Medium", "High"]
            activeOptions = ["True", "False"]
            bgcolor: String = '#bccad6'
            needtocreate = 0 # do we have any profiles yet?
            setTargetKeyTypes = ''
            createnew = 0
            print(__name__,'event:{}'.format(event))
            if Tenant == '' and event['widgetContext']['forms']['all'].get('Tenant'):
                Tenant = event['widgetContext']['forms']['all'].get('Tenant')
                print(__name__, 'Tenant assigned from form', Tenant)
            elif Tenant == '' and event.get('Tenant'):
                Tenant = event.get('Tenant')
                print(__name__, 'Tenant assigned from event', Tenant)
            if event.get('action') != 'reset': # reset form fields
                if Account == '' and event['widgetContext']['forms']['all'].get('Account'):
                    Account = str(event['widgetContext']['forms']['all'].get('Account'))
                elif Account == '' and event.get('Account'):
                    Account = str(event.get('Account',''))
                print(__name__,'target account: {}',format(Account))
                
                if ProfileType == '' and event['widgetContext']['forms']['all'].get('profiletype'):
                    ProfileType = event['widgetContext']['forms']['all'].get('profiletype')
                    print(__name__, 'Profile Type assigned from form', ProfileType)
                elif ProfileType == '' and event.get('profiletype'):
                    ProfileType = event.get('profiletype')
                    print(__name__, 'Profile Type assigned from event', ProfileType)

                if ProfileId == '' and event['widgetContext']['forms']['all'].get('profileid'):
                    ProfileId = event['widgetContext']['forms']['all'].get('profileid')
                    print(__name__, 'Profile Id assigned from form', ProfileId)
                elif ProfileId == '' and event.get('profileid'):
                    ProfileId = event.get('profileid')

                if event['widgetContext']['forms']['all'].get('configid'):
                    ConfigId = event['widgetContext']['forms']['all'].get('configid')
                    print(__name__, 'Config Id assigned from from: {}'.format( ConfigId))
                elif event.get('configid'):
                    ConfigId = event.get('configid')
                    print(__name__, 'Config Id assigned from event: {}'.format( ConfigId))
                else:
                    ConfigId = ''
            else:
                Account = ''
                #ProfileType = 'state-profile'
            #if ProfileType != '' and ProfileType.find('state') > -1: # set profile type friendly name
            #    currentTargetname = 'State-Profile'

            ##### Begin processes state and configuration changes
            if event.get('action') == 'createprofile':
                varName = hcom.get_next_profile_number(ProfileType,0)
                print(__name__, 'next num:', str(varName))

                try: 
                    profileresponse = hcom.create_state_profile(varName, ProfileType, Tenant, Account) # create Profile

                except ClientError as error:
                    print(__name__, 'Could not create profile.', error)
                    response = 'error'
                page += '<center>Profile '+ str(varName) + ' has now been created. You can now create configurations for it.</center>'
            elif event.get('action') == 'deleteprofile':
                print(__name__,'**** begin deleting state profile {}'.format(str(ProfileId)))
                hcom.delete_state_profile(ProfileId, ProfileType,Tenant, Account)
                page += '<center> All configurations and state assocaitons have been removed from State Profile ' + ProfileId + '. You can now reuse this profile.</center>'
                ProfileId = None
            elif event.get('action') == 'createconfig':
                thisProfile = {}
                thisProfile['Tenant'] = Tenant
                thisProfile['Account'] = Account
                thisProfile['Region'] = event['widgetContext']['forms']['all'].get('region')
                thisProfile['TargetKeyType'] = event['widgetContext']['forms']['all'].get('targetkeytype')
                thisProfile['TargetKeyName'] = event['widgetContext']['forms']['all'].get('targetkeyname')
                thisProfile['TargetKeyValue'] = event['widgetContext']['forms']['all'].get('targetkeyvalue')
                thisProfile['ConfigId'] = event['widgetContext']['forms']['all'].get('configid2')
                thisProfile['ProfileId'] = ProfileId
                thisProfile['ProfileType'] = ProfileType
                thisProfile['RunDoc'] = event['widgetContext']['forms']['all'].get('rundoc')
                ThisName = hcom.get_association_name(thisProfile.get("ProfileId"),thisProfile.get("ConfigId"),thisProfile.get("ProfileType"),thisProfile.get("RunDoc"),thisProfile["Tenant"], thisProfile["Account"],thisProfile.get("TargetKeyType"),thisProfile.get("TargetKeyName"),thisProfile.get("TargetKeyValue"))
                ThisName = ThisName.replace(":","-")
                print(__name__,'final format of association name:{}'.format(ThisName))
                thisProfile["Name"] = ThisName
                thisProfile['parameters'] = hcom.get_params(thisProfile['RunDoc'],runDocs)
                thisProfile['Severity'] = 'Low'
                thisProfile['Schedule'] = 'rate(1 day)'
                thisProfile['Active'] = False

                try: 
                    profileresponse = hcom.create_configuration(ProfileId, ProfileType, thisProfile) # create Profile
                    if profileresponse  != 'error':
                        page += 'New Configuration added to profile.'
                        event['action'] = 'modify'
                        ConfigId = thisProfile.get("ConfigId")
                except ClientError as error:
                    print(__name__, 'Could not create profile.', error)
                    response = 'error'
            elif event.get('action') == 'deleteconfig':
                print(__name__,'---- begin delete config')
                ## delete association
                if event['widgetContext']['forms']['all'].get('associd') !='': # must first delete assocation
                    AssociationId = event['widgetContext']['forms']['all'].get('associd')
                    RunDoc = event['widgetContext']['forms']['all'].get('rundoc')
                    Region = event['widgetContext']['forms']['all'].get('region')
                    response = hcom.delete_assocation(AssociationId,RunDoc,Account,Region, arn)
                ## delete configuration
                response2 = hcom.delete_configuration(ProfileId, ProfileType, ConfigId)
                if response2 != 'error':
                    page += 'This Configuration has been deleted.'
            elif event.get('action') == 'update': # update configuration and if selected, enable configuration and create association
                print(__name__,'---- begin update ----')
                # setup vars
                thisProfile = {}
                thisProfile['Tenant'] = Tenant
                thisProfile['Account'] = Account
                thisProfile['Region'] = event['widgetContext']['forms']['all'].get('region')
                thisProfile['TargetKeyType'] = event['widgetContext']['forms']['all'].get('targetkeytype')
                thisProfile['TargetKeyName'] = event['widgetContext']['forms']['all'].get('targetkeyname')
                thisProfile['TargetKeyValue'] = event['widgetContext']['forms']['all'].get('targetkeyvalue')
                thisProfile['ConfigId'] = event.get('configid')
                thisProfile['ProfileId'] = event.get('profileid')
                thisProfile['ProfileType'] = event['widgetContext']['forms']['all'].get('profiletype')
                thisProfile['RunDoc'] = event['widgetContext']['forms']['all'].get('rundoc')
                if thisProfile['RunDoc'] == 'AWS-ApplyAnsiblePlaybooks': # detect and pass workaround path parameter
                    thisProfile['ansiblebucket'] = event['widgetContext']['forms']['all'].get('ansiblebucket')
                    thisProfile['ansiblepath'] = event['widgetContext']['forms']['all'].get('ansiblepath')
                    #thisProfile['parameters'] = event['widgetContext']['forms']['all'].get('parameters').replace("/","\\")

                thisProfile['parameters'] = event['widgetContext']['forms']['all'].get('parameters')
                thisProfile['ChangeCal'] = event['widgetContext']['forms']['all'].get('changecal')
                ThisName = hcom.get_association_name(thisProfile.get("ProfileId"),thisProfile.get("ConfigId"),thisProfile.get("ProfileType"),thisProfile.get("RunDoc"),thisProfile["Tenant"], thisProfile["Account"],thisProfile.get("TargetKeyType"),thisProfile.get("TargetKeyName"),thisProfile.get("TargetKeyValue"))
                ThisName = ThisName.replace(":","-")
                print(__name__,'final format of association name:{}'.format(ThisName))
                thisProfile["Name"] = ThisName
                
                thisProfile['Severity'] = event['widgetContext']['forms']['all'].get('oiseverity')
                thisProfile['Schedule'] = event['widgetContext']['forms']['all'].get('schedule')
                thisProfile['Active'] = event['widgetContext']['forms']['all'].get('active')
                thisProfile['Interval'] = event['widgetContext']['forms']['all'].get('interval')
                thisProfile['id'] = event['widgetContext']['forms']['all'].get('associd')
                #### begin processing section
                setting = 'Features'
                StateFeature = hcom.get_tenant_account_setting(Tenant,Account,setting,'StateMgmt')
                print(__name__,'StateMgmt feature: {} | id: {} {} | is active: {}'.format(StateFeature,thisProfile.get('id'),len(thisProfile.get('id')),thisProfile.get('Active')))
                if thisProfile.get('Active') == 'True' and StateFeature == False:
                    return {'statusCode': 400, 'statusmessage': 'You can not enable a State Profile while State Management Feature is not acive/disabled. You must first enable his feature in the CloudWatch Dashboard Configuration Manager.'}
                
                elif len(thisProfile.get('id')) < 10 and thisProfile.get('Active') == 'True' and StateFeature == True: # no pre-existing assocation to delete but need to create assocation
                    print(__name__,'---- initiating association creation and enable')
                    associationId = hcom.create_association(thisProfile['ProfileId'], thisProfile.get('ProfileType'), thisProfile, arn)
                    if len(associationId) > 10:
                        print(__name__,'new assocation id:{}'.format(associationId))
                        response = hcom.update_configuration(hcom.setDBTable,thisProfile,associationId)
                        page += '<center>Profile Configuration has been updated.</center>'

                elif thisProfile.get('id') != '' and thisProfile.get('Active') == 'True' and StateFeature == True: # delete pre-existing assocation and create new assocation
                    print(__name__,'---- initiating association deletion')
                    response = hcom.delete_assocation(thisProfile.get('id'),thisProfile.get('RunDoc'),Account,thisProfile.get('Region'),arn)
                    print(__name__,'---- outcome association deletion: {}'.format(response))
                    print(__name__,'---- initiating association creation')
                    associationId = hcom.create_association(thisProfile['ProfileId'], thisProfile.get('ProfileType'), thisProfile, arn)
                    if type(associationId) == dict:
                        if associationId['statusCode'] == 400:
                            page = associationId['statusMessage']
                            return page
                    elif len(associationId) > 10:
                        print(__name__,'new assocation id:{}'.format(associationId))
                        response = hcom.update_configuration(hcom.setDBTable,thisProfile,associationId)
                        page += '<center>Profile Configuration has been updated.</center>'

                elif thisProfile.get('id') != '' and thisProfile.get('Active') == 'False': # delete pre-existing assocation
                    print(__name__,'---- initiating association deletion and disable')
                    response = hcom.delete_assocation(thisProfile.get('id'),thisProfile.get('RunDoc'),Account,thisProfile.get('Region'),arn)
                    print(__name__,'outcome assocation deletion:{}'.format(response))
                    if response.get('statusCode', '') != 400:
                        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                            page += '<center>Configuration was disabled and Assocation was successfully deleted.</center>'
                            associationId = ''
                            response = hcom.update_configuration(hcom.setDBTable,thisProfile,associationId)
                        else:
                            page += '<center>There was an error trying to disable this Configuration. Please check  your settings and try again.</center>'

                elif len(thisProfile.get('id')) < 10 and thisProfile.get('Active') == 'False': # just update configuration, no association to deal with
                    print(__name__,'---- initiating configuration update ----')
                    associationId = ''
                    response = hcom.update_configuration(hcom.setDBTable,thisProfile,associationId)
                    page += '<center>Profile Configuration has been updated.</center>'
                else:
                    print(__name__,'--- something is wrong is parameters/variables, no action taken ---')
            ##### begin account select form
        
            theseAccounts = hcom.get_tenant_accounts(Tenant,True) # only get active accounts
            print(__name__,'---- these accounts:{} Account:{} Tenant: {}'.format(theseAccounts, Account, Tenant))
            if Account == ''  or Account == 'Select' or len(theseAccounts) == 1 or Account not in theseAccounts:
                Account = theseAccounts[0]
                print(__name__, 'Account reassigned from first account number', Account)
            print(__name__,'-- ProfileId: {}'.format(str(ProfileId)))
            if ProfileId == None or ProfileId == 'Select' or ProfileId == '' or ProfileId == 'New':
                cols = 8
            else:
                cols = 9
            page +=  '<table ><tr><th colspan="' + str(cols) + '"><b>(1)</b> &nbsp; Select Profile Filters:</th></tr></tr>'
            page +=  '<tr><td><form id="tenant"><select id="Tenant" name="Tenant">'
            page +=  '<option value="Select">Select</option>'
            for tenant, accounts in hcom.setTenants.items():
                if Tenant == tenant:
                    selected = 'selected'
                else:
                    selected = ''
                page +=  '<option value="' + tenant + '" ' + selected + '>' + tenant + '</option>'
            page +=  '</select></form></td>'
            page +=  '<td><a class="btn btn-primary">Select Tenant</a>'
            page +=  '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 2, "action": "reset" }</cwdb-action></td>'
            ### begin account number section
            page +=  '<td><form id="account"><select id="Account" name="Account">'
            page +=  '<option value="Select">Select</option>'
            for acctnum in theseAccounts:
                if Account != '':
                    if Account == acctnum:
                        selected = 'selected'
                    else:
                        selected = ''
                    page +=  '<option value="' + acctnum + '" ' + selected + '>' + acctnum + '</option>'
            page +=  '</td></select></form><td><a class="btn btn-primary">Select Managed Account </a>'
            page +=  '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 2,"Tenant": "' + Tenant + '" }</cwdb-action></td>' #</tr></table>'
            print(__name__,page)
            ### Select Profile Number
            profilelist = get_state_profiles(table,ProfileType,Tenant,Account)
            if len(profilelist)<1: # if no profiles yet
                page +=  '<td>You Must Create your 1st Profile below.</td>'
                needtocreate = 1
            else:
                if ProfileId == 'New': # check if creating new profile
                    newselected = 'selected'
                else:
                    newselected = ''
                page +=  '<td><form id="config"><select id="profileid" name="profileid">'
                page +=  '<option value="Select">Select</option>'
                #page +=  '<option value="New" '+newselected+'>New Profile</option>'
                for profile in profilelist:
                    if profile['mspname'] == ProfileId:
                        selected = 'selected'
                    else:
                        selected = ''
                    page +=  '<option value="' + profile['mspname'] + '" ' + selected + '>' + profile['mspname'] + '</option>'
                page +=  '</select></td></form><td><a class="btn btn-primary">Select Profile #</a>'
                page +=  '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 2,"action": "list","Tenant": "' + Tenant + '", "Account": "' + Account +'", "ProfileType": "' + ProfileType +'" }</cwdb-action></td>' #</tr></table>'
                page += '<td><a class="btn btn-primary">New Profile</a>'
                page += '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 2, "action": "createprofile","Tenant": "' + Tenant + '", "Account": "' + Account +'", "profiletype": "'+ProfileType+'" }</cwdb-action>'
            print(__name__,'--- ProfileId: {} | {}'.format(str(ProfileId),str(cols)))
            if cols == 9 and ProfileId !='' and ProfileId != None: # we have a profile so show delete button
                page += '<td><a class="btn btn-primary">Remove All Configurations from Profile &nbsp;' + ProfileId + '</a>'
                page +=  '<cwdb-action action="call" confirmation="Are you sure you want to delete all existing configurations and active State Assocations? This is not reversible. After proceeding, this profile will be empty and ready for reuse." endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 2,"action": "deleteprofile","Tenant": "' + Tenant + '", "Account": "' + Account +'", "ProfileId": "' + ProfileId +'" }</cwdb-action></td>'
            page += '</tr></table>'
            if needtocreate == 1 and setTargetKeyTypes == '' or ProfileId =='New': # create first profile and initial configuration
                createnew = 1
                ProfileId = str(1)
                print(__name__,'reassign ProfileId to 1')
                createprofileregions = hcom.get_tenant_account_attribute(Tenant,Account,"Regions")
                setFormRegions = '<select id="region" name="region">'
                for cat in createprofileregions:
                    setFormRegions += '<option value="' + str(cat) + '" ' + selected + '>' + str(cat) + '</option>'
                setFormRegions += '</select>'
                # create profile
                setTargetKeyTypes = '<select id="targetkeytype" name="targetkeytype">'
                setTargetKeyTypes += '<option value="Select" selected>Select</option>'
                for cat in targetTypes:
                    if cat == 'tag:':
                        selected = 'selected'
                    else:
                        selected = ''
                    setTargetKeyTypes += '<option value="' + str(cat) + '" ' + selected + '>' + str(cat) + '</option>'
                setTargetKeyTypes += '</select>'
                #response = get_create_first_profile(bgcolor,runDocs,setTargetKeyTypes,setFormRegions,currentTargetname,ProfileType,ProfileId,Account,Tenant,ThisPartition)
                #page += response
            print(__name__,page)
            if didaction == 0:
                account = hcom.get_account(Tenant, Account) # get current account
                print(__name__,'----- no action so loading from global:{}'.format(account))
            ### begin profile drop-down section
            if event.get('action') == 'list' and ProfileId !='' and createnew == 0 and ProfileType !='': # list configurations for this profile
                stateconfigregion = 'all'
                profilelist = hcom.get_state_profile_configs(ProfileType,ProfileId,Tenant,Account,stateconfigregion,'all')
                print('show drop-down')
                print(__name__,'profile list:{}'.format(profilelist))
                # get regions for selected tenant
                createprofileregions = hcom.get_tenant_account_attribute(Tenant,Account,"Regions")
                setFormRegions = '<select id="region" name="region">'
                for cat in createprofileregions:
                    setFormRegions += '<option value="' + str(cat) + '" ' + selected + '>' + str(cat) + '</option>'
                setFormRegions += '</select>'
                setTargetKeyTypes = '<select id="targetkeytype" name="targetkeytype">'
                # create targetkeytypes field
                setTargetKeyTypes += '<option value="Select" selected>Select</option>'
                for cat in targetTypes:
                    if cat == 'tag:':
                        selected = 'selected'
                    else:
                        selected = ''
                    setTargetKeyTypes += '<option value="' + str(cat) + '" ' + selected + '>' + str(cat) + '</option>'
                setTargetKeyTypes += '</select>'
                if len(profilelist) > 0: # we have configs
                    
                    # select profile
                    page +=  '<table ><tr><th colspan="3" ><b>The following is a list of current configurations for this profile.</b></th></tr>'
                    page +=  '<tr><td>Select Existing Configuration to Modify:</td>'
                    page += '<td><form id="selectconfig"><select id="configid" name="configid">'
                    page +=  '<option value="Select">Select Configuration to Modify from the drop-down before clicking the Modify button</option>'
                    for profile in profilelist:
                        if profile['mspname'] == ConfigId:
                            selected = 'selected'
                        else:
                            selected = ''
                        if profile['Active'] == False:
                            showDisable = ' | Disabled'
                        else:
                            showDisable = ''
                        page +=  '<option value="' + profile['mspname'] + '" ' + selected + '>' + profile['mspname'] + '   |    ' + profile['Region'] + '   |    ' + profile['Name'] + showDisable + '</option>'
                    page +=  '</select></form></td>'
                    page +=  '<td><a class="btn btn-primary">Modify</a>'
                    page +=  '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 2, "action": "modify","Tenant": "' + Tenant + '", "Account": "' + Account +'", "profiletype": "'+ProfileType+'", "profileid": "'+ProfileId+'" }</cwdb-action></td>' #</tr></table>'
                    #page +=  '<td><a class="btn btn-primary">Add New Configuration</a>'
                    #page +=  '<cwdb-action action="html" event="click" display="popup">' + get_create_next_config(hcom.setDBTable,bgcolor,runDocs,setTargetKeyTypes,setFormRegions,currentTargetname,ProfileType,ProfileId,Account,Tenant,ThisPartition) + ' </cwdb-action></td>' #</tr></table>'
                    page += '</tr></table><hr>'
                     
                #begin create profile table
                page += get_create_next_config(bgcolor,runDocs,setTargetKeyTypes,setFormRegions,currentTargetname,ProfileType,ProfileId,Account,Tenant,ThisPartition)
            elif event.get('action') == 'modify' : #show details in table
                print(__name__,'--- begin modify - check vars: ProfileType: {} ProfileId:{} ConfigId: {}'.format(ProfileType,ProfileId,ConfigId))
                if ProfileType != '' and ProfileId != '': # verify we have values before attempting to get the profile details
                    profiles = get_profile_config(table,ProfileType,ProfileId,ConfigId)
                    print(__name__,'profiles: {}'.format(profiles))
                    results = profiles['Item']
                    
                else:
                    return {'statusCode': 400, 'statusmessage': 'Missing required parameters for profile type and/or profile id from the form.'}
                
                # setup severity
                setOpsSeverity = '<select id="oiseverity" name="oiseverity">'
                for cat in severities:
                    if cat == str(results.get('Severity')):
                        selected = 'selected'
                    else:
                        selected = ''
                    setOpsSeverity = setOpsSeverity + '<option value="' + str(cat) + '" ' + selected + '>' + str(cat) + '</option>'
                setOpsSeverity = setOpsSeverity + '</select>'
                """
                if results.get('TargetKey').find(':') > -1: # found colon
                    setTargetKeyName = str(results.get('TargetKey')).split(':')
                    setTargetKeyName = setTargetKeyName[1]
                    setTargetKeyType = setTargetKeyName[0]
                elif results.get('TargetKey').find('tag-key') > -1: # found colon
                    setTargetKeyName = str(results.get('TargetKey')).split('-key')
                    setTargetKeyName = setTargetKeyName[1]
                    setTargetKeyType = 'tag-key'
                """
                # setup target types
                setTargetKeyTypes = '<select id="targetkeytype" name="targetkeytype">'
                for cat in targetTypes:
                    if cat == results.get('TargetKey'): #str(setTargetKeyType):
                        selected = 'selected'
                    else:
                        selected = ''
                    setTargetKeyTypes += '<option value="' + str(cat) + '" ' + selected + '>' + str(cat) + '</option>'
                setTargetKeyTypes += '</select>'
                """ deprecated
                # setup STIG
                setSTIG = '<select id="stig" name="stig">'
                for cat in STIG:
                    if cat == str(results.get('STIG')):
                        selected = 'selected'
                    else:
                        selected = ''
                    if cat == 'Low':
                        setSTIGName = 'Low (Category III)'
                    elif cat == 'Medium':
                        setSTIGName = 'Medium (Category II)'
                    elif cat == 'High':
                        setSTIGName = 'High (Category I)'
                    else:
                        setSTIGName = 'None'
                    setSTIG += '<option value="' + str(cat) + '" ' + selected + '>' + setSTIGName + '</option>'
                setSTIG += '</select>'
                """
                # setup RunDocs
                setRunDoc = '<select id="rundoc" name="rundoc">'
                for cat, value in runDocs.items():
                    if cat == str(results.get('Type')):
                        selected = 'selected'
                    else:
                        selected = ''
                    
                    setRunDoc += '<option value="' + str(cat) + '" ' + selected + '>' + str(cat) + '</option>'
                setRunDoc += '</select>'
                # setup interval
                if results.get('Interval') == True:
                    setInterval = 'True'
                    setIntervalTrueChecked = 'checked'
                    setIntervalFalseChecked = ''
                else:
                    setInterval = 'False'
                    setIntervalFalseChecked = 'checked'
                    setIntervalTrueChecked = ''
                # setup active
                if results.get('Active') == True:
                    setActive = 'True'
                    setActiveTrueChecked = 'checked'
                    setActiveFalseChecked = ''
                else:
                    setActive = 'False'
                    setActiveFalseChecked = 'checked'
                    setActiveTrueChecked = ''
                print(__name__,'id:{} Active:{}'.format(str(results.get('id')),str(results.get('Active'))))
                if str(results.get('id')) == '' and results.get('Active') == False: # no association since disabled
                    thisId = 'Currently Disabled'
                else:
                    thisId = str(results.get('id'))
                profiletype2 = results.get('msptype').split('-')
                profiletype2 = profiletype2[0]+ '-' + profiletype2[1]
                ### get change calendars
                setChangeCal = '<select id="changecal" name="changecal">'
                setChangeCal += '<option value="">None</option>'
                cal_list = hcom.get_change_calendars(results.get('Account'),results.get('Region'),arn)
                print(__name__,'--- after call to get change calendars: {}'.format(cal_list))
                if cal_list != '' and cal_list != 'exit 1':
                    print(__name__,'list of change calendars: {}'.format(str(cal_list)))
                    for cat in cal_list:
                        if str(cat['Name']) == str(results.get('ChangeCalendar')):
                            selected = 'selected'
                        else:
                            selected = ''
                        if str(cat['Name']).find('/') > -1:
                            catName = str(cat['Name']).split('/')
                            catName= catName[1] + ' | Shared from Central '
                        else:
                            catName = str(cat['Name'])
                        setChangeCal += '<option value="' + str(cat['Name']) + '" ' + selected + '>' + catName + '</option>'
                setChangeCal += '</select>'
                ## check if StateMgmt feature is active
                setting = 'Features'
                StateFeature = hcom.get_tenant_account_setting(Tenant,Account,setting,'StateMgmt')
                
                if hcom.get_tenant_account_setting(Tenant,Account,setting,'StateMgmt') == False:
                    activecolor = '<td style="text-align:center;background-color:tomato;" ><input type="hidden" id="active" name="active" value="False" checked> State Mgmt is Disabled </td>'
                else:
                    activecolor = '<td style="text-align:center" ><input type="radio" id="active" name="active" value="True" '+setActiveTrueChecked+'>Enabled <input type="radio" id="active" name="active" value="False" '+setActiveFalseChecked+'> Disabled </td>'
                print(__name__,'StateMgmt feature: {} | {} | {} | {}'.format(Account,Tenant,StateFeature,activecolor))
                # begin table and column headers
                page += '<table ><form id="updateconfig">'
                page += '<tr><th >Configuration Name</th><td colspan="3">' + str(results.get('Name')) + '</td><td  >Profile # ' + str(ProfileId) + '</td><td >Configuration # ' + str(results.get('mspname')) + '</td></tr>'
                page += '<tr><th >Tenant</th><th >Account</th><th >Regions</th><th >Profile Type</th><th  style="text-align:center;background-color:' + bgcolor + '" colspan="2">Assocation Id</th></tr>'
                page += '<tr><td style="text-align:center"><input type="hidden" id="tenant" name="tenant" value="' + str(results.get('Tenant')) + '" required> ' + str(results.get('Tenant')) + '</td>'
                page += '<td style="text-align:center"><input type="hidden" id="account" name="account" value="' + str(results.get('Account')) + '" required>' + str(results.get('Account')) + '</td>'
                page += '<td style="text-align:center"><input type="hidden" id="region" name="region" value="' + str(results.get('Region')) + '" required>' + str(results.get('Region')) + '</td>'
                page += '<td style="text-align:center"><input type="hidden" id="profiletype" name="profiletype" value="' + str(profiletype2) + '" required>' + str(profiletype2) + '</td>'
                #page += '<td align="center"><input type="hidden" id="profileid" name="profileid" value="' + str(results.get('mspname')) + '" required>' + str(results.get('mspname')) + '</td>'
                page += '<td align="center" colspan="2"><input type="hidden" id="associd" name="associd" value="' + str(results.get('id')) + '" required>' + str(thisId) + '</td></tr>'
                # next row column headers and editable fields
                page += '<tr><th style="background-color:' + bgcolor + '">SSM RunDoc</th><th style="background-color:' + bgcolor + '">SSM Compliance Severity</th><th style="background-color:' + bgcolor + '"> Schedule (rate or cron)</th><th  style="text-align:center;background-color:' + bgcolor + '">Target Type</th><th  style="text-align:center;background-color:' + bgcolor + '">Tag or Resource Group Name</th><th  style="text-align:center;background-color:' + bgcolor + '">Target Value</th></tr>'
                page += '<tr><td style="text-align:center" ><input type="hidden" id="rundoc" name="rundoc" value="' + str(results.get('Type')) + '" required> ' + str(results.get('Type')) + '</td>'
                page += '<td style="text-align:center">' + setOpsSeverity + '</td>'
                page += '<td style="text-align:center"><input type="text" id="schedule" name="schedule" value="' + str(results.get('Schedule')) + '" required></td>'
                page += '<td style="text-align:center">' + str(setTargetKeyTypes) + '</td>'
                page += '<td style="text-align:center"><input type="text" id="targetkeyname" name="targetkeyname" value="' + str(results.get('TargetKeyName')) + '" required></td>'
                page += '<td style="text-align:center"><input type="text" id="targetkeyvalue" name="targetkeyvalue" value="' + str(results.get('TargetValue')) + '" required><br>comma separated list for tag:,tag-key:,InstanceIds</td></tr>'
                page += '<td style="text-align:center" colspan="4">' + runDocs[str(results.get('Type'))]['description'] +'</td><td style="text-align:center" colspan="2"><a href="' + runDocs[str(results.get('Type'))]['link'] +'" target="_new">Link to documentation</a></td></tr>'
                page += '<tr><th  colspan="4">Parameters (JSON) </th><th >Is Enabled?</th><th >Change Calendar</th></tr>'
                page += '<tr><td style="text-align:center" colspan="4"><input type="text" id="parameters" name="parameters" size="100" maxlength = "500" value="' + str(results.get('parameters')) + '" ></td>' + activecolor + ' <td style="text-align:center" >'+setChangeCal+'</td></tr>'
                if str(results.get('Type')) == 'AWS-ApplyAnsiblePlaybooks':
                    if results.get('ansiblebucket'):
                        thisBucket = str(results.get('ansiblebucket'))
                        thisPath = str(results.get('ansiblepath'))
                        
                        
                    else:
                        thisBucket = 'replacebucket.s3-replaceregion.amazonaws.com'
                        thisPath = '/replacepath/'
                    page += '<tr><td style="text-align:center" colspan="2">Bucket.domain from Object URL &nbsp; <input type="text" id="ansiblebucket" name="ansiblebucket" size="60" value="' + thisBucket + '" required></td><td colspan="3">Path &nbsp; <input type="text" id="ansiblepath" name="ansiblepath" value="' + thisPath + '" required> &nbsp; path portion of https URL to file (but without including filename)</td><td>Leave SourceInfo in above parameters as default. This will override it.</td></tr>'


                page += '<tr><td style="background-color:' + bgcolor + ';text-align:right">Apply only at Cron Interval?</td><td><input type="radio" id="interval" name="interval" value="True" '+setIntervalTrueChecked+'>True <input type="radio" id="interval" name="interval" value="False" '+setIntervalFalseChecked+'> False </td>'
                page += '<td></form><a class="btn btn-primary">Update</a><cwdb-action action="call" confirmation="Are you sure you want to modify this configuration?" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 2, "action": "update", "profileid": "' + str(ProfileId) + '", "configid": "' + str(results.get('mspname')) + '" }</cwdb-action></td><td> Assocations get replaced when updated with a new assocation. </td>'
                page += '<td>&nbsp;</td><td><a class="btn btn-primary">Delete</a><cwdb-action action="call" confirmation="Are you sure you want to delete this configuration? You cannot undo this action." endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 2, "action": "deleteconfig", "profileid": "' + str(event.get('profileid')) + '", "configid": "' + str(results.get('mspname')) + '" }</cwdb-action></td></tr></table>'
                print(__name__,page)
                #print(__name__,'selected profile',varName, ThisId, thisAccounts, thisRegions, ThisSchedule)

                return page
            return page
        elif Mode == 3: # CloudWatch profile
            pastprofile = 0
            profiles = ''
            ProfileType = event.get('ProfileType','')
            Profile = ''
            Tenant = ''
            Account = ''
            ProfileId = ''
            bgcolor: String = '#bccad6'
            delete = 0 # track deletion action
            Profile = event.get('Profile','')
            oldregion = ''
            #print(__name__,'event:{}'.format(event))
            try:
                if event['widgetContext']['forms']['all'].get('resourcetype'):
                    resourcetype = event['widgetContext']['forms']['all'].get('resourcetype')
                else:
                    resourcetype = event.get('resourcetype','')
            except KeyError as error: # likely coming from initial widget parameters
                print(__name__,'exception:', error)
                resourcetype = ''
                pass
            #### begin from state
            if Tenant == '' and event['widgetContext']['forms']['all'].get('Tenant'):
                Tenant = event['widgetContext']['forms']['all'].get('Tenant')
                print(__name__, 'Tenant assigned from form', Tenant)
            elif Tenant == '' and event.get('Tenant'):
                Tenant = event.get('Tenant')
                print(__name__, 'Tenant assigned from event', Tenant)
            if event.get('action') != 'reset': # reset form fields
                if Account == '' and event['widgetContext']['forms']['all'].get('Account'):
                    Account = str(event['widgetContext']['forms']['all'].get('Account'))
                elif Account == '' and event.get('Account'):
                    Account = str(event.get('Account',''))
                print(__name__,'target account: {}',format(Account))
                
                if ProfileType == '' and event['widgetContext']['forms']['all'].get('profiletype'):
                    ProfileType = event['widgetContext']['forms']['all'].get('profiletype')
                    print(__name__, 'Profile Type assigned from form', ProfileType)
                elif ProfileType == '' and event.get('profiletype'):
                    ProfileType = event.get('profiletype')
                    print(__name__, 'Profile Type assigned from event', ProfileType)

                if ProfileId == '' and event['widgetContext']['forms']['all'].get('profileid'):
                    ProfileId = event['widgetContext']['forms']['all'].get('profileid')
                    print(__name__, 'Profile Id assigned from form', ProfileId)
                elif ProfileId == '' and event.get('profileid'):
                    ProfileId = event.get('profileid')

                if event['widgetContext']['forms']['all'].get('configid'):
                    ConfigId = event['widgetContext']['forms']['all'].get('configid')
                    print(__name__, 'Config Id assigned from from: {}'.format( ConfigId))
                elif event.get('configid'):
                    ConfigId = event.get('configid')
                    print(__name__, 'Config Id assigned from event: {}'.format( ConfigId))
                else:
                    ConfigId = ''
            else:
                Account = ''
                ProfileType = 'state-profile'
            #### end from state
            print(__name__,'Profile: {} | ProfileType: {}'.format(event.get('Profile',''),event.get('ProfileType','')))
            action = event.get('action','')
            didaction = 0
            nextprofile = 0 # track next profile id value
            dup = 0 # track duplicatio action
            ssm3 = boto3.client('ssm', region_name=hcom.setCentralRegion)
            if dup == 0: # did not duplicate
                try:

                    if event['widgetContext']['forms']['all'].get('Profile') and delete !=1:
                        Profile = str(event['widgetContext']['forms']['all'].get('Profile'))
                        print(__name__,'found form passed Profile', Profile)
                        pastprofile = 1
                        #ThisId = Profile
                    elif event.get('Profile') and delete !=1:
                        Profile = str(event.get('Profile'))
                        print(__name__,'found dashboard passed Profile', Profile)
                        pastprofile = 1
                        if delete == 1:
                            Profile = '1'
                    else:
                        print(__name__,'no profile value passed')
                except KeyError as error:
                    print(__name__,'exception:', error)
                    pass
            #### Begin processing CloudWatch Profile changes
            # CloudWatch Profile removed feature check
            if event.get('action') == 'duplicate': # create a duplicate of the profile
                """
                profiles = get_profiles(dbcon,resourcetype,Tenant,Account,False)
                profilelist = profiles['Items']
                for j in range(profiles['Count']): # get high profile number
                    if int(profilelist[j]['mspname']['S']) > nextprofile:
                        nextprofile = int(profilelist[j]['mspname']['S'])
                nextprofile = nextprofile + 1 # set new profile id
                """
                nextprofile = get_next_profileid(dbcon,resourcetype)
                ### get profile details
                thisprofile = table.get_item(Key={'msptype': resourcetype, 'mspname': str(Profile)})
                thisprofiledetail = thisprofile['Item']
                print(__name__,'next profile id: {} profile to dup:{}'.format(nextprofile,thisprofiledetail))
                print(__name__,' regions to dup: {} | {}'.format(type(thisprofiledetail.get('Region')),thisprofiledetail.get('Region')))
                profiletype = thisprofiledetail.get('ProfileType')
                alarmdetails = thisprofiledetail.get('alarms')
                ProfileType = thisprofiledetail.get('ProfileType')
                ProfileConfiguration = thisprofiledetail.get('configuration')
                isTemplate = False
                if int(Profile) < 10: # since duplicating from HCOM managed template (which has no designated Tenant,Account,Region), assing from web form
                    ProfileRegion = []
                    tempProfileRegion = hcom.get_tenant_account_attribute(Tenant,Account,'Regions') 
                    print(__name__,'raw regions to copy: {} | {}'.format(type(tempProfileRegion),tempProfileRegion)) # get all regions for account and assign to new profile
                    #for i in tempProfileRegion:
                    #    print(__name__,'i: {} | {}'.format(type(i),i))
                    #    ProfileRegion.append(i)
                    ProfileRegion = tempProfileRegion
                    ProfileTenant = Tenant
                    ProfileAccount = Account
                    print(__name__,' creating from template, assigned Region: {} {} | Tenant: {} | Account: {}'.format(type(ProfileRegion),ProfileRegion,ProfileTenant,ProfileAccount))
                else:    # since duplicating from existing editable template, just use the same settings. 
                    ProfileRegion = thisprofiledetail.get('Region')
                    ProfileTenant = thisprofiledetail.get('Tenant')
                    ProfileAccount = thisprofiledetail.get('Account')
                ### create duplicate profile
                if resourcetype == 'cw-profile':
                    try:
                        response = table.update_item(Key={'msptype': resourcetype, 'mspname': str(nextprofile)},
                        UpdateExpression='SET #alm = :alm, #type = :type, #temp = :temp, #region = :region, #tenant = :tenant, #account = :account',
                        ExpressionAttributeNames={'#alm': 'alarms','#type': 'ProfileType', '#temp': 'isTemplate', '#region': 'Region', '#tenant': 'Tenant', '#account': 'Account' },
                        ExpressionAttributeValues={':alm': alarmdetails, ':type': profiletype,':temp': isTemplate, ':region': ProfileRegion, ':tenant': ProfileTenant, ':account': ProfileAccount})
                        dup = 1
                        Profile = str(nextprofile)
                        #clear_caches()
                        #response = ssm3.get_parameter(Name=logname) #unknown purpose for this line of code
                        ## update CW Agent Config
                        for reg in ProfileRegion:
                            print(__name__,f'Duplication: creating CW config for profile: {reg}')
                            #ThisConfig =  {'Function': 'cw_config', 'Action': 'add','Account': ProfileAccount, 'Region': reg, 'Profile': nextprofile, 'ProfileType': profiletype}
                            update_message = {'Function': 'cw_config', 'Action': 'add','Account': ProfileAccount, 'Region': reg, 'Profile': nextprofile, 'ProfileType': ProfileType}
                            hcom.update_central_queque(update_message, hcom.setSQS['HCOM-PlatformAutomation'])
                    except ClientError as error:
                        print(__name__,'exception:{}'.format(error))
                        pass
                else:
                    print(__name__,' creating non-cw profile: {} | {}'.format(resourcetype,str(nextprofile)))
                    response = table.update_item(Key={'msptype': resourcetype, 'mspname': str(nextprofile)},
                    UpdateExpression='SET #alm = :alm, #type = :type, #temp = :temp, #tenant = :tenant, #account = :account',
                    ExpressionAttributeNames={'#alm': 'alarms','#type': 'ProfileType', '#temp': 'isTemplate', '#tenant': 'Tenant', '#account': 'Account' },
                    ExpressionAttributeValues={':alm': alarmdetails, ':type': profiletype,':temp': isTemplate, ':tenant': ProfileTenant, ':account': ProfileAccount})
                    dup = 1
                    Profile = str(nextprofile)
            elif event.get('action') == 'delete' and int(Profile) > 6:
                ### delete profile
                regions = []
                if resourcetype == 'cw-profile':
                    print(__name__,' event vars:{} | region: {}'.format(event,type(event.get('region'))))
                    response = table.delete_item(Key={'msptype': resourcetype, 'mspname': str(Profile)})
                    region = event.get('region').replace('[', '')
                    region = region.replace(']', '')
                    print(__name__,'new region list: {}'.format(region))
                    region = region.replace("'", '')
                    print(__name__,'new region list: {}'.format(region))
                    #region = region.strip()
                    region = region.split(',')
                    print(__name__,'new region list: {}'.format(region))
                    for i in region:
                        regions.append(str(i).strip())
                    print(__name__,'new region list: {}'.format(regions))
                    for reg in regions:
                        try:
                            
                            update_message = {'Function': 'cw_config', 'Action': 'delete','Account': Account, 'Region': reg, 'Profile': Profile}
                            hcom.update_central_queque(update_message, hcom.setSQS['HCOM-PlatformAutomation'])
                            #hcom.delete_cwagent_configuration(ThisConfig)
                            #Profile = '1'
                            #delete = 1
                            
                        except ClientError as error:
                            print(__name__,'exception:{}'.format(error))
                            pass
                else: # non CW
                    print(__name__,' event vars:{} | region: {}'.format(event,type(event.get('region'))))
                    response = table.delete_item(Key={'msptype': resourcetype, 'mspname': str(Profile)})
            elif event.get('action') == 'region':
                ### update region for profile
                try:
                    newregions = ast.literal_eval(event['widgetContext']['forms']['all'].get('newregion'))
                    oldregions = ast.literal_eval(event.get('oldregion'))
                    response = table.update_item(Key={'msptype': resourcetype, 'mspname': str(Profile)}, #### need to switch this to client not resource update.
                        UpdateExpression='SET #region = :region',
                        ExpressionAttributeNames={'#region': 'Region' },
                        ExpressionAttributeValues={':region': newregions},
                        )
                    regprocess = 0 # count regions
                    for tempregion in oldregions:
                        print(__name__,' is old region: {} no longer in new regions: {}'.format(tempregion, newregions))
                        if tempregion not in newregions: # if not in new region, delete parameter
                            ## create queue to delete
                            #hcom.delete_cwagent_configuration(Account, tempregion, Profile)
                            update_message = {'Function': 'cw_config', 'Action': 'delete','Account': Account, 'Region': tempregion, 'Profile': Profile}
                            hcom.update_central_queque(update_message, hcom.setSQS['HCOM-PlatformAutomation'])
                        # now create parameter in all current regions
                    for tempregion in newregions:    
                        # create queue to add
                        update_message = {'Function': 'cw_config', 'Action': 'add','Account': Account, 'Region': tempregion, 'Profile': Profile, 'ProfileType': ProfileType}
                        hcom.update_central_queque(update_message, hcom.setSQS['HCOM-PlatformAutomation'])
                except ClientError as error:
                    print(__name__,'exception:{}'.format(error))
                    pass
            elif event.get('action') == 'createalarms': # create alarm requests in SQS
                print(__name__,'-- Begin createalarms section')
                targetaccount = Account
                skipconfig = 0 # push config
                instanceids = []
                if type(event.get('targetregions')) == str:
                    print(__name__,'regions is string, converting to list')
                    targetregions = ast.literal_eval(event.get('targetregions')) # convert form string to list variable
                    
                else:
                    targetregions = event.get('targetregions')
                #if event.get('subaction') == 'allregionsconfig': # all regions and push config
                #    print()
                #elif event.get('subaction') == 'thisregionconfig':
                    #targetregions.append(event.get('thisregion'))
                #    print()
                if event.get('subaction') == 'allregions' or event.get('subaction') == 'thisregion': # all regions with no config push
                    skipconfig = 1 # skip cwagent configuration push
                #elif event.get('subaction') == 'thisregion':
                #    skipconfig = 1
                #    print()
                    #targetregions.append(event.get('thisregion'))
                elif event.get('subaction') in ['table', 'function','rdsinstance']:
                    skipconfig = 1 # skip cwagent configuration push
                elif event.get('subaction') == 'thisinstance':
                    instanceids.append(event['widgetContext']['forms']['all'].get('singleinstanceid'))
                    if event.get('pushconfig') == 'no': #set to skip pusing config
                        skipconfig = 1
                
                ### create request items
                print(__name__,'len of regions:{} | regions: {}'.format(len(targetregions), targetregions))
                currentids = 0
                if len(targetregions) > 0:
                    for thisRegion in targetregions:
                        ## set target instances
                        if event.get('resourcetype') == 'cw-profile':
                            if event.get('subaction') != 'thisinstance': # process multiple instances
                                instanceids = get_instances(Account, thisRegion, Profile,ProfileType,None)
                                currentids += len(instanceids)
                            elif len(instanceids) == 1: # process single instance
                                instanceids = get_instances(Account, thisRegion, Profile,ProfileType,instanceids[0])
                                currentids += len(instanceids)
                        elif event.get('resourcetype') == 'lambda-profile':
                            if event.get('subaction') != 'thisinstance': # process multiple lambda functions
                                instanceids = get_instances(Account, thisRegion, Profile,ProfileType,None)
                                currentids += len(instanceids)
                            elif len(instanceids) == 1: # process single lambda function
                                instanceids = get_instances(Account, thisRegion, Profile,ProfileType,instanceids[0])
                                currentids += len(instanceids)
                        for targetinstance in instanceids:
                            print(__name__,'--- sending to queue to create alarms for {} in region: {}'.format(targetinstance,thisRegion))
                            msg_body = str({ "Function": 'cw_lifecycle', "tenant": Tenant,"account": Account, "instance": targetinstance, "region": thisRegion, "resource": "ec2","reboot": "no", "mode": 1, "skipconfig": skipconfig })
                            hcom.update_central_queque(msg_body,hcom.setSQS['HCOM-PlatformAutomation'])
                page += '<center>Number of instances impacted (<b>'+ str(currentids) + '</b>).</center>'
                if currentids == 0:
                    page += '<center><b>No instances were impacted. Please check that the instances are turned on and have the target CloudWatch Profile tag value for this Profile.</b></center>'
            ### Begin navigation menu
            theseAccounts = hcom.get_tenant_accounts(Tenant,True) # only get active accounts
            print(__name__,'---- these accounts:{} Account:{} Tenant: {}'.format(theseAccounts, Account, Tenant))
            if Account == ''  or Account == 'Select' or len(theseAccounts) == 1 or Account not in theseAccounts:
                Account = theseAccounts[0]
                print(__name__, 'Account reassigned from first account number', Account)
            page +=  '<table ><tr><th ><b>(1)</b> &nbsp; Select Tenant & Account:</th>'
            page +=  '<td><form id="tenant"><select id="Tenant" name="Tenant">'
            page +=  '<option value="Select">Select</option>'
            for tenant, accounts in hcom.setTenants.items():
                if Tenant == tenant:
                    selected = 'selected'
                else:
                    selected = ''
                page +=  '<option value="' + tenant + '" ' + selected + '>' + tenant + '</option>'
            page +=  '</select></form></td>'
            page +=  '<td><a class="btn btn-primary">Select Tenant</a>'
            page +=  '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "reset" }</cwdb-action></td>'
            ### begin account number section
            page +=  '<td><form id="account"><select id="Account" name="Account">'
            page +=  '<option value="Select">Select</option>'
            for acctnum in theseAccounts:
                if Account != '':
                    if Account == acctnum:
                        selected = 'selected'
                    else:
                        selected = ''
                    page +=  '<option value="' + acctnum + '" ' + selected + '>' + acctnum + '</option>'
            page +=  '</td></select></form><td><a class="btn btn-primary">Select Managed Account </a>'
            page +=  '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3,"Tenant": "' + Tenant + '" }</cwdb-action></td></tr>' #</tr></table>'
            print(__name__,page)
            #### profile type drop-down
            page += '<tr><th><b>(2)</b> Select Type & Profile</th>'
            page += '<td><form id="resourcetype"><select id="resourcetype" name="resourcetype">'
            page = page + '<option value="Select">Select</option>'
            for var in hcom.setCWResourceTypes['resourcetypes']:
                #resourcetype2 = ast.literal_eval(resourcetype2)
                print(__name__,'1316 var type: {} '.format(type(var)))
                for x, y in var.items():
                    print(__name__,'1318 x and y: {} | {}'.format(x, y))
                    for z,a in y.items():
                        print(__name__,'1320 z: {} | a: {}'.format(z,a))
                        if z == 'service':
                            typename = a
                    if x == resourcetype:
                        selected = 'selected'
                    else:
                        selected = ''
                    page +=  '<option value="' + x + '" ' + selected + '>' + typename + '</option>'
                page +=  '</select></form></td>' # last changed 8/11
                page = page + '<td><a class="btn btn-primary">Select Service</a>'
                page = page + '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3 }</cwdb-action></td>'

                
                if didaction == 0 and resourcetype != '': #already got profiles
                    templates = get_profiles(dbcon,resourcetype,Tenant,Account,True) # only get templates
                    temphtml = ''
                    configuration2 = templates['Items']
                    print(__name__,'templates found: {}'.format(configuration2))
                    
                    for j in range(templates['Count']):
                        ThisProfile = configuration2[j]['ProfileType']['S']
                        varName = configuration2[j]['mspname']['S'] # this is the friendly name not the profile number
                        temphtml += '<option value="' + varName + '" ' + selected + '>' + varName + '&nbsp;|&nbsp;' +  ThisProfile + '&nbsp;|&nbsp; Managed Template' + '</option>'
                    temphtml += '<option value="">--- Managed Templates Above ---</option>'
                    print(__name__,'found templates: {}'.format(temphtml))
                    profiles = get_profiles(dbcon,resourcetype,Tenant,Account,False) # don't get any templates
                    configuration1 = templates['Items'] + profiles['Items']
                
                    print(__name__,'profiles:', profiles['Count'],configuration1)
                if resourcetype != '': # load profile list drop-down
                    page += '<td><form id="profile"><select id="Profile" name="Profile">'
                    page += '<option value="Select">Select</option>'
                    #page += temphtml
                    for j in range(len(configuration1)): #profiles['Count']):
                        description = '&nbsp;|&nbsp; Managed Template'
                        ThisProfile = configuration1[j]['ProfileType']['S']
                        varName = configuration1[j]['mspname']['S'] # this is the friendly name not the profile number
                        print(__name__,'if ', varName, ' = ', Profile)
                        print(__name__,' this row: {}'.format(configuration1[j]))
                        if Profile == str(configuration1[j]['mspname']['S']):
                            selected = 'selected'
                            ThisName = varName
                            ProfileType = configuration1[j]['ProfileType']['S']
                            try:
                                if configuration2[j]['Description']['S'] is not None:
                                    description = '&nbsp;|&nbsp; Managed Template | &nbsp;' + configuration2[j]['Description']['S']
                                else: 
                                    description = '&nbsp;|&nbsp; Managed Template'
                            except Exception as error:
                                pass
                        else:
                            selected = ''
                        if int(varName) > 10:
                            page = page + '<option value="' + varName + '" ' + selected + '>' + varName + '&nbsp;|&nbsp;' +  ThisProfile + '</option>' #'&nbsp;|&nbsp;' + configuration1[j]['Region']['L'] + '</option>'
                            """ not sure what purpose of this section is - might be obsolete and its causing issues
                            try:
                                if configuration1[j]['Region']['L']: 
                                    oldregion = configuration1[j]['Region']['L']
                            except KeyError as e:
                                oldregion = ''
                                pass
                            """
                        else:
                            page = page + '<option value="' + varName + '" ' + selected + '>' + varName + '&nbsp;|&nbsp;' +  ThisProfile + description + '</option>'
                    page = page + '</select></form></td>'

                    page = page + '<td><a class="btn btn-primary">Select Profile</a>'
                    page = page + '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "resourcetype": "' + resourcetype +  '" }</cwdb-action></td></tr>'               
                
                ### once all fields have been selected show alarms with option to modify
                if profiles !='' and resourcetype !='' and ProfileType !='': # show detail list of selected profile alarms
                    alarms = table.get_item(Key={'msptype': resourcetype, 'mspname': str(Profile)}) # get profile alarms
                    print('alarms:{} | {}'.format(oldregion,alarms))
                    if alarms['Item']['isTemplate'] == False and resourcetype == 'cw-profile':
                        oldregion = alarms['Item']['Region']
                        print(__name__,'old region: {}'.format(oldregion))
                    page += '<tr><th ><b>(3)</b>  Profile Options</th>'
                    page = page + '<td><a class="btn btn-primary">Duplicate Profile ' + Profile + '</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "duplicate", "Profile": ' + str(Profile) + ',"resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '","region": "' + ThisRegion + '" }</cwdb-action></td>'
                    if int(Profile) > 10:
                        page = page + '<td><a class="btn btn-primary">Delete Profile ' + Profile + '</a><cwdb-action action="call" confirmation="Are you sure you want to delete this profile?" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "delete", "Profile": ' + str(Profile) + ',"resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '","region": "' + str(oldregion) + '" }</cwdb-action></td>'
                        if resourcetype == 'cw-profile':
                            page += '<td><form id="region"><input type="text" id="newregion" name="newregion" value="' + str(oldregion) + '" size="30"></form>'
                            page +=  '</td><td><a class="btn btn-primary">Update Regions' + Profile + '</a><cwdb-action action="call" confirmation="Are you sure you want to change the region for this profile?" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "region", "Profile": ' + str(Profile) + ',"resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '","region": "' + ThisRegion + '","profiletype": "' + alarms['Item']['ProfileType'] + '","oldregion": "' + str(oldregion) + '" }</cwdb-action></td>'
                        else: # blank cells since no region to deal with
                            page += '<td colspan="2"></td>'
                        page = page + '</tr>'
                        page += '<tr><th ><b>(4)</b>  Create Alarms</th>'
                        # all regions with config
                        explanation = " All target instances must be turned on and with required tags for CloudWatch-Profile and Environment. Instances stopped will be skipped. HCOM is event-driven. Consequently, when stopped instances are turned on later, they will automatically get CW Agent config push and alarms created."
                        
                        ### check with profile type
                        print('resourcetype check: {}'.format(resourcetype))
                        if resourcetype == 'cw-profile':
                            page += '<td><a class="btn3 ">All Regions & push CWAgent config</a><cwdb-action action="call" confirmation="Are you sure you want to initiate alarm creation for all instances using this profile along with pushing the latest CloudWatch Agent configuration?'+explanation+'" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "createalarms", "subaction": "allregionsconfig","Profile": ' + str(Profile) + ',"profiletype": "' + alarms['Item']['ProfileType'] + '","resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '","targetregions": "' + str(oldregion) + '" }</cwdb-action>'
                            for profileregion in oldregion:
                                page += ' <br><a class="btn3 ">' + profileregion + ' Region</a><cwdb-action action="call" confirmation="Are you sure you want to initiate alarm creation for all instances with this profile along with pushing the latest CloudWatch Agent configuration?'+explanation+'" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "createalarms", "subaction": "thisregionconfig", "targetregions": ["' + profileregion + '"], "Profile": ' + str(Profile) + ',"profiletype": "' + alarms['Item']['ProfileType'] + '","resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '" }</cwdb-action>'
                            page += '</td>'
                            ### all regions without config
                            page += '<td><a class="btn3 ">All Regions</a><cwdb-action action="call" confirmation="Are you sure you want to initiate alarm creation for all instances using this profile along with pushing the latest CloudWatch Agent configuration?'+explanation+'" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "createalarms", "subaction": "allregions","Profile": ' + str(Profile) + ',"profiletype": "' + alarms['Item']['ProfileType'] + '","resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '","targetregions": "' + str(oldregion) + '" }</cwdb-action>'
                            for profileregion in oldregion:
                                page += ' <br><a class="btn3 ">' + profileregion + ' Region</a><cwdb-action action="call" confirmation="Are you sure you want to initiate alarm creation for all instances with this profile along with pushing the latest CloudWatch Agent configuration?'+explanation+'" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "createalarms", "subaction": "thisregion", "targetregions": ["' + profileregion + '"], "Profile": ' + str(Profile) + ',"ProfileType": "' + alarms['Item']['ProfileType'] + '","resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '" }</cwdb-action>'
                            page += '</td>'
                            ### do single instance
                            page += '<td><form id="createalarms"><input type="text" id="singleinstanceid" name="singleinstanceid" value="i-insertinstanceid" size="30"></form>'
                            page +=  '</td><td><a class="btn3 ">Single Instance & push CWAgent config</a><cwdb-action action="call" confirmation="Are you sure you want to initiate alarm creation for this instance? The instance must be turned on and with required tags for CloudWatch-Profile and Environment." endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "createalarms", "subaction": "thisinstance", "pushconfig": "yes","Profile": ' + str(Profile) + ',"resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '","targetregions": "' + str(oldregion) + '","profiletype": "' + alarms['Item']['ProfileType'] + '" }</cwdb-action>'
                            if len(oldregion) > 1:
                                page += ' <br> <a class="btn3 ">Single Instance</a><cwdb-action action="call" confirmation="Are you sure you want to initiate alarm creation for this instance? The instance must be turned on and with required tags for CloudWatch-Profile and Environment." endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "createalarms", "subaction": "thisinstance", "pushconfig": "no", "Profile": ' + str(Profile) + ',"resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '","targetregions": "' + str(oldregion) + '","profiletype": "' + alarms['Item']['ProfileType'] + '" }</cwdb-action>'
                            page += '</td>'
                        else: # all other profiles
                            ### do single instance
                            if resourcetype == 'lambda-profile':
                                resourceid = 'Function Name'
                                subaction = 'singlefunction'

                            elif resourcetype == 'dynamodb-profile':
                                resourceid = 'Table Name'
                                subaction = 'singletable'
     
                            elif resourcetype == 'rds-profile':
                                resourceid = 'Instance Name'
                                subaction = 'singlerdsinstance'

                            else:
                                resourceid = 'resource id'
                            ### all regions without config
                            print('region check: {}'.format(oldregion))
                            page += '<td colspan="2"><a class="btn3 ">All Regions</a><cwdb-action action="call" confirmation="Are you sure you want to initiate alarm creation for all instances using this profile along with pushing the latest CloudWatch Agent configuration?'+explanation+'" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "createalarms", "subaction": "allregions","Profile": ' + str(Profile) + ',"profiletype": "' + alarms['Item']['ProfileType'] + '","resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '","targetregions": "' + str(oldregion) + '" }</cwdb-action>'
                            for profileregion in oldregion:
                                page += ' <br><a class="btn3 ">' + profileregion + ' Region</a><cwdb-action action="call" confirmation="Are you sure you want to initiate alarm creation for all instances with this profile along with pushing the latest CloudWatch Agent configuration?'+explanation+'" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "createalarms", "subaction": "thisregion", "targetregions": ["' + profileregion + '"], "Profile": ' + str(Profile) + ',"ProfileType": "' + alarms['Item']['ProfileType'] + '","resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '" }</cwdb-action>'
                            page += '</td>'
                            
                            page += '<td><form id="createalarms"><input type="text" id="singleinstanceid" name="singleinstanceid" value="' + resourceid +'" size="30"></form>'
                            page +=  '</td><td><a class="btn3 ">Single Instance</a><cwdb-action action="call" confirmation="Are you sure you want to initiate alarm creation for this instance? The instance must be turned on and with required tags for CloudWatch-Profile and Environment." endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "createalarms", "subaction": "'+ subaction +'", "pushconfig": "no", "Profile": ' + str(Profile) + ',"resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '","targetregions": "' + str(oldregion) + '","profiletype": "' + alarms['Item']['ProfileType'] + '" }</cwdb-action>'
                            if len(oldregion) > 1:
                                page += ' <br> <a class="btn3 ">Single Instance</a><cwdb-action action="call" confirmation="Are you sure you want to initiate alarm creation for this instance? The instance must be turned on and with required tags for CloudWatch-Profile and Environment." endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 3, "action": "createalarms", "subaction": "'+ subaction +'", "pushconfig": "no", "Profile": ' + str(Profile) + ',"resourcetype": "' + resourcetype +  '","Tenant": "' + Tenant + '","Account": "' + Account + '","targetregions": "' + str(oldregion) + '","profiletype": "' + alarms['Item']['ProfileType'] + '" }</cwdb-action>'
                            page += '</td>'
                    
                    else:
                        page = page + '<td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>'
                    page = page + '</tr></table>'

                    #### Show detailed view of selected profile
                    print(__name__,'page check: {}'.format(page))
                    page = page + '<p><center>To create a new CloudWatch Profile, first select one from the drop-down and click "Select Profile". Then click the duplicate Button. <br>In the same manner you can delete a profile. Note Profiles up to # 10 are managed profiles and can only be duplicated. You can then edit the new duplicate.</center>'
                    #print(__name__,'selected profile',ThisId, ThisMetricName)
                    #### show table for selected CloudWatch Profile
                    if Profile != "":
                        page = page+ '<table >'
                        if int(Profile) > 10: # not a template
                            page += '<tr ><th >Options </th> <th >Category | Metric Name | Namespace</th><th >Process Name</th><th >Threshold </th><th >Operator </th><th >Data Points </th> <th >Eval Period </th><th >Polling Period </th><th >Alarm Action</th></tr>\n'
                        else: # template
                            page += '<tr ><th >Metric Name | Namespace</th><th >Process Name</th><th >Threshold </th><th >Operator </th><th >Data Points </th> <th >Eval Period </th><th >Polling Period </th><th >Alarm Action</th></tr>\n'
                            print(__name__,'profile:{}'.format(Profile))

                        #alarms = table.get_item(Key={'msptype': resourcetype, 'mspname': str(Profile)})
                        alarmdef1 = alarms['Item']['alarms']
                        alarmdef = dict(sorted(alarmdef1.items()))
                        rows = len(alarmdef)
                        
                        print(__name__, 'rows:', rows, alarmdef.keys(),alarmdef)
                        for key, value in alarmdef.items(): # loop through alarm definitions
                                #print(__name__,'key', key)
                                #print(__name__,'value', value)
                                ThisId = key
                                #value = ast.literal_eval(value)
                                print(__name__, 'alarm row:', ThisId, value)
                                OI=0 #reset
                                OISeverity = ''
                                OICategory = ''
                                processName = 'N/A'
                                #counter = counter + 1
                                #alarmType = varName
                                alarmPath = ''
                                ThisResponseType = ''
                                ThisResponseName = ''
                                ThisMetric = value.get('metricname')
                                ThisMetricCategory = value.get('metriccategory')
                                ThisOperator = value.get('operator')
                                ThisThreshold = int(value.get('threshold'))
                                ThisEvalPeriod = int(value.get('evaluationperiods'))
                                ThisDataPoints = int(value.get('datapoints'))
                                ThisPeriod = int(value.get('period'))
                                ThisData = value.get('TreatMissingData')
                                if value.get('opsitempriority'):
                                    OISeverity = int(value.get('opsitempriority'))
                                    OI = 1
                                if value.get('opsitemcategory'):
                                    OICategory = (value.get('opsitemcategory'))
                                    OI = 1
                                if value.get('type'):
                                    alarmPath = value.get('type')
                                if value.get('name'):
                                    processName = value.get('name')
                                    OI = 1
                                if value.get('ResponseName'):
                                    ThisResponseName = value.get('ResponseName')
                                if value.get('namespace'):
                                    ThisNameSpace = value.get('namespace')
                                if value.get('ResponseType'):
                                    ThisResponseType = value.get('ResponseType')
                                    
                                    if ThisResponseType == 'Stop': ### check for alarm action automations to invoke EC2 state changes
                                        ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + Account +':action/actions/AWS_EC2.InstanceId.Stop/1.0'
                                    elif ThisResponseType == 'Reboot':
                                        ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + Account +':action/actions/AWS_EC2.InstanceId.Reboot/1.0'
                                    else:
                                        ec2Action = ''
                                else:
                                    ec2Action = ''
                                page = page + '<tr ><td >'#<a >Delete</a><cwdb-action action="call" confirmation="Are you sure" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-Platform-Configuration-Manager" display="widget"> { "Action": "Delete", "Type": "Alarm", "id": "' + ThisId + '", "profile": "' + str(ThisName) + '" } </cwdb-action>' 
                                #page = page + ' | <a>Duplicate</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-Platform-Configuration-Manager" display="widget"> { "Function": "CW","Action": "Duplicate", "Item": "profile", "id": "' + ThisId + '", "profile": "' + str(ThisName) + '" } </cwdb-action>'
                                if int(Profile) > 10: # not a template
                                    page += '<a class="btn btn-primary">Modify</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-Platform-Configuration-Manager" display="widget"> { "Function": "CW","Action": "Modify", "Item": "profile", "alarmid": "' + str(ThisId) + '","profile": "' + str(Profile) + '", "resourcetype": "' + resourcetype +  '", "profiletype": "' + ProfileType + '", "namespace": "' + ThisNameSpace + '","Tenant": "' + Tenant + '","Account": "' + Account + '","region": "' + ThisRegion + '","metriccategory": "' + str(ThisMetricCategory) + '" } </cwdb-action>  </td> <td>' + str(ThisMetricCategory) + ' | ' + str(ThisMetric) + ' | ' + str(ThisNameSpace) +' </td><td >' + str(processName) + ' </td><td >' + str(ThisThreshold) + ' </td><td >' + str(ThisOperator) + ' </td><td >' + str(ThisDataPoints) + ' </td><td >' + str(ThisEvalPeriod) + ' </td><td >' + str(ThisPeriod) + ' </td><td>' + str(ThisResponseType) + ' </td>  </tr>\n'    
                                else: # template
                                    page += str(ThisMetric) + ' | ' + str(ThisNameSpace) +' </td><td >' + str(processName) + ' </td><td >' + str(ThisThreshold) + ' </td><td >' + str(ThisOperator) + ' </td><td >' + str(ThisDataPoints) + ' </td><td >' + str(ThisEvalPeriod) + ' </td><td >' + str(ThisPeriod) + ' </td><td >' + str(ThisResponseType) + ' </td>  </tr>\n'    
                        page += '</table>'
                    
                    return page
                else: # CloudWatch feature is disabled
                    page += '</tr></table>'
                    return page
        elif Mode == 5: # Manage Tenants
            background1: String = 'text-align:center;'
            bgcolor: String = '#bccad6'

            print(__name__, 'region:', ThisRegion)
            ##### begin account select form
            if event.get('Tenant'):
                Tenant: String = event.get('Tenant')
            elif event['widgetContext']['forms']['all'].get('Tenant'):
                Tenant: String = event['widgetContext']['forms']['all'].get('Tenant')
            if event.get('action') == 'add' and Tenant != '' and Tenant not in hcom.setTenants:
                tempacc = str(random.randrange(10**11, 10**12)) + 'Z'
                if hcom.setPartition.find('gov') > -1:
                    nregions = ['us-gov-east-1', 'us-gov-west-1']
                else:
                    nregions = ['us-east-1', 'us-west-1']

                acctTemplate = {'account': str(tempacc), 'acctname': 'replaceZ', 'Active': False, 'Regions': nregions, 'Environments': ['TEST', 'DEV'], 'Backup': {'Most Recent Backup': '36'}, 'Webhook': {'channel-name': 'collaboration', 'channel-url': 'replace with url'}, 'Features': {'AWSBackup': True, 'CloudWatch': True, 'OnPrem': False, 'SSMOpsItems': False, 'StateMgmt': True, 'Webhooks': False}, 'Tags': {'description': 'Description', 'environment': 'Environment', 'patch': 'Patch Group', 'product': 'Product', 'role': 'Product-Role'}, 'Topics': {'General': 'arn:partition:sns:region:centralaccount:replacewithtopicname', 'HelpDesk': 'arn:partition:sns:region:centralaccount:replacewithtopicname'}}

                #acctTemplate = {'account': '', 'acctname': 'rename me', 'Active': False, 'Regions': ['us-gov-east-1'],'Environments': ['DEV','TEST','PROD'], 'Features': {'AWSBackup':False,'CloudWatch':True,'OnPrem':False,'PatchMgmt':True,'SSMOpsItems':False,'StateMgmt':True,'Webhooks':False}, 'Tags': {'description':'Description','environment': 'Environment', 'patch': 'Patch Group', 'product': 'Product', 'role': 'Role'}, 'Topics': {'General':'','HelpDesk':''} }
                #acctTemplate['account'] = str(tempacc)
                newtenant = {'msptype': 'tenant', 'mspname': Tenant, 'accounts': [acctTemplate]}

                response = table.put_item(Item=newtenant)
                #hcom.clear_caches()
                if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                    #### log event in EventBridge
                    ## get schema/dictionary
                    etype = 'cw-event'
                    ename = 'tenant'
                    etarget = 'StateChange'
                    eventFormat = hcom.get_hcom_event(etype,ename,etarget)
                    # assign event values
                    source = 'hcom.tenant'
                    eventFormat['Detail']['tenant'] = Tenant
                    eventFormat['Detail']['state'] = 'added'
                    eventresponse = hcom.put_hcom_event(source,json.dumps(eventFormat['Detail']),eventFormat['DetailType'])
                    return '<b>New Tenant created.</b> You will need to refresh the widgets below to pickup the change. <br>The new account has been created with an initial dummy AWS account.<br> You will need to use the AWS Account Management Widget below to update the dummy <br>account with a valid AWS account number,friendly name, and make it Active to start using it.'
                else:
                    return {'stateCode': response['ResponseMetadata']['HTTPStatusCode'], 'statusmessage': error}
            elif event.get('action') == 'flush':
                #hcom.clear_caches()
                print()
                return '<b>Caches have been cleared.</b> You will need to refresh CloudWatch Dashboards to pickup any new tenant, account, or platform settings.'
            page += '<table >'
            
            page += '<tr><th>Existing Tenants:</th>'
            page += '<td><form><select id="Tenant" name="Tenant">'
            page += '<option value="Select"></option>'
            for tenant in hcom.setTenants:
                if Tenant == tenant:
                    selected: String = 'selected'
                else:
                    selected: String = ''
                page += '<option value="' + tenant + '" ' + selected + '>' + tenant + '</option>'
            page += '</select></form></td>'
            #page += '<td></td></tr>'
            #page += '<td><a class="btn btn-primary">Edit</a>'
            #page += '<cwdb-action action="call" endpoint="arn:'+ hcom.setPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 5, "action": "edit"}</cwdb-action></td></tr>'
            #page += '<tr><td>Options<td>'
            page += '<td><a class="btn btn-primary">New</a>'
            page += '<cwdb-action action="call" endpoint="arn:'+ hcom.setPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 5, "action": "new" }</cwdb-action></td>'
            page += '<td><a class="btn btn-primary">Clear Tenant & Account Cache</a>'
            page += '<cwdb-action action="call" endpoint="arn:'+ hcom.setPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 5, "action": "flush" }</cwdb-action></td></tr></table>'
            print(__name__,page)
          
            if event.get('action') == 'edit' and event['widgetContext']['forms']['all'].get('Tenant') != 'Select':
                ### begin account table
                page += '<br><table ><form>'
                page += '<tr ><th >Tenant Name</th><td ><input id="tenant" name="tenant" type="text" size="20" value="' + str(Tenant) + '"</td></tr>'
                page += '<tr style="border: 1px solid black; "><td colspan="2" align="center"><a class="btn btn-primary">Update</a><cwdb-action action="call" confirmation="Are you sure you want to make this change? Any existing platform objects referencing this tenant name will be orphaned while still incuring AWS usage charges." endpoint="arn:'+ hcom.setPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 5, "action": "update" }</cwdb-action></td></tr></form></table>\n'
                page += '<b>USE CAUTION!!</b> Names are a critical part of platform object names. Do not modify existing tenant names if platform objects like CloudWatch,State, and Patch profiles exist. Delete all platform components before changing an existing Tenant name. Otherwise, you will orphan platform objects that will no longer be managed but may still incur AWS usage charges.'
            elif event.get('action') == 'new':

                ### begin account table
                page += '<br><table ><form>'
                page += '<tr ><th >New Tenant Name</th><th ><input id="Tenant" name="Tenant" type="text" size="20" value="new name here"</th></tr>\n'
                page += '<tr style="border: 1px solid black; "></form><td colspan="2" align="center"><a class="btn btn-primary">Add</a><cwdb-action action="call" confirmation="Please confirm the spelling for this tenant as you will not be able to edit it later. Tenant names get embedded in objects created and thus can not be changed later." endpoint="arn:'+ hcom.setPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 5, "action": "add" }</cwdb-action></td></tr></table>\n'

            
            return page
        elif Mode == 6: # core platform configuration
            configuration1 = dbcon.query(
                TableName=hcom.setDBTable,
                Select='ALL_ATTRIBUTES',
                ConsistentRead=True, 
                KeyConditionExpression='msptype = :core',
                #FilterExpression: 'contains(mspname, :val1)',
                ExpressionAttributeValues={':core':{'S': 'core'}})
            results = configuration1['Items']
            rows = len(results)
            print(__name__,'results:', len(results), results)
            page = page + '<table ><tr >'
            for i in results: # for each row of core settings
                if i['mspname']['S'] != 'gui':
                    #page = page + '<tr><td>'
                    cols = len(i)
                    ### begin account table
                    
                    page = page + '<th style="text-align:center"><a class="btn btn-primary">' + i['mspname']['S'] + '</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 7, "config": "' + i['mspname']['S'] +'" }</cwdb-action></th>' 
                    #page = page + '<tr >'
                    #print(__name__,'len:', len(i),'row:',i)
            page = page + '</tr></table><br>\n'
                    
            
            return page
        elif Mode == 7:
            configuration1 = dbcon.query(
                TableName=hcom.setDBTable,
                Select='ALL_ATTRIBUTES',
                ConsistentRead=True, 
                KeyConditionExpression='msptype = :core',
                #FilterExpression: 'contains(mspname, :val1)',
                ExpressionAttributeValues={':core':{'S': 'core'}})
            results = configuration1['Items']
            rows = len(results)
            print(__name__,'results:', len(results), results)
            page = page + '<table , align="left">'
            for i in results: # for each row of core settings
                if i['mspname']['S'] == event.get('config'):
                    page = page + '<tr><td>'
                    cols = len(i)
                    ### begin account table
                    page = page + '<br><table , align="left">'
                    page = page + '<tr ><th style="text-align:center"><a class="btn btn-primary">Update ' + i['mspname']['S'] + '</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 7, "Function": "Core", "Item": "' + i['mspname']['S'] +'" }</cwdb-action></th></tr>\n'
                    #page = page + '<tr >'
                    print(__name__,'len:', len(i),'row:',i)
                    
                    for setting, value in i.items(): # for each attribute value pair
                        print(__name__,'this setting:', setting)
                        if setting !='mspname' and setting !='msptype':
                            page = page + '<tr ><th>' + setting + ': ' + value['S'] + '</th></tr>'
                    page = page + '</table><br>\n'
                    page = page + '</td></tr>'
            page = page + '</table>'
            
            return page
        elif Mode == 8: ## manage AWS Accounts and features
            dup=0
            delete = 0
            didaction = 0
            updatetenant = 0 # flag to track change in tenant assigned to aws account
            print(__name__,'event:{}'.format(event))
            if event['widgetContext']['forms']['all'].get('Account'):
                Account = str(event['widgetContext']['forms']['all'].get('Account'))
            elif event.get('Account'):
                Account = str(event.get('Account'))
            print(__name__,'target account: {}',format(Account))
            if event['widgetContext']['forms']['all'].get('Account'):
                Account = event['widgetContext']['forms']['all'].get('Account')
                print(__name__, 'Account assigned from form', Account)
            elif event.get('Account'):
                Account = event.get('Account','')
                print(__name__, 'Account assigned from event', Account)
            else:
                Account = ''
                print(__name__, 'Account assigned by default', Account)
            if event['widgetContext']['forms']['all'].get('Tenant'):
                Tenant = event['widgetContext']['forms']['all'].get('Tenant')
                print(__name__, 'Tenant assigned from form', Tenant)
            elif event.get('Tenant'):
                Tenant = event.get('Tenant')
                print(__name__, 'Tenant assigned from event', Tenant)
            if Action == 'duplicate': # create a duplicate of the Account
                account = enroll_account(table,Tenant,Account,'existing')
                Account = account['account']
                ## clear caches
                #hcom.clear_caches()
                ## reload new values
                hcom.core_initializer(ThisRegion) # reload new values
                Action = '' # resetting action for full table display
            elif Action == 'toggle': # change Active status
                ### delete Account
                isvalid = hcom.is_valid_account(Account)
                print(__name__,'{} is it valid? {}'.format(Account,isvalid))
                if isvalid == True: # is this a valid AWS account format
                    didaction = 1
                    try:
                        thisrecord = hcom.get_account(Tenant,Account) # get current account

                    except ClientError as error:
                        print(__name__,'exception:{}'.format(error))
                        pass
                    try:
                        print(__name__,'Updating Account:{}'.format(thisrecord))
                        #thisrecord.pop("msptype")
                        #thisrecord.pop("name")
                        if str(event.get('Active')) == 'True':
                            thisrecord["Active"] = True
                        else:
                            thisrecord["Active"] = False
                        #thisrecord["Active"] = str(event.get('Active'))
                        print(__name__,'after Active update but pre db update: {}|{}'.format(str(thisrecord["Active"]),str(thisrecord) ))
                        response = table.update_item(Key={'msptype': 'tenant', 'mspname': str(Tenant)}, #### need to switch this to client not resource update.
                        UpdateExpression='SET #active = :active',
                        ExpressionAttributeNames={'#active': 'Active' },
                        ExpressionAttributeValues={':active': thisrecord["Active"]},
                        ConditionExpression=Attr('account').eq(Account))
                        ## clear caches
                        #hcom.clear_caches()
                        ## reload new values
                        hcom.core_initializer(ThisRegion) # reload new values
                        """
                        UpdateExpression='SET #alm = :alm, #type = :type',
                        ExpressionAttributeNames={'#alm': 'alarms','#type': 'ProfileType' },
                        ExpressionAttributeValues={':alm': alarmdetails, ":type": profiletype})
                        """
                    except ClientError as error:
                        print(__name__,'exception:{}'.format(error))
                        return {'statusCode': 500, 'message': str(error)}
                    account = thisrecord
                else:
                    print(__name__,'Not a valid AWS Account format: {}. You must update this to a valid AWS Account number before you can make it Active.'.format(Account))
                    message = 'Not a valid AWS Account format: {}. You must update this to a valid AWS Account number before you can make it Active.'.format(Account)
                    return {'statusCode': 400, 'message': message}
            ##### begin account select form

            theseAccounts = hcom.get_tenant_accounts(Tenant, False) # get all accounts since this is account management
            print(__name__,'these accounts:', theseAccounts, Account)
            if Account == ''  or Account == 'Select' or len(theseAccounts) == 1 or Account not in theseAccounts:
                Account = theseAccounts[0]
                print(__name__, 'Account reassigned from first account number', Account)
            page +=  '<table ><tr><thead><th colspan="5"><b>(1)</b> &nbsp;Select Account Filters:</th></thead></tr>'
            page +=  '<tr><td><form><select id="Tenant" name="Tenant">'
            page +=  '<option value="Select">Select</option>'
            for tenant, accounts in hcom.setTenants.items():
                if Tenant == tenant:
                    selected = 'selected'
                else:
                    selected = ''
                page +=  '<option value="' + tenant + '" ' + selected + '>' + tenant + '</option>'
            page +=  '</select></form></td>'
            page +=  '<td><a class="btn btn-primary">Select Tenant</a>'
            page +=  '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 8 }</cwdb-action></td>'
            ### begin account number section
            page +=  '<td></form><select id="Account" name="Account">'
            page +=  '<option value="Select">Select</option>'
            for acctnum in theseAccounts:
                if Account != '':
                    if Account == acctnum:
                        selected = 'selected'
                    else:
                        selected = ''
                    
                    activestatus = hcom.get_tenant_account_attribute(Tenant,acctnum,'Active')
                    print(__name__,' is account active:{} | {}'.format(acctnum, activestatus))
                    if activestatus == True:
                        background3 = ''
                    else:
                        background3 = ' (disabled)'
                    page +=  '<option value="' + acctnum + '" ' + selected + '>' + acctnum + background3 + '</option>'
            page +=  '</td></form><td><a class="btn btn-primary">Select Managed Account</a>'
            page +=  '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 8, "account": "' + str(Account) + '","Tenant": "' + Tenant + '" }</cwdb-action></td>' #</tr></table>'
            print(__name__,page)
           
            #configuration1 = hcom.setTenantAccounts2 # get account list from core initialization
            if didaction == 0:
                account = hcom.get_account(Tenant, Account) # get current account
                print(__name__,'----- no action so loading from global:{}'.format(account))
            #rows = len(configuration1)
            #print(__name__,'Accounts:', len(configuration1),configuration1)
            page += '</select></form></td>'
            print(__name__,'Active state is:{}'.format(str(account.get('Active'))))
            if str(account.get('Active')) == 'True' or str(account.get('Active')) == 'true':
                toggleActive = 'Disable'
                toggleValue = 'False'
            else:
                toggleActive = 'Enable'
                toggleValue = 'True'
            
            page += '<td><a class="btn btn-primary">Enroll pre-existing AWS account for the selected tenant.</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 8, "action": "duplicate", "Tenant": "' + Tenant + '","Account": "' + str(Account) + '" }</cwdb-action></td>'
            #page += '<td><a class="btn btn-primary">' + toggleActive + ' Account ' + Account + '</a><cwdb-action action="call" confirmation="Are you sure you want to change the Active state for this Account?" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 8, "action": "toggle", "Account": "' + str(Account) + '","Active": "' + str(toggleValue) + '" }</cwdb-action></td>'
            page += '</tr></table>'
            #"""
            page += '<center>To <b>view</b> the platform configuration for a managed AWS Account, first select a managed account from the drop-down and click "Select Managed Account".<br>To <b>disable</b> a managed AWS account, set "Active" to False. To <b>add</b> AWS account, click the Duplicate button to copy current settings into a new Account.</center><br>'
            page += '<br><center><table width="65%"><tr><td style="background-color:tomato;"><p ><b>NOTE:</b></p></td>'
            page += '<td> <ul><li><b><i>Managed AWS Accounts can be disabled but not deleted.</i></b> Disabling by changing the Active status to False only stops future audit reports and limit some platform features. Pre-existing CloudWatch, State, and Patch profiles will continue to exist and work since they utilize cloud-native servicves.</li>'
            page += '<li>When you add a managed account through "duplication",  it will not be active by default and must be edited to enter a valid existing AWS account number, friendly account name, and make sure you deploy the Cloudformation template for managed AWS accounts first, then may the account Active.</li>'
            page += '<li><b><i>Changing the Systems Manager OpsItems (SSMOpsITems) </i></b>feature flag will require recreating all assocated alarms to remove or add the alarm action for OpsItems.</li>'
            page += '<li><b><i>Changing Account Name </i></b>will not update any prexisting profiles and state associations that have the previous Account Name embedded.</li></ul></td></tr></table></center>'
            if Action == '' or Action == 'update' and Tenant !='':
                deleteold = 0
                ActiveOptions = [True,False] # valid Active options
                if Action == 'update':
                    print(__name__,'widget:{}'.format(event['widgetContext']))
                    print(__name__,'widget: {}'.format(event))
                    #account['Active'] = str(event['widgetContext']['forms']['all'].get('Active'))
                    
                    if str(event['widgetContext']['forms']['all'].get('Active')) == 'True':
                        account['Active'] == True
                    else:
                        account['Active'] == False
                    isvalid = hcom.is_valid_account(str(event['widgetContext']['forms']['all'].get('accnum')))
                    if str(event['widgetContext']['forms']['all'].get('accnum')) != account.get('account') and isvalid == True: #check if changing aws account number which is sort key in db
                        originalaccount = account.get('account')
                        deleteold = 1
                        account['account'] = str(event['widgetContext']['forms']['all'].get('accnum'))

                    elif isvalid == True: # update account record
                        try:
                            print(__name__,'Updating Account:{}'.format(account))
                            if str(event['widgetContext']['forms']['all'].get('Active')) == 'True':
                                account["Active"] = True
                                keyaction = 'add'
                            else:
                                account["Active"] = False
                                keyaction = 'remove'
                            account['Features']["CloudWatch"] = is_true(event['widgetContext']['forms']['all'].get('cloudwatch'))
                            account['Features']["AWSBackup"] = is_true(event['widgetContext']['forms']['all'].get('backup'))
                            account['Features']["OnPrem"] = is_true(event['widgetContext']['forms']['all'].get('onprem'))
                            #account['Features']["PatchMgmt"] = is_true(event['widgetContext']['forms']['all'].get('patchmgmt'))
                            account['Features']["SSMOpsItems"] = is_true(event['widgetContext']['forms']['all'].get('ssmopsitems'))
                            account['Features']["StateMgmt"] = is_true(event['widgetContext']['forms']['all'].get('statemgmt'))
                            account['Features']["Webhooks"] = is_true(event['widgetContext']['forms']['all'].get('webhooks'))
                            account['Tags']['description'] = event['widgetContext']['forms']['all'].get('description').strip()
                            account['Tags']['environment'] = event['widgetContext']['forms']['all'].get('env').strip()
                            account['Tags']['patch'] = event['widgetContext']['forms']['all'].get('patch').strip()
                            account['Tags']['product'] = event['widgetContext']['forms']['all'].get('product').strip()
                            account['Tags']['role'] = event['widgetContext']['forms']['all'].get('tagrole').strip()
                            account['acctname'] = event['widgetContext']['forms']['all'].get('acctname').strip()
                            account['Topics']['General'] = event['widgetContext']['forms']['all'].get('general').strip()
                            account['Topics']['HelpDesk'] = event['widgetContext']['forms']['all'].get('helpdesk').strip()
                            account['Webhook']['channel-name'] = event['widgetContext']['forms']['all'].get('channel-name').strip()
                            account['Webhook']['channel-url'] = event['widgetContext']['forms']['all'].get('channel-url').strip()
                            account['Backup']['Most Recent Backup'] = event['widgetContext']['forms']['all'].get('backupwindow').strip()
                            ## tenant

                            ### regions
                            print(__name__,'region type:{}'.format(type(event['widgetContext']['forms']['all'].get('regions'))))
                            if event['widgetContext']['forms']['all'].get('regions') != '':
                                print(__name__,'made it inside regions')
                                formregions = ast.literal_eval(event['widgetContext']['forms']['all'].get('regions'))
                                print(__name__,'formregions:{}'.format(formregions))
                                account['Regions'] = formregions
                            ### environments
                            print(__name__,'region type:{}'.format(type(event['widgetContext']['forms']['all'].get('environments'))))
                            if event['widgetContext']['forms']['all'].get('environs') != '':
                                print(__name__,'made it inside regions')
                                formrenvs = ast.literal_eval(event['widgetContext']['forms']['all'].get('environs'))
                                print(__name__,'formenvirons:{}'.format(formrenvs))
                                account['Environments'] = formrenvs
                            #account["Features"]['Regions'] = event['widgetContext']['forms']['all'].get('regions')

                            print(__name__,'after var updates but pre db update:{}'.format(str(account) ))
                            
                            if Tenant != '' and account != '':
                                response = hcom.update_tenant_account(table,Tenant, account) # update account settings
                                #### log event in EventBridge
                                ## get schema/dictionary
                                etype = 'cw-event'
                                ename = 'account'
                                etarget = 'StateChange'
                                eventFormat = hcom.get_hcom_event(etype,ename,etarget)
                                # assign event values
                                source = 'hcom.account'
                                eventFormat['Detail']['tenant'] = Tenant
                                eventFormat['Detail']['account'] = account['account']
                                eventFormat['Detail']['account-name'] = account['acctname']
                                eventFormat['Detail']['state'] = 'updated'
                                eventresponse = hcom.put_hcom_event(source,json.dumps(eventFormat['Detail']),eventFormat['DetailType'])
                                ### reinitialize core vars
                                hcom.core_initializer(ThisRegion) # reinitialize account settings
                                response2 = update_key_policy() # update key policy
                                update_dlq_permission()
                            else:
                                return {'statusCode': 500, 'message': 'There was an error making the update. Check with the Administrator to review the logs.'}

                            hcom.core_initializer(ThisRegion)
                        except ClientError as error:
                            print(__name__,'exception:{}'.format(error))
                            return {'statusCode': 500, 'message': str(error)}

                    else:
                        return {'statusCode': 400, 'message': 'There was an error making the update. You must provide a valid AWS Account Number to make any further changes. Remember the dummy account number is only a placeholder and must be replaced with a valid AWS Account Number.'}
                    print(__name__,'post update:{}'.format(account))
                ### manage background
                if str(account.get('account')).find('Z') > -1: # check if temp Account Number
                    background = 'style="text-align:center;background-color:tomato;"'
                else:
                    background = 'text-align:center;'
                print(__name__,'if Active state: {} = {}'.format(str(account.get('Active')),'false'))
                if str(account.get('Active')) == 'False': # check Active State
                    background1 = 'style="text-align:center;background-color:tomato;"'
                else:
                    background1 = 'text-align:center;'
                if str(account.get('acctname')).find('Z') > -1: # check Active State
                    background2 = 'style="text-align:center;background-color:tomato;"'
                else:
                    background2 = 'text-align:center;'
                #### manage Active form field
                setActive = '<select id="Active" name="Active">'
                for value in ActiveOptions:
                    print(__name__,'Active - if {} = {}'.format(str(account.get('Active')),str(value)))
                    if str(account.get('Active')) == str(value):
                            selected = 'selected'
                            print(__name__,'this one selected:{}'.format(str(value)))
                    else:
                        selected = ''
                    setActive = setActive + '<option value="' + str(value) + '" ' + selected + '>' + str(value) + '</option>'
                setActive += '</select>'
                #### manage Regions form field
                print(__name__,'full account:{}'.format(account))
                setRegions = '<input type="text" id="regions" name="regions" size="25" value="' + str(account.get('Regions')) + '">'
                setEnvirons = '<input type="text" id="environs" name="environs" size="25" value="' + str(account.get('Environments')) + '">'
                setDescription = '<input type="text" id="description" name="description" size="12" value="' + str(account.get('Tags').get('description')) + '">'
                setEnv = '<input type="text" id="env" name="env" size="12" value="' + str(account.get('Tags').get('environment')) + '">'
                setPatch = '<input type="text" id="patch" name="patch" size="12" value="' + str(account.get('Tags').get('patch')) + '">'
                setProduct = '<input type="text" id="product" name="product" size="12" value="' + str(account.get('Tags').get('product')) + '">'
                setRole = '<input type="text" id="tagrole" name="tagrole" size="12" value="' + str(account.get('Tags').get('role')) + '">'
                setGeneral = '<input type="text" id="general" name="general" size="60" value="' + str(account.get('Topics').get('General')) + '">'
                setHelpDesk2 = '<input type="text" id="helpdesk" name="helpdesk" size="60" value="' + str(account.get('Topics').get('HelpDesk')) + '">'
                setAcctName = '<input type="text" id="acctname" name="acctname" size="12" value="' + str(account.get('acctname')) + '">'
                setChannelName = '<input type="text" id="channel-name" name="channel-name" size="12" value="' + str(account.get('Webhook').get('channel-name')) + '">'
                setChannelURL = '<input type="text" id="channel-url" name="channel-url" size="60" value="' + str(account.get('Webhook').get('channel-url')) + '">'
                setBackupWindow = '<input type="text" id="backupwindow" name="backupwindow" size="5" value="' + str(account.get('Backup').get('Most Recent Backup')) + '">'

                #### manage SSMOpsItems form field
                setSSMOpsItems = '<select id="ssmopsitems" name="ssmopsitems">'
                for value in ActiveOptions:
                    print(__name__,'SSMOpsItems - if {} = {}'.format(str(account.get('Features').get('SSMOpsItems')),str(value)))
                    if str(account.get('Features').get('SSMOpsItems')) == str(value):
                            selected = 'selected'
                            print(__name__,'this one selected:{}'.format(str(value)))
                    else:
                        selected = ''
                    setSSMOpsItems += '<option value="' + str(value) + '" ' + selected + '>' + str(value) + '</option>'
                setSSMOpsItems += '</select>'
                #### manage CloudWatch form field
                setCloudWatch = '<select id="cloudwatch" name="cloudwatch">'
                for value in ActiveOptions:
                    print(__name__,'CloudWatch - if {} = {}'.format(str(account.get('Features').get('CloudWatch')),str(value)))
                    if str(account.get('Features').get('CloudWatch')) == str(value):
                            selected = 'selected'
                            print(__name__,'this one selected:{}'.format(str(value)))
                    else:
                        selected = ''
                    setCloudWatch += '<option value="' + str(value) + '" ' + selected + '>' + str(value) + '</option>'
                setCloudWatch += '</select>'
                #### manage State Mgmt form field
                setStateMgmt = '<select id="statemgmt" name="statemgmt">'
                for value in ActiveOptions:
                    print(__name__,'StateMgmt - if {} = {}'.format(str(account.get('Features').get('StateMgmt')),str(value)))
                    if str(account.get('Features').get('StateMgmt')) == str(value):
                            selected = 'selected'
                            print(__name__,'this one selected:{}'.format(str(value)))
                    else:
                        selected = ''
                    setStateMgmt += '<option value="' + str(value) + '" ' + selected + '>' + str(value) + '</option>'
                setStateMgmt += '</select>'
                #### manage State Mgmt form field
                setWebhooks = '<select id="webhooks" name="webhooks">'
                for value in ActiveOptions:
                    print(__name__,'Webhooks - if {} = {}'.format(str(account.get('Features').get('Webhooks')),str(value)))
                    if str(account.get('Features').get('Webhooks')) == str(value):
                            selected = 'selected'
                            print(__name__,'this one selected:{}'.format(str(value)))
                    else:
                        selected = ''
                    setWebhooks += '<option value="' + str(value) + '" ' + selected + '>' + str(value) + '</option>'
                setWebhooks += '</select>'
                #### manage Patch Mgmt form field
                """
                setPatchMgmt = '<select id="patchmgmt" name="patchmgmt">'
                for value in ActiveOptions:
                    print(__name__,'PatchMgmt - if {} = {}'.format(str(account.get('Features').get('PatchMgmt')),str(value)))
                    if str(account.get('Features').get('PatchMgmt')) == str(value):
                            selected = 'selected'
                            print(__name__,'this one selected:{}'.format(str(value)))
                    else:
                        selected = ''
                    setPatchMgmt += '<option value="' + str(value) + '" ' + selected + '>' + str(value) + '</option>'
                setPatchMgmt += '</select>'
                """
                #### manage Backup Mgmt form field
                setBackup = '<select id="backup" name="backup">'
                for value in ActiveOptions:
                    print(__name__,'Backup - if {} = {}'.format(str(account.get('Features').get('AWSBackup')),str(value)))
                    if str(account.get('Features').get('AWSBackup')) == str(value):
                            selected = 'selected'
                            print(__name__,'this one selected:{}'.format(str(value)))
                    else:
                        selected = ''
                    setBackup += '<option value="' + str(value) + '" ' + selected + '>' + str(value) + '</option>'
                setBackup += '</select>'
                #### manage OnPrem form field
                setOnPrem = '<select id="onprem" name="onprem">'
                for value in ActiveOptions:
                    print(__name__,'OnPrem - if {} = {}'.format(str(account.get('Features').get('OnPrem')),str(value)))
                    if str(account.get('Features').get('OnPrem')) == str(value):
                            selected = 'selected'
                            print(__name__,'this one selected:{}'.format(str(value)))
                    else:
                        selected = ''
                    setOnPrem += '<option value="' + str(value) + '" ' + selected + '>' + str(value) + '</option>'
                setOnPrem += '</select>'
                #### manage Tenant form field
                setTenant = '<select id="tenant" name="tenant">'
                for tenant in hcom.setTenants:
                    print(__name__,'Tenant - if {} = {}'.format(str(account.get('Tenant')),str(tenant)))
                    if str(account.get('Tenant')) == str(tenant):
                            selected = 'selected'
                            print(__name__,'this one selected:{}'.format(str(value)))
                    else:
                        selected = ''
                    setTenant += '<option value="' + str(tenant) + '" ' + selected + '>' + str(tenant) + '</option>'
                setTenant += '</select>'

                #### manage
                bgcolor: String = '#bccad6'
                page +=  '<table style="border: 1px solid black;margin-left:auto;margin-right:auto;border-collapse:collapse;"><form name="modacc">'
                
                page +=  '<tr><th  rowspan="2">SETTINGS</th><th style="background-color:' + bgcolor + '">Active?</th><th style="background-color:' + bgcolor + '">AWS #</th><th style="background-color:' + bgcolor + '">Account Name</th><th colspan="2" style="background-color:' + bgcolor + '">Regions</th><th colspan="2" style="background-color:' + bgcolor + '">Environments</th></tr>'
                page +=  '<tr><td ' + background1 + '>' + setActive + ' </td><td ' + background + '><input type="text" id="accnum" name="accnum" size="13" maxlength="12" value="' + str(account.get('account')) + '"> </td><td ' + background2 + '>' + setAcctName + '</td><td colspan="2">' + setRegions + '</td><td colspan="2">' + setEnvirons + '</td></tr>'
                
                page +=  '<tr><th   rowspan="2">FEATURES Enabled</th><th style="background-color:' + bgcolor + '">SSMOpsItems</th><th style="background-color:' + bgcolor + '">CloudWatch</th><th style="background-color:' + bgcolor + '">StateMgmt</th><th style="background-color:' + bgcolor + '">OnPremise</th><th style="background-color:' + bgcolor + '">AWSBackup</th><th style="background-color:' + bgcolor + '">Webhooks</th><th style="background-color:' + bgcolor + '">&nbsp;</th></tr>'
                page +=  '<tr><td>' + setSSMOpsItems + '</td><td>' + setCloudWatch + '</td><td>' + setStateMgmt + '</td><td>' + setOnPrem + '</td><td>' + setBackup + '</td><td>' + setWebhooks + '</td><td>&nbsp;</td></tr>'
                
                page +=  '<tr><th  rowspan="2">STANDARD Tag Names</th><th style="background-color:' + bgcolor + '">description</th><th style="background-color:' + bgcolor + '">environment</th><th style="background-color:' + bgcolor + '">product</th><th colspan="2" style="background-color:' + bgcolor + '">role</th><th colspan="2" style="background-color:' + bgcolor + '">Patch</th></tr>'
                page +=  '<tr><td>' + setDescription + '</td><td>' + setEnv + '</td><td>' + setProduct + '</td><td colspan="2">' + setRole + '</td><td colspan="2">' + setPatch + '</td></tr>'
                
                page +=  '<tr"><th  rowspan="2">SNS Topic ARNs</th><th colspan="3" style="background-color:' + bgcolor + '">General</th><th colspan="4" style="background-color:' + bgcolor + '">Help Desk</th></tr>'
                page +=  '<tr><td colspan="3">' + setGeneral + '</td><td colspan="4">' + setHelpDesk2 + '</td></tr>'
                
                page +=  '<tr"><th  rowspan="2">Webhook</th><th colspan="3" style="background-color:' + bgcolor + '">Channel Friendly Name</th><th colspan="4" style="background-color:' + bgcolor + '">Channel URL</th></tr>'
                page +=  '<tr><td colspan="3">' + setChannelName + '</td><td colspan="4">' + setChannelURL + '</td></tr>'
                
                page +=  '<tr"><th  rowspan="2">Backup</th><th colspan="7" style="background-color:' + bgcolor + '">Most Recent Backup (in hours)</th></tr>'
                page +=  '<tr><td colspan="7">' + setBackupWindow + '</td></tr>'

                page +=  '<tr><td colspan="8"><center><a class="btn btn-primary">Update</a><cwdb-action action="call" confirmation="Are you sure you want to update this account? If you did not read the NOTE above the form, please read it before updating." endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 8, "action": "update", "Account": "' + str(Account) + '","Tenant": "' + Tenant + '" }</cwdb-action></center></td>'
                page +=  '</tr></form></table>'

                

            return page
    elif Widget == 5: # AWS Accounts
        page += '<table >'
        dropdown = ''
        for h,i in setTenants:
            for j, k in setTenantsEnv:
                if h == j:
                    print()
        
        page +=  '<tr ><th style="text-align:center">Accounts </th><th style="text-align:center"> Profile #</th> <th style="text-align:center">Account(s) </th><th style="text-align:center">Region(s) </th><th style="text-align:center">Assocation Id </th><th style="text-align:center">Name </th><th style="text-align:center">Schedule </th><th style="text-align:center">Run Doc </th> </tr>\n'                   
    elif Widget == 6: # Platform documentation for operations staff
        region = event.get('region', os.environ['AWS_REGION'])
        s3 = boto3.client('s3', region_name=region)
        docs = 'docs/' + event.get('docs','index.md')
        print(__name__,'key = {} from bucket: {}'.format(docs,hcom.setS3.get('Software')))
        if docs != '':
            try:
                result = s3.get_object(Bucket=hcom.setS3.get('Software'), Key=docs)
                temp = result['Body'].read().decode('utf-8')
                html = markdown.markdown(temp)
                return html #result['Body'].read().decode('utf-8')
            except Exception as e:
                print(__name__,'failed to find index.md')
                if str(e).find('NoSuchKey') > -1: # if index.md does not exist yet, because first time after deployment, then create it. This file needs to be dynamically created.
                    docs2 = 'docs/index-template.md'
                    result = s3.get_object(Bucket=hcom.setS3.get('Software'), Key=docs2)
                    lambdalocation = hcom.setCentralRegion + ':' + hcom.setCentralAccount
                    temp = result['Body'].read().decode('utf-8')
                    print(__name__,'index after decoding but before find/replace: {}'.format(temp)) # used for debugging
                    temp = temp.replace('region:account', lambdalocation)
                    temp = temp.replace('partition', setPartition)
                    ## upload to S3
                    response = s3.put_object (
                        Body = temp,
                        Bucket = hcom.setS3.get('Software'),
                        Key = docs,
                        ServerSideEncryption = 'aws:kms'
                    )
                    html = markdown.markdown(temp)
                    pass
                    #return html
                else:
                    result = s3.get_object(Bucket=hcom.setS3.get('Software'), Key='docs/platform-config.md')
                    temp = result['Body'].read().decode('utf-8')
                    html = markdown.markdown(temp)
                    pass
                return html
        else:
            return "Nothing found."
    elif Widget == 7: # core configuration updates
        
        if Function == 'Core':
            if Item == 'centralaccount':
                cols = 2 # for each field being updated
                page = page + '<table><tr><td>Select Tenant name for the Central Management Account:</td>'
                page = page + '<td><form><select id="Tenant" name="Tenant" >'

                for tenant in hcom.setTenants:
                    page = page + '<option value="' + tenant + '">' + tenant + '</option>'
                page = page + '</select></td></tr>'

                page = page + '<tr><td>Select AWS Account Number for Central Management Account:</td>'
                page = page + '<td><select id="Account" name="Account" >'
                for account in hcom.setTenantAccounts:
                    page = page + '<option value="' + account + '">' + account + '</option>'
                page = page + '</select></form></td></tr><tr><td colspan="' + str(cols) + '"><a class="btn btn-primary">Update Central Account Settings</a>'
                page = page + '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-Platform-Configuration-Manager">{ "Action": "Update", "Region": "us-gov-east-1","Function": "Core", "Item": "' + Item +'" }</cwdb-action></td></tr></table>'
            print(__name__,page)
            #sysexit()
            return page
    elif Widget == 8: # custom menu and DLQ
        ### initialize settings
        page = get_style()
        bgcolor: String = '#bccad6'
        leaderboard = '12px'
        messageAttribute = 'All' #'ApproximateNumberOfMessages'

        sqs1num = 0
        sqsdlqnum = 0
        dlqnum = 0
        autonum = 0
        autodlqnum = 0
        ##### push message back into queue for processing

        if Mode == 2: # reload automation queue
            sqsregion = event.get('region', hcom.setCentralRegion)
            sqs2 = boto3.client('sqs') #, region_name=sqsregion)
            print(__name__,'pre-redrive, {} | source: {} | destination: {}'.format(boto3.__version__,event.get('source'),event.get('destination')))
            try:
                response = sqs2.start_message_move_task(SourceArn=event.get('source'),DestinationArn=event.get('destination'))
                print(__name__,'redrive results: {}'.format(response))
            except Exception as e:
                if str(e).find('object has no attribute') > -1: # at the time of devleopment Lambdas are still loading an older version of boto3 that does not support this method
                    page += 'Redrive not yet supported by this Lambdas boto3 version. You will have to use AWS Console for SQS to redrive.'
                    pass
            
        #### begin content

        ## eventbus DLQ
        sqs3 = boto3.client('sqs', region_name=hcom.setCentralRegion)
        dlqarn = 'https://sqs.' + hcom.setCentralRegion +'.amazonaws.com/' + hcom.setCentralAccount + '/HCOM-EB-DeadLetterQueue'
        dlq = sqs3.get_queue_attributes(QueueUrl=dlqarn, AttributeNames=[messageAttribute]) # get number of messages in the queue
        if dlq != '': 
            dlqnum = dlq['Attributes']['ApproximateNumberOfMessages']
            dlqif = dlq['Attributes']['ApproximateNumberOfMessagesNotVisible']
        
        ###### create DLQ table
        page += '<br><br><table>'
        page += '<tr><th>Queues</th><th>Region</th><th>In-Queue</th><th>In-Flight</th><th>DLQ</th></tr>'
        # loop through core platform automation queues
        print(__name__,'regions with queues: {}'.format(hcom.setReportRegions))
        for regs in hcom.setReportRegions:
            region = regs['S']
            print(__name__,'checking region for queues: {}'.format(region))
            sqs = boto3.client('sqs', region_name = region)
            autoarn = 'https://sqs.' + region +'.amazonaws.com/' + hcom.setCentralAccount + '/HCOM-PlatformAutomation'
            autodlqarn = 'https://sqs.' + region +'.amazonaws.com/' + hcom.setCentralAccount + '/HCOM-PlatformAutomationDLQ'
        
            try:
                autodlq = sqs.get_queue_attributes(QueueUrl=autodlqarn, AttributeNames=[messageAttribute]) # get number of messages in the queue
                auto = sqs.get_queue_attributes(QueueUrl=autoarn, AttributeNames=[messageAttribute]) # get number of messages in the queue
                if autodlq != '':
                    autodlqnum = autodlq['Attributes']['ApproximateNumberOfMessages']
                    if int(autodlqnum) > 0:
                        autodlqhtml = '<a class="btn2">' + autodlqnum + '</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 8, "mode": 2, "source": "' + autodlqarn + '", "destination": "' + autoarn + '", "region": "' + region + '" }</cwdb-action>'
                    else:
                        autodlqhtml = str(autodlqnum)
                    if auto != '':
                        autonum = auto['Attributes']['ApproximateNumberOfMessages']
                        autoif = auto['Attributes']['ApproximateNumberOfMessagesNotVisible']
                        page += '<tr><td>Automations</td><td>' + str(region) + '</td><td >' + str(autonum) + '</td><td >' + str(autoif) + '</td><td >' + str(autodlqhtml) + '</td></tr>'
            except Exception as e:
                print(__name__,'-- not queues found')
                if str(e).find('QueueDoesNotExist') > -1:
                    print(__name__,'--- There is no queque for this region. The CF template for this region has not yet been deployed.')
                    pass
                else:
                    #return {'statusCode': 400, 'message': 'There was a problem. Have admins check the logs.'}
                    pass
 
        
        page += '<tr><td>EventBus</td><td>' + hcom.setCentralRegion +'</td><td >N/A</td><td >' + str(dlqif) + '</td><td >' + str(dlqnum) + '</td></tr>'
        page += '</table>'

        page += '<p><b>NOTE:</b> &nbsp; Items in DLQ indicate a service or platform issue. Fix the issue before clicking the orange button to redrive/reload".</p>'
        print(__name__,' page HTML: {}'.format(page))
        return page
    elif Widget == 99: # testing this one
        print()
    else:
        print(__name__,' missing valid Widget parameter.')

def get_other_instances(Account, Region, Profile,ProfileType,TargetInstance):
    """pass in account, region, CW profile #, CW Profile Type, and targetinstance, query and return non-EC2/onprem instances

    Args:
        Account (_type_): AWS Account
        Region (_type_): AWS Region
        Profile (_type_): Profile number
        ProfileType (_type_): CloudWatch Profile type
        TargetInstance (_type_): _description_

    Returns:
        List: List of Instance Ids
    """    
    print(__name__,'get instances for: {} | {} | {} - {} | {}'.format(Account,Region,hcom.setCWTags.get("profile"),Profile,ProfileType))
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    
    ThisARN = hcom.setIAM.get("Cross-Account") # used to assume role in cross accounts
    ThisARN = ThisARN.replace("tenantaccount", Account)
    ThisARN = ThisARN.replace("partition", hcom.setPartition)
    ssm1 = hcom.get_lambda_connection(Account, Region, ThisARN)
    setProfileName = hcom.setCWTags.get("profile")
    tag = 'tag:' + setProfileName
    targetinstances = []
    counter = 0
    if ProfileType == 'Lambda': # Lambda
        print(__name__,'--- This is Lambda profile type: {}'.format(ProfileType))
        #filters = [{'Name':'instance-state-name', 'Values':['running','stopped','stopping']},{'Name':tag, 'Values':[Profile]}]
        if TargetInstance == None:
            instancefilter = [{'Key':tag, 'Values': [tagvalue]}]
        else:
            instancefilter = [{'Key':'InstanceIds', 'Values': [TargetInstance]},{'Key':tag, 'Values': [tagvalue]}]
        try:
            
            tagvalue = Profile
            responses = ssm1.describe_instance_information(Filters=instancefilter,MaxResults=500)
            #responses = ssm1.describe_instance_information(Filters=[{'Key':'PingStatus', 'Values': ['Online']} ])
            print(__name__,'onprem instances found: {} for {}'.format(len(responses['InstanceInformationList']),tagvalue))
            for i in responses['InstanceInformationList']:
                print(__name__, '# instances: {}'.format(i)) # used for testing
                
                if i['InstanceId'].find('mi-') == -1: # skip EC2 instances. only process onprem with mi- instance ids
                    print(__name__,'--- skipping EC2 within OnPrem: {}'.format(i['InstanceId']))
                    continue
                counter = counter + 1
                targetinstances.append(i['InstanceId'])

        except ClientError as error:
            print(__name__, 'Unexpected error occurred... could not get onprem instances', error)
            return error
    else:
        
        ## Assume cross account role to get credentials for client connections
        ec2 = hcom.get_ec2_client_connection(Account, Region, ThisARN)
        #Create EC2 client connection in cross account
        ec3 = hcom.get_ec2_resource_connection(Account, Region, ThisARN)
        if TargetInstance == None:
            instancefilter = [{'Name':'instance-state-name', 'Values':['running','stopped','stopping']},{'Name':tag, 'Values':[Profile]}]
        else:
            instancefilter = [{'Name':'instance-id', 'Values':[TargetInstance]},{'Name':'instance-state-name', 'Values':['running','stopped','stopping']},{'Name':tag, 'Values':[Profile]}]
        try:
            responses = ec2.describe_instances(Filters=instancefilter) # Find instances
            print(__name__,'--- instances found: {}'.format(len(responses['Reservations'])))
            for r in responses['Reservations']:
                for i in r['Instances']:
                    ## reset variables
                    counter = counter + 1
                    targetinstances.append(i['InstanceId'])
        except ClientError as error:
            print(__name__, 'Unexpected error occurred... could not create EC2 cross account query', error)
            return error
    print(__name__,'--- final list of target instances: {}'.format(targetinstances))
    return targetinstances

def get_instances(Account, Region, Profile,ProfileType,TargetInstance):
    """pass in account, region, CW profile #, CW Profile Type, and targetinstance, query and return instance ids

    Args:
        Account (_type_): AWS Account
        Region (_type_): AWS Region
        Profile (_type_): Profile number
        ProfileType (_type_): CloudWatch Profile type
        TargetInstance (_type_): _description_

    Returns:
        List: List of Instance Ids
    """    
    print(__name__,'get instances for: {} | {} | {} - {} | {}'.format(Account,Region,hcom.setCWTags.get("profile"),Profile,ProfileType))
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    
    ThisARN = hcom.setIAM.get("Cross-Account") # used to assume role in cross accounts
    ThisARN = ThisARN.replace("tenantaccount", Account)
    ThisARN = ThisARN.replace("partition", hcom.setPartition)
    ssm1 = hcom.get_ssm_connection(Account, Region, ThisARN)
    setProfileName = hcom.setCWTags.get("profile")
    tag = 'tag:' + setProfileName
    targetinstances = []
    counter = 0
    if ProfileType.find('OnPrem') > -1: # onprem profile
        print(__name__,'--- This is OnPrem profile type: {}'.format(ProfileType))
        #filters = [{'Name':'instance-state-name', 'Values':['running','stopped','stopping']},{'Name':tag, 'Values':[Profile]}]
        if TargetInstance == None:
            instancefilter = [{'Key':tag, 'Values': [tagvalue]}]
        else:
            instancefilter = [{'Key':'InstanceIds', 'Values': [TargetInstance]},{'Key':tag, 'Values': [tagvalue]}]
        try:
            
            tagvalue = Profile
            responses = ssm1.describe_instance_information(Filters=instancefilter,MaxResults=500)
            #responses = ssm1.describe_instance_information(Filters=[{'Key':'PingStatus', 'Values': ['Online']} ])
            print(__name__,'onprem instances found: {} for {}'.format(len(responses['InstanceInformationList']),tagvalue))
            for i in responses['InstanceInformationList']:
                print(__name__, '# instances: {}'.format(i)) # used for testing
                
                if i['InstanceId'].find('mi-') == -1: # skip EC2 instances. only process onprem with mi- instance ids
                    print(__name__,'--- skipping EC2 within OnPrem: {}'.format(i['InstanceId']))
                    continue
                counter = counter + 1
                targetinstances.append(i['InstanceId'])

        except ClientError as error:
            print(__name__, 'Unexpected error occurred... could not get onprem instances', error)
            return error
    else:
        
        ## Assume cross account role to get credentials for client connections
        ec2 = hcom.get_ec2_client_connection(Account, Region, ThisARN)
        #Create EC2 client connection in cross account
        ec3 = hcom.get_ec2_resource_connection(Account, Region, ThisARN)
        if TargetInstance == None:
            instancefilter = [{'Name':'instance-state-name', 'Values':['running','stopped','stopping']},{'Name':tag, 'Values':[Profile]}]
        else:
            instancefilter = [{'Name':'instance-id', 'Values':[TargetInstance]},{'Name':'instance-state-name', 'Values':['running','stopped','stopping']},{'Name':tag, 'Values':[Profile]}]
        try:
            responses = ec2.describe_instances(Filters=instancefilter) # Find instances
            print(__name__,'--- instances found: {}'.format(len(responses['Reservations'])))
            for r in responses['Reservations']:
                for i in r['Instances']:
                    ## reset variables
                    counter = counter + 1
                    targetinstances.append(i['InstanceId'])
        except ClientError as error:
            print(__name__, 'Unexpected error occurred... could not create EC2 cross account query', error)
            return error
    print(__name__,'--- final list of target instances: {}'.format(targetinstances))
    return targetinstances

def update_key_policy():
    """
        Updates the primary encryption key policy after updating AWS account settings. This enables cross account automations to work as expected that uses central KMS key like backup vaults.

    Args:
        action (_type_): _description_
        Account (_type_): _description_
    """    
    arnlist = []
    kms = boto3.client('kms', region_name=hcom.setCentralRegion)
    keyid = "alias/" + hcom.setCentralConfig['KMSAlias']
    thiskey = kms.describe_key(KeyId=keyid)
    keydetails = thiskey['KeyMetadata']
    thispolicy = kms.get_key_policy(KeyId=thiskey['KeyMetadata']['KeyId'],PolicyName='default')
    thisPolicy = ast.literal_eval(thispolicy['Policy'])
    #keyarn = thiskey['KeyMetadata']['Arn'] # not used
    rootarn = "arn:" + hcom.setPartition + ":iam::" + hcom.setCentralAccount + ":root"
    arnlist.append(rootarn)
    ## create account arn list
    for tenant, accounts in hcom.setTenants.items():
        print(__name__,'tenant: {} | accounts: {}'.format(tenant,accounts))
        for account in accounts:
            print(__name__,'this account: {}'.format(account))
            if account['Active'] == False: # matches account being updated
                continue
            else:
                temparn = "arn:" + hcom.setPartition + ":iam::" + account['account'] + ":root"
                if temparn not in arnlist: # if not already in list (like central management account) then add active account arn
                    arnlist.append(temparn)
    match = 0
    row = 0
    for policysegment in thisPolicy['Statement']:
        for key, value in policysegment.items():
            if key == 'Sid':
                print(__name__,' current Sid: {}'.format(value))
            if key == 'Sid' and value == 'Enable IAM User Permissions':
                match = 1
            elif key == 'Sid' and value == 'Allow use of the key by cross-accounts':
                match = 1
            if key == 'Principal' and match == 1:
                thisPolicy['Statement'][row]['Principal'] = {"AWS": arnlist}
                match = 0
        row += 1
    """    
    thisPolicy = {"Version": "2012-10-17","Id": "key-consolepolicy-3","Statement": [{"Sid": "Enable IAM User Permissions", "Effect": "Allow","Principal": {"AWS": arnlist},
            "Action": "kms:*","Resource": "*"},
        {
            "Sid": "Allow Service use of the key",
            "Effect": "Allow",
            "Principal": {
                "Service": [
                    "events.amazonaws.com",
                    "cloudwatch.amazonaws.com",
                    "backup.amazonaws.com",
                    "logs.amazonaws.com"
                ]
            },
            "Action": [
                "kms:Encrypt",
                "kms:Decrypt",
                "kms:ReEncrypt*",
                "kms:GenerateDataKey*",
                "kms:DescribeKey"
            ],
            "Resource": "*"
        },
        {
            "Sid": "Allow use of the key by cross-accounts",
            "Effect": "Allow",
            "Principal": {
                "AWS": arnlist
            },
            "Action": [
                "kms:Encrypt",
                "kms:Decrypt",
                "kms:ReEncrypt*",
                "kms:GenerateDataKey*",
                "kms:DescribeKey",
                "kms:CreateGrant",
                "kms:GetKeyRotationStatus",
                "kms:GetPublicKey",
                "kms:ListGrants",
                "kms:RetireGrant",
                "kms:RevokeGrant",
                "kms:Sign",
                "kms:Verify"
            ],
            "Resource": "*",
            "Condition": {
                "StringEquals": {
                    "aws:PrincipalOrgID": hcom.setPrincipalOrgID
                }
              }
            }
          ]
        }
    """
    print(__name__,'list of arns to add: {} | {}'.format(str(arnlist), str(thisPolicy)))
    policy = kms.put_key_policy(KeyId = keydetails.get('KeyId'), PolicyName='default', Policy = json.dumps(thisPolicy))
    print(__name__,'policy update response: {}'.format(json.dumps(policy)))
    #### log event in EventBridge
    ## get schema/dictionary
    etype = 'cw-event'
    ename = 'kms'
    etarget = 'StateChange'
    eventFormat = hcom.get_hcom_event(etype,ename,etarget)
    # assign event values
    source = 'hcom.kms'
    
    eventFormat['Detail']['key-id'] = keydetails.get('KeyId')
    eventFormat['Detail']['account'] = hcom.setCentralAccount
    eventFormat['Detail']['region'] = hcom.setCentralRegion
    eventFormat['Detail']['state'] = 'updated'
    eventresponse = hcom.put_hcom_event(source,json.dumps(eventFormat['Detail']),eventFormat['DetailType'])

def update_dlq_permission():
    """
        Invoked when AWS account settings are changed. Removes existing DLQ permission and Adds new DLQ permission granting access to all active AWS accounts enabling send of failed eventbridge events to the central DLQ
    """    
    ## create account list
    accountlist = []
    actions = ['SendMessage']
    queueurl = hcom.setSQS['HCOM-EB-DeadLetterQueue']
    print(__name__,'target DLQ: {}'.format(queueurl))
    sqs = boto3.resource('sqs', region_name=hcom.setCentralRegion)
    queue = sqs.Queue(queueurl)
    for tenant, accounts in hcom.setTenants.items():
        print(__name__,'tenant: {} | accounts: {}'.format(tenant,accounts))
        for account in accounts:
            print(__name__,'this account: {}'.format(account))
            if account['Active'] == False: # matches account being updated
                continue
            else:
                accountlist.append(account['account'])
    print(__name__,'--- updating DLQ permission: {} | {}'.format(str(accountlist),queueurl))
    response = queue.remove_permission(Label='HCOM')
    response = queue.add_permission(Label='HCOM', AWSAccountIds = accountlist, Actions = actions)

def get_style():
    page = '<span class="cwdb-no-default-styles"></span>' # turn off default style
    ### manage styles
    page += '<style>\n'
    page += 'table { width: auto; border-collapse: collapse; margin-left: auto; margin-right: auto; border: 1px solid black;}\n' #style="border: 1px solid black;margin-left:auto;margin-right:auto;
    #page += "table,th,td { border: 1px solid black;}" # 
    page += "thead { background-color: #bccad6;}\n"
    page += "tr { padding: 5px;}\n"
    page += "th { background-color: #bccad6; text-align: center; padding:10px; border: 1px solid LightGray; font-family: Arial, Helvetica, sans-serif; font-size: 14px;}\n"
    page += "td { text-align: center; padding: 5px; border: 1px solid LightGray; font-family: Arial, Helvetica, sans-serif; font-size: 12px;}\n"
    
    page +=".button1 { box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);}"
    page += ".btn-primary:hover { border-radius: 2px; box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);}"
    page += ".btn {background-color: #E07941; /* dark orange */ border-radius: 4px; border: none; color: white; padding: 10px 15px; text-align: center; text-decoration: none; display: inline-block; font-size: 14px; font-weight: bold; font-family: Arial, Helvetica, sans-serif; margin: 4px 2px; cursor: pointer; -webkit-transition-duration: 0.4s; /* Safari */ transition-duration: 0.4s;}"
    page += ".btn:hover { border-radius: 2px; box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);}"
    page += ".btn2 {background-color: #E07941; /* dark orange */ border-radius: 2px; border: none; color: white; padding: 5px 8px; text-align: center; text-decoration: none; display: inline-block; font-size: 8px; font-weight: bold; font-family: Arial, Helvetica, sans-serif; margin: 2px 1px; cursor: pointer; -webkit-transition-duration: 0.4s; /* Safari */ transition-duration: 0.4s;}"
    page += ".btn2:hover { border-radius: 1px; box-shadow: 0 6px 8px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);}"
    page += ".btn3 {background-color: #E07941; /* dark orange */ border-radius: 2px; border: none; color: white; padding: 7px 10px; text-align: center; text-decoration: none; display: inline-block; font-size: 10px; font-weight: bold; font-family: Arial, Helvetica, sans-serif; margin: 2px 1px; cursor: pointer; -webkit-transition-duration: 0.4s; /* Safari */ transition-duration: 0.4s;}"
    page += ".btn3:hover { border-radius: 1px; box-shadow: 0 6px 8px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);}"
    page += "p { font-family: Arial, Helvetica, sans-serif;}"

    #page += "tbody tr:nth-child(odd) { background: #ffffff;}"
    #page += "tbody tr:nth-child(even) { background: #f4f4f4;}"
    #page += "a { font-family: Arial, sans-serif; font-size:12px; padding: 8px}\n"
    page += '</style>\n'
    return page

def get_create_first_profile(bgcolor,runDocs,setTargetKeyTypes,setFormRegions,currentTargetname,ProfileType,ProfileId,Account,Tenant,ThisPartition):
    """Create first profile HTML form

    Args:
        table (_type_): _description_
        bgcolor (_type_): _description_
        runDocs (_type_): _description_
        setTargetKeyTypes (_type_): _description_
        setFormRegions (_type_): _description_
        currentTargetname (_type_): _description_
        ProfileType (_type_): _description_
        ProfileId (_type_): _description_
        Account (_type_): _description_
        Tenant (_type_): _description_
        ThisPartition (_type_): _description_

    Returns:
        _type_: _description_
    """    
    #begin table
    varName = hcom.get_next_profile_number(ProfileType,0)
    print(__name__, 'next num:', str(varName))
    page =  '<table ><tr><th colspan="3" ><b>Create First Profile with Initial Configuration</b></th></tr>'
    page += '<tr><th style="text-align:center" colspan="3">There are 2 steps to creating a profile. This is step 1 of 2</th></tr>'
    page += '<tr><th >Select SSM RunDoc</th><th >Select Region</th><th style="background-color:' + bgcolor + '">Next Profile #</th></tr>'
    
    page += '<tr><td style="text-align:center"><form id="newprofile"><input type="hidden" id="Tenant" name="Tenant" value="'+Tenant+'"><input type="hidden" id="Account" name="Account" value="'+Account+'"><input type="hidden" id="configid" name="configid" value="1"><select id="rundoc" name="rundoc">'
    page +=  '<option value="Select">Select</option>'
    for profile, description in runDocs.items():
        page +=  '<option value="' + profile + '" >' + profile + ' | ' + description['description'] + '</option>'
    page +=  '</select></td><td style="text-align:center">'+setFormRegions+'</td><td style="text-align:center"> <input type="hidden" id="profileid" name="profileid" value="'+str(varName)+'" required>'+str(varName)+'</td></tr>'
    page +=  '<tr><th >Target Key Type</th><th >Target Key Name</th><th >Target Key Value</th></tr>'
    page +=  '<tr><td style="text-align:center">'+setTargetKeyTypes+'</td>'
    page += '<td style="text-align:center"><input type="text" id="targetkeyname" name="targetkeyname" value="'+currentTargetname+'" required></td>'
    page += '<td style="text-align:center"><input type="text" id="targetkeyvalue" name="targetkeyvalue" value="'+str(varName)+'" required></td></tr>'
    page += '<tr><td style="text-align:center" colspan="3">All Profile filter values above (Tenant, Account, Profile #) carry over into this form for creating a new profile. Profile numbers are managed centrally.</td></tr>'
    page += '<tr><td colspan="3" style="text-align:center"></form><a class="btn btn-primary">Create</a>'
    page += '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 2, "action": "createprofile","Tenant": "' + Tenant + '", "Account": "' + Account +'", "profiletype": "'+ProfileType+'" }</cwdb-action>' #</tr></table>'
    page += '&nbsp; | &nbsp;<form id="reset"></form><a class="btn btn-primary">RESET FORM</a><cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 2, "prime": 1, "Tenant": "' + Tenant + '", "Account": "' + Account +'","Profile": "1", "profiletype": "'+ProfileType+'" }</cwdb-action>'
    page += '</td></tr></table>'
    return page

def get_create_next_config(bgcolor,runDocs,setTargetKeyTypes,setFormRegions,currentTargetname,ProfileType,ProfileId,Account,Tenant,ThisPartition):
    """Create HTML form for adding additional configuration

    Args:
        table (_type_): _description_
        bgcolor (_type_): _description_
        runDocs (_type_): _description_
        setTargetKeyTypes (_type_): _description_
        setFormRegions (_type_): _description_
        currentTargetname (_type_): _description_
        ProfileType (_type_): _description_
        ProfileId (_type_): _description_
        Account (_type_): _description_
        Tenant (_type_): _description_
        ThisPartition (_type_): _description_

    Returns:
        _type_: _description_
    """    
    #begin table
    varName = hcom.get_next_profile_number(ProfileType,ProfileId)
    print(__name__, 'next num:', str(varName))
    page =  '<table ><tr><th colspan="3" ><b>Add configuration to this profile.</b></th></tr>'
    page += '<tr><th style="text-align:center" colspan="3">There are 2 steps to creating a profile configuration. This is step 1 of 2</th></tr>'
    page += '<tr><th >Select AWS Systems Manager (SSM) RunDoc</th><th >Select Region</th><th style="background-color:' + bgcolor + '">Next Profile Configuration #</th></tr>'
    
    page += '<tr><td style="text-align:center"><form id="createconfig"><select id="rundoc" name="rundoc">'
    page +=  '<option value="Select">Select</option>'
    for profile, description in runDocs.items():
        page +=  '<option value="' + profile + '" >' + profile + ' | ' + description['description'] + '</option>'
    page +=  '</select></td><td style="text-align:center">'+setFormRegions+'</td><td style="text-align:center"><input type="hidden" id="configid2" name="configid2" value="'+str(varName)+'">'+str(varName)+'</td></tr>'
    page +=  '<tr><th >Target Key Type</th><th >Tag or Resource Group Name</th><th >Target Key Value</th></tr>'
    page +=  '<tr><td style="text-align:center">'+setTargetKeyTypes+'</td>'
    page += '<td style="text-align:center"><input type="text" id="targetkeyname" name="targetkeyname" value="'+currentTargetname+'" required></td>'
    page += '<td style="text-align:center"><input type="text" id="targetkeyvalue" name="targetkeyvalue" value="'+ProfileId+'" required><br>comma separated list for tag:,tag-key:,InstanceIds</td></tr>'
    page += '<tr><td style="text-align:center" colspan="3">All Profile filter values above (Tenant, Account, Profile #) carry over into this form for creating a new profile. Profile Configuration Numbers are managed within each profile.</td></tr>'
    page += '<tr><td colspan="3" style="text-align:center"></form><a class="btn btn-primary">Add Configuration </a>'
    page += '<cwdb-action action="call" endpoint="arn:'+ ThisPartition + ':lambda:' + hcom.setCentralRegion +':' + hcom.setCentralAccount + ':function:HCOM-CloudWatch-Dashboard-Widgets">{ "widget": 4, "mode": 2, "action": "createconfig","Tenant": "' + Tenant + '", "Account": "' + Account +'", "profiletype": "'+ProfileType+'" }</cwdb-action></td>' #</tr></table>'
    page += '</tr></table>'
    return page
    
def get_alarm_logs(ssm0,metricname, namespace):
    """_summary_

    Args:
        ssm0 (_type_): _description_
        metricname (_type_): _description_
        namespace (_type_): _description_

    Returns:
        _type_: _description_
    """    
    results = {}
    count = 0
    page = ''
    logname = str(hcom.setCWConfigurations.get('CustomMetricLog').replace('XX', metricname))
    logname = logname.replace('YY', namespace)
    try:
        response = ssm0.get_parameter(Name=logname)
        ThisResponse= response['Parameter']['Value']
        split_config = ThisResponse.split(';')
        loglen = len(split_config)-1
        for i in range(loglen):
            instances = ast.literal_eval(split_config[i])
            print(instances)
            page = page + '<tr><td>' + instances.get('Resource') + '</td><td>' + instances.get('Tenant') + '</td><td>' + instances.get('Region') + '</td><td>' + instances.get('Hostname') + '</td><td>' + instances.get('InstanceId') + '</td><td>' + instances.get('Date') + '</td><td>' + instances.get('AlarmName') + '</td></tr>'
            count = count + 1
    except ClientError as error:
        print(__name__, 'No existing log.', error)
        count = 0
        pass

    #print(split_config)
    print(__name__, 'log name:', logname, 'number of alarms:', count)
    results['page'] = page
    results['count'] = count
    return results

#@lru_cache(maxsize=None)
def get_profiles(dbcon, profiletype,Tenant,Account,template):
    """Get a list of CloudWatch Profiles based on tenant, account, and profile type passed

    Args:
        dbcon (_type_): _description_
        profiletype (_type_): _description_
        Tenant (_type_): _description_
        Account (_type_): _description_

    Returns:
        _type_: _description_
    """    
    if template == False:
        configuration = dbcon.query(
            TableName=hcom.setDBcon,
            Select='ALL_ATTRIBUTES',
            ConsistentRead=True, 
            ExpressionAttributeValues={':cores':{'S': profiletype},':temp':{'BOOL': template},':Tenant':{'S': Tenant},':Account':{'S': Account}},
            KeyConditionExpression='msptype = :cores',
            FilterExpression='isTemplate = :temp AND Account = :Account AND Tenant = :Tenant')
    else:
        configuration = dbcon.query(
            TableName=hcom.setDBcon,
            Select='ALL_ATTRIBUTES',
            ConsistentRead=True, 
            ExpressionAttributeValues={':cores':{'S': profiletype},':temp':{'BOOL': template}},
            KeyConditionExpression='msptype = :cores',
            FilterExpression='isTemplate = :temp')

    print(__name__,'-- filtered profiles: {}'.format(configuration))
    return configuration

def get_next_profileid(dbcon, profiletype):
    """Get a list of CloudWatch Profiles based on tenant, account, and profile type passed

    Args:
        dbcon (_type_): _description_
        profiletype (_type_): _description_
        Tenant (_type_): _description_
        Account (_type_): _description_

    Returns:
        _type_: _description_
    """    
    nextprofile = 0
    configuration = dbcon.query(
        TableName=hcom.setDBcon,
        Select='ALL_ATTRIBUTES',
        ConsistentRead=True, 
        ExpressionAttributeValues={':cores':{'S': profiletype}},
        KeyConditionExpression='msptype = :cores')
    profilelist = configuration['Items']
    for j in range(configuration['Count']): # get high profile number
        if int(profilelist[j]['mspname']['S']) > nextprofile:
            nextprofile = int(profilelist[j]['mspname']['S'])
    nextprofile = nextprofile + 1 # set new profile id

    print(__name__,'-- next profile: {}'.format(nextprofile))
    return nextprofile

#@lru_cache(maxsize=None)
def get_state_profiles(table, profiletype,tenant,account):
    """Query and return all state profiles for given tenant and account

    Args:
        table (_type_): _description_
        profiletype (_type_): _description_
        tenant (_type_): _description_
        account (_type_): _description_

    Returns:
        _type_: _description_
    """    
    configuration = table.query(
        KeyConditionExpression=Key('msptype').eq(profiletype),
        FilterExpression=Attr('Tenant').eq(tenant) & Attr('Account').contains(account))
    return configuration['Items']

def get_state_profile_config(table, profiletype,profileid,configid,tenant,account):
    """Get a specific config/association for a specific profile

    Args:
        table (String): DynamoDB Table
        profiletype (_type_): Is this this state or patch profile
        profileid (_type_): Profile number
        configid (_type_): Specific config number
        tenant (_type_): Tenant name
        account (_type_): AWS Account number

    Returns:
        dict: returns specific configuration details
    """    
    profile = profiletype + str(profileid)
    configuration = table.query(
        KeyConditionExpression=Key('msptype').eq(profile) & Key('mspname').eq(configid),
        FilterExpression=Attr('Tenant').eq(tenant) & Attr('Account').contains(account))
    return configuration['Items']

#@lru_cache(maxsize=None)
def get_profile_config(table, profiletype,profileid,configid):
    profile = profiletype + '-' + str(profileid)
    """Get State profile from DynamoDB

    Args:
        table (_type_): DynamoDB table
        profiletype (_type_): profile type, state or patch
        profileid (_type_): profile number

    Returns:
        dict: profile details from database
    """    
    configuration = table.get_item(Key={'msptype': profile, 'mspname': configid})
    return configuration
def get_custom_metrics(targetTenant,account):
    """_summary_

    Args:
        ssm0 (_type_): _description_
        targetTenant (_type_): _description_

    Returns:
        _type_: _description_
    """
    dbcon = boto3.resource('dynamodb', region_name=hcom.setCentralRegion)
    table = dbcon.Table(hcom.setDBcon)
    counter = 0
    results = {}
    master = ''
    config = 'HCOM-' + targetTenant + '-Custom'
    print(__name__, 'looking for:', config)
    try:
        dailyCount1 = table.get_item(Key={'msptype': 'cw', 'mspname': config})
        print(__name__,' get_item results:', dailyCount1)
        if 'Item' in dailyCount1:
            ThisDailyCount = dailyCount1['Item']
            loglen = len(ThisDailyCount)
            print(__name__,'get results:', ThisDailyCount)
            return ThisDailyCount
            #dailyCount = ssm0.get_parameter(Name=hcom.setCWConfigurations.get('Lifecycle')) ## removing multiple metrics to single custom metric for now 2/27/2023
            #for i in range(loglen):
            #    instances = ast.literal_eval(split_config[i])
            #if targetTenant in instances.get('Tenants'):
            #print(__name__, 'Tenant has this metric',instances.get('Metric') )
            results["Resource"] = ThisDailyCount.get('Resource')
            results["Metric"] = ThisDailyCount.get('Metric')
            results["NameSpace"] = ThisDailyCount.get('NameSpace')
            master = results
        else: # no custom metric found
            print()
            #if i == 0:
            #    master = str(results) + ';'
            #else:
            #    master = master + str(results) + ';'
    except ClientError as error:

        pass
    """
    try:
        response = ssm0.get_parameter(Name=hcom.setCWConfigurations.get('CustomMetricsConfiguration'))
        ThisResponse= response['Parameter']['Value']
        split_config = ThisResponse.split(';')
        loglen = len(split_config)-1
        for i in range(loglen):
            instances = ast.literal_eval(split_config[i])
            if targetTenant in instances.get('Tenants'):
                print(__name__, 'Tenant has this metric',instances.get('Metric') )
                results["Resource"] = instances.get('Resource')
                results["Metric"] = instances.get('Metric')
                results["NameSpace"] = instances.get('NameSpace')
                if i == 0:
                    master = str(results) + ';'
                else:
                    master = master + str(results) + ';'

    except ClientError as error:
        print(__name__, 'error try to get and count custom Metrics', error)
        pass
    """
    return master

def get_update_params(body):
    """Given a dictionary we generate an update expression and a dict of values
    to update a dynamodb table.

    Params:
        body (dict): Parameters to use for formatting.

    Returns:
        update expression, dict of values.
    """
    update_expression = ["set "]
    update_values = {}

    for key, val in body.items():
        update_expression.append(f" {key} =  :{key},")
        update_values[f":{key}"] = val

    return "".join(update_expression)[:-1], update_values

def is_true(var):
    if var == 'True':
        return True
    else:
        return False

    #set  Environments =  :Environments, Features =  :Features, msptype =  :msptype, mspname =  :mspname, Regions =  :Regions, acctname =  :acctname, Tenant =  :Tenant, Topics =  :Topics, Active =  :Active, Tags =  :Tags

def enroll_account(table,Tenant,Account,mode):
    """Enroll new AWS account from existing account or template

    Args:
        Tenant (_type_): Tenant Name
        Account (_type_): AWS Account Number
        mode (_type_): existing, meaning copying an existing account settings versus use a template provided within this function

        Return: Dict: Full account settings in dictionary format
    """    
    tempacc = str(random.randrange(10**11, 10**12)) + 'Z'
    if hcom.setPartition.find('gov') > -1:
        nregions = ['us-gov-east-1', 'us-gov-west-1']
    else:
        nregions = ['us-east-1', 'us-west-1']
    if mode == 'existing':
        thisrecord = hcom.get_account(Tenant,Account)
    elif mode == 'template':
        thisrecord = {'account': tempacc, 'acctname': 'replaceZ', 'Active': False, 'Regions': regions, 'Environments': ['TEST', 'DEV'], 'Backup': {'Most Recent Backup': '36'}, 'Webhook': {'channel-name': 'collaboration', 'channel-url': 'replace with url'}, 'Features': {'AWSBackup': True, 'CloudWatch': True, 'OnPrem': False, 'SSMOpsItems': False, 'StateMgmt': True, 'Webhooks': False}, 'Tags': {'description': 'Description', 'environment': 'Environment', 'patch': 'Patch Group', 'product': 'Product', 'role': 'Product-Role'}, 'Topics': {'General': 'arn:partition:sns:region:centralaccount:replacewithtopicname', 'HelpDesk': 'arn:partition:sns:region:centralaccount:replacewithtopicname'}}

    thisrecord['account'] = str(tempacc)
    thisrecord['acctname'] = str(thisrecord['acctname']) + 'Z'

    thisrecord['Active'] = False # set new account to not active since only a seed account was put in by default
    print(__name__,'temp account:{}|{}'.format(str(tempacc),thisrecord))
    #print(__name__,'next Account id: {} Account to dup:{}'.format(nextAccount,thisAccountdetail))
    Account = str(tempacc)
                
    newrecord = table.get_item(Key={'msptype': 'tenant', 'mspname': Tenant})
    print(__name__,'tenant to update:{}'.format(newrecord))
    newrecord = newrecord['Item']
    newrecord['accounts'].append(thisrecord)

    try:
        response = table.put_item(Item=newrecord)
        didaction = 1
        #hcom.clear_caches()
                    ## reload new values
        #hcom.initializer(ThisRegion) # reload new values
        #account = thisrecord
    except ClientError as error:
        print(__name__,'exception:{}'.format(error))
        pass
    #Action = '' # resetting action for full table display
    return thisrecord

"""
def clear_caches():
    #print(__name__,'pre-cleared caches {} | {} | {} | {} | {} | '.format(get_profile.cache_info(),get_profiles.cache_info(),get_state_profiles.cache_info()))
    #get_profile.cache_clear() # clear core cache
    get_state_profiles.cache_clear() # clear tenant accounts cache
    get_profiles.cache_clear() # clear account detail cache
    return
"""