"""
Copyright 2023 General Dynamics Information Technology (GDIT). or its affiliates. All Rights Reserved.
Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
including the rights to use, copy, modify, merge, and to permit persons to whom the
Software is furnished to do so. GDIT does not grant permission 
to license, sublicense or resell this software, modified or unmodified.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""

import boto3
import ast, datetime, json, os, sys, time, uuid
import hcom
from botocore.exceptions import ClientError
global UpdateList
UpdateList = ''
def lambda_handler(event, context):
    """Provides dynamic alarm lifecycle management. disables or re-enables, creates and deletes CloudWatch alarm actions. HCOM-CloudWatch-Alarm-Lifecycle-Automation (deployed as __name__)
    v.53 Last modified on 9/6/2023. Developed by tom.moore@gdit.com
    Mode: 1 = EC2/Onprem running/rebooted, 4 =  stopped, 5 = terminated
    Mode 2 = DynamoDB events, 3 = RDS events

    """
    global UpdateList
    Mode=''
    myUUID = uuid.uuid4()
    print('show full event: {}'.format(event))
    if type(event) == str:
        event = ast.literal_eval(event)
        event = event.get('event')
        print('dictionary event : {}'.format(event))
        Account = event.get('account', '')
        Mode = int(event.get('mode','0'))
        test = int(event.get('test', 0))
        ThisInstanceID = event.get('instance', '')
        reboot = event.get('reboot', '')
        skipconfig = event.get('skipconfig', 0)
    else:
        Account = event.get('account', '')
        Mode = int(event.get('mode','0'))
        test = int(event.get('test', 0))
        ThisInstanceID = event.get('instance', '')
        reboot = event.get('reboot', '')
        skipconfig = event.get('skipconfig', 0)
    ThisAccount = Account
    
    #print(__name__,'*** event:{}'.format(event)) # used for testing
    
    print('check values: {} | {} | {} | {} | {} | {}'.format(str(Mode),Account, ThisInstanceID, reboot,skipconfig, myUUID))
    if Account == '': # or ThisInstanceID == '':
        return {'statusCode': '400', 'statusmessage': 'The Account number is missing when function is called. Check with system adminisrator.'}

    ThisRegion = event.get('region', '')
    if ThisRegion == '':
        print(__name__,'*** There was a problem receiving the region from the event. Setting it to: {} | event: {}'.format(os.environ['AWS_REGION'],event))
        ThisRegion = os.environ['AWS_REGION']
    #print(__name__,'region:{}'.format(ThisRegion)) # used for testing
    if ThisInstanceID != '' and ThisInstanceID.find("mi-") > -1:
        onprem = 'yes'
    else:
        onprem = 'no'
    
    ####### Initialize Configuration #######
    hcom.core_initializer(ThisRegion) # Initilaize platform configuration
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    Tenant = hcom.account_to_name(Account, hcom.setTenants) # translate account number to tenant name
    AccountName = hcom.get_tenant_account_attribute(Tenant,Account,'acctname')
    print(__name__,'Tenant:{} | Account:{} | onprem: {}'.format(Tenant,Account, onprem))
    setting = 'Features'
    isCloudWatch = hcom.get_tenant_account_setting(Tenant,Account,setting,'CloudWatch')
    if isCloudWatch == True: # Cloudwatch is on
        print(__name__,': load CW config:', isCloudWatch) # read cloudwatch configuration
        hcom.cw_initializer(hcom.setDBcon,table)
    else:
        print(__name__,': CloudWatch is not enabled. Contact the MSP PlatformOps Team. {}'.format(isCloudWatch))
        sys.exit()
    
    ThisPartition = hcom.setPartition

    setting = 'Tags'
    setEnvName = hcom.get_tenant_account_setting(Tenant,Account,setting,'environment')#hcom.setTags.get("environment")
    setProfileName = hcom.setCWTags.get("profile")
    setSuppressNam = hcom.setCWTags.get("suppress")
    setCentralAccount = hcom.setCentralAccount 
    #print(__name__,': inherit central account:', setCentralAccount)
    #setFeatures = hcom.setFeatures
    setting = 'Topics'
    #ThisSNSHelpDesk = hcom.get_tenant_account_setting(Tenant,Account,setting,'HelpDesk')#hcom.setSNSHelpDesk
    if Tenant != '' and Account != '':
        getHelpDeskARN = hcom.get_tenant_account_setting(Tenant,Account,setting,'HelpDesk')
        setSNSGeneral = hcom.get_tenant_account_setting(Tenant,Account,setting,'General')
    else:
        return {'statusCode': 400, 'statusmessage': 'no SNS topic was found'}
    print(__name__,'HelpDesk Topic:{}'.format(getHelpDeskARN))
    setSNSHelpDesk = hcom.convert_arn(getHelpDeskARN,ThisRegion,hcom.setCentralAccount,hcom.setPartition,Tenant,AccountName)
    setSNSGeneral = hcom.convert_arn(setSNSGeneral,ThisRegion,hcom.setCentralAccount,hcom.setPartition,Tenant,AccountName)
    setting = 'Features'
    setOpsItems = hcom.get_tenant_account_setting(Tenant,Account,setting,'SSMOpsItems')
    setStateMgmt = hcom.get_tenant_account_setting(Tenant,Account,setting,'StateMgmt')
    setCloudWatch = hcom.get_tenant_account_setting(Tenant,Account,setting,'CloudWatch')
    setOnPrem = hcom.get_tenant_account_setting(Tenant,Account,setting,'OnPrem')
    setWebhooks = hcom.get_tenant_account_setting(Tenant,Account,setting,'Webhooks')
    if setCloudWatch == False: # check if CloudWatch feature is enabled for this account
        print(__name__,'-- CloudWatch Feature is turned off. You must enable this feature for this account in the CloudWatch Operations Manager Dashboard. --')
        return {'statusCode': 400, 'statusmessage': '-- CloudWatch Feature is turned off. You must enable this feature for this account in the CloudWatch Operations Manager Dashboard. --'}
    
    ####### End: Get CWAgent Configuration #################
    #Set Tenant Name for alarms 
    
    #AccountName = Tenant
    print(__name__, ' Mode =', Mode)
    if Mode in [1,4,5]: # EC2/Onprem
        print(__name__, ' Account', Account, ' Tenant:',Tenant, 'reboot:',reboot, 'Instance:',ThisInstanceID, event.get('instance', ''))

    ThisRegion1 = hcom.get_region_name(ThisRegion)

    outcome = 0
    counter = 0
    ThisMessage = ''
    ThisMessage = ''
    alarmSuppression = ''
    setHelpDesk = ''
    needConfig = 0
    createAlarms = 0
    defaultProfile = 'no'
    updatestats = 0
    BaseARN = hcom.setIAM.get("Cross-Account")
    ThisARN = BaseARN.replace('tenantaccount', Account)
    ThisARN = ThisARN.replace("partition", hcom.setPartition)
    #################### Start: create client connections ##############################
    ## Assume cross account role to get credentials for client connections
    ## Assume cross account role to get credentials for client connections
    ec2 = hcom.get_ec2_client_connection(Account, ThisRegion, BaseARN)
    #Create EC2 client connection in cross account
    ec3 = hcom.get_ec2_resource_connection(Account, ThisRegion, BaseARN)
    # Create SSM Client connect
    ssm1 = hcom.get_ssm_connection(Account, ThisRegion, BaseARN)
    response = hcom.assume_role(ThisARN, ThisRegion)
    cw2 = hcom.get_cloudwatch_connection(ThisARN, ThisRegion)
    # Create CloudWatch connection
    try:
        print(__name__,'creating cross account cross region CloudWatch connection for which region: {} ARN:{}'.format(ThisRegion,ThisARN))
        cloudwatch = boto3.client('cloudwatch', region_name=ThisRegion)
    except ClientError as error:
        print(__name__, ' Unexpected error occurred... could not create SSM Client connection', error)
        return error
    ###Create iam client connection 
    try:
        iam = boto3.client('iam',
                           aws_access_key_id=response['Credentials']['AccessKeyId'],
                           aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                           aws_session_token=response['Credentials']['SessionToken']
                           )
        iam2 = boto3.resource('iam',
                           aws_access_key_id=response['Credentials']['AccessKeyId'],
                           aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                           aws_session_token=response['Credentials']['SessionToken']
                           )
    except ClientError as error:
        print(__name__, ' Unexpected error occurred... could not create EC2 cross account client on trusting account', error)
        return error
    # Create SNS Client connect
    sns = boto3.client('sns', region_name=ThisRegion)
    ssm0 = boto3.client('ssm')
    ##### end create SNS client connection ######
    ## create DynamoDB connection
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    #################### End: create client connections ##############################
    setSSMagent = hcom.setSoftware.get("ssm-agent")
    setCWagent = hcom.setSoftware.get("cloudwatch-agent")
    ####### End: Get CWAgent Configuration #################
    ThisSNSTopic1 = ''
    #################### Start: main flow control section ############################
    TheseAlarms = []
    if Mode != '' and Account != '': # and ThisInstanceID !='':
        if Mode == 1 and ThisInstanceID !='': # EC2 Running State and Rebooted
            ThisStateProfile = ''
            hcom.state_initializer() # initialize state settings
            ##### Begin CloudWatch Section
            print(__name__, 'Instance:', ThisInstanceID, 'test:', test, 'reboot:', reboot, 'UID:', myUUID)
            ##### Inspection ####
            print(__name__, ' pre-check', ThisInstanceID, Tenant, setEnvName, hcom.setCWTags.get("profile"), hcom.setCWTags.get("suppress"))
            mode6 = hcom.running_checklist(Account, ec2, ec3, ssm1, iam, iam2, ThisInstanceID, Tenant, setEnvName, hcom.setCWTags.get("profile"), hcom.setCWTags.get("suppress"),hcom.setIAM.get("Cross-Account"),ThisARN,hcom.setPartition, ThisRegion)
            print(__name__, ' inspection checklist: {} | type: {}'.format( mode6, type(mode6)))
            
            service = 'EC2 / Hybrid OnPrem' # which service are we getting the alarm prefix for?
            namespace = 'CWAgent'
            if type(mode6) is dict and onprem =='no': # len(mode6.keys()) > 1:
                ThisPlatform = mode6.get("tPlatform")
                RunningState = mode6.get("RunningState")
                IamServerRole = mode6.get("IamServerRole")
                HasCWPolicy = mode6.get("HasCWPolicy")
                if mode6.get("ThisProfile") == '':
                    ThisProfile = 0
                else:
                    ThisProfile = int(mode6.get("ThisProfile"))
                print(__name__,' Profile = ', ThisProfile)
                ManagedInstance = mode6.get("managedInstance")
                alarmSuppression = mode6.get("alarmSuppression")
                AgentVersion = mode6.get("AgentVersion")
                ThisHostName = mode6.get("ThisHostName")
                Thisenv = mode6.get("Thisenv")
                #BaseAlarmName = mode6.get("BaseAlarmName")
                PingStatus = mode6.get("PingStatus")
                lastStat = mode6.get("lastStat")
                onprem = mode6.get("onprem")
                ThisStateProfile = mode6.get("ThisStateProfile")
                print(__name__,': metric history:', lastStat)
                if lastStat == 0:
                    firstboot = 'yes'
                else:
                    firstboot = 'no'
                #sys.exit()
            elif onprem == 'yes':
                ec2 = ''
                ec3= ''
                ### Check status and attributes
                try:
                    mode6 = ssm1.describe_instance_information(Filters=[{'Key':'InstanceIds' , 'Values':[ThisInstanceID]}])
                except Exception as e:
                    if str(e).find('InvalidInstanceId') > -1: # check if this instance exists
                        print(__name__,'This instance {} does not exist in the target account/region. {}'.format(ThisInstanceID, str(e)))
                    return {'statusCode': 400, 'message': 'This instance does not exist in the target account/region.' }
                print(__name__,'onprem mode6, found: {} | {}'.format(len(mode6['InstanceInformationList']),mode6))
                if len(mode6['InstanceInformationList']) == 1:
                    mode6 = mode6['InstanceInformationList'][0]
                else:
                    return {'statusCode': 400, 'statusmessage': 'Managed node not found. Check with administrator.'}
                PingStatus = mode6.get("PingStatus")
                AgentVersion = mode6.get("AgentVersion")
                if mode6.get("ResourceType") == 'ManagedInstance':
                    ManagedInstance = 'yes'
                if PingStatus == 'Online':
                    RunningState = 'running'
                elif PingStatus == 'ConnectionLost':
                    RunningState = 'stopped'
                else:
                    RunningState = 'could not determine'
                ThisPlatform = mode6.get("PlatformType")
                print(__name__,'computername:',mode6.get("ComputerName"))
                ThisHostName1 = mode6.get("ComputerName")
                print(__name__,'computername:',ThisHostName1)
                ThisHostName1 = ThisHostName1.split('.',1)
                ThisHostName = ThisHostName1[0]
                IamServerRole = ''
                HasCWPolicy = ''
                #### Check tags
                tags = ssm1.list_tags_for_resource(ResourceType='ManagedInstance',ResourceId=ThisInstanceID)
                print(__name__, 'tags', tags)
                for tag in tags['TagList']:
                    print(__name__, 'tag',tag)
                    if tag['Key'] == setEnvName:
                        Thisenv = tag['Value'] # set the Environment name from tag value
                    elif tag['Key'] == hcom.setCWTags.get('suppress'):
                        alarmSuppression = tag['Value']
                    elif tag['Key'] == hcom.setCWTags.get('profile'):
                        ThisProfile = int(tag['Value'])
                    elif tag["Key"] == hcom.setStateTags['profile']: # check for State-Profile tag
                        ThisStateProfile = tag["Value"]
                #### Check metric history
                timecheck = 1
                datapoints = hcom.check_onprem_metric_history(ThisPlatform, ThisInstanceID, ThisHostName, timecheck, ThisARN,ThisRegion)
                lastStat = len(datapoints['MetricDataResults'][0]['Timestamps'])
            else: # we did not get results
                print(__name__,': nothing found based on parameters passed')
                ThisMessage = ThisMessage + '\n ---- Nothing found based on parameters passed by EventBridge Rule----\n'
                return {'Status': 400}
            ### End Inspection ####
            #service = 'EC2 / Hybrid OnPrem' # which service are we getting the alarm prefix for?
           # namespace = 'CWAgent'
            BaseAlarmName = hcom.get_alarm_prefix(Account, AccountName, ThisRegion, ThisARN, hcom.setPartition, ec2, ec3, ssm1, ThisInstanceID, Tenant, setEnvName, onprem,service)
           
            if BaseAlarmName.get('Name').find('localhost') > -1:
                print(__name__,': Base Alarm Name contains the word localhost which should not be use. Double check all the required EC2 tags are present.')
                sys.exit()
            if BaseAlarmName is None:
                print(__name__,': There was a problem getting the BaseAlarmName.')
                sys.exit()
            else:
                TheseAlarms = hcom.get_alarms(cloudwatch, BaseAlarmName.get('Name'))

            numAlarms = len(TheseAlarms)
            print(__name__, "onprem numAlarms: {} | Tenant:".format(numAlarms, Tenant))
            #check_profile = hcom.setCWConfigurations.get("Alarms").replace("XX", str(ThisProfile)) # set cloudwatch profile name
            #ProfileAlarms = int(hcom.get_profile_alarms(ssm0, check_profile)) # get current alarms defined in profile.
            #print(__name__,': server roles', roleResults)
            #print(__name__,': Inspection:', Tenant, ThisHostName, ' ', ThisInstanceID, ManagedInstance, BaseAlarmName, ThisProfile, alarmSuppression, numAlarms, ThisPlatform, RunningState)
            print(__name__,': SSM Agent:', AgentVersion, PingStatus)
            print(__name__,': Iam ServerRole:', IamServerRole, 'Have CW Server Policy?', HasCWPolicy)
            #ThisSubject = 'Mode 6 - Testing: ' + ThisInstanceID
            ThisHostName2 = BaseAlarmName.get('InstanceName')
            print(__name__,': ThisHostName:', ThisHostName2)
            if reboot == 'yes':
                runType = 'Rebooted'
                targetmessage = 'Hostname: ' + ThisHostName2 + ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now Rebooted and all the alarms have been recreated to ensure they are up-to-date. '
            else:
                runType = 'Running'
                targetmessage = 'Hostname: ' + ThisHostName2 + ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now Running and all the alarms have been created or recreated to ensure they are up-to-date.'
            ThisSubject = Tenant + ' EC2 Instance '+ ThisInstanceID + ' is now ' + runType + ' - lifecycle report'
            ThisMessage = ThisMessage + 'Inspection Checklist: \n'
            ThisMessage = ThisMessage + '------------ Server Info ---------------\n'
            ThisMessage = ThisMessage + '*Hostname: ' + ThisHostName + '\n*Tenant: ' + Tenant + '\n*InstanceId: ' + ThisInstanceID  + '\n*tag:' + setEnvName + ': ' + Thisenv + '\nPlatform: ' + ThisPlatform + '\n'
            ThisMessage = ThisMessage + '------------ SSM Section ---------------\n'
            ThisMessage = ThisMessage + '\n*Is Managed? ' + ManagedInstance + '\n*SSM: ' + AgentVersion + '\nState: ' + RunningState   + '\nPingStatus: ' + PingStatus + '\n'
            ThisMessage = ThisMessage + '----- CloudWatch Alarm Review Section ----\n'
            ThisMessage = ThisMessage + '\n*Iam Server Role Has CW Policy? ' + HasCWPolicy + '\n*tag:' + hcom.setCWTags.get("profile") + ': ' + str(ThisProfile) + '\nAlarm Prefix: ' + BaseAlarmName.get('Name') + '\n# of Alarms: ' + str(numAlarms)  + '\nSuppression: ' + alarmSuppression +'\nRecent Metric History: ' + str(lastStat) + '\n'
            ThisMessage = ThisMessage + '-------------------- End Checklist -------------------\n' + '* = Required for CloudWatch Agent-based profile\n'
            #ThisMessage = ThisMessage + '------------------------------------------------------\n'
            if numAlarms == 0 and lastStat == 0 : # likely first time boot up and instance needs more time to communicate before attempting to use SSM
                if AgentVersion == '' or PingStatus != 'Online':
                    time.sleep(120) # pause to allow start up and initial comm with SSM to enable Run Document automation.
                    print(__name__,': pausing for 2 minutes, instance is starting')
                else:
                    print() # SSM agent is communicating
                lastStat = -1 # override value for first time installation of CW Agent
                print(__name__,': give time for SSM agent communication')
            if (numAlarms < 3  and Thisenv !='' and ThisProfile == 0) or (ThisProfile == -1): # get default generic monitor
                print(__name__, "#1")
                defaultProfile = 'yes'
                ThisMessage = ThisMessage + '----------------- Create Default Alarms -------------------\n'
                try:
                    ThisProfile = -1 # default 3 alarms that does not require cloudwatch agent
                    baseline = hcom.create_profile_alarms(firstboot,cloudwatch, cw2, ec2, ec3, ThisInstanceID, ThisProfile,defaultProfile,BaseAlarmName.get('Name'), ThisHostName, Tenant, ThisPlatform, setEnvName, ThisRegion, ThisAccount, hcom.setCWTags.get("profile"),test,setSNSGeneral, setCentralAccount, setOpsItems, setSNSHelpDesk, lastStat,hcom.setCWConfigurations.get("AlarmResponseDimension"),ThisARN,ThisPartition,AccountName)
                    ThisMessage = ThisMessage + baseline

                except ClientError as error:
                    print(__name__,': Error trying to send email to topic', error)
                ThisMessage = ThisMessage + '---------------------------------------------\n'
            #elif numAlarms <= ProfileAlarms and ManagedInstance == 'Yes' and ThisProfile > 0: # push CW Agent Install and configure alarms
            #elif ManagedInstance == 'Yes' and ThisProfile > 0: # always recreate the alarms 
            elif (ThisProfile > 0 and Thisenv !=''):
                if skipconfig == 1:
                    createAlarms = 1
                if skipconfig == 0:
                    print(__name__, "#2 --- checking CW Agent ---")
                    time.sleep(10)
                    cwstatus = hcom.check_cw_agent(ssm1, ThisInstanceID, ThisPlatform,onprem) # CW Agent installation
                    print(__name__, "cwstats", cwstatus)
                    if str(cwstatus).find("not in a valid state") > -1: # instance is likely still starting up, sleep and try again
                        time.sleep(30)
                        cwstatus = hcom.check_cw_agent(ssm1, ThisInstanceID, ThisPlatform,onprem) # CW Agent installation
                        print(__name__, "cwstats 2nd attempt", cwstatus)

                    #sys.exit()
                    if cwstatus == 'running': # modified to force install for testing (use != for testing and == as normal) 
                        needConfig = 1 # push config
                        ThisMessage = ThisMessage + '--------------- CloudWatch Agent is Running --------------\n'
                    else: # install CW Agent
                        ThisMessage = ThisMessage + '--------------- Attempting to install CloudWatch Agent --------------\n'
                        cwinstall = hcom.install_cw_agent(ssm1, ThisInstanceID, ThisPlatform)
                        print(__name__, "CWStatus", cwinstall)
                        if cwinstall == 'Success':
                            print(__name__,': Attempt to install CW Agent was a Success')
                            ThisMessage = ThisMessage + 'CloudWatch Agent was successfully installed.\n'
                            needConfig = 1
                        else:
                            print(__name__,': Attempt to install CW Agent Failed')
                            ThisMessage = ThisMessage + 'Attempt to install CloudWatch Agent failed. Check that SSM agent is running and it can access the installer download endpoint.\n'
                    if needConfig == 1: #### Push CW Agent Configuration to start CW Agent process
                        ########### Start: push CW Agent Configuration file to EC2 ############
                        ThisConfig = hcom.setCWConfigurations.get("CWAgent").replace("XX", str(ThisProfile)) 
                        if RunningState == 'running': # Check feature switch
                            print(__name__, "Attempt to push config")
                            ThisMessage = ThisMessage + '--------------- Attempting to push CloudWatch Agent Configuration --------------\n'
                            try:
                                needConfigStatus = hcom.push_cw_config(ssm1, ThisInstanceID, ThisConfig, ThisPlatform, onprem, Wait=90)
                                if needConfigStatus == 'Failed':
                                    print(__name__,': Push Config file failed.')
                                    ThisMessage = ThisMessage + 'Attempt to Push Config file failed. Check that target Profile is in target AWS Account DynamoDB.\n'
                                    createAlarms = 1 ### adding override to see if it will create Windows Alarms. Its not currently and don't know why.
                                else:
                                    ThisMessage = ThisMessage + ThisConfig + ' profile was successfully pushed\n'
                                    createAlarms = 1
                                    print(__name__, "Pausing for config push to start sending metric data")
                                    if lastStat > 0 :
                                        time.sleep(15)
                                    else:
                                        time.sleep(90) ## this will need to 120/300 or more to give agent time to send first set of data so volume discovery will work
                            except ClientError as error:
                                print(__name__,': pushing CW Agent config file ran into an error', error)
                                return error
                            print(__name__,': Pushed Config file successfully')
                            #ThisMessage = ThisMessage + 'Pushed Config file\n'
                        else:
                            print(__name__,': Did not push config. State:', RunningState)
                            ThisMessage = ThisMessage + 'Did not push config. State: ' + RunningState + '\n'
                        ############### End: push CW Agent Configuration file to EC2 ##########
                    print(__name__,'pre-alarm creation check: creaeAlarms: {} | onprem: {}'.format(createAlarms, onprem))
                if createAlarms == 1 and onprem != 'yes': #### create profile alarms for EC2
                    print(__name__, "Creating Alarms")
                    ThisMessage = ThisMessage + '--------------- Attempting to create EC2 CloudWatch Agent Alarms using Profile ' + str(ThisProfile) + ' --------------\n'
                    try:
                        baseline = hcom.create_profile_alarms(firstboot, cloudwatch, cw2, ec2, ec3, ThisInstanceID, str(ThisProfile),defaultProfile,BaseAlarmName.get('Name'), ThisHostName, Tenant, ThisPlatform, setEnvName, ThisRegion, ThisAccount, hcom.setCWTags.get("profile"),test,setSNSGeneral, setCentralAccount, setOpsItems, setSNSHelpDesk, lastStat,hcom.setCWConfigurations.get("AlarmResponseDimension"),ThisARN,ThisPartition,AccountName)
                        if type(baseline) != ClientError:
                            ThisMessage = ThisMessage + str(baseline)
                    except ClientError as error:
                            print(__name__,': Creating EC2 Alarms had an issue and stopped.', error)
                elif createAlarms == 1 and onprem == 'yes': # create profile alarms for onprem
                    ThisMessage = ThisMessage + '--------------- Attempting to create OnPrem CloudWatch Agent Alarms using Profile ' + str(ThisProfile) + ' --------------\n'
                    print('--------------- Attempting to create OnPrem CloudWatch Agent Alarms using Profile {} --------------'.format(str(ThisProfile)))
                    try:
                        baseline = hcom.create_onprem_profile_alarms(hcom.setCentralRegion,hcom.setDBcon, cw2,  ThisInstanceID, str(ThisProfile),BaseAlarmName.get('Name'), Tenant, ThisRegion, ThisAccount, test,setSNSGeneral, setCentralAccount, setOpsItems, setSNSHelpDesk, ThisPartition,AccountName,namespace)
                        print(__name__,'onprem result baseline: {} | {}'.format(type(baseline),baseline))
                        if baseline is not None and type(baseline) is dict :
                            targetmessage = 'Hostname: ' + ThisHostName2 + ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now running but not yet sending CW metrics. Check CWAgent configuration on instance and awscli credentials for root/administrator.'
                            ThisMessage = ThisMessage + "---- There is a problem with the CWAgent configuration or awscli credentials as the agent is not sending metrics. Please check these settings on the instance. ----\n"
                        else:
                            ThisMessage = ThisMessage + baseline
                    except ClientError as error:
                            print(__name__,': Creating Alarms had an issue and stopped.', error)
            """elif numAlarms > 0 and alarmSuppression == 'Off' and reboot != 'yes': # re-enable alarms when suppression is off and we have alarms
                print(__name__, "#3")
                response2 = hcom.enable_alarms(cloudwatch, TheseAlarms)
                ThisMessage = ThisMessage + '\nCloudWatch Alarms (' + str(numAlarms) + ') have been re-enabled.\n'
                #### Update Alarms 'enabled' counter
                if test != 1:
                    item = 'enabled'
                    itemValue = numAlarms
                    hcom.update_queue(AccountName, Account, item, itemValue, hcom.setSQS.get("HCOM-StateChange"), ThisInstanceID, ThisRegion1,ThisRegion)
            """
            ### update start count
            item = 'reboot'
            itemValue = 1
            msg_body = str({ "Function": 'cw_state', "Account": Account, "item": item, "itemValue": itemValue, "instance": ThisInstanceID, "ThisRegion": ThisRegion })
            hcom.update_central_queque(msg_body,hcom.setSQS.get("HCOM-PlatformAutomation"))                
            #### log HCOM event in EventBridge
            etype = 'cw-event'
            ename = 'alarms'
            etarget = 'StateChange'
            eventFormat = hcom.get_hcom_event(etype,ename,etarget)
            print(__name__,'event type is: {} | {}'.format(type(eventFormat),eventFormat))
            #eventFormat = json.dumps(eventFormat) # convert string to dictionary
            #print(__name__,'event type is: {} | {}'.format(type(eventFormat),eventFormat))
            eventFormat['Detail']['state'] = 'created'
            eventFormat['Detail']['instance-id'] = ThisInstanceID
            eventFormat['Detail']['account'] = Account
            eventFormat['Detail']['region'] = ThisRegion
            eventFormat['Detail']['tenant'] = Tenant
            eventresponse = hcom.put_hcom_event(eventFormat['Source'],json.dumps(eventFormat['Detail']),eventFormat['DetailType'])

            #### update SSM Agent ######
            if RunningState == 'running':
                print(__name__, ' Update SSM Agent to target version in core configuration.')
                try:
                    hcom.update_ssm_agent(ssm1, ThisInstanceID, hcom.setSoftware.get("ssm-agent"))
                except ClientError as error:
                    print(__name__,': Error updating SSM Agent', error)
                    pass
            ########### end mode 1 Start/Reboot ###########
            ########### Begin State Manager ########
            if setStateMgmt == True and ThisStateProfile !='': # check is state management feature is enabled and this instance has a State Profile
                #### initialize and load settings
                print(__name__,': load state config:', setStateMgmt) # read cloudwatch configuration
                hcom.state_initializer()
                #### begin execution
                #StateConfig = hcom.setConfigurations.get("Profiles")
                ThisMessage = ThisMessage + '\n\n---- Defined Configuration State settings are listed below ----\n'
                try:
                    ThisConfig = hcom.run_state(ThisInstanceID, ThisRegion, ThisAccount, Tenant)
                    
                    #if ThisConfig.get('STIG'):
                    #    ThisMessage = ThisMessage + 'STIG settings applied, level:' + str(ThisConfig.get('STIG')) + '\n'
                    if ThisConfig.get('State'):
                        ThisMessage = ThisMessage + 'State settings applied: ' + str(ThisConfig.get('State')) + '\n'
                except ClientError as error:
                    print(__name__,': Error updating SSM Agent', error)
            ########### End State Manager ###########
        elif Mode == 2: # other AWS services
            print(__name__,'mode:{}'.format(Mode))
            if event.get('event') == 'TagResource':
                print(__name__,'inside TagResource event arn: {}'.format(event.get('tablearn2','')))
                arn = event.get('tablearn2','')
                #tabname = event.get('tablearn2','')
                if arn != '':
                    tabname = arn.split('/')
                    print(__name__,'split arn: {}'.format(tabname))
                    if len(tabname) >1:
                        ThisInstanceID = tabname[1]
                else:
                    return {'statusCode': 400, 'statusmessage': 'TagResource is missing ARN used to derive table name.'}
            else:
                ThisInstanceID = event.get('tablename')
                arn = event.get('tablearn')
            print(__name__,' ThisInstanceID: {} | arn: {} | event: {}'.format(ThisInstanceID, arn, event))
            setting = 'Tags'
            setEnvTag = hcom.get_tenant_account_setting(Tenant,Account,setting,'environment')
            dyncon = hcom.get_dynamodb_client_connection(Account,ThisRegion,ThisARN)
            ProfileTag = hcom.setCWTags.get("profile")
            source = event.get('source','none')
            thisevent = event.get('event','non')
            print(__name__,' changed var: {}'.format(event.get('changed')))
            if event.get('source') == 'aws.tag' and event.get('service') == 'rds' and event.get('instancearn')[0].find(':subgrp:') == -1: # this is a tag change on RDS instance
                if 'CloudWatch-Profile' in event.get('changed') or 'Environment' in event.get('changed'):# and len(event.get('instancearn')) == 1: # found relevant changes to invoke automation
                    source = 'aws.rds' # detecting tag change on RDS
                    thisevent = 'RDS-EVENT-0088'
                    tempname = event.get('instancearn')[0].split(':')
                    ThisInstanceID = tempname[6]
                    print(__name__,' instance: {}'.format(ThisInstanceID))
                else:
                    return {'statusCode': 200, 'statusmessage': 'Tag change did not impact CloudWatch Profiles, so not action required.'}
            if source == 'dynamodb.amazonaws.com': # dynamodb
                Thisenv = hcom.get_dynamodb_tag(dyncon,setEnvName,ThisPartition,ThisRegion,Account,ThisInstanceID)
                ThisProfile = hcom.get_dynamodb_tag(dyncon,ProfileTag,ThisPartition,ThisRegion,Account,ThisInstanceID)
                resourcetype = 'dynamodb-profile'
                print(__name__,'DynamoDB source: {} | account: {} | region: {} | event: {} | table name: {} | Env Tag: {} | Profile Tag: {} | arn: {}'.format(event.get('source'),event.get('account'),event.get('region'),event.get('event'),ThisInstanceID,setEnvName,ProfileTag,arn))
                
                if event.get('event') in ['CreateTable','ImportTable','TagResource']:# 'CreateTable' or event.get('event') == 'TagResource': # create alarms
                    service = 'DynamoDB' #'DynamoDB'
                    ThisSubject = Tenant + ' ' + service + ' Instance '+ ThisInstanceID + ' is now Created or Tagged - lifecycle report'
                    namespace = event.get('namespace', 'AWS/DynamoDB') #'AWS/DynamoDB'
                    setting = 'Topics'
                    if Tenant != '' and Account != '':
                        getHelpDeskARN = hcom.get_tenant_account_setting(Tenant,Account,setting,'HelpDesk')
                        setSNSGeneral = hcom.get_tenant_account_setting(Tenant,Account,setting,'General')
                    print(__name__,'HelpDesk Topic:{}'.format(getHelpDeskARN))
                    setSNSHelpDesk = hcom.convert_arn(getHelpDeskARN,hcom.setCentralRegion,hcom.setCentralAccount,hcom.setPartition,Tenant,AccountName)
                    setSNSGeneral = hcom.convert_arn(setSNSGeneral,hcom.setCentralRegion,hcom.setCentralAccount,hcom.setPartition,Tenant,AccountName)
                    setting = 'Features'
                    setOpsItems = hcom.get_tenant_account_setting(Tenant,Account,setting,'SSMOpsItems')
                    ###### create alarms for service
                    BaseAlarmName = hcom.get_alarm_prefix(Account, AccountName, ThisRegion, ThisARN, hcom.setPartition, ec2, ec3, ssm1, ThisInstanceID, Tenant, setEnvTag,onprem,service)
                    print(__name__, 'check:', ThisInstanceID, str(ThisProfile),defaultProfile,BaseAlarmName.get('Name'), Tenant, setEnvTag, ThisRegion, Account, hcom.setCWTags.get("profile"),test,setSNSGeneral, hcom.setCentralAccount, setOpsItems, setSNSHelpDesk, hcom.setIAM.get("Cross-Account"),hcom.setSQS.get("HCOM-PlatformAutomation"),hcom.setCWConfigurations.get("AlarmResponseDimension"),ThisPartition)
                    baseline = hcom.create_service_profile_alarms(table, resourcetype, cloudwatch, ThisInstanceID, str(ThisProfile),BaseAlarmName.get('Name'), Tenant, ThisRegion, Account, setSNSGeneral, hcom.setCentralAccount, setOpsItems, setSNSHelpDesk, ThisPartition, AccountName, namespace)
                    print(__name__,'baseline:{}'.format(baseline))
                    ThisMessage += baseline
                    targetmessage = ' Service: ' + service + ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now Created or Tagged and all the alarms have been created to ensure they are up-to-date. '
                elif event.get('event') == 'DeleteTable': # delete alarms
                    service = 'DynamoDB' # which service are we getting the alarm prefix for? 
                    ThisSubject = Tenant + ' ' + service + ' Instance '+ ThisInstanceID + ' is now terminated - lifecycle report'
                    namespace = event.get('namespace', 'AWS/DynamoDB') #'AWS/DynamoDB'
                    print(__name__,' Action: DeleteTable Mode:', Mode, 'Instance:', ThisInstanceID, 'UID:', myUUID)
                    
                    namespace = 'AWS/DynamoDB'
                    BaseAlarmName = hcom.get_alarm_prefix(Account, AccountName, ThisRegion, ThisARN, hcom.setPartition, ec2, ec3, ssm1, ThisInstanceID, Tenant, setEnvName,onprem,service)
                    print(__name__,': basealarmname:', BaseAlarmName)
                    if BaseAlarmName == '':
                        print(__name__,': There was a problem getting the BaseAlarmName.')
                        sys.exit()
                    else:
                        TheseAlarms = hcom.get_alarms(cloudwatch, BaseAlarmName.get('Name'))

                    print(__name__,': # alarms:', len(TheseAlarms))
                    if len(TheseAlarms) > 0:
                        response2 = hcom.delete_alarms(cloudwatch, TheseAlarms)
                        ThisMessage = ThisMessage + '\n CloudWatch Alarms (' + str(len(TheseAlarms)) + ') have been deleted.\n'
                        """
                        #### Update deleted counter
                        if test != 1:
                            item = 'deleted'
                            itemValue = len(TheseAlarms)
                            hcom.update_queue(Tenant, Account, item, itemValue, hcom.setSQS.get("HCOM-StateChange"), ThisInstanceID,ThisRegion1,ThisRegion)
                        """
                        targetmessage = ' Service: ' + service + ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now terminaed and all the alarms have been deleted. '
                    else:
                        ThisMessage = ThisMessage + '\n No CloudWatch Alarms have been deleted. Check the Base Alarm Name: ' + BaseAlarmName.get('Name') +' as some or all alarms may be orphaned.\n'
                        ########### Send Report ####################
                    ThisMessage = ThisMessage + 'Instance: '  + ThisInstanceID + ' instance now terminated'
                    """
                    updatestats = 1 # invoke lambda updates
                    #### Update terminated counter
                    if test != 1:
                        item = 'terminatedd'
                        itemValue = 1
                        hcom.update_queue(Tenant, Account, item, itemValue, hcom.setSQS.get("HCOM-StateChange"), ThisInstanceID,ThisRegion1,ThisRegion)
                    """
                    ########### Send Report ####################
                    ### Send Webhook ###
                    ThisHostName = BaseAlarmName.get('Name').split('-')
                    ThisHostName = ThisHostName[3]
                    targetmessage = 'Service: DynamoDB Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now terminated and its alarms have been deleted.'
                    ### End Send Webhook ###
                    time.sleep(30) # let instance fully terminate/delete before running EC2 audit
                    ########### End Report #####################
            elif source == 'aws.rds':
                service = 'RDS'
                resourcetype = 'rds-profile'
                Thisenv = event.get('environment')
                if event.get('instancename') != '' and event.get('source') != 'aws.tag':
                    ThisInstanceID = event.get('instancename')
                ThisProfile = event.get('profile')
                namespace = event.get('namespace', 'AWS/RDS') #'AWS/DynamoDB'
                setting = 'Topics'
                if Tenant != '' and Account != '':
                    getHelpDeskARN = hcom.get_tenant_account_setting(Tenant,Account,setting,'HelpDesk')
                    setSNSGeneral = hcom.get_tenant_account_setting(Tenant,Account,setting,'General')
                print(__name__,'HelpDesk Topic:{}'.format(getHelpDeskARN))
                setSNSHelpDesk = hcom.convert_arn(getHelpDeskARN,hcom.setCentralRegion,hcom.setCentralAccount,hcom.setPartition,Tenant,AccountName)
                setSNSGeneral = hcom.convert_arn(setSNSGeneral,hcom.setCentralRegion,hcom.setCentralAccount,hcom.setPartition,Tenant,AccountName)
                setting = 'Features'
                setOpsItems = hcom.get_tenant_account_setting(Tenant,Account,setting,'SSMOpsItems')
                print(__name__,'RDS source: {} | tenant: {} | account: {} | region: {} | event: {} | service: {} | instance name: {} | arn: {} | environment: {} | profile: {}'.format(event.get('source'),Tenant, event.get('account'),event.get('region'),thisevent,service,ThisInstanceID,event.get('instancearn'),event.get('environment'),ThisProfile))
                if thisevent == 'RDS-EVENT-0005': # created db instance
                    ThisSubject = Tenant + ' ' + service + ' Instance '+ ThisInstanceID + ' is now Created or Tagged - lifecycle report'
                    ###### create alarms for service
                    BaseAlarmName = hcom.get_alarm_prefix(Account, AccountName, ThisRegion, ThisARN, hcom.setPartition, ec2, ec3, ssm1, ThisInstanceID, Tenant, setEnvTag,onprem,service)
                    print(__name__, 'check:', ThisInstanceID, str(ThisProfile),defaultProfile,BaseAlarmName.get('Name'), Tenant, setEnvTag, ThisRegion, Account, hcom.setCWTags.get("profile"),test,setSNSGeneral, hcom.setCentralAccount, setOpsItems, setSNSHelpDesk, hcom.setIAM.get("Cross-Account"),hcom.setSQS.get("HCOM-PlatformAutomation"),hcom.setCWConfigurations.get("AlarmResponseDimension"),ThisPartition)
                    baseline = hcom.create_service_profile_alarms(table, resourcetype, cloudwatch,  ThisInstanceID, str(ThisProfile),BaseAlarmName.get('Name'), Tenant, ThisRegion, Account, setSNSGeneral, hcom.setCentralAccount, setOpsItems, setSNSHelpDesk, ThisPartition, AccountName, namespace)
                    print(__name__,'baseline:{}'.format(baseline))
                    ThisMessage += baseline
                    targetmessage = ' Service: ' + service + ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now Created or Tagged and all the alarms have been created to ensure they are up-to-date. '
                    ########### Send Report ####################
                    ### Send Webhook ###
                    targetmessage = 'Service: RDS Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now started and its alarm actions have been created.'
                    ### End Send Webhook ###
                elif thisevent == 'RDS-EVENT-0003': # deleted db instance
                    ThisSubject = Tenant + ' ' + service + ' Instance '+ ThisInstanceID + ' is now Deleted - lifecycle report'
                    ###### delete alarms for service
                    BaseAlarmName = hcom.get_alarm_prefix(Account, AccountName, ThisRegion, ThisARN, hcom.setPartition, ec2, ec3, ssm1, ThisInstanceID, Tenant, setEnvTag,onprem,service)
                    print(__name__, 'check:', ThisInstanceID, str(ThisProfile),defaultProfile,BaseAlarmName.get('Name'), Tenant, setEnvTag, ThisRegion, Account, hcom.setCWTags.get("profile"),test,setSNSGeneral, hcom.setCentralAccount, setOpsItems, setSNSHelpDesk, hcom.setIAM.get("Cross-Account"),hcom.setSQS.get("HCOM-PlatformAutomation"),hcom.setCWConfigurations.get("AlarmResponseDimension"),ThisPartition)
                    if BaseAlarmName == '':
                        print(__name__,': There was a problem getting the BaseAlarmName.')
                        sys.exit()
                    else:
                        TheseAlarms = hcom.get_alarms(cloudwatch, BaseAlarmName.get('Name'))
                    print(__name__,': # alarms:', len(TheseAlarms))
                    if len(TheseAlarms) > 0:
                        response2 = hcom.delete_alarms(cloudwatch, TheseAlarms)
                        ThisMessage = ThisMessage + '\n CloudWatch Alarms (' + str(len(TheseAlarms)) + ') have been deleted.\n'
                    targetmessage = ' Service: ' + service + ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now terminated and all the alarms have been deleted. '
                    ########### Send Report ####################
                    ### Send Webhook ###
                    targetmessage = 'Service: RDS Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now terminated and its alarms have been deleted.'
                    ### End Send Webhook ###
                elif thisevent == 'RDS-EVENT-0087': # stopped db instance
                    print(__name__,'tenant:{}'.format(Tenant))
                    print(__name__,'service:{}'.format(service))
                    print(__name__,'Instance:{}'.format(ThisInstanceID))
                    ThisSubject = Tenant + ' ' + service + ' Instance '+ ThisInstanceID + ' is now Stopped - lifecycle report'
                    ###### suppress alarm actions for service
                    BaseAlarmName = hcom.get_alarm_prefix(Account, AccountName, ThisRegion, ThisARN, hcom.setPartition, ec2, ec3, ssm1, ThisInstanceID, Tenant, setEnvTag,onprem,service)
                    print(__name__, 'check:', ThisInstanceID, str(ThisProfile),defaultProfile,BaseAlarmName.get('Name'), Tenant, setEnvTag, ThisRegion, Account, hcom.setCWTags.get("profile"),test,setSNSGeneral, hcom.setCentralAccount, setOpsItems, setSNSHelpDesk, hcom.setIAM.get("Cross-Account"),hcom.setSQS.get("HCOM-PlatformAutomation"),hcom.setCWConfigurations.get("AlarmResponseDimension"),ThisPartition)
                    TheseAlarms = hcom.get_alarms(cloudwatch, BaseAlarmName.get('Name'))
                    if len(TheseAlarms) > 0:
                        response2 = hcom.disable_alarms(cloudwatch, TheseAlarms)
                        ThisMessage = ThisMessage + '\n CloudWatch Alarms (' + str(len(TheseAlarms)) + ') have been disabled.\n'
                        print(__name__, "Disabled Alarms")
                    #print(__name__,'baseline:{}'.format(baseline))
                    #ThisMessage += baseline
                    targetmessage = ' Service: ' + service + ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now Stopped and all the alarm actions have been disabled / suppressed.'
                    ########### Send Report ####################
                    ### Send Webhook ###
                    targetmessage = 'Service: RDS Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now stopped and its alarm actions have been disabled.'
                    ### End Send Webhook ###
                    ########### End Report #####################
                elif thisevent == 'RDS-EVENT-0088': # started db instance
                    print(__name__,'tenant:{}'.format(Tenant))
                    print(__name__,'service:{}'.format(service))
                    print(__name__,'Instance:{}'.format(ThisInstanceID))
                    ThisSubject = Tenant + ' ' + service + ' Instance ' + ThisInstanceID + ' is now Started or Tagged - lifecycle report'
                    ###### create alarms for service
                    BaseAlarmName = hcom.get_alarm_prefix(Account, AccountName, ThisRegion, ThisARN, hcom.setPartition, ec2, ec3, ssm1, ThisInstanceID, Tenant, setEnvTag,onprem,service)
                    print(__name__, 'check:', ThisInstanceID, str(ThisProfile),defaultProfile,BaseAlarmName.get('Name'), Tenant, setEnvTag, ThisRegion, Account, hcom.setCWTags.get("profile"),test,setSNSGeneral, hcom.setCentralAccount, setOpsItems, setSNSHelpDesk, hcom.setIAM.get("Cross-Account"),hcom.setSQS.get("HCOM-PlatformAutomation"),hcom.setCWConfigurations.get("AlarmResponseDimension"),ThisPartition)
                    if ThisProfile != '':
                        baseline = hcom.create_service_profile_alarms(table, resourcetype, cloudwatch, ThisInstanceID, str(ThisProfile),BaseAlarmName.get('Name'), Tenant, ThisRegion, Account, setSNSGeneral, hcom.setCentralAccount, setOpsItems, setSNSHelpDesk, ThisPartition, AccountName, namespace)
                    else:
                        return {'statusCode': 400, 'statusmessage': 'Missing Profile ID or other value. Check your profile configuration.'}
                    print(__name__,'baseline:{}'.format(baseline))
                    ThisMessage += baseline
                    targetmessage = ' Service: ' + service + ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now Created or Tagged and all the alarms have been created to ensure they are up-to-date. '
                    ########### Send Report ####################
                    ### Send Webhook ###
                    targetmessage = 'Service: RDS Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now started and its alarm actions have been created.'
                    ### End Send Webhook ###
                    ########### End Report #####################
            #return {'stateCode': '200'}
            #### log event in EventBridge
            etype = 'cw-event'
            ename = 'alarms'
            etarget = 'StateChange'
            eventFormat = hcom.get_hcom_event(etype,ename,etarget)
            print(__name__,'event type is: {} | {}'.format(type(eventFormat),eventFormat))
            #eventFormat = json.dumps(eventFormat) # convert string to dictionary
            #print(__name__,'event type is: {} | {}'.format(type(eventFormat),eventFormat))
            eventFormat['Detail']['state'] = 'created'
            eventFormat['Detail']['instance-id'] = ThisInstanceID
            eventFormat['Detail']['account'] = Account
            eventFormat['Detail']['region'] = ThisRegion
            eventFormat['Detail']['tenant'] = Tenant
            eventresponse = hcom.put_hcom_event(eventFormat['Source'],json.dumps(eventFormat['Detail']),eventFormat['DetailType'])
        elif Mode == 4 and ThisInstanceID !='': # EC2 now in stopped state
            #print(__name__,': Instance:',ThisInstanceID)
            ThisSubject = Tenant + ' EC2 Instance '+ ThisInstanceID + ' is now stopped - lifecycle report'
            print(__name__,': Mode:', Mode, 'Instance:', ThisInstanceID, 'UID:', myUUID)
            #sys.exit()
            ThisMessage = ThisMessage + 'Instance: '  + ThisInstanceID + ' now Stopped and any existing alarms have been disabled.'
            service = 'EC2 / Hybrid OnPrem' # which service are we getting the alarm prefix for?
            namespace = 'CWAgent'
            BaseAlarmName = hcom.get_alarm_prefix(Account, AccountName, ThisRegion, ThisARN, hcom.setPartition, ec2, ec3, ssm1, ThisInstanceID, Tenant, setEnvName,onprem,service)
            if BaseAlarmName is None:
                print(__name__,': There was a problem getting the BaseAlarmName.')
                sys.exit()
            else:
                TheseAlarms = hcom.get_alarms(cloudwatch, BaseAlarmName.get('Name'))

            print(__name__,': # alarms:', len(TheseAlarms))
            if len(TheseAlarms) > 0: # do we have alarms to disable?
                response2 = hcom.disable_alarms(cloudwatch, TheseAlarms)
                ThisMessage = ThisMessage + '\n CloudWatch Alarms (' + str(len(TheseAlarms)) + ') have been disabled.\n'
                print(__name__, "Disabled Alarms")
                #### Update suppress counter
                if test != 1:
                    item = 'suppressed'
                    itemValue = len(TheseAlarms)
                    msg_body = str({ "Function": 'cw_state', "Account": Account, "item": item, "itemValue": itemValue, "instance": ThisInstanceID, "ThisRegion": ThisRegion })
                    hcom.update_central_queque(msg_body,hcom.setSQS.get("HCOM-PlatformAutomation"))
                    
                ########### Send Report ####################
            ### send stop count
            item = 'stopped'
            itemValue = 1
            msg_body = str({ "Function": 'cw_state', "Account": Account, "item": item, "itemValue": itemValue, "instance": ThisInstanceID, "ThisRegion": ThisRegion })
            hcom.update_central_queque(msg_body,hcom.setSQS.get("HCOM-PlatformAutomation"))
            updatestats = 1 #invoke lambda updates
            #### log event in EventBridge
            etype = 'cw-event'
            ename = 'alarms'
            etarget = 'StateChange'
            eventFormat = hcom.get_hcom_event(etype,ename,etarget)
            print(__name__,'event type is: {} | {}'.format(type(eventFormat),eventFormat))
            #eventFormat = json.dumps(eventFormat) # convert string to dictionary
            #print(__name__,'event type is: {} | {}'.format(type(eventFormat),eventFormat))
            eventFormat['Detail']['state'] = 'suppressed'
            eventFormat['Detail']['instance-id'] = ThisInstanceID
            eventFormat['Detail']['account'] = Account
            eventFormat['Detail']['region'] = ThisRegion
            eventFormat['Detail']['tenant'] = Tenant
            eventresponse = hcom.put_hcom_event(eventFormat['Source'],json.dumps(eventFormat['Detail']),eventFormat['DetailType'])
            
            ########### Send Report ####################
            #ThisMessage = ThisMessage + 'Account: ' + Account + 'Instance: ' + ThisInstanceID + ' is now Stopped.\n'
            ### Send Webhook ###
            #ThisHostName = BaseAlarmName.get('Name').split('-')
            print(__name__,'hostname var:{}'.format(BaseAlarmName.get('InstanceName')))
            ThisHostName = BaseAlarmName.get('InstanceName')
            targetmessage = 'Hostname: ' + ThisHostName + ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now stopped and all the alarm actions have been disabled.'
            ### End Send Webhook ###
            time.sleep(30)
        elif Mode == 5 and ThisInstanceID !='': # EC2 now in terminated state
            ThisSubject = Tenant + ' EC2 Instance '+ ThisInstanceID + ' is now terminated - lifecycle report'
            print(__name__,': Mode:', Mode, 'Instance:', ThisInstanceID, 'UID:', myUUID)
            service = 'EC2 / Hybrid OnPrem' # which service are we getting the alarm prefix for?
            namespace = 'CWAgent'
            BaseAlarmName = hcom.get_alarm_prefix(Account, AccountName, ThisRegion, ThisARN, hcom.setPartition, ec2, ec3, ssm1, ThisInstanceID, Tenant, setEnvName,onprem,service)
            print(__name__,': basealarmname:', BaseAlarmName)
            if BaseAlarmName is None:
                print(__name__,': There was a problem getting the BaseAlarmName.')
                sys.exit()
            else:
                TheseAlarms = hcom.get_alarms(cloudwatch, BaseAlarmName.get('Name'))

            print(__name__,': # alarms:', len(TheseAlarms))
            if len(TheseAlarms) > 0:
                response2 = hcom.delete_alarms(cloudwatch, TheseAlarms)
                ThisMessage = ThisMessage + '\n CloudWatch Alarms (' + str(len(TheseAlarms)) + ') have been deleted.\n'
                #### Update deleted counter
                if test != 1:
                    item = 'deleted'
                    itemValue = len(TheseAlarms)
                    msg_body = str({ "Function": 'cw_state', "Account": Account, "item": item, "itemValue": itemValue, "instance": ThisInstanceID, "ThisRegion": ThisRegion })
                    hcom.update_central_queque(msg_body,hcom.setSQS.get("HCOM-PlatformAutomation"))
            else:
                ThisMessage = ThisMessage + '\n No CloudWatch Alarms have been deleted. Check the Base Alarm Name: ' + BaseAlarmName.get('Name') +' as some or all alarms may be orphaned.\n'
                ########### Send Report ####################
            ThisMessage = ThisMessage + 'Instance: '  + ThisInstanceID + ' instance now terminated'
            updatestats = 1 # invoke lambda updates
            #### Update terminated counter
            if test != 1:
                item = 'terminatedd'
                itemValue = 1
                msg_body = str({ "Function": 'cw_state', "Account": Account, "item": item, "itemValue": itemValue, "instance": ThisInstanceID, "ThisRegion": ThisRegion })
                hcom.update_central_queque(msg_body,hcom.setSQS.get("HCOM-PlatformAutomation"))
            #### log event in EventBridge
            etype = 'cw-event'
            ename = 'alarms'
            etarget = 'StateChange'
            eventFormat = hcom.get_hcom_event(etype,ename,etarget)
            print(__name__,'event type is: {} | {}'.format(type(eventFormat),eventFormat))
            eventFormat['Detail']['state'] = 'deleted'
            eventFormat['Detail']['instance-id'] = ThisInstanceID
            eventFormat['Detail']['account'] = Account
            eventFormat['Detail']['region'] = ThisRegion
            eventFormat['Detail']['tenant'] = Tenant
            eventresponse = hcom.put_hcom_event(eventFormat['Source'],json.dumps(eventFormat['Detail']),eventFormat['DetailType'])
            ########### Send Report ####################
            ### Send Webhook ###
            ThisHostName = BaseAlarmName.get('InstanceName')
            #ThisHostName = ThisHostName[3]
            targetmessage = 'Hostname: ' + ThisHostName + ' Instance: ' + ThisInstanceID + ' in ' + Tenant + ' ' + AccountName + ' ' + ThisRegion1 + ' is now terminated and its alarms have been deleted.'
            ### End Send Webhook ###
            time.sleep(30) # let instance fully terminate/delete before running EC2 audit
            ########### End Report ######################
        elif Mode == 6: # for developer testing for EC2 states Ansible & Salt
            
            print(__name__,': nothing to do, you did not provide valid parameters')
        ###### Email Audit  Report ######
        ThisMessage = ThisMessage + '\nThis message was generated by the GDIT Hive CloudWatch Lifecycle Lambda automation and sent at: ' + str(datetime.datetime.now()) + '\n'
        ThisGUID = str(myUUID)
        ThisMessage = ThisMessage + '\n\nGUID: ' + ThisGUID
        #print(__name__, "Email GUID", ThisGUID, hcom.setSNSHelpDesk, hcom.setTestARN)
        print(__name__,'general topic:{} | Help Desk topic:{}'.format(setSNSGeneral, setSNSHelpDesk))
        print(__name__,'subject:{} | message:{}'.format(ThisSubject, ThisMessage))
        try:
            response2 = hcom.send_sns_message(sns, setSNSHelpDesk, ThisSubject, ThisMessage )
            response  = hcom.send_sns_message(sns, setSNSGeneral, ThisSubject, ThisMessage )
            print(__name__,': Successfully emailed Automation Report.')
        except ClientError as error:
            print(__name__,': Error trying to send email to topic', error)
            pass
        ### placeholder for email

        ### placeholder for S3 bucket report
        
        ### Send Webhook ###
        print(__name__,'----- begin webhook section -----')
        if setWebhooks == True:  ### tenant/account specific setting
            print(__name__,'--- sending tenant webhook ---')   
            try:
                sender = hcom.setPlatformName # set sender name
                #### Tenant Channel
                setting = 'Webhook'
                attribute = 'channel-name'
                targetchannel = hcom.get_account_setting(Account,setting,attribute)
                attribute = 'channel-url'
                targeturl = hcom.get_account_setting(Account,setting,attribute)
                print(__name__,'pre send check: {} | {}'.format(targeturl,targetchannel))
                hcom.send_webhook(targetchannel, targeturl, targetmessage, sender)
            except Exception as error:
                print(__name__, 'error trying to send tenant webook. {} | '.format(error))
                pass
        if hcom.setWebhooks.get('Active') == True: ### Central Platform setting
            print(__name__,'--- sending platform webhook ---')   
            try:
                sender = hcom.setPlatformName # set sender name
                #### PlatformOps Channel
                targetchannel = hcom.setWebhooks.get('PlatformOps') 
                targeturl = hcom.setWebhooks.get('PlatformOps-channel') 
                hcom.send_webhook(targetchannel, targeturl, targetmessage, sender)
            except Exception as error:
                print(__name__, 'error trying to send platform webook. {} | {} | {}'.format(targeturl,targetchannel,error))
                pass
        ### End Send Webhook ###

        if Mode in [1,4,5]: # invoke EC2/onprem audit
            #### update EC2 count ops stats
            lname = 'HCOM-EC2-Detail-Report'
            itype = 'Event'
            ppload = "{'region':'"+ThisRegion+"','tenant':'" +Tenant + "','report':'no'}"
            payload = json.dumps(ppload)
            response2 = hcom.invoke_lambda(lname,itype, payload, hcom.setCentralRegion)
            print(__name__,': invoked EC2 audit to update Ops Stats for EC2 and OnPrem Instances.', hcom.setCentralRegion, payload, itype,lname)
            #### update Alarm ops stats - runs after state change
            
            lname = 'HCOM-CloudWatch-Alarm-Audit'
            itype = 'Event'
            ppload = "{'mode': 2, 'resetcount': 'no', 'tenant':'" +Tenant + "','report':'no'}"
            payload = json.dumps(ppload)
            response = hcom.invoke_lambda(lname,itype, payload, hcom.setCentralRegion)
            print(__name__,': invoked alarm audit to update Ops Stats for alarms.',hcom.setCentralRegion, payload, itype,lname)
        
        ###### End Audit Report #######
        return {
            'statusCode': 200,
            'Update Alarms': ThisMessage
        }
        #################### End: main flow control section ############################

