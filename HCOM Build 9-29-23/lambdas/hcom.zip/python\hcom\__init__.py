"""
Copyright 2023 General Dynamics Information Technology (GDIT). or its affiliates. All Rights Reserved.
Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
including the rights to use, copy, modify, merge, and to permit persons to whom the
Software is furnished to do so. GDIT does not grant permission 
to license, sublicense or resell this software, modified or unmodified.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
# This file contains AWS automation platform shared services functions. This is foundation for the rest of the capabilities. HCOM package
# v.75 Last modified on 9/6/2023 Author tom.moore@gdit.com
import ast, boto3, json, datetime, os, sys, time, uuid, urllib3, random, logging
import re
from urllib import request as req
from botocore.exceptions import ClientError
from functools import lru_cache
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

#from cw

#import index as Main
logger = logging.getLogger('CloudWatch Library')
logger.setLevel(logging.INFO)

#from state
#import index as Main
#from core import get_ssm_connection
from boto3.dynamodb.conditions import Key, Attr

#-- initialize AWS Automation Features and Funttions --#

### Used by: All AWS automations
#@lru_cache(maxsize=None)
def core_initializer(region): ###### Central automation platform Configuration #######
    """Reads the core platform configuration from DynamoDB. 
    Args:
        region (String): Pass the region that holds the centralized configuration file

        Establishes global variables for platform settings

    Global Variables:
        setCentralAccount (String): cental management AWS account for the Hive Platform
        setEnvName (String): cental management AWS account for the Hive Platform
        setProductName (String): cental management AWS account for the Hive Platform
        setRoleName (String): cental management AWS account for the Hive Platform
        setIAM (String): cental management AWS account for the Hive Platform
        setS3 (String): cental management AWS account for the Hive Platform
        setTags (String): cental management AWS account for the Hive Platform
        setEmails (String): cental management AWS account for the Hive Platform
        setSoftware (String): cental management AWS account for the Hive Platform
        setTopics (String): cental management AWS account for the Hive Platform
        setFeatures (String): cental management AWS account for the Hive Platform
        setTenants (Dict): List of currently defined Tenants

    """  
    global primaryregion
    ThisRegion = os.environ['AWS_REGION'] ## set region to current region this is running in
    primaryregion = get_central_region(ThisRegion)
    print(__name__,f'primary region:{primaryregion} | current region: {ThisRegion}')  
    ssm0 = boto3.client('ssm', region_name=primaryregion)
    try:
        dbcon = boto3.client('dynamodb', region_name=primaryregion)
    except Exception as e:
        print(__name__,f'failed dynamodb query with target region {primaryregion}')
    print(__name__,': core initializing core configuration')
    
    global setCentralAccount, setCentralTenant, setCentralSNS,setPlatformName, setProductName, setRoleName, setIAM, setS3, setTags, setEmails, setSoftware, setTopics, setFeatures, setTenants, setConfigurations, setBucket, setBucketReg, setRegion, setSNSHelpDesk
    global setTestARN, setReportRegions, setSoftwareBucket, setGUI, setWebhooks, setSQS, setCentralRegion, setDBcon, setTenantAccounts, setDBTable, setNIST80053_ARN_BASE, setPartition, setPrincipalOrgID, setCentralConfig

    
    if ThisRegion.find('gov') > -1: #detect if GovCloud and set partition
        setPartition = "aws-us-gov"
    else:
        setPartition = "aws"
    ### Get Core Platform level Configuration settings
    setDBTable = 'hcom-configuration'
    try:
        configuration1 = dbcon.query(
            TableName=setDBTable,
            Select='ALL_ATTRIBUTES',
            ConsistentRead=True, 
            ExpressionAttributeValues={':cores':{'S': 'core'}},
            KeyConditionExpression='msptype = :cores')
    except Exception as e:
        print(__name__,f'failed dynamodb query with target region {primaryregion}')
    print(__name__,'configuration from db:{}'.format(configuration1['Items']))
    for j in range(configuration1['Count']): # loop through configuration items
       # print(__name__,': row:',configuration1['Items'][j]['msptype']['S'], varName = configuration1['Items'][j]['mspname']['S'])
        varName = varName = configuration1['Items'][j]['mspname']['S']
        
        #thislen = len(configuration1['Items'][0])
        #print(__name__,': num of pairs:', thislen, configuration1['Items'][0] )
        if varName == 'centralaccount':
            setCentralConfig = {}
            setCentralAccount = configuration1['Items'][j]['account']['S']
            setCentralRegion = configuration1['Items'][j]['region']['S']
            setCentralSNS = configuration1['Items'][j]['alerts']['S']
            setCentralTenant = configuration1['Items'][j]['tenant']['S']
            setPlatformName = configuration1['Items'][j]['platform']['S']
            setWebhooks = {}
            setWebhooks['Active'] = configuration1['Items'][j]['webhook']['BOOL']
            setWebhooks['PlatformOps'] = configuration1['Items'][j]['channel-name']['S']
            setWebhooks['PlatformOps-channel'] = configuration1['Items'][j]['channel-url']['S']
            setReportRegions = []
            setReportRegions = configuration1['Items'][j]['reportregions']['L']
            setPrincipalOrgID = configuration1['Items'][j]['PrincipalOrgID']['S']
            setCentralConfig['KMSAlias'] = configuration1['Items'][j]['KMSAlias']['S']
        elif varName == 'iam':
            setIAM = {} 
            setIAM['Cross-Account'] = configuration1['Items'][j]['Cross-Account']['S']
            setIAM['LambdaRole'] = configuration1['Items'][j]['LambdaRole']['S']
            print(__name__,': added iam')
        elif varName == 's3':
            setS3 = {} 
            setS3['Reports'] = configuration1['Items'][j]['Reports']['S']
            setS3['Reports-region'] = configuration1['Items'][j]['Reports-region']['S']
            setS3['Software'] = configuration1['Items'][j]['Software']['S']
        elif varName == 'sqs':
            setSQS = {} 
            #setSQS['HCOM-StateChange'] = 'http://sqs.' + setCentralRegion + '.amazonaws.com/' + setCentralAccount + '/' + configuration1['Items'][j]['HCOM-StateChange']['S']
            setSQS['HCOM-PlatformAutomation'] = 'http://sqs.' + setCentralRegion + '.amazonaws.com/' + setCentralAccount + '/' + configuration1['Items'][j]['PlatformAutomation']['S']
            setSQS['HCOM-PlatformAutomationDLQ'] = 'http://sqs.' + setCentralRegion + '.amazonaws.com/' + setCentralAccount + '/' + configuration1['Items'][j]['PlatformAutomationDLQ']['S']
            setSQS['HCOM-EB-DeadLetterQueue'] = 'http://sqs.' + setCentralRegion + '.amazonaws.com/' + setCentralAccount + '/' + configuration1['Items'][j]['EBDLQ']['S']
        elif varName == 'software': #------ move all to AWS Account ------#
            setSoftware = {}
            setSoftware['ssm-agent'] = configuration1['Items'][j]['ssm-agent']['S']
            setSoftware['cloudwatch-agent'] = configuration1['Items'][j]['cloudwatch-agent']['S']
        elif varName == 'configurations': 
            setConfigurations = {}
            setConfigurations['account'] = configuration1['Items'][j]['account']['S']
            setConfigurations['TemplatePath'] = configuration1['Items'][j]['TemplatePath']['S']
            setConfigurations['OpsDashboard'] = configuration1['Items'][j]['OpsDashboard']['S']
            setConfigurations['coredb'] = configuration1['Items'][j]['coredb']['S']
            setConfigurations['CentralEB'] = configuration1['Items'][j]['CentralEB']['S']
            
        elif varName == 'topics': #------ move all to AWS Account ------#
            setTopics = {}
            setTopics['HelpDesk'] = configuration1['Items'][j]['HelpDesk']['S']
            setTopics['PlatformOps-Engineers'] = configuration1['Items'][j]['PlatformOps-Engineers']['S']
            setTopics['PlatformAutomation'] = configuration1['Items'][j]['PlatformAutomation']['S']
            """elif varName == 'email':
                setEmails = {}
                setEmails['developer'] = configuration1['Items'][j]['developer']['S']
            elif varName == 'regions': #------ move all to AWS Account ------#
                setRegions = {}
                setRegions['East'] = configuration1['Items'][j]['East']['S']
                setRegions['West'] = configuration1['Items'][j]['West']['S']
            """
        elif varName == 'gui':
            setGUI = {}
            tagging= {'Template': configuration1['Items'][j]['Tagging']['M']['Template']['S'], 'URL': configuration1['Items'][j]['Tagging']['M']['URL']['S']} 
            print(__name__,'this row:',tagging)
            #print(__name__,'this row:',configuration1['Items'][j])
            setGUI['Tagging']: String = tagging
            ### set Alarm Control
            alarmcontrol= {'Template': configuration1['Items'][j]['AlarmControl']['M']['Template']['S'], 'URL': configuration1['Items'][j]['AlarmControl']['M']['URL']['S']} 
            setGUI['AlarmControl']: String = alarmcontrol
            ### set Alarm Creator
            alarmcreator= {'Template': configuration1['Items'][j]['AlarmCreator']['M']['Template']['S'], 'URL': configuration1['Items'][j]['AlarmCreator']['M']['URL']['S']} 
            setGUI['AlarmCreator']: String = alarmcreator
            ### set Alarm Testing
            alarmtesting= {'Template': configuration1['Items'][j]['AlarmTesting']['M']['Template']['S'], 'URL': configuration1['Items'][j]['AlarmTesting']['M']['URL']['S']} 
            setGUI['AlarmTesting']: String = alarmtesting
            ### set State GUI
            stategui= {'Template': configuration1['Items'][j]['StateMgmt']['M']['Template']['S'], 'URL': configuration1['Items'][j]['StateMgmt']['M']['URL']['S']} 
            setGUI['StateMgmt']: String = stategui

    ### Get Tenant Configuration settings
    tenantquery = dbcon.query(
        TableName=setDBTable,
        Select='ALL_ATTRIBUTES',
        ConsistentRead=True, 
        ExpressionAttributeValues={':cores':{'S': 'aws-account'}},
        KeyConditionExpression='msptype = :cores')

    setTenants = {}
    setTenants2 = {}

    setTenantAccounts = [] # based on only method that does not include platform features
    #setTenantAccounts2 = [] # this will likely replace setTenantAccounts. This new approach includes platform features
    """
    for j in range(tenantquery['Count']): # loop through configuration items
        print(__name__,': row:',tenantquery['Items'][j]['msptype']['S'], tenantquery['Items'][j]['mspname']['S'])
        varName = tenantquery['Items'][j]['mspname']['S']
        thisAccounts = []
        env=[]
        for i in range(len(tenantquery['Items'][j]['Accounts']['L'])): # keep for new method
            thisAccounts.append(tenantquery['Items'][j]['Accounts']['L'][i]['S'])
            setTenantAccounts.append(tenantquery['Items'][j]['Accounts']['L'][i]['S'])
        for h in range(len(tenantquery['Items'][j]['Environments']['L'])): # phase out as env moves inside aws-account record
            env.append(tenantquery['Items'][j]['Environments']['L'][h]['S'])
        setTenants[varName] = thisAccounts
        setTenantsEnv[varName] =  env
    """
    #### get all Tenant AWS accounts configured (new 2023 approach)
    awsaccounts = dbcon.query(
        TableName=setDBTable,
        Select='ALL_ATTRIBUTES',
        ConsistentRead=True, 
        ExpressionAttributeValues={':cores':{'S': 'tenant'}},
        KeyConditionExpression='msptype = :cores'
    )
    #setTenantAccounts2 = awsaccounts.get('Items')
    rows = awsaccounts['Count']
    
    response = awsaccounts['Items']
    print(__name__,'tenants found:{}, #accts:{}'.format(rows,response))
    for t in range(rows): # loop through tenants
        #print(__name__,'tenant: {}'.format(response[t]['mspname']['S'])) # for debugging
        tenantName = response[t]['mspname']['S']
        listofaccounts = []
        #numberofaccounts = len(response[t]['accounts']['L'])
        try:
            if response[t]['accounts']['L']: # we have accounts so loop through them
                for a in range(len(response[t]['accounts']['L'])):
                    setTenantAccounts.append(response[t]['accounts']['L'][a]['M']['account']['S']) # build central list of AWS accounts
                    numaccounts = response[t]['accounts']['L']
                    #print(__name__,'number of accounts:{} | {}'.format(numaccounts,response[t]['accounts']['L'][a]['M'])) # used for debugging
                    acctTemplate = {'account': '', 'acctname': '', 'Active': True, 'Regions': [],'Environments': [], 'Backup': {'Most Recent Backup': ''},'Webhook': {'channel-name':'', 'channel-url':''},'Features': {'AWSBackup':False,'CloudWatch':True,'OnPrem':False,'PatchMgmt':True,'SSMOpsItems':False,'StateMgmt':True,'Webhooks':False}, 'Tags': {'description':'','environment': '', 'patch': '', 'product': '', 'role': ''}, 'Topics': {'General':'','HelpDesk':''} }
                    acctTemplate['account'] =  response[t]['accounts']['L'][a]['M']['account']['S']
                    acctTemplate['acctname'] =  response[t]['accounts']['L'][a]['M']['acctname']['S']
                    acctTemplate['Active'] =  response[t]['accounts']['L'][a]['M']['Active']['BOOL']
                    if response[t]['accounts']['L'][a]['M']['Environments']['L']: # very environments are defined
                        for i in response[t]['accounts']['L'][a]['M']['Environments']['L']:
                            acctTemplate['Environments'].append(i['S'])
                    if response[t]['accounts']['L'][a]['M']['Regions']['L']: #very regions are defined
                        for i in response[t]['accounts']['L'][a]['M']['Regions']['L']:
                            acctTemplate['Regions'].append(i['S'])
                    acctTemplate['Features']['SSMOpsItems'] =  response[t]['accounts']['L'][a]['M']['Features']['M']['SSMOpsItems']['BOOL']
                    acctTemplate['Features']['CloudWatch'] =  response[t]['accounts']['L'][a]['M']['Features']['M']['CloudWatch']['BOOL']
                    acctTemplate['Features']['StateMgmt'] =  response[t]['accounts']['L'][a]['M']['Features']['M']['StateMgmt']['BOOL']
                    acctTemplate['Features']['Webhooks'] =  response[t]['accounts']['L'][a]['M']['Features']['M']['Webhooks']['BOOL']
                    acctTemplate['Features']['OnPrem'] =  response[t]['accounts']['L'][a]['M']['Features']['M']['OnPrem']['BOOL']
                    #acctTemplate['Features']['PatchMgmt'] =  response[t]['accounts']['L'][a]['M']['Features']['M']['PatchMgmt']['BOOL']
                    acctTemplate['Features']['AWSBackup'] =  response[t]['accounts']['L'][a]['M']['Features']['M']['AWSBackup']['BOOL']
                    acctTemplate['Topics']['General'] =  response[t]['accounts']['L'][a]['M']['Topics']['M']['General']['S']
                    acctTemplate['Topics']['HelpDesk'] =  response[t]['accounts']['L'][a]['M']['Topics']['M']['HelpDesk']['S']
                    acctTemplate['Tags']['patch'] =  response[t]['accounts']['L'][a]['M']['Tags']['M']['patch']['S']
                    acctTemplate['Tags']['description'] =  response[t]['accounts']['L'][a]['M']['Tags']['M']['description']['S']
                    acctTemplate['Tags']['environment'] =  response[t]['accounts']['L'][a]['M']['Tags']['M']['environment']['S']
                    acctTemplate['Tags']['product'] =  response[t]['accounts']['L'][a]['M']['Tags']['M']['product']['S']
                    acctTemplate['Tags']['role'] =  response[t]['accounts']['L'][a]['M']['Tags']['M']['role']['S']
                    acctTemplate['Webhook']['channel-name'] =  response[t]['accounts']['L'][a]['M']['Webhook']['M']['channel-name']['S']
                    acctTemplate['Webhook']['channel-url'] =  response[t]['accounts']['L'][a]['M']['Webhook']['M']['channel-url']['S']
                    acctTemplate['Backup']['Most Recent Backup'] =  response[t]['accounts']['L'][a]['M']['Backup']['M']['Most Recent Backup']['S']
                    # print(__name__,'final account before adding:{}'.format(acctTemplate)) # used for debugging
                    listofaccounts.append(acctTemplate)
                    # print(__name__,'list of accounts so far:{}'.format(acctTemplate)) # used for debugging
                setTenants[tenantName] = listofaccounts
                

                #print(__name__,'setTenant Global Var for {} so far:{}'.format(tenantName,setTenants)) # used for debugging
        except KeyError as error:
            print(__name__,'There was a problem tenant accounts. {}'.format(error))
            setTenants[tenantName] = None
            pass
            #return {'statusCode': 500}

    ##### set constants ######
    setHelpDesk = setTopics.get("HelpDesk")

    setBucket = setS3.get("Reports")
    setBucketReg = setS3.get("Reports-region")
    setSoftwareBucket = setS3.get("Software")
    setRegion = region #os.environ['AWS_REGION']
    setDBcon = setConfigurations.get("coredb") # sets core configuration database name
    ##### 2nd level (derived) constants #####

    ### Security Hub section
    setNIST80053_ARN_BASE = 'standards/nist-800-53/v/5.0.0'
#-- Tenant Name and Account Number translation --#

## Get Central Region from parameter store
@lru_cache(maxsize=None)
def get_central_region(something):
    """Primer to get central region from parameter store

    Args:
        something (_type_): not used

    Returns:
        string: aws region name
    """    
    ssm = boto3.client('ssm')
    region = ssm.get_parameter(Name='HCOM-Primary-Region')
    print(__name__,f'region: {region}')
    return str(region['Parameter']['Value'])

### HCOM-CloudWatch-Alarm-Creator, HCOM-Lifecycle-Automation
def convert_arn(arn,region,account,partition,tenant,accountname):
    """convert templatized SNS topic arn into valid ARN

    Args:
        arn (_type_): template arn that has inserted words to be dynamically replaced at runtime
        region (_type_): AWS region name
        account (_type_): AWS account number

    Returns:
        String: valid SNS topic ARN
    """    
    if arn != '' and region != '' and account != '':
        setARN = arn.replace('region', region) 
        setARN = setARN.replace('centralaccount', account)
        setARN = setARN.replace('partition', partition)
        setARN = setARN.replace('XX', accountname)
        setARN = setARN.replace('Tenant', tenant)
        return setARN
    else:
        return None

### Used by: HCOM-SSM-State-Manager, HCOM-CloudWatch-Alarm-Audit, HCOM-CloudWatch-Alarm-Control,HCOM-CloudWatch-Alarm-Creator
### HCOM-CloudWatch-Alarm-Response, HCOM-Universal-Tagging

def name_to_account(name, tenants): # Converts name to AWS account number
    """Take Tenant name and return list of accounts

    Args:
        name (_type_): _description_
        tenants (_type_): _description_

    Returns:
        _type_: _description_
    """    
    # setTenants must be set by initializer
    Account = ''
    for key, value in tenants.items():
        if key == name:
            Account = value
    return Account

### HCOM-CloudWatch-Dashboard-Widget
#@lru_cache(maxsize=None)
def get_account(tenant, targetAccount):
    """Take tenant and target account and return platform settings for account

    Args:
        table (_type_): DynamoDB resource connection and table
        targetAccount (_type_): target AWS account record to return

    Returns:
        Dict: single record return from DynamoDB for target AWS account
    """    
    print(__name__, 'looking for:', targetAccount)

    try:
        #response = table.get_item(Key={'msptype': 'aws-account', 'mspname': targetAccount})
        for thisTenant, accounts in setTenants.items():
            if thisTenant == tenant: # matched tenant
                for settings in accounts: # loop through accounts
                    if settings['account'] == targetAccount: # matched target account
                        return settings
        
    except ClientError as error:
        print(__name__,'There was a problem getting AWS Account record from DynamoDB: {}'.format(error))
        pass
        return {'statusCode': 500}

###
#@lru_cache(maxsize=None)
def is_valid_account(acct):
    """Take AWS Account and use regex to validate format

    Args:
        acct (_type_): AWS account number

    Returns:
        Bool: return true or false for valid format
    """    
    length = len(acct)
    if length == 12:
        if not re.match(r'[0-9]{12}', str(acct)):
            return False
        else:
            return True
    else: # if has 13 characters its likely a new account that was duplicated with the Z on the end to force admins to put in valid account
        if not re.match(r'[0-9]{13}', str(acct)):
            return False
        else:
            return True

### used by: HCOM-CloudWatch-Dashboard-Widgets
def get_nist80053_status(account, region,arn,partition):
    """Return the status of Security Hub NIST 800-53

    Args:
        account (_type_): AWS Account
        region (_type_): AWS Region
        arn (_type_): assume role template arn
        partition (_type_): arn partition in use

    Returns:
        Boolean: Status of NIST 800-53 as standard in Security Hub
    """    
    awsservice = 'securityhub'
    connectiontype = 'client'
    shcon = get_service_connection(account,region, arn,awsservice,connectiontype)
    NIST80053_ARN = 'arn:{}:securityhub:{}::{}'.format(partition,region, setNIST80053_ARN_BASE)

    try:
        response = shcon.get_enabled_standards(StandardsSubscriptionArns=[setNIST80053_ARN_BASE])
        print(__name__,'results:', len(response['StandardsSubscriptions']),response)
        for enabled_standard in response['StandardsSubscriptions']:
            enabled_standard_arn = enabled_standard['StandardsArn']
            enabled_standard_status = enabled_standard['StandardsStatus']
            standards_status[enabled_standard_arn] = enabled_standard_status
                        
            if enabled_standard_arn == NIST80053_ARN and enabled_standard_status == 'READY':
                print("Finished enabling standard NIST 800-53 on account {} for region {}".format(account, region))
                standard_enabled = True
                return True
            else:
                return False
    except ClientError as e:
        print(__name__,': Unexpected error occurred... could not query security hub. {}'.format(e))
        pass
        return False


### used by: HCOM-CloudWatch-Dashboard-Widgets, HCOM-EC2-Detail-Report
#@lru_cache(maxsize=None)
def get_tenant_accounts(tenant,active):
    """get and return specific tenant record

    Args:
        tenant (String): target tenant name to query
        active (Bool): only Active? indicator. True = only active, False = all accounts

    Returns:
        Dict: Tenant record from query
    """    
    ThisResult = []
    for thisTenant, accounts in setTenants.items():
        print(__name__,'--row tenant: {} | accounts: {}'.format(thisTenant,accounts))
        if thisTenant == tenant:
            print(__name__,'j:{} | {} | All:{}'.format(thisTenant,accounts,thisTenant))
            rows = len(accounts)
            for i in accounts:
                if active == True and i['Active'] == True or active == False:
                    ThisResult.append(i['account'])
                #elif active == False: # add all accounts
                #ThisResult.append(i['account'])
            print(__name__,'ThisResult:{}'.format(ThisResult))
            return ThisResult
    return ThisResult

## HCOM-CloudWatch-Dashboard-Widget, HCOM-EC2-Detail-Report
#@lru_cache(maxsize=None)
def get_tenant_account_attribute(tenant,account,attribute):
    """Return a specific attribute based on tenant and account

    Args:
        tenant (_type_): named tenant or organizational unit
        account (_type_): AWS Account number
        attribute (_type_): which attribute from database for tenant/account to return

    Returns:
        varies: target tenant attribute
    """    
    try:
        #response = table.get_item(Key={'msptype': 'aws-account', 'mspname': targetAccount})
        for thisTenant, accounts in setTenants.items():
            if thisTenant == tenant: # matched tenant
                for settings in accounts: # loop through accounts
                    if settings['account'] == account: # matched target account
                        print(__name__,'returning {} with accounts {}'.format(attribute,settings[attribute] ))
                        return settings[attribute]
        
    except ClientError as error:
        print(__name__,'There was a problem getting environments {}'.format(error))
        pass
        return {'statusCode': 500}

## HCOM-CloudWatch-Dashboard-Widget, HCOM-EC2-Detail-Report
#@lru_cache(maxsize=None)
def get_tenant_account_setting(tenant,account,setting,attribute):
    """pass in tenant, account, setting and attribute and return value. This corresponds with data model in dynamodb for Tenant
        setting is: Environments, Features, Regions, Tags, Topics, Webhook
        attribute is sub value within settings to return

    Args:
        tenant (_type_): Named Tenant
        account (_type_): AWS Account assoiciated with Tenant
        setting (_type_): attribute family/collection
        attribute (_type_): named attribute to return

    Returns:
        _type_: value for attribute from dynamodb
    """    
    try:
        #response = table.get_item(Key={'msptype': 'aws-account', 'mspname': targetAccount})
        for thisTenant, accounts in setTenants.items():
            if thisTenant == tenant: # matched tenant
                for settings in accounts: # loop through accounts
                    if settings['account'] == account: # matched target account
                        print(__name__,'returning {} with accounts {}'.format(attribute,settings[setting][attribute] ))
                        return settings[setting][attribute]
        
    except ClientError as error:
        print(__name__,'There was a problem getting feature {}'.format(error))
        pass
        return {'statusCode': 500}

## HCOM-EC2-Detail-Report
#@lru_cache(maxsize=None)
def get_account_setting(account,setting,attribute):
    """Given account number and specified attribute, return value

    Args:
        account (_type_): AWS Account Number of existing Tenant
        setting (_type_): specific setting family defined in DynamoDB for AWS Account
        attribute (_type_): setting name

    Returns:
        String or list: value of specified setting
    """    
    try:
        #response = table.get_item(Key={'msptype': 'aws-account', 'mspname': targetAccount})
        for thisTenant, accounts in setTenants.items():
            for settings in accounts: # loop through accounts
                if settings['account'] == account: # matched target account
                    print(__name__,'returning {} with accounts {}'.format(attribute,settings[setting][attribute] ))
                    return settings[setting][attribute]
        
    except ClientError as error:
        print(__name__,'There was a problem getting feature {}'.format(error))
        pass
        return {'statusCode': 500}

### HCOM-CloudWatch-Dashboard
@lru_cache(maxsize=None)
def get_region_name(region):
    """_summary_

    Args:
        region (_type_): _description_

    Returns:
        _type_: _description_
    """    
    if region.find('east') > -1:
        return 'East'
    elif region.find('west') > -1:
        return 'West'
    elif region.find('south') > -1:
        return 'South'
    elif region.find('southeast') > -1:
        return 'SouthEast'
    elif region.find('northeast') > -1:
        return 'NorthEast'
    elif region.find('central') > -1:
        return 'Central'
    elif region.find('north') > -1:
        return 'North'

### HCOM-CloudWatch-Dashboard-Widget
def update_tenant_account(table,tenant, account):
    """_summary_

    Args:
        table (_type_): _description_
        tenant (_type_): _description_
        account (_type_): _description_

    Returns:
        _type_: _description_
    """    
    print(__name__,'tenant:{} update:{} tenants:{}'.format(tenant,account,setTenants))
    #acctTemplate = {'account': '', 'acctname': '', 'Active': True, 'Regions': [],'Environments': [], 'Features': {'AWSBackup':False,'CloudWatch':True,'OnPrem':False,'PatchMgmt':True,'SSMOpsItems':False,'StateMgmt':True,'Webhooks':False}, 'Tags': {'description':'','environment': '', 'patch': '', 'product': '', 'role': ''}, 'Topics': {'General':'','HelpDesk':''} }
    accountTemplate = {'msptype': 'tenant', 'mspname': tenant, 'accounts': [account]}
    for j, value in setTenants.items():
            if j == tenant: # matched tenant
                for i in value: # loop through accounts
                    print(__name__,'this account:{}'.format(i))
                    if i['account'] == account['account']: # matched target account
                        #accountTemplate['accounts'].append(account)
                        continue
                    else:
                        
                        accountTemplate['accounts'].append(i)
                    print(__name__,'accountTemplate: {}'.format(accountTemplate))
    print(__name__,'final modified tenant before update:{}'.format(accountTemplate))
    
    try:
        response = table.put_item(Item=accountTemplate)
        #clear_caches() # caching as been disabled
        return response
    except ClientError as error:
        print(__name__,'There was a problem updating Tenant Account in DynamoDB: {}'.format(error))
        pass
        return {'statusCode': 500}

"""
def clear_caches():
      
    print(__name__,'pre-cleared caches {} | {} | {} '.format(initializer.cache_info()))
    initializer.cache_clear() # clear core cache
    #get_tenant_accounts.cache_clear() # clear tenant accounts cache
    #get_account.cache_clear() # clear account detail cache
    #get_tenant_account_attribute.cache_clear # clear tenant account settings 
    #get_tenant_account_setting.cache_clear # clear tenant account features
    #get_account_setting.cache_clear # clear account settings
    is_valid_account.cache_clear # clear account settings
    print(__name__,'post-cleared caches {} | {} | {}  '.format(initializer.cache_info()) )
""" 

### HCOM-CloudWatch-Dashboard-Widget
def clear_widget_caches():
    """_summary_
    """    
    get_consolidated_widget_stats.cache_clear()
### Used by: HCOM-Backup-Job-Report.py,HCOM-CloudWatch-Alarm-Lifecycle-Automation.py

def account_to_name(account, tenants): # Converts AWS account number to name
    """Convert AWS account number to a friendly tenant name

    Args:
        account (String): AWS account number
        tenants (dict): list of tenants and their AWS account numbers

    Returns:
        String: friendly tenant name
    """
    # setTenants must be set by initializer. 
    Tenant: String = ''
    print(__name__,': source account:', account, ' list:', tenants)
    for key, value in tenants.items():
        for i in range(len(value)):
            print(__name__,'if {} = {}'.format(value[i],account))
            if value[i]['account'] == account:
                Tenant = key
                print(__name__,': found:', Tenant)
                return Tenant
    return Tenant

#-- Manage AWS API Connections --#

### Used by: HCOM-Backup-Job-Report.py, HCOM-Control-CW-Alarms.py, HCOM-CrossAccount-EC2-Detai-Report.py, HCOM-EC2-CW-Profile-Tagging.py
def send_sns_message(sns, TopicARN, ThisSubject, ThisMessage): # standard email function
    """Reusable send email to SNS topic

    Args:
        sns connection: boto3 connection to SNS service
        TopicARN string: target SNS topic
        ThisSubject string: subject of the message
        ThisMessage string: body of the message

    Returns:
        N/A
    """ 
    #emailtype = '' # this feature was removed as a pass-in variable. SNS topics does not yet support HTML emails
    #if emailtype != '': # standard non-html message
    try:
        snsresponse = sns.publish(
            TargetArn = TopicARN,
            Message = ThisMessage,
            Subject = ThisSubject
        )
    except ClientError as error:
        print(__name__,': SNS Send error. {} | {}'.format(TopicARN, error))
        print(__name__,': Subject: ', ThisSubject, '\n')
        print(__name__,': Message: ', ThisMessage, '\n')
        return error 

    return


### Used by: HCOM-CrossAccount-Diagrams-Lambda.py, HCOM-CrossAccount-EC2-Detail-Report.py
def upload_report(datafile,setBucket, setBucketReg, path, filename): # standard file upload to operations folder with path
    """_summary_

    Args:
        datafile (_type_): _description_
        setBucket (_type_): _description_
        setBucketReg (_type_): _description_
        path (_type_): _description_
        filename (_type_): _description_

    Returns:
        _type_: _description_
    """    
    s3 = boto3.client('s3', region_name=setBucketReg) # get connection
    ThisGUID = str(uuid.uuid4())
    #print(ThisGUID)
    today = datetime.datetime.now()
    thistime = today.strftime("%m") + '-' + today.strftime("%d") + '-' + today.strftime("%Y")
    filename = filename.split('.')
    Thisfilename = path+ filename[0] + '-' + thistime + '-' + ThisGUID[30:35] + '.' + filename[1]
    #print(__name__,': upload fields:', bucket, Thisfilename)
    response = s3.put_object (
        Body = datafile,
        Bucket = setBucket,
        Key = Thisfilename,
        ServerSideEncryption = 'aws:kms'
    )
    print(__name__,': upload:', response)
    return Thisfilename

### Used by:HCOM-Backup-Job-Report.py,
def upload_report2(datafile,setBucket, setBucketReg, Thisfilename): # standard file upload to operations folder without path
    """_summary_

    Args:
        datafile (_type_): _description_
        setBucket (_type_): _description_
        setBucketReg (_type_): _description_
        Thisfilename (_type_): _description_

    Returns:
        _type_: _description_
    """    
    try:
        s3 = boto3.client('s3', region_name=setBucketReg) # get connection
        response = s3.put_object (
            Body = datafile,
            Bucket = setBucket,
            Key = Thisfilename,
            ServerSideEncryption = 'aws:kms'
        )
        print(__name__,': upload:', response)
        return Thisfilename
    except Exception as error:
        print(__name__,': Unexpected error occurred trying to upload file...', error)
        return error
### Used By: HCOM-GUI-SSM-Automation-Docs
def download_file(setBucket, setBucketReg, path, filename):
    """_summary_

    Args:
        setBucket (_type_): _description_
        setBucketReg (_type_): _description_
        path (_type_): _description_
        filename (_type_): _description_

    Returns:
        _type_: _description_
    """    
    print(__name__,': bucket and region', setBucket, setBucketReg)
    print(__name__,': path/filename', path, filename)
    thisfilename = path + filename
    try:
        s3 = boto3.client('s3', region_name=setBucketReg) # get connection
        response = s3.get_object (
            Bucket = setBucket,
            Key = thisfilename,

        )
    except Exception as error:
        print(__name__,': Unexpected error occurred trying to download template...', error)
        return error
    #print(__name__,': upload:', response)
    content = response['Body'].read().decode('utf-8')
    return content

### Used By: HCOM-GUI
def create_stack(ThisRegion, stackname, cfbody):
    """_summary_

    Args:
        ThisRegion (_type_): _description_
        stackname (_type_): _description_
        cfbody (_type_): _description_

    Returns:
        _type_: _description_
    """    
    print(__name__,': --- Creating Stack for region:',ThisRegion, ' stack:',stackname)
    #print(__name__,': body:', cfbody)
    cf = boto3.client('cloudformation', region_name=ThisRegion)
    ### create stack
    try:
        response2 = cf.create_stack(
            StackName=stackname,
            TemplateBody=cfbody

        )
    except ClientError as error:
        print(__name__,': Unexpected error occurred... could not create stack. ', error)
        pass
        
        return error
    return response2['StackId']

### Used By: HCOM-GUI
def delete_stack(ThisRegion, stackname):
    """_summary_

    Args:
        ThisRegion (_type_): _description_
        stackname (_type_): _description_

    Returns:
        _type_: _description_
    """    
    print(__name__,': region:',ThisRegion, ' stack:',stackname)
    cf = boto3.client('cloudformation', region_name=ThisRegion)
    try:
        response = cf.delete_stack(
            StackName=stackname
        )
        print(__name__,': response:', response)
    except ClientError as error:
        print(__name__,': Unexpected error occurred... could not delete stack. ', error)
        pass
        
        return error

### Used by: HCOM-Backup-Job-Report.py, HCOM-CloudWatch-Alarm-Lifecycle-Automation.py, mspcwalarmcreator.py
def get_connection(Account,ThisRegion, arn): # standard sts connection
    """_summary_

    Args:
        Account (_type_): _description_
        ThisRegion (_type_): _description_
        arn (_type_): _description_

    Returns:
        _type_: _description_
    """    
    ThisARN = arn # used to assume role in cross accounts
    ThisARN = ThisARN.replace("tenantaccount", Account)
    ThisARN = ThisARN.replace("partition", setPartition)
    #################### Start: create client connections ##############################
    ## Assume cross account role
    sts_client = boto3.client('sts')
        
    try:
        crossCreds = sts_client.assume_role(
            RoleArn = ThisARN,
            RoleSessionName='assume_role_session3'
        )
    except ClientError as error:
        print(__name__,': Unexpected error occurred... could not assume role for EC2 resrouce connection', error)
        pass
        return {'statusCode': 400, 'statusmessage': error}
    try:
        ec3 = boto3.resource('ec2', 
                                  region_name=ThisRegion,
                                  aws_access_key_id=crossCreds['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=crossCreds['Credentials']['SecretAccessKey'],
                                  aws_session_token=crossCreds['Credentials']['SessionToken']
                                  )
        
    except ClientError as error:
        print(__name__,': Unexpected error occurred... could not create EC3 cross acount client on trusting account. ', error)
        return {'statusCode': 400, 'statusmessage': error}
    return ec3

### Used by: Core
def get_service_connection(Account,ThisRegion, arn,awsservice,connectiontype): # standard sts connection
    """Universal connection function that creates cross-account 'resource' or 'client' connections

    Args:
        Account (_type_): AWS account number
        ThisRegion (_type_): AWS Region
        arn (_type_): template arn for assume role

    Returns:
        conn: aws resource connection
    """
    ThisARN = arn # used to assume role in cross accounts
    ThisARN = ThisARN.replace("tenantaccount", Account)
    ThisARN = ThisARN.replace("partition", setPartition)
    #################### Start: create client connections ##############################
    ## Assume cross account role
    #print(__name__,': assume role info for ec2 resource:', ThisARN, ThisRegion)
    crossCreds = assume_role(ThisARN, ThisRegion)
    if connectiontype == 'client':
        try:
            ec3 = boto3.client(awsservice, 
                                    region_name=ThisRegion,
                                    aws_access_key_id=crossCreds['Credentials']['AccessKeyId'],
                                    aws_secret_access_key=crossCreds['Credentials']['SecretAccessKey'],
                                    aws_session_token=crossCreds['Credentials']['SessionToken']
                                    )
            
        except ClientError as error:
            print(__name__,': Unexpected error occurred... could not create {} cross acount client on trusting account. {}'.format(awsservice, error))
            return {'statusCode': 400, 'message': error}
    elif connectiontype == 'resource':
        try:
            ec3 = boto3.resource(awsservice, 
                                    region_name=ThisRegion,
                                    aws_access_key_id=crossCreds['Credentials']['AccessKeyId'],
                                    aws_secret_access_key=crossCreds['Credentials']['SecretAccessKey'],
                                    aws_session_token=crossCreds['Credentials']['SessionToken']
                                    )
            
        except ClientError as error:
            print(__name__,': Unexpected error occurred... could not create {} cross acount client on trusting account. {}'.format(awsservice, error))
            return {'statusCode': 400, 'message': error}
    return ec3

### Used by: HCOM-EC2-CW-Profile-Tagging.py, HCOM-CloudWatch-Alarm-Lifecycle-Automation.py, mspcwalarmcreator.py
def get_ec2_resource_connection(Account,ThisRegion, arn): # standard sts connection
    """_summary_

    Args:
        Account (_type_): _description_
        ThisRegion (_type_): _description_
        arn (_type_): _description_

    Returns:
        _type_: _description_
    """    
    ThisARN = arn # used to assume role in cross accounts
    ThisARN = ThisARN.replace("tenantaccount", Account)
    ThisARN = ThisARN.replace("partition", setPartition)
    #################### Start: create client connections ##############################
    ## Assume cross account role
    #print(__name__,': assume role info for ec2 resource:', ThisARN, ThisRegion)
    crossCreds = assume_role(ThisARN, ThisRegion)
    try:
        ec3 = boto3.resource('ec2', 
                                  region_name=ThisRegion,
                                  aws_access_key_id=crossCreds['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=crossCreds['Credentials']['SecretAccessKey'],
                                  aws_session_token=crossCreds['Credentials']['SessionToken']
                                  )
        
    except ClientError as error:
        print(__name__,': Unexpected error occurred... could not create EC3 cross acount client on trusting account. ', error)
        return error
    return ec3

### Used by: HCOM-CrossAccount-Diagrams-Lambda.py, HCOM-CrossAccount-EC2-Detail-Report.py, HCOM-EC2-CW-Profile-Tagging.py, HCOM-CloudWatch-Alarm-Lifecycle-Automation.py, mspcwalarmcreator.py
def get_ec2_client_connection(Account,ThisRegion, arn): # standard sts connection
    """_summary_

    Args:
        Account (_type_): _description_
        ThisRegion (_type_): _description_
        arn (_type_): _description_

    Returns:
        _type_: _description_
    """    
    ThisARN = arn # used to assume role in cross accounts
    ThisARN = ThisARN.replace("tenantaccount", Account)
    ThisARN = ThisARN.replace("partition", setPartition)
    #################### Start: create client connections ##############################
    ## Assume cross account role
    #print(__name__,': assume role info for ec2 client:', ThisARN, ThisRegion)
    crossCreds = assume_role(ThisARN, ThisRegion)
    try:
        ec3 = boto3.client('ec2', 
                                  region_name=ThisRegion,
                                  aws_access_key_id=crossCreds['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=crossCreds['Credentials']['SecretAccessKey'],
                                  aws_session_token=crossCreds['Credentials']['SessionToken']
                                  )
        
    except ClientError as error:
        print(__name__,': Unexpected error occurred... could not create EC3 cross acount client on trusting account. ', error)
        return error
    return ec3

### Used by: HCOM-CrossAccount-EC2-Detail-Report.py
def get_dynamodb_client_connection(Account,ThisRegion, arn): # standard sts connection
    """create cross account dynamodb connection

    Args:
        Account (_type_): _description_
        ThisRegion (_type_): _description_
        arn (_type_): _description_

    Returns:
        _type_: _description_
    """    
    ThisARN = arn # used to assume role in cross accounts
    ThisARN = ThisARN.replace("tenantaccount", Account)
    ThisARN = ThisARN.replace("partition", setPartition)
    #################### Start: create client connections ##############################
    ## Assume cross account role
    #print(__name__,': assume role info for ec2 client:', ThisARN, ThisRegion)
    crossCreds = assume_role(ThisARN, ThisRegion)
    try:
        ec3 = boto3.client('dynamodb', 
                                  region_name=ThisRegion,
                                  aws_access_key_id=crossCreds['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=crossCreds['Credentials']['SecretAccessKey'],
                                  aws_session_token=crossCreds['Credentials']['SessionToken']
                                  )
        
    except ClientError as error:
        print(__name__,': Unexpected error occurred... could not create dynamodb cross acount client on trusting account. ', error)
        return error
    return ec3

### Used by: HCOM-EC2-CW-Profile-Tagging.py, HCOM-CloudWatch-Alarm-Lifecyle-Automation, mspcwalarmcreator.py
def get_ssm_connection(Account,ThisRegion, arn): # standard ssm connection
    """_summary_

    Args:
        Account (_type_): _description_
        ThisRegion (_type_): _description_
        arn (_type_): _description_

    Returns:
        _type_: _description_
    """    
    #ThisARN = 'arn:aws-us-gov:iam::' + Account + ':role/HCOM-CrossAccount-Automation' # used to assume role in cross accounts for alarm creation based on metrics in cross accounts
    ThisARN = arn # used to assume role in cross accounts
    ThisARN = ThisARN.replace("tenantaccount", Account)
    ThisARN = ThisARN.replace("partition", setPartition) # setPartition is global var in core
    #################### Start: create client connections ##############################
    ## Assume cross account role
    print(__name__,': assume role info for ssm conn:', Account, ThisARN, ThisRegion, setPartition)
    response = assume_role(ThisARN, ThisRegion)
    print(__name__,'assume role credentials:{}'.format(response))
    ### Creae Systems Manager client connection
    try:
        ssm1 = boto3.client('ssm',
                            region_name=ThisRegion,
                            aws_access_key_id=response['Credentials']['AccessKeyId'],
                            aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                            aws_session_token=response['Credentials']['SessionToken']
                            )
    except ClientError as error:
        print(__name__,'-- get_ssm_connection -- Unexpected error occurred... could not create SSM Client connection. Error:{}'.format(error))
        return error
    return ssm1

### Used by: HCOM-CrossAccount-Diagrams-Lambda.py, HCOM-Backup-Job-Report.py, HCOM-CloudWatch-Alarm-Lifecycle-Automation.py, mspcwalarmcreator.py
def assume_role(ThisARN, ThisRegion):
    """Create a cross-account role for invoking automations within tenant accounts

    Args:
        ThisARN (String): template ARN to role to assume
        ThisRegion (String): Region for target account

    Returns:
        Conn: AWS role for target account
    """   

    ThisGUID = str(uuid.uuid4())
    session = 'session' + ThisGUID[30:35]
    print(__name__,'-- assuming role for arn: {} | region: {} | session: {}'.format(ThisARN,ThisRegion, session))  
    initial_client = boto3.client('sts', region_name=ThisRegion)
    try:
        response = initial_client.assume_role(
            RoleArn = ThisARN,
            RoleSessionName=session
        )
        return response
    except ClientError as error:
        print(__name__,'-- assume_role -- Unexpected error occurred... could not assume role. Check cross-account roles and permissions. Error: {}'.format(error))
        pass
        return {'statusCode': 400, 'message': error}

### Used by: HCOM-Dashboard-Widget
#@lru_cache(maxsize=None)
def get_consolidated_widget_stats(tenant, account, ThisRegion, env):
    """Read ops stats from DynamoDB to display in CloudWatch Dashboard widget

    Args:
        tenant (_type_): _description_
        account (_type_): _description_
        ThisRegion (_type_): _description_
        env (_type_): _description_

    Returns:
        _type_: _description_
    """    
    #ssm0 = boto3.client('ssm')
    dbcon = boto3.resource('dynamodb', region_name=setCentralRegion)
    table = dbcon.Table(setDBcon)
    standardenv = env.replace(' ', '')
    getStats = setConfigurations.get("OpsDashboard").replace('VV', tenant)
    getStats = getStats.replace('XX', account)
    getStats = getStats.replace('YY', standardenv)
    getStats = getStats.replace('region', ThisRegion)
    print(__name__,': parameter', setConfigurations.get("OpsDashboard"),getStats, tenant, ThisRegion, standardenv)
    try:
        dailyCount1 = table.get_item(Key={'msptype': 'opsstats', 'mspname': getStats})
        ThisDailyCount = dailyCount1['Item']
        print(__name__,'get results:', ThisDailyCount)
        #dailyCount = ssm0.get_parameter(Name=cw.setCWConfigurations.get('Lifecycle'))
        results = 1
    except KeyError as error:
        # set default
        ThisDailyCount = {'running': 0, 'stopped': 0, 'Online': 0, 'ConnectionLost': 0,'Inactive': 0,'In Alarm': 0, 'Insufficient Data': 0, 'Investigate': 0, 'EC2 Unprotected': 0, 'EFS Unprotected': 0} # default since no parameter exists yet
        pass
    """
    try:
        currentCount = ssm0.get_parameter(Name=getStats)
        ThisDailyCount2 = currentCount['Parameter']['Value']
        ThisDailyCount = ast.literal_eval(ThisDailyCount2)
    except Exception as error:
        print(__name__,': parameter not found: ', getStats, tenant, ThisRegion, standardenv)
        # set default
        ThisDailyCount = {'running': 0, 'stopped': 0, 'In Alarm': 0, 'Insufficient Data': 0, 'Investigate': 0, 'EC2 Unprotected': 0, 'EFS Unprotected': 0} # default since no parameter exists yet
    """
    return ThisDailyCount

### Used by: HCOM-CloudWatch-Custom-Metric-Processor, HCOM-EC2-Detail-Report
def update_ops_stats(tenantStats, account, ThisRegion, env, aname, count, count_details,mode): # updates parameter with ops stats for custom CW Dashboard widget
    """Update the ops stats in DynamoDB that drives the stats on CloudWatch Dashboard

    Args:
        tenantStats (_type_): _description_
        ThisRegion (_type_): AWS Region for target instances to count
        env (_type_): target environment for stats to update
        aname (_type_): _description_
        count (_type_): the value or count to update
        mode (_type_): mode for feature to invoke
    """
    # mode, 1 = replace, 2 = add, 3 = subtract
    print(__name__, '--- Begin update_ops_stats, Tenant:{} | Region: {} | env: {} | name: {} | count: {} | count_detail: {} mode: {}'.format( tenantStats, ThisRegion, env, aname, count, count_details,mode))
    Thiscounter = 0
    #ssm0 = boto3.client('ssm')
    #dbcon = boto3.resource('dynamodb', region_name=setCentralRegion)
    #table = dbcon.Table(setDBcon)
    table = boto3.resource('dynamodb', region_name=setCentralRegion).Table(setDBcon)
    standardenv = env.replace(' ', '')
    print(__name__,' OpsDashboard template name: {}'.format(setConfigurations.get("OpsDashboard")))
    getStats = setConfigurations.get("OpsDashboard").replace('VV', tenantStats)
    getStats = getStats.replace('XX', account)
    getStats = getStats.replace('YY', standardenv)
    getStats = getStats.replace('region', ThisRegion)
    opsstats = 'opsstats'
    print(__name__,': parameter', getStats, tenantStats, ThisRegion, aname, count) # for testing use
    try:
        dailyCount1 = table.get_item(Key={'msptype': opsstats, 'mspname': getStats})
        if dailyCount1['Item']:
            print(__name__,'results:', type(dailyCount1), dailyCount1)
            ThisDailyCount = dailyCount1['Item']
            results = 1
        else:
            print(__name__,'nothing found')
        
    except KeyError as error:
        print(__name__, getStats, ' does not exist so creating it.', dailyCount1)
        #createitem = {"msptype": {"S": "core"},"name": {"S": getStats},"running": {"S": "0"},"stopped": {"S": "0"},"In Alarm": {"S": "0"},"Insufficient Data": {"S": "0"},"EC2 Unprotected": {"S": "0"},"EFS Unprotected": {"S": "0"}}
        createitem = {"msptype": opsstats, "mspname": getStats,"running": 0,'running details': [],"stopped": 0,'stopped details': [],"Online": 0,'Online details': [],"ConnectionLost": 0,'ConnectionLost details': [],"Inactive":0,'Inactive details': [],"In Alarm": 0,'In Alarm details': [],"EC2 Unprotected": 0,'EC2 Unprotected details': [],"EC2 Unprotected": 0,'EC2 Unprotected details': [],"EFS Unprotected": 0,'EFS Unprotected details': [],"OnPrem Unprotected": 0,'OnPrem Unprotected details': [],"RDS Unprotected": 0,'RDS Unprotected details': [],"DynamoDB Unprotected": 0,'DynamoDB Unprotected details': []}
        results = table.put_item(Item=createitem)
        print(__name__, ' put item results:',results)
        ThisDailyCount = {'running': 0, 'running details': [],'stopped': 0, 'stopped details': [],'Online': 0,'Online details':[],'ConnectionLost': 0,'ConnectionLost details':[],'Inactive': 0,'Inactive details':[],'In Alarm': 0, 'In Alarm details':[],'Insufficient Data': 0, 'Insufficient Data details':[],'Investigate': 0, 'Investigate details':[],'EC2 Unprotected': 0, 'EC2 Unprotected details':[],'EFS Unprotected': 0,'EFS Unprotected details':[],'OnPrem Unprotected': 0,'OnPrem Unprotected details':[],"RDS Unprotected": 0,'RDS Unprotected details': [],"DynamoDB Unprotected": 0,'DynamoDB Unprotected details': []}
        pass
    """
    try:
        dailyCount = ssm0.get_parameter(Name=getStats)
        ThisDailyCount2 = dailyCount['Parameter']['Value']
        ThisDailyCount = ast.literal_eval(ThisDailyCount2)
    except Exception as error:
        print(__name__,': parameter not found: ', getStats, tenantStats, ThisRegion, aname, count)
        # set default
        ThisDailyCount = {'running': 0, 'stopped': 0, 'In Alarm': 0, 'Insufficient Data': 0, 'Investigate': 0, 'EC2 Unprotected': 0, 'EFS Unprotected': 0} # default since no parameter exists yet
    """
    ### Update values
    detailsname = aname + ' details'
    try:
        print(__name__,': get counter for metric:', aname)
        Thiscounter = int(ThisDailyCount.get(aname))
        Thisdetails = [ThisDailyCount.get(detailsname)]
    except Exception as error:
        print(__name__,': no existing stat for:', aname)
        Thiscounter = 0
    print(aname,' targetItem:', count)
    
    if mode == 1: # replace
        ThisDailyCount.update({aname : count})
        ThisDailyCount.update({detailsname : count_details})
    elif mode == 2: # add
        Thiscounter = Thiscounter + 1
        for i in count_details:
            Thisdetails.append(i)
        ThisDailyCount.update({aname : Thiscounter})
        ThisDailyCount.update({detailsname : Thisdetails})
    elif mode == 3: # subtract
        if Thiscounter != 0:
            Thiscounter = Thiscounter - 1
            for i in count_details:
                Thisdetails.remove(i)
        ThisDailyCount.update({aname : Thiscounter})
        ThisDailyCount.update({detailsname : Thisdetails})     
    print(ThisDailyCount)
    ### Update Parameter
    try:
        print(__name__, ' updating:',ThisDailyCount)
        response2 = table.put_item(
            Item=ThisDailyCount
        )

        print(__name__, ' results from final put/update:', response2)
    except ClientError as error:
        print(__name__, 'Could not update EC2 count.', error)
        response = 'error'
    """
    try:
        #print(__name__,': putting:', getStats)
        results = ssm0.put_parameter(Name=getStats,
        Value = str(ThisDailyCount),
        Type = 'String',
        Overwrite=True)
        #results = 1
                
    except Exception as error:
        print(__name__,': An error occurred while trying to update ops stats. Will automatically retry in 10 secs.', aname, count, ThisRegion, getStats, error)
        time.sleep(10)
        results = ssm0.put_parameter(Name=getStats,
        Value = str(ThisDailyCount),
        Type = 'String',
        Overwrite=True)
    #print(__name__,': results 2:', results)   
    """

### Used by: HCOM-CloudWatch-Dashboard-Widgets
#@lru_cache(maxsize=None)
def get_environs(environs, tenant):
    """Get environments for target Tenant for dashboard widget use
    Environments examples: DEV, Test, Prod, etc.

    Args:
        environs (dict): all existing tenants and their environments
        tenant (string): name of target tenant to find in dict

    Returns:
        String: List of enviornments for tenant
    """    
    print(__name__,': check:', environs, tenant)
    env = []
    env = environs.get(tenant)
    print(__name__,': final:',env)
    return env

# used by HCOM-SQS-Processor
""" # this is likely obsolete and no longer needed 3/1/2023
def update_ec2_status(item, ec2Status, config, ThisSSMRegion):
    ############## Get daily automation counts #############
    ssm0 = boto3.client('ssm', region_name=ThisSSMRegion)
    ThisCurrentCount = {}
    try: # this may not exist yet
        currentCount = ssm0.get_parameter(Name=config)
        ThisCurrentCount2 = currentCount['Parameter']['Value']
        ThisCurrentCount = ast.literal_eval(ThisCurrentCount2)
    except ClientError as error:
        ThisCurrentCount = {}
        pass
    #time.sleep(10)
    #print(__name__,': ThisCurrentCount', ThisCurrentCount.get('reboot'), ThisCurrentCount.get('terminated'))
    print(__name__,': EC2 Status Before Update: ThisCurrentCount', ThisCurrentCount)
    print(__name__,': ec2Status:', ec2Status)
    ThisCurrentCount.update({'running': ec2Status.get("running")})
    ThisCurrentCount.update({'stopped': ec2Status.get("stopped")})
    print(__name__,': Revised Count: ThisCurrentCount', ThisCurrentCount)
    ssm0.put_parameter(Name=config,
        Value = str(ThisCurrentCount),
        Type = 'String',
        Overwrite=True)
"""

### HCOM-SQS-Processor # this might be discontinued currently commented out of SQS Lambda
def get_ec2_environment_status(AccountNum, BaseARN, EnvTag, ThisEnv, ThisRegion):
    """Lookup current status for all EC2 based on account, region and Environment Tag value

    Args:
        AccountName string: AWS Account Name
        AccountNum string: AWS Account Number
        BaseARN string): ARN for cross account role to assume
        InstanceId string: Instance Id
        ThisRegion string: AWS region of instance

    Returns:
        dict: running, stopped
    """    
    #ec2 = get_ec2_client_connection(Account,ThisRegion, BaseARN)
    ec2 = get_ec2_client_connection(AccountNum, ThisRegion, BaseARN)
    #print(__name__,': type',type(ec3), InstanceId)
    ec2Status = {}
    EnvTag = 'tag:' + EnvTag
    try: # get all running instances
        responses = ec2.describe_instances(Filters=[{'Name': EnvTag, 'Values':[ThisEnv]},{'Name':'instance-state-name', 'Values':['running','pending']}]) # Find instances
        running = len(responses['Reservations'])
        print(__name__,': running instances found:', len(responses['Reservations']))
        ec2Status["running"] = running
    except ClientError as error:
        print(__name__,': Unexpected error occurred... could not find target EC2 instance. Check that the Tag value ' + EnvTag +'/' + ThisEnv + ' are correct.', error)
    try: # get all stopped instances
        responses2 = ec2.describe_instances(Filters=[{'Name': EnvTag, 'Values':[ThisEnv]},{'Name':'instance-state-name', 'Values':['stopped','stopping']}]) # Find instances
        stopped = len(responses2['Reservations'])
        print(__name__,': stopped instances found:', len(responses2['Reservations']))
        ec2Status["stopped"] = stopped
    except ClientError as error:
        print(__name__,': Unexpected error occurred... could not find target EC2 instance. Check that the Tag value ' + EnvTag +'/' + ThisEnv + ' are correct.', error)   
    return ec2Status
### HCOM-SQS-Processor # this might be discontinued currently commented out of SQS Lambda
def get_this_ec2_environment(AccountName, AccountNum, ThisARN, InstanceId, ThisRegion,onprem):
    """Lookup EC2/OnPrem Environment Tag value

    Args:
        AccountName string: AWS Account Name
        AccountNum string: AWS Account Number
        BaseARN string): ARN for cross account role to assume
        InstanceId string: Instance Id
        ThisRegion string: AWS region of instance

    Returns:
        string: Environment Tag value
    """
    if onprem == 0: # this is EC2 instance
        #ec2 = get_ec2_client_connection(Account,ThisRegion, BaseARN)
        ec3 = get_ec2_resource_connection(AccountNum, ThisRegion, ThisARN)
        #print(__name__,': type',type(ec3), InstanceId)
        env = ''
        try:
            ec2instance = ec3.Instance(InstanceId)
            instancename = ''
            for tags in ec2instance.tags:
                if tags["Key"] == setTags.get("environment"):
                    env = tags["Value"]
                    return env
                else:
                    continue
        except ClientError as error:
            print(__name__,': Error connecting to EC2 to grab environment tag value', error)
            return env
    else: # this is onprem instance
        ssm1 = get_ssm_connection(AccountNum, ThisRegion, ThisARN)
        tags = ssm1.list_tags_for_resource(ResourceType='ManagedInstance',ResourceId=InstanceId)
        print(__name__, 'tags', tags)
        for tag in tags['TagList']:
            print(__name__, 'tag',tag)
            if tag['Key'] == setTags.get("environment"):
                Thisenv = tag['Value'] # set the Environment name from tag value
                return Thisenv

### Used by: HCOM-CloudWatch-Alarm-Response-Runner
def invoke_lambda(lname,itype, payload, region):
    """Invoke Lambdas for various functions including alarm response

    Args:
        lname (string): target Lambda function name
        itype (string): type of invocation
        payload (string): parameters being passed
        region (string): region where the target lambda is located

    Returns:
        string: response
    """    
    client = boto3.client('lambda', region_name=region)
    if itype == '':
        itype = 'Event'
    
    response = client.invoke(
        FunctionName=lname,
        InvocationType=itype,
        ClientContext='hcom-automation',
        Payload=payload)
    return response

### Used by: HCOM-CloudWatch-Alarm-Response-Runner
def invoke_runbook(runbook, runbookrole, payload,Account,ThisRegion):
    """Used to invoke AWS SSM Automation Runbook for cloudwatch alarm response

    Args:
        runbook (string): SSM Automation document/runbook name
        instance (string): EC2 instance ID from triggered alarm
        account (string): AWS account from triggered alarm
        payload (string): event parameters from triggered alarm
        region (string): region for central account where Lambda is located

    Returns:
        string: response
    """
    ThisARN = setIAM.get("Cross-Account") # used to assume role in cross accounts
    ThisARN = ThisARN.replace("tenantaccount", Account)
    ThisARN = ThisARN.replace("partition", hcom.setPartition)
    #targets = []
    #locations = [{}]
    params = {}
    client = get_ssm_connection(Account,ThisRegion, ThisARN)
     
    #targets = "[ {Key=InstanceIds, Values=" + payload.get('InstanceId') +"} ]"
    #targets.append("Key=InstanceIds")
    #targets.append("Values=" + payload.get('InstanceId'))
    targets = [{'Key': 'InstanceIds', 'Values': [payload.get('InstanceId')]}]
    #params = payload
  
    #locations = "[ { 'Accounts':[" + payload.get('account') + " ], [ { 'Regionss':[" + payload.get('region') + "]} ]]"
    #locations.append("Accounts: [" + payload.get('account') + "]")
    #locations["Regions"] = [payload.get('region')]
    TargetName = 'InstanceId'
    locations = [{'Accounts': [payload.get('account')], 'Regions': [payload.get('region')], 'ExecutionRoleName': runbookrole}]
    Thispayload = {'InstanceId' : [payload.get('InstanceId')]}
    print(__name__,': targets: ',targets)
    print(__name__,': parms: ', payload)
    print(__name__,': Thispyload: ', Thispayload)
    print(__name__,': locations: ', locations)
    print(__name__,': execution role: ', runbookrole)
    #sys.exit()
    ppload = params
    params2 = json.dumps(str(payload))
    response = client.start_automation_execution(
        DocumentName=runbook,
        Parameters= Thispayload,
        #TargetParameterName=TargetName,
        #Targets=targets,
        TargetLocations=locations)
    return response

### Used by: HCOM-CloudWatch-Alarm-Response-Runner
def invoke_rundoc(ThisInstanceID, RunDocument, RunDocumentParam,ThisRegion,Account): # purpose: , used by:
    ThisARN = setIAM.get("Cross-Account") # used to assume role in cross accounts
    ThisARN = ThisARN.replace("tenantaccount", Account)
    ThisARN = ThisARN.replace("partition", setPartition)
    ssm1 = client = get_ssm_connection(Account,ThisRegion, ThisARN)
    print(__name__,': before parsing:', RunDocumentParam)
    #RunParam = ast.literal_eval(RunDocumentParam)
    RunParam = RunDocumentParam
    #RunDocParam = json.loads(RunDocumentParam)
    #RunDocParam = dict((a.strip(), b.strip())  
    #                 for a, b in (element.split('-')  
    #                              for element in RunDocumentParam.split(', ')))
    print(__name__,': params type:', type(RunParam), ' value:', RunParam)
    try:
        cwresponse = ssm1.send_command(
            InstanceIds=[ThisInstanceID],
            DocumentName = RunDocument,
            DocumentVersion='$LATEST',
            Parameters=RunParam,
        )
    except ClientError as error:
        print(__name__,': Run Command ran into an error.', error)
        return error

### Used by: HCOM-CloudWatch-Lifecycle-Automation
def send_webhook(targetchannel, targeturl,message, sender): # docs for example at https://hevodata.com/learn/sns-to-slack/ https://dev.to/aws-builders/how-to-send-aws-notifications-aws-sns-to-microsoft-teams-1d1l
    http = urllib3.PoolManager()
    url = targeturl
    #"text": event['Records'][0]['Sns']['Message'],
    #"icon_emoji": ""
    msg = {
        "channel": targetchannel,
        "username": sender,
        "text": message
        }
    
    encoded_msg = json.dumps(msg).encode('utf-8')
    try:
        resp = http.request('POST',url, body=encoded_msg)
        print({
            "message": message, 
            "status_code": resp.status, 
            "response": resp.data })
    except ClientError as error:
        print(__name__, 'Error trying to send webhook. {} | {}'.format(targetchannel, error))
        pass 

### All automations *** For future use
def log_hcom_event(ThisSource,detail):
    eb = boto3.client('events', region_name=setCentralRegion) # create connection
    source = 'hcom.' + ThisSource
    detailtype = '' # get from either DynamoDB or cw initializer variable
    event = {'Source': source, 'DetailType': detailtype, 'Detail': detail, 'EventBusName': setConfigurations['CentralEB']}
    try:
        response = eb.put_events(Entries=event)
    except ClientError as e:
        print(__name__,'we had a problem creating event. {} | {}'.format(response,e))
#-- Inactive or in development (not actively used) --#

### This was used as alternative for testing but not used
def send_webhook2(event, targetchannel, targeturl,message):
    thisdata = {}
    thisdata.update({"message": message})
    thisdata.update({"channel": targetchannel})
    request = req.Request(url="https://mooreinsight.webhook.office.com/webhookb2/c892cd82-5b1f-4dee-81b7-7821241876d9@f4f94473-19f9-45a6-a926-0e26f126f2c7/IncomingWebhook/47b265af479644de9abefe789014e597/9b070572-333e-4a44-b19a-66052253473b", method="POST")
    request.add_header(key="Content-Type", val="application/json")
    data = json.dumps({"text": "Test message"}).encode()
    r = req.urlopen(url=request, data=data)
class TeamsWebhookException(Exception):
    pass

### Used by: May not be used

#### divider core above, cw below

# This file contains cloudwatch shared services functions. Filename: cw.py Used by all CloudWatch automations.
# v.70 Last modified on 7/26/2023 Author tom.moore@gdit.com

#-- initialize CloudWatch Features and Functions --#
global setAlarmActions, setNonEC2AlarmActions, setMissingData, setMetricOperators #setOnPremLinuxMetrics, setOnPremWindowsMetrics,setEC2LinuxMetrics,setEC2WindowsMetrics
#setOnPremLinuxMetrics = ["cpu_usage_idle", "cpu_usage_iowait","mem_used_percent","disk_used_percent", "disk_inodes_free","diskio_write_bytes","diskio_read_bytes","diskio_writes","diskio_reads","net_bytes_sent","net_bytes_recv","net_packets_sent", "net_packets_recv", "swap_used_percent","procstat_lookup_pid_count"]
#setOnPremWindowsMetrics = ["Processor % Idle Time","Processor % Interrupt Time","Processor % User Time","Memory % Committed Bytes In Use", "LogicalDisk % Free Space","Paging File % Usage","PhysicalDisk % Disk Time","procstat_lookup_pid_count"]
#setEC2LinuxMetrics = ["CPUUtilization","cpu_usage_idle", "cpu_usage_iowait","cpu_usage_user","cpu_usage_system","mem_used_percent","disk_used_percent", "disk_inodes_free","diskio_io_time","diskio_write_bytes","diskio_read_bytes","diskio_writes","diskio_reads","swap_used_percent","procstat_lookup_pid_count"]
#setEC2WindowsMetrics = ["CPUUtilization","mem_used_percent", "Processor % Idle Time","Processor % Interrupt Time","Processor % User Time","Memory % Committed Bytes In Use", "LogicalDisk % Free Space","Paging File % Usage","PhysicalDisk % Disk Time","procstat_lookup_pid_count"]
setMetricOperators = ["GreaterThanThreshold", "GreaterThanOrEqualToThreshold", "LessThanThreshold", "LessThanOrEqualToThreshold"]
setAlarmActions = ["Lambda","SSM-Rundoc","State Profile","Stop","Reboot","Terminate"] # removing "SSM-Runbook" for now to add execution role option
setNonEC2AlarmActions = ["Lambda","SSM-Rundoc","State Profile"]
setMissingData = ['breaching', 'missing', 'notBreaching','ignore']
### Used by: All CW automations except: HCOM-CloudWatch-Custom-Metric-Runner.py
#@lru_cache(maxsize=None)
def cw_initializer(config,table):
    """Initializes CloudWatch configuration settings to leverage shared code/module

    Args:
        config (String): Passes the name of the parameter for the CloudWatch configuration settings
    """
    global setCWResourceTypes
    #ssm0 = boto3.client('ssm')
    dbcon = boto3.client('dynamodb', region_name=primaryregion)
    print(__name__, ' CW -initializing CW configuration')
    global setGUI, setCWTopics, setCWTags, setCWConfigurations, setCustomMetrics, setOnPremLinuxMetrics, setOnPremWindowsMetrics,setEC2LinuxMetrics,setEC2WindowsMetrics
    ####### Start: Get CWAgent Configuration ###############
    configuration1 = dbcon.query(
        TableName=config,
        Select='ALL_ATTRIBUTES',
        ConsistentRead=True, 
        ExpressionAttributeValues={':cores':{'S': 'cw'}},
        KeyConditionExpression='msptype = :cores')
    #print(__name__, 'count:',range(configuration1['Count']))
    print(__name__, 'results:',configuration1)

    for j in range(configuration1['Count']): # loop through configuration items
        #print(configuration1['Items'][j]['msptype']['S'], varName = configuration1['Items'][j]['mspname']['S'])
        varName = varName = configuration1['Items'][j]['mspname']['S']
        
        if varName == 'tags': ## have not replaced yet
            setCWTags = {}
            setCWTags['profile'] = configuration1['Items'][j]['profile']['S']
            setCWTags['suppress'] = configuration1['Items'][j]['suppress']['S']
            #elif varName == 'topics':
            #    setCWTopics = {} 
            #    setCWTopics['Central'] = configuration1['Items'][j]['Central']['S'] 
        elif varName == 'configurations':
            setCWConfigurations = {} 
            setCWConfigurations['CWAgent'] = configuration1['Items'][j]['CWAgent']['S'] 
            setCWConfigurations['Alarms'] = configuration1['Items'][j]['Alarms']['S'] 
            setCWConfigurations['AuditReportPath'] = configuration1['Items'][j]['AuditReportPath']['S'] 
            setCWConfigurations['AuditReport'] = configuration1['Items'][j]['AuditReport']['S'] 
            setCWConfigurations['Lifecycle'] = configuration1['Items'][j]['Lifecycle']['S'] 
            setCWConfigurations['CustomMetricsConfiguration'] = configuration1['Items'][j]['CustomMetricsConfiguration']['S'] 
            setCWConfigurations['CustomMetricsTemplate'] = configuration1['Items'][j]['CustomMetricsTemplate']['S'] 
            setCWConfigurations['CustomMetricLog'] = configuration1['Items'][j]['CustomMetricLog']['S'] 
            setCWConfigurations['AlarmResponseDimension'] = configuration1['Items'][j]['AlarmResponseDimension']['S'] 
            setCWConfigurations['AlarmReportPath'] = configuration1['Items'][j]['AlarmReportPath']['S'] 
            setCWConfigurations['AlarmReport'] = configuration1['Items'][j]['AlarmReport']['S'] 
            setCWConfigurations['ProfileTypes'] = []
            for item in configuration1['Items'][j]['ProfileTypes']['L']:
                #print(__name__,'--item: ', item, type(item), item['S']) # for debugging
                setCWConfigurations['ProfileTypes'].append(item['S'])

        #elif varName == 'custommetrics':
        #    setCustomMetrics = {} 
        #    setCustomMetrics = configuration1['Items'][j]['suppress']['S'] 
           
    ###### load cloudwatch profile data
    #table = dbcon.Table(core.setDBTable)
    try:
        response = table.get_item(Key={'msptype': 'cw-profiles', 'mspname': 'types'})
        #print(__name__,'loaded profile results:{}'.format(response['Item']))   # for debugging
        setCWResourceTypes = response['Item']

    except ClientError as error:
        print(__name__,'error loading profiles:{}'.format(error))
    #sys.exit()
#-- functions used to manage agents --#

### Used by: HCOM-CloudWatch-Alarm-Lifecycle-Automation.py
def install_cw_agent(ssm1, ThisInstanceID, ThisPlatform): # purpose: install CW agent, used by: CW Alarm creator, Lifecycle Automation
    try:
        
        cwresponse = ssm1.send_command(
            InstanceIds=[ThisInstanceID],
            DocumentName="AWS-ConfigureAWSPackage",
            Parameters={'action': ['Install'], 'name': ['AmazonCloudWatchAgent'], 'installationType': ['Uninstall and reinstall']},
        )
        cmdId = cwresponse['Command']['CommandId']
        print(__name__,'--- Start Installation of CW Agent ---', ThisInstanceID, cmdId)

        
        if ThisPlatform == 'Linux':
            time.sleep(25)
        else: ## must be windows
            time.sleep(45)
            print(__name__, 'waiting 40 seconds for install to finish')
        
        downloadFolder = ssm1.get_command_invocation(
            CommandId=cmdId,
            InstanceId=ThisInstanceID,
            PluginName="createDownloadFolder"
        )
        count = 0
        while downloadFolder.get('Status') != 'Success' and downloadFolder.get('Status') != 'Failed':
            time.sleep(5)
            downloadFolder = ssm1.get_command_invocation(
            CommandId=cmdId,
            InstanceId=ThisInstanceID,
            PluginName="createDownloadFolder"
            )
            count = count + 1
            print(__name__,'wait:', count, downloadFolder.get('Status'))
            if count == 24: # only give 2 mins maximum time 5 secs * 24 = 120 seconds
                break
        configurePackage = ssm1.get_command_invocation(
            CommandId=cmdId,
            InstanceId=ThisInstanceID,
            PluginName="configurePackage"
            )
        count = 0 # reset counter, this next one should take less time as it runs concurrent to previous
        while configurePackage.get('Status') != 'Success' and configurePackage.get('Status') != 'Failed':
            configurePackage = ssm1.get_command_invocation(
            CommandId=cmdId,
            InstanceId=ThisInstanceID,
            PluginName="configurePackage"
            )
            count = count + 1
            print(__name__,'wait:', count,onfigurePackage.get('Status'))
            if count == 24: # only give 2 mins maximum time 5 secs * 24 = 120 seconds
                break
        #print(__name__, 'download:', downloadFolder)
        #print(__name__, 'config package:', configurePackage)
        downloadFolderStatus = downloadFolder.get('Status')
        configurePackageStatus = configurePackage.get('Status')
        if downloadFolderStatus == 'Success' and configurePackageStatus == 'Success':
            cwstatus = 'Success'
        else:
            cwstatus = 'Failed'
        print(__name__,'--- Finish Installation of CW Agent ---', cmdId,cwstatus)
        return cwstatus
    except Exception as e:
        print(__name__, 'Error trying to install CW Agent. Sleeping for 60 sec and will try again.',cmdId, e)
        time.sleep(60)
        cwresponse = ssm1.send_command(
            InstanceIds=[ThisInstanceID],
            DocumentName="AWS-ConfigureAWSPackage",
            Parameters={'action': ['Install'], 'name': ['AmazonCloudWatchAgent']},
        )
        cmdId = cwresponse['Command']['CommandId']
        print(__name__,'--- Start Installation attempt #2 of CW Agent pausing another 60 secs ---', ThisInstanceID, cmdId)
        time.sleep(60)
        pass
        return 'Success' # did not actually recheck but sending Success so it attempts to create alarms to improve first-time boot alarm creation reliability

## used by HCOM-CloudWatch-Dashboard-Widget, HCOM-Platform-Configuration-Manager
#@lru_cache(maxsize=None)    
def get_cw_resource_type(targetprofiletype):
    """Given a cloudwatch profile type, return the resource type for dynamodb calls

    Args:
        targetprofiletype (String): name of profile type

    Returns:
        String: return resource type name (cw-profile,dynamodb-profile, etc.)
    """
    print(__name__,'targetprofiletype: {}'.format(targetprofiletype))
    for var in setCWResourceTypes['resourcetypes']: # loop through resource types
        for x, namespaces in var.items():
            print(__name__,'step 1: get_cw_resource_type: X:{} | namespaces: {}'.format(x,namespaces))
            for namespace, ptype in namespaces['namespace'].items():
                print(__name__,'step 2: get_cw_resource_type: namespace:{} | {}'.format(namespace, ptype))
                if targetprofiletype in ptype:
                    print(__name__,'-- step 3: resource type: {} found in: {}'.format(x, ptype))
                    return x
    return ''

### Used by: HCOM-CloudWatch-Alarm-Lifecycle-Automation.py
def check_cw_agent(ssm1, ThisInstanceID, ThisPlatform,onprem):
    global ThisPushConfig
    thisparam = {}
    thisparam['action'] = ['status']
    thisparam['mode'] = ['ec2']
    if onprem == 'yes':
        thisparam['mode'] = ['onPremise']
    try:
        cwresponse = ssm1.send_command(
            InstanceIds=[ThisInstanceID],
            DocumentName='AmazonCloudWatch-ManageAgent',
            DocumentVersion='$LATEST',
            Parameters=thisparam,
        )
        print(__name__,'initial response:', cwresponse)
        cmdId = cwresponse['Command']['CommandId']
        #plugin = cwresponse['Command']['PluginName']
        
        if ThisPlatform == 'Linux':
            time.sleep(60)
            output = ssm1.get_command_invocation(
                CommandId=cmdId,
                InstanceId=ThisInstanceID,
                PluginName="ControlCloudWatchAgentLinux"
            )
            cw_status = output['Status']
            print(__name__,' inside status:', cw_status)
        else: # windows check status
            time.sleep(30)
            print(__name__, 'waiting 30 secs for cw agent check')
            output = ssm1.get_command_invocation(
                CommandId=cmdId,
                InstanceId=ThisInstanceID,
                PluginName="ControlCloudWatchAgentWindows"
            )
            cw_status = output['Status']
            print(__name__,' inside status:', cw_status)
        #print(output)
        """
        try:
            x = output.get('StandardOutputContent')
            y = json.loads(x)
            cw_status = y['status']
            print(__name__, 'CW Agent Final status', cw_status)
        except ClientError as error: # changed from Exception
            cw_status = 'timedout waiting for response'
            pass
        """
        return cw_status
    except ClientError as error:
        print(__name__, 'Run Command ran into an error checking CW Agent Status: {}'.format(error))
        return error

### Used by: mspcwalarmcreator.py, HCOM-CloudWatch-Alarm-Lifecycle-Automation.py
def push_cw_config(ssm1, ThisInstanceID, ThisConfig, ThisPlatform, onprem, Wait):
    """Switch that will push the CloudWatch Agent configuration to instance to configure and start agent

    Args:
        ssm1 (_type_): SSM Connection
        ThisInstanceID (_type_): Instance to push agent configuration
        ThisConfig (_type_): Which parameter in parameter store holds configuration
        ThisPlatform (_type_): Is Linux or Windows
        onprem (_type_): is this an onpremise instance?
        Wait (_type_): pause in seconds

    Returns:
        String: results
    """    
    global ThisPushConfig
    print(__name__, 'instance:', ThisInstanceID, 'config:',ThisConfig, "platform:",ThisPlatform)
    #sys.exit()
    thisparam = {}
    thisparam['optionalConfigurationLocation'] = [ThisConfig]
    if onprem == 'yes':
        thisparam['mode'] = ['onPremise']

    try:
        cwresponse = ssm1.send_command(
            InstanceIds=[ThisInstanceID],
            DocumentName='AmazonCloudWatch-ManageAgent',
            DocumentVersion='$LATEST',
            Parameters=thisparam,
        )
        try:
            print(__name__, 'raw response:', cwresponse)
            cmdId = cwresponse['Command']['CommandId']
            time.sleep(5)
            if ThisPlatform == 'Linux':
                status = ssm1.get_command_invocation(CommandId=cmdId, InstanceId=ThisInstanceID)
                #print(__name__, 'inside Linux')
                while status == 'Pending' or status == 'In Progress':
                    time.sleep(1)
                    status = ssm1.get_command_invocation(CommandId=cmdId, InstanceId=ThisInstanceID)
                    print(__name__, 'status inside While:', status['Status'], status['StatusDetails'])
                    
                output = ssm1.get_command_invocation(
                    CommandId=cmdId,
                    InstanceId=ThisInstanceID,
                    PluginName="ControlCloudWatchAgentLinux"
                )
            else:
                time.sleep(Wait)
                status = ssm1.get_command_invocation(CommandId=cmdId, InstanceId=ThisInstanceID)
                print(__name__, 'status:', status['Status'], status['StatusDetails'])
                output = ssm1.get_command_invocation(
                    CommandId=cmdId,
                    InstanceId=ThisInstanceID,
                    PluginName="ControlCloudWatchAgentWindows"
                )
            #print(__name__, 'output', output)
            print(__name__, 'status', output['Status'])
            return output['Status']
        except ClientError as error:
            print(__name__, 'Error retrieving Push Config Run Document results.', error)
            logger.exception('error')
            return error
    #command_id = cwresponse['Command']['CommandId']
    #print(__name__, 'Push CWAgent config file Results (Run Command):',command_id)
    except ClientError as error2:
        print(__name__, 'Run Command ran into an error.', error2)
        #ThisPushConfig = ThisPushConfig + 'Instance:' + ThisInstanceID + ' CWAgent-Profile:' + ThisConfig + '\n'
        print
        return error2

#-- CW Utility Functions --#

### Used by: HCOM-Control-CW-Alarms.py
def get_alarm_prefix(Account, AccountName, ThisRegion, ThisARN, ThisPartition, ec2, ec3, ssm1, ThisInstanceID, Tenant, setEnvName, onprem,service):
    """Query instance attributes and tags to formulate the baseline alarm name to be used with alarms.

    Args:
        Account (_type_): AWS Account number for instance
        ec2 (_type_): ec2 service connection for instance
        ec3 (_type_): ec2 service connection for resource
        ssm1 (_type_): systems manager connect to query parameter store
        SingleInstanceID (_type_): instance ID for EC2 or onprem instance
        Tenant (_type_): friendly account name that corresponds to account number
        setEnvName (_type_): tag name for Environment from platform configuration
        onprem (_type_): Is this an onprem instance or not
        service (String): name of AWS service: 'EC2 / Hybrid OnPrem', DynamoDB, RDS

    Returns:
        String: baseline alarm name / alarm prefix that will be used with each alarm created
    """
    print(__name__, '--- Begin get_alarm_prefix --- onprem: {} | ThisARN: {}'.format(onprem,ThisARN))
    Thisenv = ''
    BaseAlarmName = {}
    
    ThisRegion1 = get_region_name(ThisRegion)
    #ThisRegion = os.environ['AWS_REGION']
    if service == 'EC2 / Hybrid OnPrem': # EC2/OnPrem
        if onprem == 'no':
            print(__name__,'instance:',ThisInstanceID)
            try:
                responses = ec2.describe_instances(
                    Filters=[{'Name':'instance-id' , 'Values':[ThisInstanceID]}
                    #,{'Name':tag , 'Values':[ThisProfile]}
                    ]) # Find instances
                print(__name__, 'response:', responses) # for testing
            except ClientError as error:
                print(__name__, 'Unexpected error occurred... could not create EC2 cross account query', error)
                return error
            ################## Start: parse through EC2 search results to create alarm name prefix ###################
            for r in responses['Reservations']:
                for i in r['Instances']:
                     ## reset variables
                    ThisHostName = ''
                    ThisInstanceID = ''
                    ssminstancename = ''
                    t = i['InstanceId']
                    thisresult = 1
                    #Get EC2 attributes 
                    try:
                        ec2instance = ec3.Instance(t)
                        instancename = ''
                        for tags in ec2instance.tags:
                            if tags["Key"] == 'Name':
                                BaseAlarmName['InstanceName'] = tags["Value"]
                                instancename = tags["Value"]
                                ThisInstance = instancename.split(' ', 1)
                                ThisHostName = ThisInstance[0]
                            #elif tags["Key"] == setCWProfileName':
                            #   ThisProfile = int(tags["Value"])
                            elif tags["Key"] == setEnvName:
                                Thisenv = tags["Value"]
                        print(__name__, 'row:', 'InstanceId:', t,'Hostname', ThisHostName ) # for testing
                    except ClientError as error:
                        print(__name__, 'EC2 query ran into an error', error)
                        return error
                    #print(__name__, 'hostname:',ssminstancename, ThisInstance)
                    ## Detect if is production or non-production to include in alarm name prefix
                    if Thisenv == '': # not found from tag
                        Thisenv = 'UNK'
                    else:
                        Thisenv = Thisenv.replace(' ', '')
                    ThisInstanceID = t
                    #BaseAlarmName = Tenant + '-' + Thisenv  + '-' + ThisHostName + '-' + ThisInstanceID
                    BaseAlarmName['Name'] = Tenant + '-' + AccountName + '-' + ThisRegion1 + '-' + Thisenv  + '-' + ThisHostName + '-' + ThisInstanceID
                    BaseAlarmName['hostname'] = ThisHostName
                    # Set variables
        else: # if onprem yes
            try:
                ## get onprem managed instance attributes
                response = ssm1.describe_instance_information(
                    Filters=[{'Key': 'InstanceIds', 'Values': [ThisInstanceID]}, {'Key': 'ResourceType', 'Values': ['ManagedInstance']}]
                )
                print(__name__, 'response', onprem, ThisInstanceID, response)
                ThisHostName1 = response["InstanceInformationList"][0]["ComputerName"].split('.')
                ThisHostName = ThisHostName1[0] # set the hostname
                BaseAlarmName['InstanceName'] = ThisHostName
                # get tags for onprem managed instance 
                tags = ssm1.list_tags_for_resource(ResourceType='ManagedInstance',ResourceId=ThisInstanceID)
                print(__name__, 'tags', tags)
                for tag in tags['TagList']:
                    print(__name__, 'tag',tag)
                    if tag['Key'] == setEnvName:
                        Thisenv = tag['Value'] # set the Environment name from tag value
                if response["InstanceInformationList"][0]["ResourceType"] == 'ManagedInstance':
                    BaseAlarmName['onprem'] = 'yes'
                elif response["InstanceInformationList"][0]["PlatformType"] == 'EC2Instance':
                    BaseAlarmName['onprem'] = 'no'
                BaseAlarmName['Name'] = Tenant + '-' + AccountName + '-' + ThisRegion1 + '-' + Thisenv  + '-' + ThisHostName + '-' + ThisInstanceID
                BaseAlarmName['hostname'] = ThisHostName
                BaseAlarmName['platform'] = response["InstanceInformationList"][0]["PlatformType"]
                
                print(__name__, 'BaseAlarmName:', BaseAlarmName)
                
            except ClientError as error:
                print(__name__, 'Ran into an error getting onprem hostname and tag information.', error)
                return error
    elif service == 'DynamoDB' or service == 'RDS':
        BaseAlarmName['Name'] = Tenant + '-' + AccountName + '-' + ThisRegion1 + '-' + ThisInstanceID
    #elif service == 'RDS':
    #BaseAlarmName['Name'] = Tenant + '-' + AccountName + '-' + ThisRegion1 + '-' + ThisInstanceID
    print(__name__, '--- End get_alarm_prefix --- {}'.format(BaseAlarmName))
    return BaseAlarmName

### HCOM-Lifecycle-Automation
def get_dynamodb_tag(conn,tagname,ThisPartition,ThisRegion,Account,ThisInstanceID):
    dbarn = 'arn:partition:dynamodb:region:tenantaccount:table/name'
    dbarn = dbarn.replace('partition', ThisPartition)
    dbarn = dbarn.replace('region', ThisRegion)
    dbarn = dbarn.replace('tenantaccount', Account)
    dbarn = dbarn.replace('name', ThisInstanceID)
    print(__name__,' resourcename: {}'.format(dbarn))
    tagvalue = 'Unknown'
    try:
        response = conn.list_tags_of_resource(ResourceArn=dbarn)
        print(__name__,'tags from query:{}'.format(response))
        for tag in response['Tags']:
            print(__name__,'tag:{} Value:{} | target:{}'.format(tag['Key'],tag['Value'], tagname))
            if tag['Key'] == tagname:
                tagvalue = tag['Value']
    except ClientError as error:
        if str(error).find('Requested resource not found') > -1:
            errormessage = 'The instance is already deleted and can not be queried for tags.'
            print(__name__, 'DynamoDB Tag query ran into an error. {}'.format(errormessage))
        else:
            print(__name__, 'DynamoDB Tag query ran into an error', error)
        tagvalue = ''
        pass
    print(__name__,'--- found tag: {} | value: {}'.format(tagname, tagvalue))
    return tagvalue

### HCOM-Lifecycle-Automation
def get_rds_tag(conn,tagname,ThisPartition,ThisRegion,Account,ThisInstanceID):
    """given parameters for rds, return requested tag value

    Args:
        conn (_type_): _description_
        tagname (_type_): _description_
        ThisPartition (_type_): _description_
        ThisRegion (_type_): _description_
        Account (_type_): _description_
        ThisInstanceID (_type_): _description_

    Returns:
        _type_: _description_
    """    
    dbarn = 'arn:partition:rds:region:tenantaccount:db:name'
    dbarn = dbarn.replace('partition', ThisPartition)
    dbarn = dbarn.replace('region', ThisRegion)
    dbarn = dbarn.replace('tenantaccount', Account)
    dbarn = dbarn.replace('name', ThisInstanceID)
    try:
        response = conn.list_tags_for_resource(ResourceName=dbarn)
        print(__name__,'tags from query:{}'.format(response))
        for tag in response['TagList']:
            print(__name__,'tag:{} Value:{} | target:{}'.format(tag['Key'],tag['Value'], tagname))
            if tag['Key'] == tagname:
                tagvalue = tag['Value']
    except ClientError as error:
        print(__name__, 'RDS Tag query ran into an error', error)
        tagvalue = ''
        pass
    return tagvalue

### HCOM-CloudWatch-Alarm-Response-Runner
def get_ec2_tag(tagname,Tenant,Account,ThisRegion,ThisInstanceID):
    """given parameters for ec2, return requested tag value

    Args:
        conn (_type_): _description_
        tagname (_type_): _description_
        ThisPartition (_type_): _description_
        ThisRegion (_type_): _description_
        Account (_type_): _description_
        ThisInstanceID (_type_): _description_

    Returns:
        _type_: _description_
    """   
    tagvalue = ''
    print(__name__,'var check for get_ec2_tag: {} | {} | {} | {} | {}'.format(tagname,Tenant,Account,ThisRegion,ThisInstanceID))
    ec2 = get_ec2_client_connection(Account,ThisRegion, setIAM.get("Cross-Account"))
    
    try:
        response = ec2.describe_tags(Filters=[{'Name': 'resource-id', 'Values': [ThisInstanceID]}])
        print(__name__,'tags from query:{}'.format(response))
        for tag in response['Tags']:
            print(__name__,'tag:{} Value:{} | target:{}'.format(tag['Key'],tag['Value'], tagname))
            if tag['Key'] == tagname:
                tagvalue = tag['Value']
    except ClientError as error:
        print(__name__, 'EC2 Tag query ran into an error', error)
        tagvalue = ''
        pass
    print(__name__,'tagvalue: {} | should not be null'.format(tagvalue))
    return tagvalue

## HCOM-Platform-Configuration-Manager
def get_target_metrics(resourcetype, ProfileType,targetnamespace, category):
    """Take profile type passed value and return metric list f

    Args:
        ProfileType (String): alarm profile type

    Returns:
        List: Metric List
    """
    print(__name__,'-- get_target_metrics: {} | category: {} | resourcetype: {} | profiletype: {}'.format(targetnamespace, category, resourcetype, ProfileType))
    targetmetrics = {}
    targetmetrics[targetnamespace] = []
    #metriclist = []
    for var in setCWResourceTypes['resourcetypes']: # loop through resource types
        for x, namespaces in var.items():
            print(__name__,'step 1: get_cw_resource_type: X:{} | namespaces: {}'.format(x,namespaces))
            if x == resourcetype: # matched resourcetype
                for namespace, ptype in namespaces['namespace'].items():
                    print(__name__,'step 2: get_cw_resource_type: namespace:{} | {} | {}'.format(namespace, len(ptype), ptype))
                    if len(ptype) > 0 and namespace == targetnamespace: # if we have more to iterate
                        for ptypes, pmetrics in ptype.items():
                            print(__name__,'step 3: is namespace: {} | {} | {} | {}'.format(namespace, ptypes, len(pmetrics), pmetrics))
                            if ptypes == ProfileType and len(pmetrics) > 0: # matched
                                for key, values in pmetrics.items():
                                    print(__name__,'step 4: find metric category. Key:{} | Category: {} | # of metrics: {} | metrics:{}'.format(key, category, len(values), values))
                                    if key == category and len(values) > 0: # matched category
                                        print(__name__,'found match, adding metrics')
                                        targetmetrics[targetnamespace] += values
                                        print(__name__,'current metrics:{}'.format(targetmetrics))
                                        break
        print(__name__,'-- step 5: final list of metrics: {}'.format(targetmetrics))
        
        return targetmetrics
    return {'statusCode': 400}
    
### Used by: HCOM-CloudWatch-Alarm-Response.py (use:push config)
def execute_run_document(ssm1, ThisInstanceID, ThisConfig, RunDocument, RunDocumentParam): # purpose: , used by:
    """Execute SSM Rundoc with provided parameters

    Args:
        ssm1 (_type_): SSM connection
        ThisInstanceID (_type_): target instance id to run the rundoc against
        ThisConfig (_type_): _description_
        RunDocument (_type_): SSM RunDoc name
        RunDocumentParam (_type_): SSM RunDoc parameters

    Returns:
        _type_: _description_
    """    
    try:
        cwresponse = ssm1.send_command(
            InstanceIds=[ThisInstanceID],
            DocumentName = RunDocument,
            DocumentVersion='$LATEST',
            Parameters={RunDocumentParam: [ThisConfig]},
        )
    except ClientError as error:
        print(__name__, 'Run Command ran into an error.', error)
        return error

### Used by: HCOM-CloudWatch-Alarm-Lifecycle-Automation.py
def update_counts(thisTable, item, itemValue, config, CentralRegion,info):
    """Update CloudWatch Events widget counts for instance state changes and alarm lifecycle

    Args:
        thisTable (_type_): _description_
        item (_type_): _description_
        itemValue (_type_): _description_
        config (_type_): _description_
        CentralRegion (_type_): _description_
    """    
    ############## Get daily automation counts #############
    ThisDailyCount = {}
    statlist = []
    dbcon = boto3.resource('dynamodb', region_name=CentralRegion)
    table = dbcon.Table(thisTable)
    try:
        dailyCount1 = table.get_item(Key={'msptype': 'cw', 'mspname': config})
        dailyCount = dailyCount1['Item']
        
        print(__name__,'get_item results:', dailyCount, item, itemValue)
        
        #dailyCount = ssm0.get_parameter(Name=cw.setCWConfigurations.get('Lifecycle'))
    except Exception as error:
        print(__name__, 'no lifecycle file was found ',config )
        dailyCount = {'reboot': 0, 'stopped': 0,'terminatedd': 0, 'suppressed': 0, 'created': 0, 'deleted': 0, 'respones': 0, 'responseslist': []} # set default values
        updatethis2 = 'SET reboot = :val1, deleted = :val1, terminatedd = :val1, suppressed = :val1, created = :val1, stopped = :val1, responses = :val1'
        response3 = table.update_item(
            Key={'msptype': 'cw', 'mspname': config},
            UpdateExpression=updatethis2,
            ExpressionAttributeValues={':val1' : 0}
        )
        pass

    try: # update lifecycle count in DynamoDB
        newval = int(dailyCount[item]) + int(itemValue)
        updatethis = 'SET '+ item + ' = :val1'
        
        print(__name__, 'update item ', item, ' from ', dailyCount[item], ' to value: ', newval)
        response2 = table.update_item(
            Key={'msptype': 'cw', 'mspname': config},
            UpdateExpression=updatethis,
            ExpressionAttributeValues={':val1' : newval}
        )
        print(__name__,'updated! ', response2)
        if item == 'responses' and info !='':
            print(__name__,'--- updating list now')
            updateitem = 'responseslist'
            statlist = dailyCount[updateitem]
            statlist.append(info)
            updatethis = 'SET '+ updateitem + ' = :val1'
        
            print(__name__, 'update list item ', updateitem, ' from ', dailyCount[updateitem], ' to value: ', statlist)
            response2 = table.update_item(
                Key={'msptype': 'cw', 'mspname': config},
                UpdateExpression=updatethis,
                ExpressionAttributeValues={':val1' : statlist}
            )
    except ClientError as error:
        print(__name__, 'Could not update counts.', error)
        response = 'error'
        rndsleep = random.randrange(1, 10)
        time.sleep(rndsleep)
        response2 = table.update_item(
            Key={'msptype': 'cw', 'mspname': config},
            UpdateExpression=updatethis,
            ExpressionAttributeValues={':val1' : newval}
        )


def update_central_queque(message,queue):
    """Create SQS items to create new CW configurations for all regions used by CW Profile

    Args:
        message (Dict): all attriubte value pairs for regions needing new CW profile config to be created
        queue (_type_): SQS queue name

    Returns:
        _type_: _description_
    """    
    print(__name__,f'message data type: {type(message)} | {message}')
    if type(message) == str:
        message = ast.literal_eval(message) # convert to dictionary
        print(__name__,f'message data type: {type(message)} | {message}')
    if message.get('Function') == 'cw_config':
        print(__name__, ' inside cw_config - {} pushing to SQS: {} to region queue:{}'.format(message.get('Function'),message,message.get('Region')))
        qconn = boto3.client("sqs", region_name=message.get('Region'))
    else:
        print(__name__, 'inside all others - {} pushing to SQS: {} '.format(message.get('Function'),message))
        qconn = boto3.client("sqs", region_name=setCentralRegion)
    message = json.dumps(message) # convert to string
    try:
        response = qconn.send_message(QueueUrl = queue,
            MessageBody=message)
        print(__name__, 'response from SQS:', response)
    except ClientError as error:
        print(__name__, 'Could not send meessage to the - ',queue, '.', error)
        raise
    else:
        return response
       
# used by HCOM-CloudWatch-Alarm-Audit ### discontinue use
def update_counter(item, itemValue, ThisRegion, config):
    ############## Get daily automation counts #############
    ssm0 = boto3.client('ssm', region_name=ThisRegion)
    ThisDailyCount = {}
    dailyCount = ssm0.get_parameter(Name=config)
    ThisDailyCount2 = dailyCount['Parameter']['Value']
    ThisDailyCount = ast.literal_eval(ThisDailyCount2)
 
    #time.sleep(10)
    #print(__name__, 'ThisDailyCount', ThisDailyCount.get('reboot'), ThisDailyCount.get('terminated'))
    print(__name__, 'Before Update: ThisDailyCount', ThisDailyCount)
    targetItem = ThisDailyCount.get(item)
    targetItem = targetItem + itemValue
    print(item,' targetItem:', targetItem)
    ThisDailyCount.update({item : targetItem})
    print(__name__, 'Revised Count: ThisDailyCount', ThisDailyCount)
    ssm0.put_parameter(Name=config,
        Value = str(ThisDailyCount),
        Type = 'String',
        Overwrite=True)

### Used by: HCOM-Control-CW-Alarms.py, 
def update_tag(ec2, ssm2, ThisID, setSuppressName, SuppressStatus,onprem):
    if onprem == 0:
        response = ec2.create_tags(
                    Resources = [ThisID],
                        Tags = [
                            {
                                'Key': setSuppressName,
                                'Value': SuppressStatus
                            },
                        ]
                    )
    else: # this is onprem instance
        response = ssm2.add_tags_to_resource(ResourceType='ManagedInstance',ResourceId = ThisID,Tags=[{'Key': setSuppressName, 'Value': SuppressStatus}])
    print(setSuppressName,' Tag value', SuppressStatus, ' updated for ID:', ThisID)

#-- Functions that create CW Alarms --# 

### Used By: HCOM-CLoudWatch-Alarm-Creator, HCOM-CloudWatch-Alarm-Lifecycle-Automation
def running_checklist(Account, ec2, ec3, ssm1, iam, iam2, ThisInstanceID, Tenant, setEnvName, setProfileName, setSuppressName, iamCrossAccount,ThisARN,ThisPartition,ThisRegion):
    global UpdateList, ThisStateProfile
    Thisenv = ''
    managedInstance = ''
    alarmSuppression = 'Off'
    ThisProfile = ''
    AgentVersion = ''
    PingStatus = ''
    HasCWPolicy = ''
    ThisStateProfile = ''
    finalResult = {}
    print(__name__, 'Instance:', ThisInstanceID)
    try:
        responses = ec2.describe_instances(
            Filters=[{'Name':'instance-id' , 'Values':[ThisInstanceID]}
            ,{'Name':'instance-state-name', 'Values':['running','stopped','stopping']}
                     ]) # Find instances
        #print(__name__, 'query instance for inspection', responses)
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create EC2 cross account query', error)
        return error
    print(__name__,'-- checklist results --', responses)
    #ThisRegion = os.environ['AWS_REGION']
    if 'west' in ThisRegion:
        ThisRegion1 = 'West'
    else:
        ThisRegion1 = 'East'
    ################## Start: parse through EC2 search results to create alarm name prefix ###################
    for r in responses['Reservations']:
        for i in r['Instances']:
            ## reset variables
            ThisHostName = ''
            ssminstancename = ''
            thisresult = 1
            RunningState = i['State']['Name']
            ##### Check IAM Server Role has CW agent server policy #######
            IamServerRole = i['IamInstanceProfile']['Arn'].split('/')[1]
            print(__name__, 'IAM:', IamServerRole, i['IamInstanceProfile']['Arn'] )
            if i['IamInstanceProfile']['Arn'].find('instance-profile') > 0:
                #iamRoleName = get_rolename(iam2,IamServerRole)
                iamRoleName = iam2.InstanceProfile(name=IamServerRole)
                roleName1 = str(iamRoleName.roles)
                #print(roleName1)
                roleName2 = roleName1.replace("[iam.Role(name='","")
                #print(str(roleName2))
                roleName3 = str(roleName2.replace("')]",""))
                print(__name__, 'role:',iamRoleName, roleName3)
                IamServerRole = roleName3
            try:
                policyResults = iam.list_attached_role_policies(
                    RoleName=IamServerRole
                )
            except ClientError as error:
                print(__name__, 'Could not query roles from Instance Profile', error)
                return error
            policies = [policy['PolicyName'] for policy in policyResults['AttachedPolicies']]
            if 'CloudWatchAgentServerPolicy' in policies:
                #print ('CW Role is here', policies)
                HasCWPolicy = 'Yes'
            else:
                print ('CW Role is not here')
                HasCWPolicy = 'No'
            try:
                tPlatform = i['Platform']
            except KeyError as error:
                #print(__name__, 'This is not a Window instance', error)
                tPlatform = 'Linux'
                pass
            #Get EC2 attributes 
            if ThisInstanceID.find('mi-') > -1:
                onprem = 'yes'
            else:
                onprem = 'no'
            try:
                ec2instance = ec3.Instance(ThisInstanceID)
                instancename = ''
                for tags in ec2instance.tags:

                    if tags["Key"] == 'Name':
                        instancename = tags["Value"]
                        ThisInstance = instancename.split(' ', 1)
                    elif tags["Key"] == setEnvName: # check for Environment tag
                        Thisenv = tags["Value"]
                    elif tags["Key"] == setProfileName:
                        ThisProfile = tags["Value"]
                        #print(__name__, "found CSP_CW_Profile", tags["Value"])
                    elif tags["Key"] == setStateTags['profile']: # check for State-Profile tag
                        ThisStateProfile = tags["Value"]
                    elif tags["Key"] == setSuppressName:
                        alarmSuppression = tags["Value"]
                try:
                    ssmresponse = ssm1.describe_instance_information( # query Systems Manager for OS details
                        Filters=[{'Key':'InstanceIds' , 'Values':[ThisInstanceID]}
                                 ]
                    )
                    for ssminstance in ssmresponse.get('InstanceInformationList'): # will only find results if SSM is installed
                        print(__name__, 'ssm raw', ssminstance)
                        Thisos = ssminstance['PlatformName'] # this is the actual OS of the EC2 instance
                        ssminstancename = ssminstance['ComputerName'].strip()
                        AgentVersion = ssminstance['AgentVersion']
                        if ssminstance['ResourceType'] == 'EC2Instance':
                            onprem = 'no'
                        PingStatus = ssminstance['PingStatus'] #### values: Online, ConnectionLost

                        LastPing = ssminstance['LastPingDateTime']

                    if ssminstancename != '' and len(ssminstancename) > 5:
                        ThisInstance1 = ssminstancename.split('.', 1)
                        ThisHostName = ThisInstance1[0]
                    else:
                        ThisHostName = ThisInstance[0]
                    #print(__name__, 'row:', 'InstanceId:', ThisInstanceID,'Hostname', ThisHostName ) 
                except ClientError as error:
                    print(__name__, 'This instance is likely not SSM managed.', error)
                    pass
                    return error
            except ClientError as error:
                print(__name__, 'EC2 query ran into an error', error)
                return error
            if AgentVersion == '':
                managedInstance = 'No'
            else:
                managedInstance = 'Yes'
            ## Detect if is production or non-production to include in alarm name prefix
            if Thisenv == '': # not found from tag
                Thisenv = 'UNK'
            #BaseAlarmName = Tenant + '-' + Thisenv  + '-' + ThisHostName + '-' + ThisInstanceID
            #BaseAlarmName = Tenant + '-' + ThisRegion1 + '-' + Thisenv  + '-' + ThisHostName + '-' + ThisInstanceID
            timecheck = 1
            lastStat = check_metric_history(tPlatform, ThisInstanceID, i['ImageId'], i['InstanceType'], timecheck, ThisARN,ThisRegion)
            dataPoints = len(lastStat['MetricDataResults'][0]['Timestamps'])
            #print(__name__, 'datapoints:', dataPoints)
            #sys.exit()
            # Set variables
            ThisAccount = Account
            finalResult.update({"lastStat": dataPoints})
            finalResult.update({"tPlatform": tPlatform})
            finalResult.update({"RunningState": RunningState})
            finalResult.update({"IamServerRole": IamServerRole})
            finalResult.update({"HasCWPolicy": HasCWPolicy})
            finalResult.update({"ThisProfile": ThisProfile})
            finalResult.update({"managedInstance": managedInstance})
            finalResult.update({"alarmSuppression": alarmSuppression})
            finalResult.update({"AgentVersion": AgentVersion})
            finalResult.update({"ThisHostName": ThisHostName})
            finalResult.update({"Thisenv": Thisenv})
            finalResult.update({"ThisStateProfile": ThisStateProfile})
            #finalResult.update({"BaseAlarmName": BaseAlarmName})
            finalResult.update({"PingStatus": PingStatus})
            finalResult.update({"onprem": onprem})
            print(__name__, 'finalresult', finalResult )
            return finalResult

### HCOM-CloudWatch-Alarm-Creator
def create_service_profile_alarms(table, resourcetype, cloudwatch, ThisInstanceID, ThisProfile,BaseAlarmName, Tenant, ThisRegion, Account, setSNSGeneral, setCentralAccount, opsItemFeature, setSNSHelpDesk, ThisPartition, AccountName, ThisNameSpace):
    checkmetrics = 1
    currentmetrics = get_service_metrics(cloudwatch, ThisInstanceID,ThisNameSpace) # get current metrics for Instance
    print(__name__,' available metrics: {}'.format(currentmetrics))
    rows = len(currentmetrics['Metrics'])
    while rows == 0 and checkmetrics != 5:
        time.sleep(5)
        currentmetrics = get_service_metrics(cloudwatch,ThisInstanceID,ThisNameSpace) # get current metrics for Instance
        rows = len(currentmetrics['Metrics'])
        checkmetrics = checkmetrics + 1
    print(__name__, 'rows:', rows, 'metric2:', currentmetrics)
    ThisMessage = ''
    createcount = 0
    alarmdef = {}
    if currentmetrics != '' and currentmetrics is not None: # we found metrics
        alarms = table.get_item(Key={'msptype': resourcetype, 'mspname': str(ThisProfile)})
        print(__name__,' resourcetype: {} | alarms: {} | ThisProfile:'.format(resourcetype,alarms, ThisProfile))
        print(__name__, "tenants:{} | {}".format(setSNSGeneral,Tenant))
        setSNSGeneral = convert_arn(setSNSGeneral,ThisRegion,Account,ThisPartition,Tenant,AccountName)
        print(__name__, "topic:", setSNSGeneral)
        alarmdef1 = alarms['Item']['alarms']
        alarmdef = dict(sorted(alarmdef1.items()))
        rows = len(alarmdef)
        counter = 0
        print(__name__, 'rows:', rows)
        for key, i in alarmdef.items(): # loop through alarm definitions
            print(__name__, ' create_service_profile_alarms alarm row: {} | {}'.format(key, i))
            curAlarm = i
            OI=0 #reset
            OISeverity = ''
            OICategory = ''
            counter = counter + 1
            alarmPath = ''
            ThisProcess = ''
            typename = ''
            ThisProcessName = ''
            ThisAlarmName2 = ''
            ThisResponseType = ''
            ThisOptionName = ''
            ThisMetric = curAlarm.get('metricname')
            ThisOperator = curAlarm.get('operator')
            ThisThreshold = int(curAlarm.get('threshold'))
            ThisEvalPeriod = int(curAlarm.get('evaluationperiods'))
            ThisDataPoints = int(curAlarm.get('datapoints'))
            ThisPeriod = int(curAlarm.get('period'))
            ThisData = curAlarm.get('TreatMissingData')
            ThisNameSpace = curAlarm.get('namespace')
            if curAlarm.get('option'):
                alarmPath = curAlarm.get('option')
            #elif curAlarm.get('type'):
            #    alarmPath = curAlarm.get('type')
            if curAlarm.get('optionname'):
                ThisOptionName = curAlarm.get('optionname')
            if curAlarm.get('opsitempriority'):
                OISeverity = int(curAlarm.get('opsitempriority'))
                OI = 1
            if curAlarm.get('opsitemcategory'):
                OICategory = (curAlarm.get('opsitemcategory'))
                OI = 1
            
            if curAlarm.get('name'):
                processName = curAlarm.get('name')
                OI = 1
            if curAlarm.get('ResponseType'):
                ThisResponseType = curAlarm.get('ResponseType')
                if ThisResponseType == 'Stop': ### check for alarm action automations to invoke EC2 state changes
                    ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + Account +':action/actions/AWS_EC2.InstanceId.Stop/1.0'
                elif ThisResponseType == 'Reboot':
                    ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + Account +':action/actions/AWS_EC2.InstanceId.Reboot/1.0'
                elif ThisResponseType == 'Terminate':
                    ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + Account +':action/actions/AWS_EC2.InstanceId.Terminate/1.0'
                else:
                    ec2Action = ''
            else:
                ec2Action = ''
            ThisAlarmId = key
            createcount = createcount + 1
            AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,opsItemFeature,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory, ThisRegion,ThisResponseType)
            ### Create alarm definition
            pathnames = []
            allpathnames = []
            print(__name__,'---- target metric to create: {}'.format(ThisMetric))
            for Metric in currentmetrics['Metrics']: # loop through current metrics and dimensions for this instance
                print(__name__, 'counter:', counter, ThisMetric)
                print(__name__,'metric name: {} | namespace: {} | option value: {}'.format(Metric['MetricName'],Metric['Namespace'],Metric['Dimensions']))
                if Metric['MetricName'] == ThisMetric: #target metric for alarm to be created matches found metric for instance
                    if ThisOptionName != '' and alarmPath != '': # check for alarm option
                        for x in Metric['Dimensions']:
                            print(__name__,'alarm option {} | {} | {}'.format(alarmPath,x.get('Name'),x.get('Value')))
                            if ThisOptionName == x.get('Name'): # matched alarm option
                                if alarmPath != x.get('Value'):# if alarm option not in current metric dimension then skip it
                                    print(__name__,'alarm option {} not in {}'.format(alarmPath,x.get('Value')))
                                    continue
                                else: # create alarm
                                    print(__name__,'alarm option  {} was in dimension {}'.format(alarmPath,x.get('Value')))
                                    thisDimension = []
                                    thisDimensions = {}
                                    match = 0
                                    thisDimension = Metric['Dimensions'] # test just assign it, don't parse it
                                    ThisAlarmName2 = BaseAlarmName + '-' + str(ThisMetric) + '-' + str(ThisThreshold)
                                    alarmDetails = "AlarmName='" +ThisAlarmName2 + "',"
                                    alarmDescription = 'When service resource exceeds threshold'
                                    print(__name__,'dimensions: {} | type: {}'.format(thisDimension,type(thisDimension)))
                                    
                                    print(__name__,'alarm name: {} | dimensions: {}'.format(ThisAlarmName2, thisDimension))
                                    ThisMessage = ThisMessage + '\nCreated Alarm/Monitor: ' + ' ' + ThisMetric + ' ' + alarmPath + ' ' + ThisOptionName + ' ' + ThisOperator + ' ' + str(ThisThreshold) + ' ' + str(ThisEvalPeriod) + ' ' + str(ThisDataPoints) + ' ' + str(ThisPeriod) + '\n'
                                    response = create_alarm(ThisAlarmName2,alarmDescription, ThisNameSpace, ThisOperator,ThisEvalPeriod,ThisDataPoints,ThisThreshold,setSNSHelpDesk,AAAction,ThisData,Account, ThisMetric,thisDimension,ThisPeriod,ThisRegion)
                            else: # skip to next sub-metric
                                continue
                    else: # no alarm option for this metric
                        thisDimension = []
                        thisDimensions = {}
                        match = 0
                        thisDimension = Metric['Dimensions'] # test just assign it, don't parse it
                        ThisAlarmName2 = BaseAlarmName + '-' + str(ThisMetric) + '-' + str(ThisThreshold)
                        alarmDetails = "AlarmName='" +ThisAlarmName2 + "',"
                        alarmDescription = 'When service resource exceeds threshold'
                        print(__name__,'dimensions: {} | type: {}'.format(thisDimension,type(thisDimension)))
                        
                        print(__name__,'alarm name: {} | dimensions: {}'.format(ThisAlarmName2, thisDimension))
                        ThisMessage = ThisMessage + '\nCreated Alarm/Monitor: ' + ' ' + ThisMetric + ' ' + alarmPath + ' ' + ThisOptionName + ' ' + ThisOperator + ' ' + str(ThisThreshold) + ' ' + str(ThisEvalPeriod) + ' ' + str(ThisDataPoints) + ' ' + str(ThisPeriod) + '\n'
                        response = create_alarm(ThisAlarmName2,alarmDescription, ThisNameSpace, ThisOperator,ThisEvalPeriod,ThisDataPoints,ThisThreshold,setSNSHelpDesk,AAAction,ThisData,Account, ThisMetric,thisDimension,ThisPeriod,ThisRegion)
    return ThisMessage

### Used By: CloudWatch Alarm Creator, HCOM-CloudWatch-Alarm-Lifecycle-Automation.py
def create_onprem_profile_alarms(setCentralRegion, setDBcon, cw2, SingleInstanceID, ThisProfile,BaseAlarmName, Tenant, ThisRegion, Account, test,setSNSGeneral, setCentralAccount, opsItemFeature, setSNSHelpDesk, ThisPartition,AccountName,ThisNameSpace):
    """function used to create all the cloudwatch alarms based on define CW profile for on-premise / any non-EC2 workloads running SSM & CW Agents

    Args:
        setCentralRegion (_type_): _description_
        setDBcon (_type_): _description_
        cloudwatch (_type_): _description_
        cw2 (_type_): _description_
        ssm0 (_type_): _description_
        ssm1 (_type_): _description_
        SingleInstanceID (_type_): _description_
        ThisProfile (_type_): _description_
        defaultProfile (_type_): _description_
        BaseAlarmName (_type_): _description_
        ThisHostName (_type_): _description_
        Tenant (_type_): _description_
        ThisPlatform (_type_): _description_
        setEnvName (_type_): _description_
        ThisRegion (_type_): _description_
        Account (_type_): _description_
        setProfileName (_type_): _description_
        test (_type_): _description_
        setSNSGeneral (_type_): _description_
        setCentralAccount (_type_): _description_
        opsItemFeature (_type_): _description_
        setSNSHelpDesk (_type_): _description_
        history (_type_): _description_
        iamCrossAccount (_type_): _description_
        sqsState (_type_): _description_
        alarmResponse (_type_): _description_
        ThisPartition (_type_): _description_
        AccountName (_type_): _description_
        ThisNameSpace (_type_): _description_

    Returns:
        _type_: _description_
    """    
    dbcon = boto3.resource('dynamodb', region_name=setCentralRegion)
    table = dbcon.Table(setDBcon)
    checkmetrics = 1
    currentmetrics = get_service_metrics(cw2, SingleInstanceID, 'CWAgent') # get current metrics for Instance
    rows = len(currentmetrics['Metrics']) # number of current metrics available for instance
    loop = 0
    while rows == 0 and checkmetrics != 5: ### if no metrics yet, kill some time and check again (loop up to 5 times) to allow initial metrics to be received.
        loop += 1
        time.sleep(5)
        currentmetrics = get_service_metrics(cw2, SingleInstanceID, 'CWAgent') # get current metrics for Instance
        rows = len(currentmetrics['Metrics'])
        checkmetrics = checkmetrics + 1
        print(__name__, 'loop: {} rows: {} metric2: {}'.format(loop,rows,currentmetrics))
    if rows == 0: 
        print(__name__, '**** No metrics data being received. No ALARMS will be created **** Check CW Agents is properly configured and sending metrics.')
        return {'statuscode': 400, 'statusmessage': 'No CW metrics'}
    print(__name__, ' out of loop - rows:', rows, 'metric2:', currentmetrics)
 
    ThisMessage = ''
    createcount = 0
    #currentmetrics = 'bypass' # implemented as bypass since list_metric is not supported without CloudWatch cross-account observability which is not supported in GovCloud
    alarmdef = {}
    if currentmetrics != '' and currentmetrics is not None: # we found metrics
        ##### Start: Get Alarm Definition from Parameter Store ########################################
        #print(__name__, 'getting param:', ConfigAlarm)
        alarms = table.get_item(Key={'msptype': 'cw-profile', 'mspname': str(ThisProfile)})
        print(__name__, ' alarms def:', alarms)
        ################# End: Get Alarm Defintion from DynamoDB ##################
        print(__name__, "tenants:{} | {}".format(setSNSGeneral,Tenant))
        setSNSGeneral = convert_arn(setSNSGeneral,ThisRegion,Account,ThisPartition,Tenant,AccountName)
        print(__name__, "topic:", setSNSGeneral)
        ####### End: Get SNS Topic #################
        ############### Start: Parse for alarm parameters #############################
        counter = 0
        alarmdef = alarms['Item']['alarms']
        rows = len(alarmdef)
        print(__name__, 'rows:', rows)
        for key, i in alarmdef.items(): # loop through alarm definitions
            #print(__name__, 'varName:', varName, 'configuration1['Items'][j]:',configuration1['Items'][j]) # used for testing
            print(__name__, 'create_onprem_profile_alarms alarm row: {} | {}'.format(key, i))
            curAlarm = i
            ThisAlarmId = key
            OI=0 #reset
            OISeverity = ''
            OICategory = ''
            counter = counter + 1
            #alarmType = varName
            alarmPath = ''
            ThisProcess = ''
            typename = ''
            ThisProcessName = ''
            ThisAlarmName2 = ''
            ThisResponseType = ''
            ThisOptionName = ''
            #ThisResponseconfig = {}
            ThisMetric = curAlarm.get('metricname')
            ThisMetricCategory = curAlarm.get('metriccategory')
            ThisOperator = curAlarm.get('operator')
            ThisThreshold = int(curAlarm.get('threshold'))
            ThisEvalPeriod = int(curAlarm.get('evaluationperiods'))
            ThisDataPoints = int(curAlarm.get('datapoints'))
            ThisPeriod = int(curAlarm.get('period'))
            ThisData = curAlarm.get('TreatMissingData')
            if curAlarm.get('optionname'):
                ThisOptionName = curAlarm.get('optionname')
            if curAlarm.get('opsitempriority'):
                OISeverity = int(curAlarm.get('opsitempriority'))
                OI = 1
            if curAlarm.get('opsitemcategory'):
                OICategory = (curAlarm.get('opsitemcategory'))
                OI = 1
            if curAlarm.get('option'):
                alarmPath = curAlarm.get('option')
            if curAlarm.get('name'):
                processName = curAlarm.get('name')
                OI = 1
                tempconfig = str(ThisProfile) + ':' + processName
                #ThisResponseconfig['Name'] = 'AlarmResponse'
                #ThisResponseconfig['Value'] = str(tempconfig) # text for alarm response dimension
            ThisAlarmId = key
            if curAlarm.get('ResponseType'):
                ThisResponseType = curAlarm.get('ResponseType','')
                if ThisResponseType == 'Stop': ### check for alarm action automations to invoke EC2 state changes
                    ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + Account +':action/actions/AWS_EC2.InstanceId.Stop/1.0'
                elif ThisResponseType == 'Reboot':
                    ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + Account +':action/actions/AWS_EC2.InstanceId.Reboot/1.0'
                elif ThisResponseType == 'Terminate':
                    ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + Account +':action/actions/AWS_EC2.InstanceId.Terminate/1.0'
                else:
                    ec2Action = ''
            else:
                ec2Action = ''
            if alarms['Item']['ProfileType'].find('OnPrem') > -1: # is this an on-premise alarm
                onprem = 'yes'
            else:
                onprem = 'no'
            createcount = createcount + 1
            print(__name__, 'region: {} | ThisMetric: {} | currentmetrics[Metrics]:{}'.format(ThisRegion, ThisMetric,currentmetrics['Metrics']))
            AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,opsItemFeature,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
            ### Create alarm definition
            pathnames = []
            allpathnames = []
            for Metric in currentmetrics['Metrics']: # loop through current metrics and dimensions for this instance
                print(__name__, 'counter:{} | Metric Name: {} | ThisMetric: {} {}'.format( counter, Metric['MetricName'],ThisMetricCategory,ThisMetric)) # for testing
                onPremMetric = ThisMetricCategory + ' ' + ThisMetric  
                if Metric['MetricName'] == onPremMetric: #target metric for alarm to be created matches found metric for instance
                    thisDimension = []
                    thisDimensions = {}
                    match = 0
                    thisDimension = Metric['Dimensions'] # test just assign it, don't parse it
                    ## for CPU Metric
                    if ThisMetric == 'cpu_usage_user' or ThisMetric == 'cpu_usage_idle' or ThisMetric == 'cpu_usage_iowait' or ThisMetric == 'cpu_usage_system': # for Linux CloudWatch Agent CPU metrics
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisProcessName = 'CPU'
                        ## set Alarm Name
                        if ThisMetric.find("idle") > 1:
                            typename = 'idle'
                        elif ThisMetric.find("user") > 1:
                            typename = 'user'
                        elif ThisMetric.find("system") > 1:
                            typename = 'system'
                        elif ThisMetric.find("iowait") > 1:
                            typename = 'iowait'
                        ThisAlarmName2 = BaseAlarmName + '-' + ThisProcessName + '-' + typename + '-' + ThisProcess
                        alarmDetails = "AlarmName='" +ThisAlarmName2 + "',"
                        alarmDescription = 'Alarm when cpu exceeds threshold'
                    ### for Memory metric
                    elif ThisMetric == 'mem_used_percent':
                        ThisAlarmName2 = BaseAlarmName + '-MEM-' + str(ThisThreshold)
                        alarmDescription = 'Alarm when memory utilization exceeds threshold'
                    ### for Memory metric
                    elif ThisMetric == 'swap_used_percent':
                        ThisAlarmName2 = BaseAlarmName + '-SWAP-' + str(ThisThreshold)
                        alarmDescription = 'Alarm when swap utilization exceeds threshold'
                    elif ThisMetric.find('net_bytes') > -1: # Linux Network
                        print()
                    ### for Disk metric
                    elif ThisMetric.find('disk') > -1: #== 'disk_used_percent':
                        ThisAlarmName2 = BaseAlarmName + '-' + alarmPath + '-' + str(ThisThreshold)
                        alarmDescription = 'Alarm when disk utilization exceeds threshold'
                        thisDimensions = {}
                        print(__name__, 'target metric:', ThisMetric, 'path:', alarmPath, ' Dimensions:',Metric['Dimensions'])
                        if alarmPath != 'all' and ThisMetric == 'disk_used_percent':
                            if ThisMetric == 'disk_used_percent':
                                TargetName = 'path'
                                TargetValue = alarmPath
                                TargetName2 = 'fstype'
                                TargetValue2 = ['xfs', 'ext4']
                                mustmatch = 2
                                match = check_metric_dimensions(TargetName, TargetValue, TargetName2, TargetValue2, mustmatch, Metric['Dimensions'])
                            elif ThisMetric.find('diskio') > -1:
                                TargetName = 'name'
                                TargetValue = alarmPath
                                TargetName2 = ''
                                TargetValue2 = ['']
                                mustmatch = 1
                                match = check_metric_dimensions(TargetName, TargetValue, TargetName2, TargetValue2, mustmatch, Metric['Dimensions'])
                            if match == 2:
                                #logger.info('inside create')
                                ThisMessage = ThisMessage + '\nCreated Alarm/Monitor: ' + ' ' + ThisMetric + ' ' + alarmPath + ' ' + ThisOperator + ' ' + str(ThisThreshold) + ' ' + str(ThisEvalPeriod) + ' ' + str(ThisDataPoints) + ' ' + str(ThisPeriod) + '\n'
                                thisDimension = Metric['Dimensions']
                                #if ThisResponseconfig != {}:
                                #    thisDimension.append(ThisResponseconfig)
                                if ThisResponseType in setNonEC2AlarmActions: # we have alarmid to add to dimensions for alarm response
                                    alarmid = {'Name':'AlarmId', 'Value': ThisAlarmId}
                                    thisDimension.append(alarmid)
                                response = create_alarm(ThisAlarmName2, alarmDescription, ThisNameSpace,ThisOperator,ThisEvalPeriod,ThisDataPoints,ThisThreshold,setSNSHelpDesk,AAAction,ThisData,Account, ThisMetric,thisDimension,ThisPeriod,ThisRegion)
                                print(__name__, 'we have a match - this dimension: {}'.format(thisDimension))

                                break # get next alarm from alarm definition
                            else: # did not find match
                                continue
                        elif alarmPath == 'all' and ThisMetric == 'disk_used_percent':
                            #print(__name__, 'beginning disk discovery for all')
                            TargetName = 'fstype'
                            TargetValue = 'xfs'
                            mustmatch = 1
                            #print(__name__, 'loop through disk metrics')
                            diskcount = 0
                            driveVolumes = currentmetrics['Metrics']
                            
                            for DiskMetric in driveVolumes:
                                match = 0
                                diskpath = ''
                                diskcount = diskcount + 1
                                #if TargetValue in DiskMetric['Dimensions']:
                                #print(diskcount, 'get path:', DiskMetric)
                                if DiskMetric['MetricName'] == 'disk_used_percent':
                                    diskpath = get_disk_path(DiskMetric['Dimensions'])
                                    #print(__name__, 'found diskpath:', diskpath)
                                    if diskpath != '' and diskpath not in pathnames:
                                        match = 2
                                        #thisDimension = DiskMetric['Dimensions']
                                    #else:
                                    #    print(__name__, 'not finding xfs')
                                else: # skip if not a disk_used_percent metric
                                    continue
                                #match = check_metric_dimensions(TargetName, TargetValue, TargetName2, TargetValue2, mustmatch, Metric['Dimensions'])
                                if match == 2 and diskpath not in pathnames:
                                    pathnames.append(diskpath)
                                    print(__name__, 'pathnames:',pathnames) # for testing
                                    ThisAlarmName2 = BaseAlarmName + '-' + diskpath + '-' + str(ThisThreshold)
                                    ThisMessage = ThisMessage + '\nCreated Alarm/Monitor: ' + ' ' + ThisMetric + ' ' + diskpath + ' ' + ThisOperator + ' ' + str(ThisThreshold) + ' ' + str(ThisEvalPeriod) + ' ' + str(ThisDataPoints) + ' ' + str(ThisPeriod) + '\n'
                                    thisDimension = DiskMetric['Dimensions']
                                    print(__name__,' dimensions before adding response: {}'.format(thisDimension))
                                    #if ThisResponseconfig != {}:
                                    #    thisDimension.append(ThisResponseconfig)
                                    if ThisResponseType in setNonEC2AlarmActions: # we have alarmid to add to dimensions for alarm response
                                        alarmid = {'Name':'AlarmId', 'Value': ThisAlarmId}
                                        thisDimension.append(alarmid)
                                    
                                        print(__name__,' dimensions after adding response: {}'.format(thisDimension))
                                    #print(__name__, 'inside disk all')
                                    response = create_alarm(ThisAlarmName2,alarmDescription, ThisNameSpace, ThisOperator,ThisEvalPeriod,ThisDataPoints,ThisThreshold,setSNSHelpDesk,AAAction,ThisData,Account, ThisMetric,thisDimension,ThisPeriod,ThisRegion)
                                    match = 0
                                    diskpath = ''
                    ### Windows Metrics
                    elif onPremMetric.find("Processor %") > -1: # windows processor metrics
                        if alarmPath == '':
                            print(__name__,'This Metric:',ThisMetric,' is missing the cpu parameter value in the alarm definition profile.')
                            continue
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisProcessName = 'CPU'
                        if onPremMetric.find("User Time") > 1:
                            typename = 'UserTime'
                        elif onPremMetric.find("Interrupt Time") > 1:
                            typename = 'InterruptTime'
                        elif onPremMetric.find("Idle Time") > 1:
                            typename = 'IdleTime'
                        elif onPremMetric.find("Processor Time") > 1:
                            typename = 'ProcessorTime'
                        ThisAlarmName2 = BaseAlarmName + '-' + ThisProcessName + '-' + alarmPath + '-' + typename + '-' + ThisProcess
                        alarmDetails = "AlarmName='" +ThisAlarmName2 + "',"
                        alarmDescription = 'Alarm when cpu exceeds threshold'
                        ThisMetric = onPremMetric
                    elif onPremMetric.find('Memory %') > -1: # windows memory metric
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisAlarmName2 = BaseAlarmName + '-MEM-' + ThisProcess
                        alarmDescription = 'Alarm when memory utilization exceeds threshold'
                        ThisMetric = onPremMetric
                    elif onPremMetric.find("Physical") > -1: # windows Physical disk metrics
                        if alarmPath == '':
                            print(__name__,'This Metric:',ThisMetric,' is missing the PhysicalDisk parameter value in the alarm definition profile.')
                            continue
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisProcessName = 'DISK'
                        if ThisMetric.find("% Disk Time") > 1:
                            typename = 'DiskTime'
                        elif ThisMetric.find("Disk Write Bytes") > 1:
                            typename = 'DiskWriteByes'
                        elif ThisMetric.find("Disk Read Bytes") > 1:
                            typename = 'DiskReadBytes'
                        elif ThisMetric.find("Disk Writes") > 1:
                            typename = 'DiskWrites'
                        elif ThisMetric.find("Disk Reads") > 1:
                            typename = 'DiskReads'
                        ThisAlarmName2 = BaseAlarmName + '-' + 'LogicalDisk' + '-' + typename + '-' + alarmPath + '-' + str(ThisProcess)
                        alarmDetails = "AlarmName='" +ThisAlarmName2 + "',"
                        alarmDescription = 'Alarm when disk exceeds threshold'
                        ThisMetric = onPremMetric 
                    elif onPremMetric == "LogicalDisk % Free Space": # windows LogicalDisk metrics
                        if alarmPath == '':
                            print(__name__,'This Metric:',ThisMetric,' is missing the LogicalDisk parameter value in the alarm definition profile.')
                            continue
                        print(__name__,'logicaldisk matched:{}'.format(Metric))
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisProcessName = 'DISK'
                        ThisAlarmName2 = BaseAlarmName + '-' + ThisProcessName + '-' + alarmPath + '-' + str(ThisProcess)
                        alarmDetails = "AlarmName='" +ThisAlarmName2 + "',"
                        alarmDescription = 'Alarm when disk exceeds threshold'
                        ThisMetric = onPremMetric 
                    elif onPremMetric == 'Paging File % Usage' : # windows paging file
                        print(__name__,'paging matched:{}'.format(Metric))
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisAlarmName2 = BaseAlarmName + '-PAGE-' + str(ThisProcess)
                        alarmDescription = 'Alarm when memory utilization exceeds threshold'
                        ThisMetric = onPremMetric
                    elif onPremMetric.find('Network Interface') > -1: # Windows Network
                        if alarmPath == '':
                            print(__name__,'This Metric:',ThisMetric,' is missing the network parameter value in the alarm definition profile.')
                            continue
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisProcessName = 'NET'
                        if ThisMetric.find("Bytes Sent/sec") > 1:
                            typename = 'BytesSent'
                        elif ThisMetric.find("Bytes Received/sec") > 1:
                            typename = 'BytesReceived'
                        elif ThisMetric.find("Packets Sent/sec") > 1:
                            typename = 'PacketsSent'
                        elif ThisMetric.find("Packets Received/sec") > 1:
                            typename = 'PacketsReceived'
                        ThisAlarmName2 = BaseAlarmName + '-' + ThisProcessName + '-' + alarmPath + '-' + typename + '-' + ThisProcess
                        alarmDetails = "AlarmName='" +ThisAlarmName2 + "',"
                        alarmDescription = 'Alarm when network exceeds threshold'  
                        ThisMetric = onPremMetric                
                    ### for Process metric
                    elif ThisMetric == 'procstat_lookup_pid_count' or ThisMetric == 'procstat_lookup pid_count':
                        ThisAlarmName2 = BaseAlarmName  + '-' + processName
                        alarmDescription = 'Alarm when number processes drops below threshold'

                    if ThisMetric == 'disk_used_percent' and match !=2:
                        continue
                    else:
                        
                        #if ThisResponseconfig != {}:
                        #    print(__name__,' dimensions before adding response: {}'.format(thisDimension))
                        #    thisDimension.append(ThisResponseconfig)
                        #    print(__name__,' dimensions after adding response: {}'.format(thisDimension))
                        if ThisResponseType in setNonEC2AlarmActions: # we have alarmid to add to dimensions for alarm response
                            alarmid = {'Name':'AlarmId', 'Value': ThisAlarmId}
                            thisDimension.append(alarmid)
                        
                        ThisMessage = ThisMessage + '\nCreated Alarm/Monitor: ' + ' ' + ThisMetric + ' ' + alarmPath + ' ' + ThisOperator + ' ' + str(ThisThreshold) + ' ' + str(ThisEvalPeriod) + ' ' + str(ThisDataPoints) + ' ' + str(ThisPeriod) + '\n'
                        response = create_alarm(ThisAlarmName2,alarmDescription,ThisNameSpace,ThisOperator,ThisEvalPeriod,ThisDataPoints,ThisThreshold,setSNSHelpDesk,AAAction,ThisData,Account, ThisMetric,thisDimension,ThisPeriod,ThisRegion)
                        break # get next alarm from alarm definition
        if test!= 1: # add to queue to update counter
            item = 'created'
            itemValue = createcount
            #RegionName = get_region_name(ThisRegion)
            #update_counts(ssm0,item, itemValue, setCWConfigurations.get("Lifecycle"))
            #update_queue(Tenant, Account, item, itemValue, sqsState, SingleInstanceID, RegionName, ThisRegion)
            msg_body = str({ "Function": 'cw_state', "Account": Account, "item": item, "itemValue": itemValue, "instance": SingleInstanceID, "ThisRegion": ThisRegion })
            update_central_queque(msg_body,setSQS['HCOM-PlatformAutomation'])
            
        return ThisMessage
    else:
        print(__name__, 'No metrics being received yet by CloudWatch. You cant create alarms without metrics. Check that the CloudWatch Agent is working.')
    #sysexit()
    
def check_metric_dimensions(TargetName, TargetValue, TargetName2, TargetValue2, mustmatch, ThisMetrics):
    """Loop through existing instance metrics to find match for target metric to create alarm

    Args:
        TargetName (String): first dimension name
        TargetValue (_type_): first dimension value
        TargetName2 (String): second dimension name
        TargetValue2 (String): second dimension value
        mustmatch (int): how many dimensions need to match
        ThisMetrics ( List of Dict): dimensions for current instance metric to check

    Returns:
        int: match count - needs to be 2 to confirm it found match
    """
    print(__name__,'---- checking metric dimensions --- for: {}'.format(ThisMetrics))
    analyzepath = 0
    foundit = 0
    #results = []
    for dimension in ThisMetrics:
        
        analyzepath = analyzepath + 1
        print(__name__, 'row:', analyzepath, 'dimension:', dimension)
        if mustmatch == 1 and foundit == 0:
            if dimension['Name'] == TargetName and dimension['Value'] == TargetValue and len(dimension['Value']) == len(TargetValue):
                foundit = 2
                print(__name__, 'found match')
                return foundit
            else:
                continue # test the next dimension
        elif mustmatch == 2 and foundit != 2: # must match both target values
            # deepcode ignore IdenticalBranches: <please specify a reason of ignoring this>
            if dimension['Name'] == TargetName and dimension['Value'] == TargetValue and len(dimension['Value']) == len(TargetValue):
                foundit = foundit + 1
                print(__name__, 'found match2')
            elif dimension['Name'] == TargetName2 and dimension['Value'] in TargetValue2:# and len(dimension['Value']) == len(TargetValue2):
                foundit = foundit + 1
                print(__name__, 'found match3')

    return foundit

def get_disk_path(ThisMetrics):
    """pass in existing disk metrics and make sure the discovered path has a supported filesystem type

    Args:
        ThisMetrics (dict): disk metrics

    Returns:
        string: drive path
    """    
    path = ''
    analyzepath = 0
    foundit = 0
    fstypes = ['xfs', 'ext4'] # defines supported filesystem types
    for dimension in ThisMetrics:
        
        analyzepath = analyzepath + 1
       # print(__name__, 'row:', analyzepath, 'dimension:', dimension)
        if foundit != 2: # must match both path and supported filesystem type
            if dimension['Name'] == 'path': # valid matching path
                foundit = foundit + 1
                path = dimension['Value']
                #print(__name__, 'found match1')
                continue
            elif dimension['Name'] == 'fstype' and dimension['Value'] in fstypes: # validate supported filesystem type
                foundit = foundit + 1
                #print(__name__, 'found match2')
    if foundit != 2:
        path = ''

    return path

def get_hcom_event(etype,ename,etarget):
    """Get current hcom event definition/format from DynamoDB and return so it can be used to push a custom event

    Args:
        etype (_type_): event type
        ename (_type_): event name
        etarget (string): target named event

    Returns:
        dict: JSON format from DynamoDb for target hcom event
    """    
    try:
        table = boto3.resource('dynamodb', region_name=setCentralRegion).Table(setDBcon)
        eventdef = table.get_item(Key={'msptype': etype, 'mspname': str(ename)})
        print(__name__,'hcom event is currently defined as {}'.format(eventdef['Item']))
        for key,value in eventdef['Item'].items():
            #print(__name__,'key: {} | value: {}'.format(key,value))
            if key == etarget:
                return value
        
        
    except Exception as e:
        print(__name__,'There was a problem getting the HCOM event {}. | {}'.format(etarget,e))
        pass

def put_hcom_event(source,detail, detailtype):
    """Push custom event for HCOM automation. This logs autoamtion events and allows decoupling and detection.

    Args:
        source (_type_): event type used in DynamoDB query - primary key
        detail (string): This data is a JSON but it must be as string data type. can be unique to event with schema defined in DynamoDB
        detailtype (string): description of the event
    """    
    print(__name__,'--- pushing HCOM event source: {} | detailtype: {} | detail: {}'.format(source,detailtype, detail))
    eb = boto3.client('events', region_name=setCentralRegion)
    try:
        response = eb.put_events(Entries=[{'Source': source, 'DetailType': detailtype, 'Detail': detail, 'EventBusName': setConfigurations['CentralEB']}])
        print(__name__,'Response from pushing custom event. {}'.format(response))
    except Exception as e:
        print(__name__,'There was a problem pushing the HCOM event {}. | {}'.format(source,e))
        pass
    return

def create_alarm(ThisAlarmName2,alarmDescription,ThisNameSpace,ThisOperator,ThisEvalPeriod,ThisDataPoints,ThisThreshold,setSNSHelpDesk,AAAction,ThisData,Account, ThisMetric,thisDimension,ThisPeriod,ThisRegion):
    """function creates alarms for non-ec2 workloads, called by create_onprem....

    Args:
        ThisAlarmName2 (_type_): _description_
        ThisAlarmId (String): Alarm number from profile, each alarm is given a number in sequence
        ThisResponseType (String): provide what CW profile type this is. We are looking for OnPrem and EC2
        alarmDescription (_type_): _description_
        ThisNameSpace (_type_): _description_
        ThisOperator (_type_): _description_
        ThisEvalPeriod (_type_): _description_
        ThisDataPoints (_type_): _description_
        ThisThreshold (_type_): _description_
        setSNSHelpDesk (_type_): _description_
        AAAction (_type_): _description_
        ThisData (_type_): _description_
        Account (_type_): _description_
        ThisMetric (_type_): _description_
        thisDimension (_type_): _description_
        ThisPeriod (_type_): _description_
        ThisOptionName (_type_): _description_
        ThisRegion (_type_): _description_
    """    
    cloudwatch = boto3.client('cloudwatch', region_name=ThisRegion)
    print(__name__, '------ Creating alarm: {} in Region: {} ------'.format(ThisAlarmName2,ThisRegion))
    
    print(__name__,' final dimensions: {}'.format(thisDimension))
    try:
        response = cloudwatch.put_metric_alarm(AlarmName=ThisAlarmName2,
            ComparisonOperator=ThisOperator,
            EvaluationPeriods=ThisEvalPeriod,
            DatapointsToAlarm=ThisDataPoints,
            Threshold=ThisThreshold,
            ActionsEnabled=True,
            OKActions=[setSNSHelpDesk],
            AlarmActions=AAAction,
            AlarmDescription=alarmDescription,
                                        
            TreatMissingData=ThisData,
            Metrics=[
                {
                'Id': "m1",
                'ReturnData': True,
                'AccountId': Account,
                'MetricStat': {
                    'Metric': {
                    'Namespace': ThisNameSpace,
                    'MetricName': ThisMetric,
                    'Dimensions': thisDimension
                },
                'Period': ThisPeriod,
                'Stat': 'Average'
                },
                }
                ],
                Tags=[{'Key': 'AccountNumber','Value': Account}]
        )
        print(__name__,'response to alarm creation for: {} status:{}'.format(ThisAlarmName2, response))
    except ClientError as error:
        print(__name__, 'error creating  alarm.', ThisAlarmName2, error)
        pass
    return

def create_profile_alarms(firstboot,cloudwatch, cw2, ec2, ec3, ThisInstanceID, ThisProfile,defaultProfile,BaseAlarmName,ThisHostName, Tenant, ThisPlatform, setEnvName, ThisRegion, ThisAccount, setProfileName,test, setSNSGeneral, setCentralAccount, opsItemFeature, setSNSHelpDesk, history, alarmResponse,ThisARN,ThisPartition,AccountName):
    """Main function that manages alarm creation for EC2 instances

    Args:
        firstboot (_type_): _description_
        cloudwatch (_type_): _description_
        cw2 (_type_): _description_
        ec2 (_type_): _description_
        ec3 (_type_): _description_
        ThisInstanceID (_type_): _description_
        ThisProfile (_type_): _description_
        defaultProfile (_type_): _description_
        BaseAlarmName (_type_): _description_
        ThisHostName (_type_): _description_
        Tenant (_type_): _description_
        ThisPlatform (_type_): _description_
        setEnvName (_type_): _description_
        ThisRegion (_type_): _description_
        ThisAccount (_type_): _description_
        setProfileName (_type_): _description_
        test (_type_): _description_
        Tenants (_type_): _description_
        setCentralAccount (_type_): _description_
        opsItemFeature (_type_): _description_
        setSNSHelpDesk (_type_): _description_
        history (_type_): _description_
        alarmResponse (_type_): _description_
        ThisPartition (_type_): _description_

    Returns:
        _type_: _description_
    """    
    global UpdateList
    dbcon = boto3.resource('dynamodb', region_name=setCentralRegion)
    print(__name__,'creating cloudwatch connection from inside create_profile_alarms - Region:{}'.format(ThisRegion))
    #cloudwatch = boto3.client('cloudwatch', region_name=ThisRegion) # must create alarms in same region as instance)
    table = dbcon.Table(setDBcon)
    counter=0
    found=0
    ThisMessage = ''
    createcount = 0
    if ThisPlatform == 'Linux':
        Linux = 1
    else:
        Linux = 0 # for Windows
    tag = 'tag:'+ setProfileName
    if defaultProfile != 'yes':
        try:
            responses = ec2.describe_instances(
                Filters=[{'Name':'instance-id' , 'Values':[ThisInstanceID]}
                    ,{'Name':tag, 'Values':[ThisProfile]}
                    ,{'Name':'instance-state-name', 'Values':['running','stopped','stopping']}
                         ]) # Find instances
            found = len(responses['Reservations'])
            print(__name__, 'instances found:', len(responses['Reservations']))
        except ClientError as error:
            print(__name__, 'Unexpected error occurred... could not find target EC2 instance. Check that Instance ID and Tag value are correct.', error)
            
    else: # deploy default alarms
        try:
            responses = ec2.describe_instances(
                Filters=[{'Name':'instance-id' , 'Values':[ThisInstanceID]}
                ,{'Name':'instance-state-name', 'Values':['running','stopped','stopping']}
                         #,{'Name':tag, 'Values':[ThisProfile]}
                         ]) # Find instances
            found = len(responses['Reservations'])
        except ClientError as error:
            print(__name__, 'Unexpected error occurred... could not create EC2 cross account query', error)
            return error
    ################## Start: parse through EC2 search results to create alarms ###################
    alarmdef = {}
    if found == 1:
        for r in responses['Reservations']:
            for i in r['Instances']:
                ## reset variables

                tImage = i['ImageId']
                ThisAMI = i['ImageId']
                tInstanceType = i['InstanceType']
                ThisInstanceType = i['InstanceType']
                thisresult = 1
                #Get EC2 attributes 
                try:
                    ec2instance = ec3.Instance(ThisInstanceID)
                    instancename = ''
                    for tags in ec2instance.tags:

                        if tags["Key"] == 'Name':
                            instancename = tags["Value"]
                            ThisInstance = instancename.split(' ', 1)
                        #elif tags["Key"] == setProfileName:
                        #   ThisProfile = int(tags["Value"])
                        elif tags["Key"] == setEnvName:
                            Thisenv = tags["Value"]
                        elif tags["Key"] == 'CSP_CW_Config':
                            Config = tags["Value"]

                    #print(__name__, '----New Row #', counter, '----')
                    #ThisMessage = ThisMessage + '----New Row # ' + str(counter) + '----\n'
                    gimageid = tImage
                    ginstancetype = tInstanceType
                    if ThisProfile != '-1':
                        print(__name__, 'InstanceId:', ThisInstanceID,'Hostname', ThisHostName, ' AMI: ', gimageid, ' Type:', ginstancetype, ' Platform:', ThisPlatform)
                        #ThisMessage = ThisMessage + ' InstanceId: '+ ThisInstanceID +' Hostname: ' + ThisHostName + ' AMI: '+ ec2instance.image.id + ' Type: '+ ec2instance.instance_type + ' Platform: '+ ThisPlatform  +'\n'
                    else:
                        print(__name__, 'InstanceId:', ThisInstanceID,'Hostname', ThisHostName, ' AMI: ', tImage, ' Type:', ec2instance.instance_type, ' Platform:', ThisPlatform)
                        #ThisMessage = ThisMessage + ' InstanceId: '+ ThisInstanceID +' Hostname: ' + ThisHostName + ' AMI: '+ ec2instance.image.id + ' Type: '+ ec2instance.instance_type + ' Platform: '+ strThisPlatform  + '\n'
                except ClientError as error:
                    print(__name__, 'SSM query ran into an error', error)
                    return error
        #ConfigAlarm = setCWConfigurations.get("Alarms").replace("XX", str(ThisProfile))
        ##### Start: Get Alarm Definition from Parameter Store ########################################
        #print(__name__, 'getting param:', ConfigAlarm)
        alarms = table.get_item(Key={'msptype': 'cw-profile', 'mspname': str(ThisProfile)})
        print(__name__, ' profile: {} alarms def: {}'.format(str(ThisProfile),alarms))
        ################# End: Get Alarm Defintion from Parameter Store ##################
        if alarms.get('Item','') != '': # we have a profile
            print(__name__, "tenants:", Tenant)
            setSNSGeneral = convert_arn(setSNSGeneral,setCentralRegion,setCentralAccount,ThisPartition,Tenant,AccountName) #arn,region,account,partition,tenant,accountname
            print(__name__, "topic:", setSNSGeneral)
            ####### End: Get SNS Topic #################
            ############### Start: Parse for alarm parameters #############################
            counter = 0
            try:
                alarmdef1 = alarms['Item']['alarms']
                alarmdef = dict(sorted(alarmdef1.items()))
                rows = len(alarmdef)
                print(__name__, 'rows:', rows)
                for key, i in alarmdef.items():
                    print(__name__, 'create_profile_alarms alarm row: {} | {}'.format(key, i))
                    curAlarm = i
                    OI=0 #reset
                    OISeverity = ''
                    OICategory = ''
                    counter = counter + 1
                    #alarmType = varName
                    alarmPath = ''
                    ThisResponseType = ''
                    ThisOptionName = ''
                    ThisMetricName = curAlarm.get('metricname')
                    ThisMetricCategory = curAlarm.get('metriccategory')
                    if ThisMetricCategory in ['Processor', 'Memory','PhysicalDisk','LogicalDisk', 'Paging File', 'Network Interface']:
                        print(__name__,'adding category: {} | with metric name: {}'.format(ThisMetricCategory,ThisMetricName))
                        ThisMetric = ThisMetricCategory + ' ' + ThisMetricName
                    else:
                        ThisMetric = ThisMetricName
                        print(__name__,' did not match special metric name: ThisMetric: {}'.format(ThisMetric))

                    print(__name__,' metric vars: Metric Name: {} | Metric Cat + Name {}'.format(ThisMetricName,ThisMetric))
                    ThisOperator = curAlarm.get('operator')
                    ThisThreshold = int(curAlarm.get('threshold'))
                    ThisEvalPeriod = int(curAlarm.get('evaluationperiods'))
                    ThisDataPoints = int(curAlarm.get('datapoints'))
                    ThisPeriod = int(curAlarm.get('period'))
                    ThisData = curAlarm.get('TreatMissingData')
                    ThisAlarmId = key
                    if curAlarm.get('optionname'):
                        ThisOptionName = curAlarm.get('optionname')
                    if curAlarm.get('opsitempriority'):
                        OISeverity = int(curAlarm.get('opsitempriority'))
                        OI = 1
                    if curAlarm.get('opsitemcategory'):
                        OICategory = (curAlarm.get('opsitemcategory'))
                        OI = 1
                    if curAlarm.get('option'):
                        alarmPath = curAlarm.get('option')
                    if curAlarm.get('name'):
                        processName = curAlarm.get('name')
                        OI = 1
                    if curAlarm.get('ResponseType'):
                        ThisResponseType = curAlarm.get('ResponseType')
                        
                        if ThisResponseType == 'Stop': ### check for alarm action automations to invoke EC2 state changes
                            ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + ThisAccount +':action/actions/AWS_EC2.InstanceId.Stop/1.0'
                        elif ThisResponseType == 'Reboot':
                            ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + ThisAccount +':action/actions/AWS_EC2.InstanceId.Reboot/1.0'
                        elif ThisResponseType == 'Terminate':
                            ec2Action = 'arn:'+ ThisPartition + ':swf:' + ThisRegion + ':' + ThisAccount +':action/actions/AWS_EC2.InstanceId.Terminate/1.0'
                        else:
                            ec2Action = ''
                    else:
                        ec2Action = ''
                    print(__name__,'responsetype after assignment: {}'.format(ThisResponseType))
                    if alarms['Item']['ProfileType'].find('OnPrem') > -1: # is this an on-premise alarm
                        onprem = 'yes'
                    else:
                        onprem = 'no'
                    createcount = createcount + 1
                    print(__name__, 'begin alarm creation section, metric: {}, region: {}'.format(ThisMetric,ThisRegion))
                    if alarmPath != 'all':
                        print(__name__, ' Created Alarm/Monitor: metric: {} | alarmpath: {} | operator:{} | Thresh: {} | {} | {} | {}'.format( ThisMetric, alarmPath, ThisOperator, ThisThreshold, ThisEvalPeriod, ThisDataPoints, ThisPeriod))
                        if OI==1: 
                            print(OISeverity, OICategory)            
                        ThisMessage = ThisMessage + '\nCreated Alarm/Monitor: ' + ' ' + ThisMetric + ' ' + alarmPath + ' ' + ThisOperator + ' ' + str(ThisThreshold) + ' ' + str(ThisEvalPeriod) + ' ' + str(ThisDataPoints) + ' ' + str(ThisPeriod) + '\n'
                        
                    if ThisMetric == 'CPUUtilization': # for Linux and Windows standard non-agent CPU metric
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisProcessName = 'CPUU'
                        try:
                            #print(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod)
                            create_cpu_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action)
                        except ClientError as error:
                            print(__name__, 'create cpu alarm ran into an error', error)
                            return error
                        #print(__name__, 'create cpu')
                    elif ThisMetric == 'cpu_usage_user' or ThisMetric == 'cpu_usage_idle' or ThisMetric == 'cpu_usage_iowait' or ThisMetric == 'cpu_usage_system': # for Linux CloudWatch Agent CPU metrics
                        ThisPath = alarmPath # only support named instances
                        print(__name__,'cpu_ ThisPath:{}'.format(ThisPath))
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisProcessName = 'CPU'
                        try:
                            create_cpu_linux_alarm(cloudwatch, ThisPath, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action,ThisMetric,ThisProcessName,ThisHostName,onprem)
                        except ClientError as error:
                            print(__name__, 'create windows processor alarm ran into an error', error)
                            pass
                        #print(__name__, 'create process', ThisProcess)
                    elif ThisMetric == 'mem_used_percent': # for Linux and Windows standard non-agent CPU metric
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        
                        if Linux == 1 :
                            try:
                                memresults = create_linux_mem_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,history,ThisResponseType,ThisPartition,ec2Action,ThisARN)
                                if memresults.get('firsttime') == 'yes':
                                    history = -1
                                    print(__name__, 'first time creation')
                                else:
                                    history = 1
                            except ClientError as error:
                                print(__name__, 'create linux memory alarm ran into an error', error)
                                return error
                            #print(__name__, 'create mem')
                        #else: #windows
                        #    try:
                        #        create_win_mem_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess,ThisAccount, setSNSGeneral,ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisProfile,ThisResponseType,alarmResponse,ThisPartition,ec2Action)
                        #    except ClientError as error:
                        #        print(__name__, 'creae windows memory alarm ran into an error', error)
                        #        return error
                        #print(__name__, 'create mem')
                    elif ThisMetric.find('Memory %') > -1: # windows memory metric
                        try:
                                create_win_mem_alarm(cloudwatch, ThisMetric, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisAccount, setSNSGeneral,ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action)
                        except ClientError as error:
                            print(__name__, 'creae windows memory alarm ran into an error', error)
                            return error
                    elif ThisMetric == 'procstat_lookup pid_count' or ThisMetric == 'procstat_lookup_pid_count': # for process monitoring
                        ThisProcess = processName # what makes this alarm unique
                        if Linux == 1:
                            try:
                                create_linux_process_alarm(cloudwatch, ThisAlarmId,ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action)
                            except ClientError as error:
                                print(__name__, 'create linux process alarm ran into an error. region: {} error: {}'.format(ThisRegion, error))
                                return error
                            #print(__name__, 'create process', ThisProcess)
                        else: # Windows Server
                            try:
                                create_win_process_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action)
                            except ClientError as error:
                                print(__name__, '1623 - create win process alarm ran into an error. region: {} error: {}'.format(ThisRegion, error) )
                                return error
                            #print(__name__, 'create process', ThisProcess)
                    elif ThisMetric == 'Processor % User Time' or ThisMetric == 'Processor % Idle Time' or ThisMetric == 'Processor % Interrupt Time': # for Windows CloudWatch Agent CPU metrics
                        ThisPath = alarmPath # only support 0. will need to add later dynamic discovery "all"
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisProcessName = 'Processor'
                        try:
                            create_ec2_instance_alarm(cloudwatch, ThisPath, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action,ThisMetric,ThisProcessName)
                        except ClientError as error:
                            print(__name__, 'create windows processor alarm ran into an error', error)
                            return error
                        #print(__name__, 'create process', ThisProcess)
                    elif ThisMetric == 'PhysicalDisk % Disk Time': # for Windows physicaldisk metric
                        ThisPath = alarmPath # only support 0. will need to add later dynamic discovery "all"
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisProcessName = 'PhysicalDisk'
                        try:
                            create_ec2_instance_alarm(cloudwatch, ThisPath, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action,ThisMetric,ThisProcessName)
                        except ClientError as error:
                            print(__name__, 'create windows processor alarm ran into an error', error)
                            return error
                        #print(__name__, 'create process', ThisProcess)
                    elif ThisMetric == 'diskio_io_time': # diskio metric alarm for Linux
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        ThisPath = alarmPath # set device name
                        print(__name__, 'starting diskio')
                        try:
                            create_linux_drive_io_alarm(cloudwatch, ThisPath, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory,opsItemFeature, ThisData, ThisResponseType,ThisPartition,ec2Action,ThisMetric)
                        except ClientError as error:
                            print(__name__, 'creae linux drive alarm ran into an error', error)
                            return error
                    elif ThisMetric == 'disk_used_percent': #alarmType == 'disk' or alarmType == 'diskinodes':
                        ThisPath = alarmPath
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        print(__name__, 'ThisPath:', ThisPath, ' ThisMetric:',ThisMetric)
                        if Linux == 1 : # Linux server
                            
                            if ThisPath == 'all' or alarmPath == 'all': # dynamically discover all drives and create alarms
                                filesystems = ['xfs', 'ext4']
                                for fstype in filesystems:
                                    #### Begin Dynamic Disk discovery and alarm creation
                                    #fstype = 'xfs'
                                    print('discovering type: {}'.format(fstype))
                                    paginator = cw2.get_paginator('list_metrics')
                                    try:
                                        for response in paginator.paginate(
                                                MetricName='disk_used_percent',
                                                Namespace='CWAgent',
                                                Dimensions=[
                                                    {'Name': 'InstanceId', 'Value': ThisInstanceID},
                                                    {'Name': 'ImageId'},
                                                    {'Name': 'InstanceType'},
                                                    {'Name': 'path'},
                                                    {'Name': 'fstype', 'Value': fstype},
                                                    {'Name': 'device'}
                                                ],):
                                            ### Something here
                                            #print(__name__, 'inside response:', response['Metrics'][0])
                                            print()
                                    except IndexError as error:
                                        print(__name__, 'Disk type {} not found error. {}'.format(fstype,error))
                                        pass
                                    #finally:
                                    #print(__name__, 'Response Metrics raw', response['Metrics'])
                                    #print(__name__, 'length of response[Metrics]:', len(response['Metrics']))

                                    if len(response['Metrics']) < 1 :
                                        print(__name__, 'InstanceId:',ThisInstanceID, ' Identified missing volume info and returning')
                                        ThisMessage = ThisMessage + 'InstanceId: ' + ThisInstanceID + ' Identified missing volume info and returning\n'
                                        ThisDeviceName = 'none'
                                        #return 
                                    else:
                                        try:
                                            for r in response['Metrics']: # contains number of volumes detected
                                                # print(__name__, 'Dimensions', r['Dimensions'])
                                                #print(__name__, 'volume :',r) #shows object array for each volume
                                                if len(r['Dimensions']) == 0:
                                                    #print(__name__, 'length:', len(response['Metrics']))
                                                    print()
                                                else:
                                                    #print(__name__, 'length', len(r['Dimensions']))
                                                    print()
                                                    skip = 0

                                                    try:
                                                        for j in range(5): # contains all the metadata for each volume
                                                            #print(r['Dimensions'][j]['Name'], r['Dimensions'][j]['Value'])
                                                            if r['Dimensions'][j]['Value'].find("Harddisk") != -1: # skip entire row
                                                                skip = 1
                                                                break
                                                            if r['Dimensions'][j]['Name'] == 'ImageId':
                                                                ThisAMI = r['Dimensions'][j]['Value']
                                                            elif r['Dimensions'][j]['Name'] == 'path':
                                                                ThisPath = r['Dimensions'][j]['Value']
                                                            elif r['Dimensions'][j]['Name'] == 'device':
                                                                ThisDevice = r['Dimensions'][j]['Value']
                                                                print(__name__, 'thisdevice:', ThisDevice)
                                                    except IndexError as error:
                                                        print(__name__, 'Error querying for volume Error:', error)
                                                        pass
                                                    if skip == 0:
                                                        try:
                                                            create_linux_drive_alarm(firstboot,cloudwatch, cw2, fstype,ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisPath, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,history,ThisResponseType,ThisPartition,ec2Action,ThisMetric,ThisDevice)
                                                                                    
                                                            print(__name__, 'Created Alarm/Monitor:', ThisPath, ThisOperator, ThisThreshold, ThisEvalPeriod, ThisDataPoints, ThisPeriod, ThisData)
                                                            ThisMessage = ThisMessage + '\nCreated Alarm/Monitor: ' + ' ' + ' ' +ThisPath + ' ' + ThisOperator + ' ' + str(ThisThreshold) + ' ' + str(ThisEvalPeriod) + ' ' + str(ThisDataPoints) + ' ' + str(ThisPeriod) + ' ' + ThisData +'\n'
                                                            createcount = createcount + 1
                                                        except ClientError as error:
                                                            print(__name__, 'creae windows drive alarm ran into an error', error)
                                                            return error

                                        except IndexError as error:
                                            print(__name__, 'Error querying for volume-2 Error:', error)
                                            return error
                                    #### End Dynamic Disk discovery and alarm creation
                            
                                
                            else: # only create drive specified in alarm definition file
                                fstype = 'xfs'
                                try:
                                    create_linux_drive_alarm(firstboot,cloudwatch, cw2, fstype, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisPath, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory,opsItemFeature, ThisData, history, ThisResponseType,ThisPartition,ec2Action, ThisMetric, ThisDevice='')
                                except ClientError as error:
                                    print(__name__, 'creae linux drive alarm ran into an error', error)
                                    return error
                            #print(__name__, 'create drive', ThisPath)
                    elif ThisMetric == 'swap_used_percent': # Linux Swap
                        ThisPath = alarmPath
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        print(__name__, 'ThisPath:', ThisPath, ' ThisMetric:',ThisMetric)
                        try:
                            create_linux_swap_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action)
                        except ClientError as error:
                            print(__name__, 'creae linux drive alarm ran into an error', error)
                            return error
                    elif ThisMetric == "LogicalDisk % Free Space": # Windows disk volume
                        print(__name__,' inside LogicalDisk. what is ThisPath:', ThisPath, '|', alarmPath)
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        if alarmPath == 'all': # dynamically discover all drives and create alarms
                            #### Begin Dynamic Disk discovery and alarm creation
                            print(__name__,'--- made it to dynamic discovery for Windows drive volume ---')
                            paginator = cw2.get_paginator('list_metrics')
                            try:
                                for response in paginator.paginate(
                                        MetricName='LogicalDisk % Free Space',
                                        Namespace='CWAgent',
                                        Dimensions=[
                                            {'Name': 'InstanceId', 'Value': ThisInstanceID},
                                            {'Name': 'instance'},
                                            {'Name': 'ImageId'},
                                            {'Name': 'InstanceType'},
                                            {'Name': 'objectname', 'Value': 'LogicalDisk'}
                                        ],):
                                    ### Something here
                                    print(__name__, 'inside response:', response['Metrics'][0])
                                    print()
                            except IndexError as error:
                                print(__name__, 'Page File not found error', error)
                                pass
                            #finally:
                            print(__name__, 'Response Metrics raw', response['Metrics'])
                            print(__name__, 'length of response[Metrics]:', len(response['Metrics']))

                            if len(response['Metrics']) < 1 :
                                print(__name__, 'InstanceId:',ThisInstanceID, ' Identified missing volume info and returning')
                                ThisMessage = ThisMessage + 'InstanceId: ' + ThisInstanceID + ' Identified missing volume info and returning\n'
                                ThisDeviceName = 'none'
                                #return 
                            else:
                                try:
                                    for r in response['Metrics']: # contains number of volumes detected
                                        print(__name__, 'Dimensions', r['Dimensions'])
                                        print(__name__, 'volume :',r) #shows object array for each volume
                                        if len(r['Dimensions']) == 0:
                                            print(__name__, 'length:', len(response['Metrics']))
                                            print()
                                        else:
                                            print(__name__, 'length', len(r['Dimensions']))
                                            print()
                                            skip = 0

                                            try:
                                                for j in range(5): # contains all the metadata for each volume
                                                    print(__name__,r['Dimensions'][j]['Name'], r['Dimensions'][j]['Value'])
                                                    if r['Dimensions'][j]['Value'].find("Harddisk") != -1: # skip entire row
                                                        skip = 1
                                                        break
                                                    if r['Dimensions'][j]['Name'] == 'ImageId':
                                                        ThisAMI = r['Dimensions'][j]['Value']
                                                    elif r['Dimensions'][j]['Name'] == 'InstanceType':
                                                        ThisInstanceType = r['Dimensions'][j]['Value']
                                                    elif r['Dimensions'][j]['Name'] == 'instance':
                                                        ThisPath = r['Dimensions'][j]['Value'] 

                                            except IndexError as error:
                                                print(__name__, 'Error querying for volume Error:', error)
                                                pass
                                            if skip == 0:
                                                try:
                                                    create_win_drive_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisPath, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action)
                                                    print(__name__, 'Created Alarm/Monitor:', ThisPath, ThisOperator, ThisThreshold, ThisEvalPeriod, ThisDataPoints, ThisPeriod)
                                                    ThisMessage = ThisMessage + 'Created Alarm/Monitor: ' + ' ' +ThisPath + ' ' + ThisOperator + ' ' + str(ThisThreshold) + ' ' + str(ThisEvalPeriod) + ' ' + str(ThisDataPoints) + ' ' + str(ThisPeriod) + ' ' + ThisData +'\n'
                                                    createcount = createcount + 1
                                                except ClientError as error:
                                                    print(__name__, 'creae windows drive alarm ran into an error', error)
                                                    return error

                                except IndexError as error:
                                    print(__name__, 'Error querying for volume-2 Error:', error)
                                    return error
                            #### End Dynamic Disk discovery and alarm creation
                        else: # only create drive specified in alarm definition file
                            ThisPath = alarmPath + ':'
                            print(__name__, '--- not all just a single instance.', ThisPath)
                            try:
                                create_win_drive_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisPath, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action)
                            except ClientError as error:
                                print(__name__, 'creae windows drive alarm ran into an error', error)
                                return error
                        #print(__name__, 'create drive', ThisPath)
                    elif ThisMetric == 'Paging File % Usage': # Windows Paging File
                        ThisPath = alarmPath
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        print(__name__, 'ThisPath:', ThisPath, ' ThisMetric:',ThisMetric)
                        try:
                            create_win_pagefile_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, cw2,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action)
                        except ClientError as error:
                            print(__name__, 'creae linux drive alarm ran into an error', error)
                            return error
                    elif ThisMetric == 'StatusCheckFailed':
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        try:
                            create_status_check(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralAccount,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,ThisPartition,ec2Action)
                        except ClientError as error:
                            print(__name__, 'create status alarm ran into an error', error)
                            return error
                        #print(__name__, 'create status')
                    

                    else: ### must be custom, alarmType == 'custom':
                        ThisMetricName = alarmPath
                        ThisProcess = str(ThisThreshold) # what makes this alarm unique
                        print(__name__, '--- no match for {} so creating custom alarm ---'.format(ThisMetric))
                        try:
                            create_custom_metric_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralRegion,setCentralAccount,ThisMetricName,OISeverity,OICategory,opsItemFeature,ThisData,ThisResponseType,alarmResponse,ThisPartition,ec2Action)
                        except ClientError as error:
                            print(__name__, 'create status alarm ran into an error', error)
                            return error
                        #print(__name__, 'create status')
                    #else:
                    #    break
                # old spot for update counts for number of alarms created

                
            except KeyError as error:
                errormessage = 'CloudWatch Alarm Profile ' + str(ThisProfile) + ' specified by tag has not been defined or at least not for this Account & Region'
                print(__name__,'{} | {}'.format(errormessage, error))
                return {'statusCode': 400, 'statusmessage': errormessage}
            ## update counts
            if test!= 1 and createcount > 0:
                item = 'created'
                itemValue = createcount
                #RegionName = get_region_name(ThisRegion)
                #update_counts(ssm0,item, itemValue, setCWConfigurations.get("Lifecycle"))
                #update_queue(Tenant, ThisAccount, item, itemValue, sqsState, ThisInstanceID, RegionName, ThisRegion)
                msg_body = str({ "Function": 'cw_state', "Account": ThisAccount, "item": item, "itemValue": itemValue, "instance": ThisInstanceID, "ThisRegion": ThisRegion })
                update_central_queque(msg_body,setSQS['HCOM-PlatformAutomation'])
                return ThisMessage
        else: # there was no match to the profile tag value - it does not exist
            print(__name__,'CloudWatch Alarm Profile specified by tag has not been defined or at least not for this Account & Region')
            return {'statusCode': 400, 'message': 'CloudWatch Alarm Profile specified by tag has not been defined or at least not for this Account & Region'}
    else:
        ThisMessage = 'No instance was found. Check InstanceId and Tag are accurate.'
        print(ThisMessage)
        return ThisMessage
def create_status_check(cloudwatch, ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDatapoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory, features,ThisData,ThisResponseType,ThisPartition,ec2Action):
    """ create CloudWatch alarm for EC2 instance status check metric. Settings are passed from CloudWatch Profile

    Args:
        cloudwatch (_type_): _description_
        ThisRegion (_type_): _description_
        setSNSHelpDesk (_type_): _description_
        ThisAlarmName (_type_): _description_
        ThisInstanceID (_type_): _description_
        ThisAccount (_type_): _description_
        setSNSGeneral (_type_): _description_
        ThisEvalPeriod (_type_): _description_
        ThisDatapoints (_type_): _description_
        ThisThreshold (_type_): _description_
        ThisOperator (_type_): _description_
        ThisPeriod (_type_): _description_
        setCentralAccount (_type_): _description_
        OISeverity (_type_): _description_
        OICategory (_type_): _description_
        features (_type_): _description_
        ThisData (_type_): _description_
        ThisResponseType (_type_): _description_
        alarmResponse (_type_): _description_
        ThisPartition (_type_): _description_
        ec2Action (_type_): _description_
    """    
    # Create status check alarm
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = ThisProfile + ":" + 'StatusCheckFailed' + ":" + str(ThisThreshold) # set value for alarmResponse dimension - should match agent config
    ThisAlarmName2 = ThisAlarmName + '-StatusFailed'
    print(__name__, 'Alarmname: ', ThisAlarmName2) # for testing

    try:
        cloudwatch.put_metric_alarm(
            AlarmName=ThisAlarmName2,
            ComparisonOperator=ThisOperator,
            EvaluationPeriods=ThisEvalPeriod,
            DatapointsToAlarm=ThisDatapoints,
            Threshold=ThisThreshold,
            ActionsEnabled=True,
            OKActions=[
                setSNSHelpDesk
            ],
            AlarmActions=AAAction,
            AlarmDescription='Alarm when status check exceeds threhold',
                    
            TreatMissingData=ThisData,
            Metrics=[
                {
                    'Id': "m1",
                    'ReturnData': True,
                    'AccountId': ThisAccount,
                    'MetricStat': {
                        'Metric': {
                        'Namespace': 'AWS/EC2',
                        'MetricName': 'StatusCheckFailed',
                        'Dimensions': [
                            {
                                'Name': 'InstanceId',
                                'Value': ThisInstanceID
                            },

                        ]
                    },
                    'Period': ThisPeriod,
                    'Stat': 'Average'
                },
                }
            ],
            Tags=[
                {
                    'Key': 'AccountNumber',
                    'Value': ThisAccount
                }
            ]
        )
    except Exception as e:
        print(__name__,' error creating status check: {}'.format(e))
        pass
    return
def create_cpu_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory, features,ThisData,ThisResponseType,ThisPartition,ec2Action):
    # Create cpu utilization alarm
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = ThisProfile + ":" + 'CPUUtilization' + ":" + str(ThisThreshold)
    ThisAlarmName2 = ThisAlarmName + '-CPU' + str(ThisThreshold)
    print(__name__, 'Alarmname: ', ThisAlarmName2) # for testing
    cloudwatch = boto3.client('cloudwatch', region_name=ThisRegion)

    try:
        cloudwatch.put_metric_alarm(
            AlarmName=ThisAlarmName2,
            ComparisonOperator=ThisOperator,
            EvaluationPeriods=ThisEvalPeriod,
            DatapointsToAlarm=ThisDataPoints,
            Threshold=ThisThreshold,
            ActionsEnabled=True,
            OKActions=[
                setSNSHelpDesk
            ],
            AlarmActions=AAAction,
            AlarmDescription='Alarm when CPU exceeds threhold',
                    
            TreatMissingData=ThisData,
            Metrics=[
                {
                    'Id': "m1",
                    'ReturnData': True,
                    'AccountId': ThisAccount,
                    'MetricStat': {
                        'Metric': {
                        'Namespace': 'AWS/EC2',
                        'MetricName': 'CPUUtilization',
                        'Dimensions': [
                            {
                                'Name': 'InstanceId',
                                'Value': ThisInstanceID
                            },

                        ]
                    },
                    'Period': ThisPeriod,
                    'Stat': 'Average'
                },
                }
            ],
            Tags=[
                {
                    'Key': 'AccountNumber',
                    'Value': ThisAccount
                }
            ]
        )
    except Exception as e:
        print(__name__,' error creating cpu alarm: {}'.format(e))
        pass
    return
def create_cpu_linux_alarm(cloudwatch, ThisPath, ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory,features,ThisData,ThisResponseType,ThisPartition,ec2Action,ThisMetric,ThisProcessName,ThisHostName,onprem):
    if ThisPath == '':
        print(__name__,'This Metric:',ThisMetric,' is missing the cpu parameter value in the alarm definition profile.')
        return
    cloudwatch = boto3.client('cloudwatch', region_name=ThisRegion)
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = str(ThisProfile) + ":" + ThisMetric + ":" + str(ThisThreshold)
    
    #print(__name__, "responsetype:",ThisResponseType, " value:",ThisValue) # for testing
    if ThisMetric.find("idle") > 1:
        typename = 'idle'
    elif ThisMetric.find("user") > 1:
        typename = 'user'
    elif ThisMetric.find("system") > 1:
        typename = 'system'
    elif ThisMetric.find("iowait") > 1:
        typename = 'iowait'
    ThisAlarmName2 = ThisAlarmName + '-' + ThisProcessName + '-' + typename + '-' + ThisProcess
    print(__name__, 'Alarmname: ', ThisAlarmName2, '|',ThisInstanceID, '|', ThisPath, '|', ThisHostName) # for testing

    if ThisResponseType == '' and onprem == 'no':
        cloudwatch.put_metric_alarm(
            AlarmName=ThisAlarmName2,
            ComparisonOperator=ThisOperator,
            EvaluationPeriods=ThisEvalPeriod,
            DatapointsToAlarm=ThisDataPoints,
            Threshold=ThisThreshold,
            ActionsEnabled=True,
            OKActions=[
                setSNSHelpDesk
            ],
            AlarmActions=AAAction,
            AlarmDescription='Alarm when process is not running',
                    
            TreatMissingData=ThisData,
            Metrics=[
                {
                    'Id': "m1",
                    'ReturnData': True,
                    'AccountId': ThisAccount,
                    'MetricStat': {
                        'Metric': {
                        'Namespace': 'CWAgent',
                        'MetricName': ThisMetric,
                        'Dimensions': [
                            {
                            'Name': 'cpu',
                            'Value': ThisPath
                            },
                            {
                                'Name': 'InstanceId',
                                'Value': ThisInstanceID
                            },
                            {
                                'Name': 'ImageId',
                                'Value': ThisAMI
                            },
                            {
                                'Name': 'InstanceType',
                                'Value': ThisInstanceType
                            },
                        ]
                    },
                    'Period': ThisPeriod,
                    'Stat': 'Average'
                },
                }
            ],
            Tags=[
                {
                    'Key': 'AccountNumber',
                    'Value': ThisAccount
                }
            ]
        )

    elif ThisResponseType == '' and onprem == 'yes':
        cloudwatch.put_metric_alarm(
            AlarmName=ThisAlarmName2,
            ComparisonOperator=ThisOperator,
            EvaluationPeriods=ThisEvalPeriod,
            DatapointsToAlarm=ThisDataPoints,
            Threshold=ThisThreshold,
            ActionsEnabled=True,
            OKActions=[
                setSNSHelpDesk
            ],
            AlarmActions=AAAction,
            AlarmDescription='Alarm when process is not running',
                    
            TreatMissingData=ThisData,
            Metrics=[
                {
                    'Id': "m1",
                    'ReturnData': True,
                    'AccountId': ThisAccount,
                    'MetricStat': {
                        'Metric': {
                        'Namespace': 'CWAgent',
                        'MetricName': ThisMetric,
                        'Dimensions': [
                            {
                                'Name': 'InstanceId',
                                'Value': ThisInstanceID
                            },
                            {
                                'Name': 'cpu',
                                'Value': ThisPath
                            },
                            {
                                'Name': 'host',
                                'Value': ThisHostName
                            },
                        ]
                    },
                    'Period': ThisPeriod,
                    'Stat': 'Average'
                },
                }
            ],
            Tags=[
                {
                    'Key': 'AccountNumber',
                    'Value': ThisAccount
                }
            ]
        )
def create_win_mem_alarm(cloudwatch, ThisMetric,ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory,features,ThisData,ThisResponseType,ThisPartition,ec2Action):
    # Create Windows memory utilization alarm
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = ThisProfile + ":" + 'Memory % Committed Bytes In Use' + ":" + str(ThisThreshold)
    ThisAlarmName2 = ThisAlarmName + '-MEM' + str(ThisThreshold)
    print(__name__, 'Alarmname: ', ThisAlarmName2) # for testing

    cloudwatch.put_metric_alarm(
        AlarmName=ThisAlarmName2,
        ComparisonOperator=ThisOperator,
        EvaluationPeriods=ThisEvalPeriod,
        DatapointsToAlarm=ThisDataPoints,
        Threshold=ThisThreshold,
        ActionsEnabled=True,
        OKActions=[
            setSNSHelpDesk
        ],
        AlarmActions=AAAction,
        AlarmDescription='Alarm when RAM exceeds threhold',
                
        TreatMissingData=ThisData,
        Metrics=[
            {
                'Id': "m1",
                'ReturnData': True,
                'AccountId': ThisAccount,
                'MetricStat': {
                    'Metric': {
                    'Namespace': 'CWAgent',
                    'MetricName': ThisMetric,
                    'Dimensions': [
                        {
                            'Name': 'InstanceId',
                            'Value': ThisInstanceID
                        },
                        {
                            'Name': 'ImageId',
                            'Value': ThisAMI
                        },
                        {
                            'Name': 'InstanceType',
                            'Value': ThisInstanceType
                        },
                        {
                            'Name': 'objectname',
                            'Value': 'Memory'
                        },
                    ]
                },
                'Period': ThisPeriod,
                'Stat': 'Average'
            },
            }
        ],
        Tags=[
            {
                'Key': 'AccountNumber',
                'Value': ThisAccount
            }
        ]
    )
def create_win_pagefile_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, cw2, setCentralAccount,OISeverity,OICategory,features,ThisData,ThisResponseType,ThisPartition,ec2Action):
    # Create Windows pagefile utilization alarm
    ThisPath = '\??\D:\pagefile.sys'
    allgood = 0
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = ThisProfile + ":" + 'Paging File % Usage' + ":" + str(ThisThreshold)
    ThisDeviceName = get_pagefile_device(cw2, ThisInstanceID, ThisPath)
    print(__name__, ' this page file device:', ThisDeviceName)
    if ThisDeviceName == '': # D page file not found
        ThisPath = '\??\C:\pagefile.sys'
        ThisDeviceName = get_pagefile_device(cw2, ThisInstanceID, ThisPath)
        if ThisDeviceName != '':
            allgood = 1
        else:
            ThisPath = '\??\E:\pagefile.sys'
            ThisDeviceName = get_pagefile_device(cw2, ThisInstanceID, ThisPath)
            if ThisDeviceName != '':
                allgood = 1
    else:
        allgood = 1
    if allgood == 1: # we have a page file so go create it
        ThisAlarmName2 = ThisAlarmName + '-Page' + str(ThisThreshold)
        print(__name__, 'Alarmname: ', ThisAlarmName2) # for testing

        cloudwatch.put_metric_alarm(
            AlarmName=ThisAlarmName2,
            ComparisonOperator=ThisOperator,
            EvaluationPeriods=ThisEvalPeriod,
            DatapointsToAlarm=ThisDataPoints,
            Threshold=ThisThreshold,
            ActionsEnabled=True,
            OKActions=[
                setSNSHelpDesk
            ],
            AlarmActions=AAAction,
            AlarmDescription='Alarm when Page file exceeds threhold',
                    
            TreatMissingData=ThisData,
            Metrics=[
                {
                    'Id': "m1",
                    'ReturnData': True,
                    'AccountId': ThisAccount,
                    'MetricStat': {
                        'Metric': {
                        'Namespace': 'CWAgent',
                        'MetricName': 'Paging File % Usage',
                        'Dimensions': [
                            {
                                'Name': 'InstanceId',
                                'Value': ThisInstanceID
                            },
                            {
                                'Name': 'ImageId',
                                'Value': ThisAMI
                            },
                            {
                                'Name': 'InstanceType',
                                'Value': ThisInstanceType
                            },
                            {
                                'Name': 'instance',
                                'Value': ThisDeviceName
                            },
                            {
                                'Name': 'objectname',
                                'Value': 'Paging File'
                            },
                        ]
                    },
                    'Period': ThisPeriod,
                    'Stat': 'Average'
                },
                }
            ],
            Tags=[
                {
                    'Key': 'AccountNumber',
                    'Value': ThisAccount
                }
            ]
        )
        return 1
    else:
        print(__name__, 'no paging file')
        return 0
def create_win_drive_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisDrive, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory, features,ThisData,ThisResponseType,ThisPartition,ec2Action):
    # Create drive alarm            
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = str(ThisProfile) + ":" + 'LogicalDisk % Free Space' + ":" + str(ThisThreshold) # set value for alarmResponse dimension - should match agent config
    ThisPercent = 100 - ThisThreshold
    ThisAlarmName2 = ThisAlarmName + '-' + ThisDrive + str(ThisThreshold)
    print(__name__, ' win_drive_alarm Alarmname: ', ThisAlarmName2) # for testing

    cloudwatch.put_metric_alarm(
        AlarmName=ThisAlarmName2,
        ComparisonOperator=ThisOperator,
        EvaluationPeriods=ThisEvalPeriod,
        DatapointsToAlarm=ThisDataPoints,
        Threshold=ThisPercent,
        ActionsEnabled=True,
        OKActions=[
            setSNSHelpDesk
        ],
        AlarmActions=AAAction,
        AlarmDescription='Alarm when server Drive is runnong low on available storage',
                    
        TreatMissingData=ThisData,
        Metrics=[
            {
                'Id': "m1",
                'ReturnData': True,
                'AccountId': ThisAccount,
                'MetricStat': {
                    'Metric': {
                    'Namespace': 'CWAgent',
                    'MetricName': 'LogicalDisk % Free Space',
                    'Dimensions': [
                        {
                            'Name': 'InstanceId',
                            'Value': ThisInstanceID
                        },
                        {
                            'Name': 'ImageId',
                            'Value': ThisAMI
                        },
                        {
                            'Name': 'InstanceType',
                            'Value': ThisInstanceType
                        },
                        {
                            'Name': 'instance',
                            'Value': ThisDrive
                        },
                        {
                            'Name': 'objectname',
                            'Value': 'LogicalDisk'
                        },
                    ]
                },
                'Period': ThisPeriod,
                'Stat': 'Average'
            },
            }
        ],
        Tags=[
            {
                'Key': 'AccountNumber',
                'Value': ThisAccount
            }
            ]
    )

def create_win_process_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory,features,ThisData,ThisResponseType,ThisPartition,ec2Action):
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = str(ThisProfile) + ":" + str(ThisProcess) # set value for alarmResponse dimension - should match agent config
    ThisAlarmName2 = ThisAlarmName + '-' + ThisProcess
    
    #cloudwatch = boto3.client('cloudwatch', region_name=ThisRegion)
    print(__name__, 'Alarmname: {} Region: {}'.format(ThisAlarmName2,ThisRegion)) # for testing

    cloudwatch.put_metric_alarm(
        AlarmName=ThisAlarmName2,
        ComparisonOperator=ThisOperator,
        EvaluationPeriods=ThisEvalPeriod,
        DatapointsToAlarm=ThisDataPoints,
        Threshold=ThisThreshold,
        ActionsEnabled=True,
        OKActions=[
            setSNSHelpDesk
        ],
        AlarmActions=AAAction,
        AlarmDescription='Alarm when process is not running',
                
        TreatMissingData=ThisData,
        Metrics=[
            {
                'Id': "m1",
                'ReturnData': True,
                'AccountId': ThisAccount,
                'MetricStat': {
                    'Metric': {
                    'Namespace': 'CWAgent',
                    'MetricName': 'procstat_lookup pid_count',
                    'Dimensions': [
                        {
                            'Name': 'exe',
                            'Value': ThisProcess
                        },
                        {
                            'Name': 'pid_finder',
                            'Value': 'native'
                        },
                        {
                            'Name': 'InstanceId',
                            'Value': ThisInstanceID
                        },
                        {
                            'Name': 'ImageId',
                            'Value': ThisAMI
                        },
                        {
                            'Name': 'InstanceType',
                            'Value': ThisInstanceType
                        },
                    ]
                },
                'Period': ThisPeriod,
                'Stat': 'Average'
            },
            }
        ],
        Tags=[
            {
                'Key': 'AccountNumber',
                'Value': ThisAccount
            }
        ]
    )
def create_linux_drive_alarm(firstboot,cloudwatch, cw2, fstype,ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisPath, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount, OISeverity,OICategory, features,ThisData,history,ThisResponseType,ThisPartition,ec2Action,ThisMetric,ThisDevice):
    # Create Linux disk volume alarm
    ## Set Device Name
    global UpdateList
    create = 0
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = str(ThisProfile) + ":" + ThisMetric + ":" + str(ThisThreshold) # set value for alarmResponse dimension - should match agent config
    if ThisDevice == '':
        try:
            ThisDeviceName = get_device_name(cw2, ThisInstanceID, ThisPath)
            print('---- this device name: {} | path: {}'.format(ThisDeviceName,ThisPath))
        except ClientError as error:
            print(__name__, ' error getting device name.', error)

    else:
        ThisDeviceName = ThisDevice
    if ThisDeviceName != 'none':
        if ThisPath== '/':
            lpath = 'Root'
        elif ThisPath == '/opt':
            lpath = 'Opt'
        elif ThisPath == '/var':
            lpath = 'Var'       
        elif ThisPath == '/var/log':
            lpath = "VarLog"
        else:
            lpath = ThisPath.replace('/', '')
        if history > 0 and firstboot == 'no': # there is metric history so check for recent history before creating volume
            timecheck = 3
            ThisPlatform = 'Linux'
            print(__name__, 'check', ThisPlatform, 'disk_used_percent', ThisInstanceID, ThisAMI, ThisInstanceType, ThisPath, ThisDeviceName) ## used for testing
            lastStat = check_disk_metric_history(cloudwatch,fstype,ThisPlatform, 'disk_used_percent', ThisInstanceID, ThisAMI, ThisInstanceType, ThisPath, ThisDeviceName, timecheck)
            dataPoints = len(lastStat['MetricDataResults'][0]['Timestamps'])
            print(__name__, 'drive metrics: ', dataPoints)
            """
            if dataPoints == 0: # no recent metric data so volume likely no longer exists
                create = 0
                return
            else: # create metric
                create = 1
            """
            create = 1
        elif history == -1: # override and create alarm
            create = 1
        if ThisMetric.find("used") > 1:
            typename = 'used'
        elif ThisMetric.find("inodes") > 1:
            typename = 'inodes'
        ThisAlarmName2 = ThisAlarmName + '-' + typename + '-' + lpath + '-' + str(ThisThreshold)
        print(__name__,'check dimension vars: ThisPath: {} | ThisDeviceName: {} ThisInstanceID: {} | ThisAMI: {} | ThisInstanceType: {}'.format(ThisPath,ThisDeviceName,ThisInstanceID,ThisAMI,ThisInstanceType))
        if create == 1:
            cloudwatch.put_metric_alarm(
                AlarmName=ThisAlarmName2,
                ComparisonOperator=ThisOperator,
                EvaluationPeriods=ThisEvalPeriod,
                DatapointsToAlarm=ThisDataPoints,
                Threshold=ThisThreshold,
                ActionsEnabled=True,
                OKActions=[
                    setSNSHelpDesk
                ],
                    AlarmActions=AAAction,
                    AlarmDescription='Alarm when server volume exceeds threshold',
                                
                    TreatMissingData=ThisData,
                Metrics=[
                    {
                        'Id': "m1",
                        'ReturnData': True,
                        'AccountId': ThisAccount,
                        'MetricStat': {
                            'Metric': {
                            'Namespace': 'CWAgent',
                            'MetricName': ThisMetric,
                            'Dimensions': [
                                {
                                    'Name': 'path',
                                    'Value': ThisPath
                                },
                                    {
                                    'Name': 'device',
                                        'Value': ThisDeviceName
                                },
                                {
                                    'Name': 'fstype',
                                    'Value': fstype
                                },
                                {
                                    'Name': 'InstanceId',
                                    'Value': ThisInstanceID
                                },
                                {
                                    'Name': 'ImageId',
                                    'Value': ThisAMI
                                },
                                {
                                    'Name': 'InstanceType',
                                    'Value': ThisInstanceType
                                },
                            ]
                        },
                        'Period': ThisPeriod,
                        'Stat': 'Average'
                    },
                    }
                ],
                Tags=[
                        {
                            'Key': 'AccountNumber',
                            'Value': ThisAccount
                        }
                    ]
                )
def create_linux_drive_io_alarm(cloudwatch, ThisPath, ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory,features,ThisData,ThisResponseType,ThisPartition,ec2Action,ThisMetric):
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = str(ThisProfile) + ":" + ThisMetric + ":" + str(ThisThreshold) # set value for alarmResponse dimension - should match agent config

    typename = 'diskio'
    ThisAlarmName2 = ThisAlarmName + '-' + typename + '-' + ThisPath + '-' + ThisProcess
    print(__name__, 'Alarmname: ', ThisAlarmName2) # for testing

    cloudwatch.put_metric_alarm(
        AlarmName=ThisAlarmName2,
        ComparisonOperator=ThisOperator,
        EvaluationPeriods=ThisEvalPeriod,
        DatapointsToAlarm=ThisDataPoints,
        Threshold=ThisThreshold,
        ActionsEnabled=True,
        OKActions=[
            setSNSHelpDesk
        ],
        AlarmActions=AAAction,
        AlarmDescription='Alarm when process is not running',
                
        TreatMissingData=ThisData,
        Metrics=[
            {
                'Id': "m1",
                'ReturnData': True,
                'AccountId': ThisAccount,
                'MetricStat': {
                    'Metric': {
                    'Namespace': 'CWAgent',
                    'MetricName': ThisMetric,
                    'Dimensions': [
                        {
                            'Name': 'name',
                            'Value': ThisPath
                        },
                        {
                            'Name': 'InstanceId',
                            'Value': ThisInstanceID
                        },
                        {
                            'Name': 'ImageId',
                            'Value': ThisAMI
                        },
                        {
                            'Name': 'InstanceType',
                            'Value': ThisInstanceType
                        },
                    ]
                },
                'Period': ThisPeriod,
                'Stat': 'Average'
            },
            }
        ],
        Tags=[
            {
                'Key': 'AccountNumber',
                'Value': ThisAccount
            }
        ]
    )
def create_linux_mem_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory,features,ThisData,history, ThisResponseType,ThisPartition,ec2Action,ThisARN):
    # Create Linux memory utilization alarm
    create = 0
    tresult = {}
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = ThisProfile + ":" + 'mem_used_percent' + ':' + str(ThisThreshold)  # set value for alarmResponse dimension - should match agent config
    if history == -2: # check metric history
        print(__name__, 'check', 'Linux', 'mem_used_percent', ThisInstanceID, ThisAMI, ThisInstanceType) ## used for testing
        timecheck = 3
        lastStat = check_metric_history('Linux',ThisInstanceID, ThisAMI, ThisInstanceType, timecheck, ThisARN,ThisRegion)
        dataPoints = len(lastStat['MetricDataResults'][0]['Timestamps'])
        print(__name__, 'mem metrics: ', dataPoints)
        if dataPoints == 0: # no recent metric data so volume likely no longer exists
            tresult['firsttime'] = 'yes'
        else:
            tresult['firsttime'] = 'no'
    ThisAlarmName2 = ThisAlarmName + '-MEM' + str(ThisThreshold)
    print(__name__, 'Alarmname: ', ThisAlarmName2) # for testing

    try:
        cloudwatch.put_metric_alarm(
            AlarmName=ThisAlarmName2,
            ComparisonOperator=ThisOperator,
            EvaluationPeriods=ThisEvalPeriod,
            DatapointsToAlarm=ThisDataPoints,
            Threshold=ThisThreshold,
            ActionsEnabled=True,
            OKActions=[
                setSNSHelpDesk
            ],
            AlarmActions=AAAction,
            AlarmDescription='Alarm when RAM exceeds threhold',
                    
            TreatMissingData=ThisData,
            Metrics=[
                {
                    'Id': "m1",
                    'ReturnData': True,
                    'AccountId': ThisAccount,
                    'MetricStat': {
                        'Metric': {
                        'Namespace': 'CWAgent',
                        'MetricName': 'mem_used_percent',
                        'Dimensions': [
                            {
                                'Name': 'InstanceId',
                                'Value': ThisInstanceID
                            },
                            {
                                'Name': 'ImageId',
                                'Value': ThisAMI
                            },
                            {
                                'Name': 'InstanceType',
                                'Value': ThisInstanceType
                            },
                        ]
                    },
                    'Period': ThisPeriod,
                    'Stat': 'Average'
                },
                }
            ],
            Tags=[
                {
                    'Key': 'AccountNumber',
                    'Value': ThisAccount
                }
            ]
        )
    except Exception as e:
        print(__name__,' error creating linux memory alarm: {}'.format(e))
        pass
    return tresult
def create_linux_swap_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory, features,ThisData,ThisResponseType,ThisPartition,ec2Action):
    # Create Linux swap utilization alarm
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = ThisProfile + ":" + 'swap_used_percent' + ":" + str(ThisThreshold) # set value for alarmResponse dimension - should match agent config
    ThisAlarmName2 = ThisAlarmName + '-Swap'  + str(ThisThreshold)
    print(__name__, 'Alarmname: ', ThisAlarmName2) # for testing

    cloudwatch.put_metric_alarm(
        AlarmName=ThisAlarmName2,
        ComparisonOperator=ThisOperator,
        EvaluationPeriods=ThisEvalPeriod,
        DatapointsToAlarm=ThisDataPoints,
        Threshold=ThisThreshold,
        ActionsEnabled=True,
        OKActions=[
            setSNSHelpDesk
        ],
        AlarmActions=AAAction,
        AlarmDescription='Alarm when swap exceeds threhold',
                
        TreatMissingData=ThisData,
        Metrics=[
            {
                'Id': "m1",
                'ReturnData': True,
                'AccountId': ThisAccount,
                'MetricStat': {
                    'Metric': {
                    'Namespace': 'CWAgent',
                    'MetricName': 'swap_used_percent',
                    'Dimensions': [
                        {
                            'Name': 'InstanceId',
                            'Value': ThisInstanceID
                        },
                        {
                            'Name': 'ImageId',
                            'Value': ThisAMI
                        },
                        {
                            'Name': 'InstanceType',
                            'Value': ThisInstanceType
                        },
                    ]
                },
                'Period': ThisPeriod,
                'Stat': 'Average'
            },
            }
        ],
        Tags=[
            {
                'Key': 'AccountNumber',
                'Value': ThisAccount
            }
        ]
    )
def create_linux_process_alarm(cloudwatch3, ThisAlarmId,ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory,features,ThisData,ThisResponseType,ThisPartition,ec2Action):
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = ThisProfile + ":" + ThisProcess # set value for alarmResponse dimension - should match agent config
    ThisAlarmName2 = ThisAlarmName + '-' + ThisProcess
    #print(__name__, "responsetype:",ThisResponseType, " value:",ThisValue) # for testing
    cloudwatch = boto3.client('cloudwatch', region_name=ThisRegion)
    print(__name__, ' not using passthru connection. Alarmname: {} Region: {} | alarm actions: {} | sns: {}'.format(ThisAlarmName2,ThisRegion,AAAction, setSNSHelpDesk)) # for testing
    Dimensions = [
                            {
                                'Name': 'pattern',
                                'Value': ThisProcess
                            },
                            {
                                'Name': 'pid_finder',
                                'Value': 'native'
                            },
                            {
                                'Name': 'InstanceId',
                                'Value': ThisInstanceID
                            },
                            {
                                'Name': 'ImageId',
                                'Value': ThisAMI
                            },
                            {
                                'Name': 'InstanceType',
                                'Value': ThisInstanceType
                            },
                        ]
    if ThisResponseType in setAlarmActions:
        alarmid = {'Name':'AlarmId', 'Value': ThisAlarmId}
        Dimensions.append(alarmid)
    print(__name__,' final dimensions: {}'.format(Dimensions))
    try:
        cloudwatch.put_metric_alarm(
            AlarmName=ThisAlarmName + '-' + ThisProcess,
            ComparisonOperator=ThisOperator,
            EvaluationPeriods=ThisEvalPeriod,
            DatapointsToAlarm=ThisDataPoints,
            Threshold=ThisThreshold,
            ActionsEnabled=True,
            OKActions=[
                setSNSHelpDesk
            ],
            AlarmActions=AAAction,
            AlarmDescription='Alarm when process is not running',
                    
            TreatMissingData=ThisData,
            Metrics= [
                {
                    'Id': 'm1',
                    'ReturnData': True,
                    'AccountId': ThisAccount,
                    'MetricStat': {
                        'Metric': {
                        'Namespace': 'CWAgent',
                        'MetricName': 'procstat_lookup_pid_count',
                        'Dimensions': Dimensions
                    },
                    'Period': ThisPeriod,
                    'Stat': 'Average'
                },
                }
            ],
            Tags=[
                {
                    'Key': 'AccountNumber',
                    'Value': ThisAccount
                }
            ]
        )
    except Exception as e:
        print(__name__,' error creating linux process alarm: {}'.format(e))
        pass
    return
def create_ec2_instance_alarm(cloudwatch, ThisPath, ThisRegion, setSNSHelpDesk, ThisAlarmName, ThisInstanceID, ThisAMI, ThisInstanceType, ThisProcess, ThisAccount, setSNSGeneral,  ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod, setCentralAccount,OISeverity,OICategory,features,ThisData,ThisResponseType,ThisPartition,ec2Action,ThisMetric,ThisProcessName):
    """_summary_

    Args:
        cloudwatch (_type_): _description_
        ThisPath (_type_): _description_
        ThisRegion (_type_): _description_
        setSNSHelpDesk (_type_): _description_
        ThisAlarmName (_type_): _description_
        ThisInstanceID (_type_): _description_
        ThisAMI (_type_): _description_
        ThisInstanceType (_type_): _description_
        ThisProcess (_type_): _description_
        ThisAccount (_type_): _description_
        setSNSGeneral (_type_): _description_
        ThisEvalPeriod (_type_): _description_
        ThisDataPoints (_type_): _description_
        ThisThreshold (_type_): _description_
        ThisOperator (_type_): _description_
        ThisPeriod (_type_): _description_
        setCentralAccount (_type_): _description_
        OISeverity (_type_): _description_
        OICategory (_type_): _description_
        features (_type_): _description_
        ThisData (_type_): _description_
        ThisProfile (_type_): _description_
        ThisResponseType (_type_): _description_
        alarmResponse (_type_): _description_
        ThisPartition (_type_): _description_
        ec2Action (_type_): _description_
        ThisMetric (_type_): _description_
        ThisProcessName (_type_): _description_
    """    
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    #ThisValue = str(ThisProfile) + ":" + str(ThisProcess) # set value for alarmResponse dimension - should match agent config
    #print(__name__, "responsetype:",ThisResponseType, " value:",ThisValue) # for testing
    if ThisMetric.find("Idle") > 1:
        typename = 'idle'
    elif ThisMetric.find("Interrupt") > 1:
        typename = 'interrupt'
    elif ThisMetric.find("User") > 1:
        typename = 'user'
    else:
        typename = str(ThisPath).strip(' ')
    ThisAlarmName2 = ThisAlarmName + '-' + ThisProcessName + '-' + typename + '-' + ThisProcess
    print(__name__, 'Alarmname: {} | ThisPath: {} | ThisProcessName: {} | ThisInstanceID: {} | ImageId: {} | InstanceType: {}'.format( ThisAlarmName2, ThisPath, ThisProcessName,ThisInstanceID,ThisAMI,ThisInstanceType)) # for testing

    cloudwatch.put_metric_alarm(
        AlarmName=ThisAlarmName2,
        ComparisonOperator=ThisOperator,
        EvaluationPeriods=ThisEvalPeriod,
        DatapointsToAlarm=ThisDataPoints,
        Threshold=ThisThreshold,
        ActionsEnabled=True,
        OKActions=[
            setSNSHelpDesk
        ],
        AlarmActions=AAAction,
        AlarmDescription='Alarm when process is not running',
                
        TreatMissingData=ThisData,
        Metrics=[
            {
                'Id': "m1",
                'ReturnData': True,
                'AccountId': ThisAccount,
                'MetricStat': {
                    'Metric': {
                    'Namespace': 'CWAgent',
                    'MetricName': ThisMetric,
                    'Dimensions': [
                        {
                        'Name': 'instance',
                        'Value': ThisPath
                        },
                        {
                            'Name': 'objectname',
                            'Value': ThisProcessName
                        },
                        {
                            'Name': 'InstanceId',
                            'Value': ThisInstanceID
                        },
                        {
                            'Name': 'ImageId',
                            'Value': ThisAMI
                        },
                        {
                            'Name': 'InstanceType',
                            'Value': ThisInstanceType
                        }
                    ]
                },
                'Period': ThisPeriod,
                'Stat': 'Average'
            },
            }
        ],
        Tags=[
            {
                'Key': 'AccountNumber',
                'Value': ThisAccount
            }
        ]
    )
def get_device_name(cloudwatch, ThisInstanceID, ThisPath):  
    """get os-level storage device names for use as dimensions in alarm creation

    Args:
        cloudwatch (conn): CloudWatch service connection connection
        ThisInstanceID (String): target instance to get storage device name
        ThisPath (String): storage path to get device name for

    Returns:
        String: os-level device name
    """    
    ThisDeviceName = '' 
    #global MissingVolumes
    #global UpdateList

    # List metrics through the pagination interface
    paginator = cloudwatch.get_paginator('list_metrics')
    #if MissingVolumes:
    #    print(__name__, ' We have missing volumes already')
    #else:
    #    MissingVolumes = ''
    try:
        for response in paginator.paginate(
            MetricName='disk_used_percent',
            Namespace='CWAgent',
            Dimensions=[
            {'Name': 'InstanceId', 'Value': ThisInstanceID},
                {'Name': 'path', 'Value': ThisPath},
                {'Name': 'device'}
            ],):
            ### Something here
            #print(__name__, 'inside response:', response['Metrics'][0])
            print()
    except IndexError as error:
        print(__name__, 'Disk Volume not found error', error)
        pass
    #finally:
        #print(__name__, 'Response Metrics raw', response['Metrics'])
        #print(__name__, 'length of response[Metrics]:', len(response['Metrics']))
    
    if len(response['Metrics']) < 1 :
        print(__name__, 'Identified missing volume info and returning. If this instance is new, it may not have sent device metrics yet.')
        ThisDeviceName = 'none'
        if len(response['Metrics']) > 0:
            print(__name__, 'found multiple devices with this path:', len(response['Metrics']), 'Path:', ThisPath)
        #MissingVolumes = MissingVolumes + 'Instance:' + ThisInstanceID + ' Path:' + ThisPath + '\n' ## this feature stopped working after dynamodb implementation
        #if len(UpdateList) > 7:
        #    UpdateList = UpdateList + ',' + ThisInstanceID
        #else:
        #    UpdateList = UpdateList + ThisInstanceID
        return ThisDeviceName
    else:
        try:
            for r in response['Metrics']:
                #print(__name__, 'Name', len(r['MetricName']))
                #print(__name__, 'Dimensions', r['Dimensions'])
                if len(r['Dimensions']) == 0:
                    #print(__name__, 'length:', len(response['Metrics']))
                    print()
                else:
                    #print(__name__, 'length', len(r['Dimensions']))
                    print()
                    try:
                        for j in range(5):
                            #print(r['Dimensions'][j]['Name'], r['Dimensions'][j]['Value'])
                            if r['Dimensions'][j]['Name'] == 'device':
                                print(__name__, 'Path:',ThisPath, 'Device', r['Dimensions'][j]['Value'])
                                ThisDeviceName = r['Dimensions'][j]['Value']
                                break
                    except IndexError as error:
                        print(__name__, 'Error querying for volume-1:',ThisPath, 'Error:', error)
                        pass
                    break
                        
        except IndexError as error:
            print(__name__, 'Error querying for volume-2:',ThisPath, 'Error:', error)
            return error
    
    print(__name__, ' device name:', ThisDeviceName)
    return ThisDeviceName
def get_pagefile_device(cloudwatch, ThisInstanceID, ThisPath):
    """get os-level storage device names for use as dimensions in alarm creation

    Args:
        cloudwatch (conn): CloudWatch service connection connection
        ThisInstanceID (String): target instance to get storage device name
        ThisPath (String): storage path to get device name for

    Returns:
        String: os-level device name
    """  
    ThisDeviceName = '' 
    UpdateList = ''
    #global MissingVolumes
    #global UpdateList
    # List metrics through the pagination interface
    paginator = cloudwatch.get_paginator('list_metrics')
    
    try:
        for response in paginator.paginate(
            MetricName='Paging File % Usage',
            Namespace='CWAgent',
            Dimensions=[
            {'Name': 'InstanceId', 'Value': ThisInstanceID},
                {'Name': 'instance', 'Value': ThisPath},
                {'Name': 'objectname', 'Value': 'Paging File'}
            ],):
            ### Something here
            print(__name__, 'inside response:', response['Metrics'][0])
            print()
    except IndexError as error:
        print(__name__, 'No ' + ThisPath + ' Page File error', error)
        pass
    #finally:
        #print(__name__, 'Response Metrics raw', response['Metrics'])
        #print(__name__, 'length of response[Metrics]:', len(response['Metrics']))
    
    if len(response['Metrics']) < 1 :
        #print(__name__, 'Identified missing volume info and returning')
        #ThisDeviceName = 'none'
        #print(__name__, 'found multiple devices with this path:', len(response['Metrics']), 'Path:', ThisPath)
        #MissingVolumes = MissingVolumes + 'Instance:' + ThisInstanceID + ' Pagefile:' + ThisPath + '\n'
        
        #if len(UpdateList) > 7:
        #    UpdateList = UpdateList + ',' + ThisInstanceID
        #else:
        #    UpdateList = UpdateList + ThisInstanceID
        ThisDeviceName = '\??\C:\pagefile.sys'
        return ThisDeviceName
    else:
        ThisDeviceName = ThisPath
    return ThisDeviceName
def create_custom_metric_alarm(cloudwatch, ThisRegion, setSNSHelpDesk, BaseAlarmName, ThisInstanceID, ThisAccount, setSNSGeneral, ThisEvalPeriod, ThisDataPoints, ThisThreshold, ThisOperator, ThisPeriod,setCentralRegion,setCentralAccount,ThisMetricName,OISeverity,OICategory, features,ThisData,ThisResponseType,alarmResponse,ThisPartition,ec2Action):
    """_summary_

    Args:
        cloudwatch (_type_): _description_
        ThisRegion (_type_): _description_
        setSNSHelpDesk (_type_): _description_
        BaseAlarmName (_type_): _description_
        ThisInstanceID (_type_): _description_
        ThisAccount (_type_): _description_
        setSNSGeneral (_type_): _description_
        ThisEvalPeriod (_type_): _description_
        ThisDataPoints (_type_): _description_
        ThisThreshold (_type_): _description_
        ThisOperator (_type_): _description_
        ThisPeriod (_type_): _description_
        setCentralRegion (_type_): _description_
        setCentralAccount (_type_): _description_
        ThisMetricName (_type_): _description_
        OISeverity (_type_): _description_
        OICategory (_type_): _description_
        features (_type_): _description_
        ThisData (_type_): _description_
        ThisResponseType (_type_): _description_
        alarmResponse (_type_): _description_
        ThisPartition (_type_): _description_
        ec2Action (_type_): _description_
    """    
    # Create stuatus check alarm
    AAAction = get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition,setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType)
    ThisAlarmName2 = BaseAlarmName + '-' +ThisMetricName
    print(__name__, ' custom_metric_alarm Alarmname: ', ThisAlarmName2) # for testing
    if ThisResponseType != '':
        cloudwatch.put_metric_alarm(
            AlarmName=ThisAlarmName2,
            ComparisonOperator=ThisOperator,
            EvaluationPeriods=ThisEvalPeriod,
            DatapointsToAlarm=ThisDataPoints,
            Threshold=ThisThreshold,
            ActionsEnabled=True,
            OKActions=[
                setSNSHelpDesk
            ],
            AlarmActions=AAAction,
            AlarmDescription='Alarm when custom metric exceeds threhold',

            TreatMissingData=ThisData,
            Metrics=[
                {
                    'Id': "m1",
                    'ReturnData': True,
                    'AccountId': ThisAccount,
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'Custom',
                            'MetricName': ThisMetricName,
                            'Dimensions': [
                                {
                                    'Name': alarmResponse,
                                    'Value': ThisValue
                                },
                                {
                                    'Name': 'Instance',
                                    'Value': ThisInstanceID
                                },

                            ]
                        },
                        'Period': ThisPeriod,
                        'Stat': 'Average'
                    },
                }
            ],
            Tags=[
                {
                    'Key': 'AccountNumber',
                    'Value': ThisAccount
                }
            ]
        )
    else:
        cloudwatch.put_metric_alarm(
            AlarmName=ThisAlarmName2,
            ComparisonOperator=ThisOperator,
            EvaluationPeriods=ThisEvalPeriod,
            DatapointsToAlarm=ThisDataPoints,
            Threshold=ThisThreshold,
            ActionsEnabled=True,
            OKActions=[
                setSNSHelpDesk
            ],
            AlarmActions=AAAction,
            AlarmDescription='Alarm when custom metric exceeds threhold',

            TreatMissingData=ThisData,
            Metrics=[
                {
                    'Id': "m1",
                    'ReturnData': True,
                    'AccountId': ThisAccount,
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'Custom',
                            'MetricName': ThisMetricName,
                            'Dimensions': [
                                {
                                    'Name': 'Instance',
                                    'Value': ThisInstanceID
                                },

                            ]
                        },
                        'Period': ThisPeriod,
                        'Stat': 'Average'
                    },
                }
            ],
            Tags=[
                {
                    'Key': 'AccountNumber',
                    'Value': ThisAccount
                }
            ]
        )
def get_cloudwatch_connection(ThisARN,ThisRegion): # 
    """create cross account CloudWatch connection

    Args:
        ThisARN (_type_): ARN for cross account role
        ThisRegion (_type_): AWS region to create connection

    Returns:
        connection: cross account CloudWatch connection
    """    
    sts_client = boto3.client('sts')
    print(__name__,'ThisARN: {}'.format(ThisARN))
    try:
        crossCreds = sts_client.assume_role(RoleArn = ThisARN,RoleSessionName='assume_role_session')
        #crossCreds = assume_role(ThisARN, ThisRegion)
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not assume CrossAccount role', error)
        return error
    try:
        cloudwatch2 = boto3.client('cloudwatch', region_name=ThisRegion, 
                                  aws_access_key_id=crossCreds['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=crossCreds['Credentials']['SecretAccessKey'],
                                  aws_session_token=crossCreds['Credentials']['SessionToken']
                                  )
        
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create cloudwatch2 cross acount client on trusting account', error)
        return error
    return cloudwatch2
def check_metric_history( ThisPlatform, ThisInstanceId, ThisImageId, ThisInstanceType, timecheck, ThisARN,ThisRegion):
    """_summary_

    Args:
        Account (_type_): _description_
        ThisMetric (_type_): _description_
        ThisPlatform (_type_): _description_
        ThisInstanceId (_type_): _description_
        ThisImageId (_type_): _description_
        ThisInstanceType (_type_): _description_
        timecheck (_type_): _description_
        iamCrossAccount (_type_): _description_
        ThisARN (_type_): _description_
        ThisPartition (_type_): _description_
        ThisRegion (_type_): _description_

    Returns:
        _type_: _description_
    """    
    now = datetime.datetime.now()
    then = now - datetime.timedelta(days=timecheck)
    #cloudwatch2 = get_cloudwatch_connection(Account, iamCrossAccount,ThisPartition)
    cloudwatch2 = get_cloudwatch_connection(ThisARN, ThisRegion)
    if ThisPlatform == 'Linux':
        response = cloudwatch2.get_metric_data(
            MetricDataQueries =[
                {
                    'Id': 'm1',
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'CWAgent',
                            'MetricName': 'mem_used_percent',
                            'Dimensions': [
                                {
                                    'Name': 'InstanceId',
                                    'Value': ThisInstanceId
                                },
                                {
                                    'Name': 'ImageId',
                                    'Value': ThisImageId
                                },
                                {
                                    'Name': 'InstanceType',
                                    'Value': ThisInstanceType
                                }
                            ]
                        },
                        'Period': 300,
                        'Stat': 'Average',
                        'Unit': 'Percent'
                    },
                    'ReturnData': True
                },
            ],
            StartTime = then,
            EndTime = now
        )
    else: # Windows memory Metric
        print(__name__, 'windows')
        response = cloudwatch2.get_metric_data(
            MetricDataQueries =[
                {
                    'Id': 'm1',
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'CWAgent',
                            'MetricName': 'Memory % Committed Bytes In Use',
                            'Dimensions': [
                                {
                                    'Name': 'InstanceId',
                                    'Value': ThisInstanceId
                                },
                                {
                                    'Name': 'ImageId',
                                    'Value': ThisImageId
                                },
                                {
                                    'Name': 'InstanceType',
                                    'Value': ThisInstanceType
                                },
                                {
                                    'Name': 'objectname',
                                    'Value': 'Memory'
                                }
                            ]

                        },
                        'Period': 300,
                        'Stat': 'Average'
                    },

                },
            ],
            StartTime = then,
            EndTime = now
        )
    #print(__name__, 'metric history:', len(response['MetricDataResults'][0]['Timestamps']), ThisInstanceId, ThisImageId, ThisInstanceType, now, then)
    #sys.exit()
    return response
def check_onprem_metric_history(ThisPlatform, ThisInstanceId, ThisHostName, timecheck, ThisARN, ThisRegion):
    """check onprem metric history for alarm monitoring to validate their is history in the last # of days passed in

    Args:
        Account (_type_): _description_
        ThisMetric (_type_): _description_
        ThisPlatform (_type_): _description_
        ThisInstanceId (_type_): _description_
        ThisHostName (_type_): _description_
        timecheck (_type_): _description_
        ThisARN (_type_): _description_
        ThisRegion (_type_): _description_

    Returns:
        _type_: _description_
    """    
    now = datetime.datetime.now()
    then = now - datetime.timedelta(days=timecheck)
    #cloudwatch2 = get_cloudwatch_connection(Account, iamCrossAccount,ThisPartition)
    cloudwatch2 = get_cloudwatch_connection(ThisARN,ThisRegion)
    if ThisPlatform == 'Linux':
        response = cloudwatch2.get_metric_data(
            MetricDataQueries =[
                {
                    'Id': 'm1',
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'CWAgent',
                            'MetricName': 'mem_used_percent',
                            'Dimensions': [
                                {
                                    'Name': 'InstanceId',
                                    'Value': ThisInstanceId
                                },
                                {
                                    'Name': 'host',
                                    'Value': ThisHostName
                                }
                            ]
                        },
                        'Period': 300,
                        'Stat': 'Average',
                        'Unit': 'Percent'
                    },
                    'ReturnData': True
                },
            ],
            StartTime = then,
            EndTime = now
        )
    else: # Windows memory Metric
        print(__name__, 'windows')
        response = cloudwatch2.get_metric_data(
            MetricDataQueries =[
                {
                    'Id': 'm1',
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'CWAgent',
                            'MetricName': 'Memory % Committed Bytes In Use',
                            'Dimensions': [
                                {
                                    'Name': 'InstanceId',
                                    'Value': ThisInstanceId
                                },
                                {
                                    'Name': 'host',
                                    'Value': ThisHostName
                                },
                                {
                                    'Name': 'objectname',
                                    'Value': 'Memory'
                                }
                            ]

                        },
                        'Period': 300,
                        'Stat': 'Average'
                    },

                },
            ],
            StartTime = then,
            EndTime = now
        )
    #print(__name__, 'metric history:', len(response['MetricDataResults'][0]['Timestamps']), ThisInstanceId, ThisImageId, ThisInstanceType, now, then)
    #sys.exit()
    return response

def get_service_metrics(cw,ThisInstanceId,namespace,):
    """query CloudWatch for recent metrics

    Args:
        cw (Conn): CloudWatch service connection
        Account (_type_): _description_
        ThisInstanceId (_type_): _description_
        ThisPlatform (_type_): _description_

    Returns:
        _type_: _description_
    """
    servicename = ''
    if namespace == 'AWS/DynamoDB' :
        servicename = 'TableName'
    elif namespace == 'CWAgent':
        servicename = 'InstanceId'
    elif namespace == 'AWS/RDS':
        servicename = 'DBInstanceIdentifier'

    try:
        response = cw.list_metrics(
            Namespace = namespace,
            Dimensions = [{'Name': servicename, 'Value': ThisInstanceId}]
        )
    except ClientError as error:
        print(__name__, 'error getting metric list.', error)
    #print(__name__, 'metrics:', response)
    return response

def check_disk_metric_history(cloudwatch2,fstype,ThisPlatform, ThisMetricName, ThisInstanceId, ThisImageId, ThisInstanceType, ThisVolume, ThisDeviceName, timecheck):
    """check disk metric history for alarm monitoring disk to validate their is history in the last # of days passed in

    Args:
        cloudwatch2 (_type_): _description_
        ThisPlatform (_type_): _description_
        ThisMetricName (_type_): _description_
        ThisInstanceId (_type_): _description_
        ThisImageId (_type_): _description_
        ThisInstanceType (_type_): _description_
        ThisVolume (_type_): _description_
        ThisDeviceName (_type_): _description_
        timecheck (_type_): _description_

    Returns:
        _type_: _description_
    """    
    print(__name__,'--- checking disk metric history metric: {} | path: {} | fstype: {} | device: {}'.format(ThisMetricName,ThisVolume,fstype,ThisDeviceName))
    now = datetime.datetime.now()
    then = now - datetime.timedelta(days=timecheck)
    if ThisPlatform == 'Linux':
        response = cloudwatch2.get_metric_data(
            MetricDataQueries =[
                {
                    'Id': 'm1',
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'CWAgent',
                            'MetricName': ThisMetricName,
                            'Dimensions': [
                                {
                                    'Name': 'path',
                                    'Value': ThisVolume
                                },
                                {
                                    'Name': 'InstanceId',
                                    'Value': ThisInstanceId
                                },
                                {
                                    'Name': 'ImageId',
                                    'Value': ThisImageId
                                },
                                {
                                    'Name': 'InstanceType',
                                    'Value': ThisInstanceType
                                },
                                {
                                    'Name': 'fstype',
                                    'Value': fstype
                                },
                                {
                                    'Name': 'device',
                                    'Value': ThisDeviceName
                                }
                            ]

                        },
                        'Period': 300,
                        'Stat': 'Average',
                        'Unit': 'Percent'
                    },
                    'ReturnData': True
                },
            ],
            StartTime = then,
            EndTime = now
        )
    else: # Windows Disk volume Metric
        print(__name__, 'windows')
        response = cloudwatch2.get_metric_data(
            MetricDataQueries =[
                {
                    'Id': 'm1',
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'CWAgent',
                            'MetricName': ThisMetricName,
                            'Dimensions': [
                                {
                                    'Name': 'InstanceId',
                                    'Value': ThisInstanceId
                                },
                                {
                                    'Name': 'ImageId',
                                    'Value': ThisImageId
                                },
                                {
                                    'Name': 'InstanceType',
                                    'Value': ThisInstanceType
                                },
                                {
                                    'Name': 'instance',
                                    'Value': ThisVolume
                                },
                                {
                                    'Name': 'objectname',
                                    'Value': 'LogicalDisk'
                                }
                            ]

                        },
                        'Period': 300,
                        'Stat': 'Average'
                    },

                },
            ],
            StartTime = then,
            EndTime = now
        )
    return response
def get_alarm_actions(setSNSGeneral,setSNSHelpDesk,features,ec2Action, ThisPartition, setCentralAccount,OISeverity,OICategory,ThisRegion,ThisResponseType):
    """Analyzes parameters passed to alarm creator and returns a valid list of alarm actions to add to alarm being created.

    Args:
        setSNSGeneral (_type_): _description_
        setSNSHelpDesk (_type_): _description_
        features (_type_): _description_
        ec2Action (_type_): _description_
        ThisPartition (_type_): _description_
        ThisRegion (_type_): _description_
        setCentralAccount (_type_): _description_
        OISeverity (_type_): _description_
        OICategory (_type_): _description_

    Returns:
        AAAction string list: comma separated list of alarm actions
    """
    """
    if ThisRegion.find('west') > -1:
        setSNSHelpDesk = setSNSHelpDesk.replace('east', 'west')
        setSNSGeneral = setSNSGeneral.replace('east', 'west')
        #ec2Action = ec2Action.replace('east', 'west')
    """
    if setSNSGeneral != '':
        if ec2Action != '':
            AAAction = [setSNSHelpDesk, setSNSGeneral, ec2Action]
        else:
            AAAction = [setSNSHelpDesk, setSNSGeneral]
    else:
        if ec2Action != '':
            AAAction = [setSNSHelpDesk, ec2Action]
        else:
            AAAction = [setSNSHelpDesk]
    if features == "Yes": # is opsitems enabled?
        WarningOpsAlert = 'arn:'+ ThisPartition +':ssm:' + ThisRegion + ':' + setCentralAccount + ':opsitem:'+str(OISeverity)+'#CATEGORY='+OICategory
        WarningOpsAlert = 'arn:'+ ThisPartition +':ssm:' + ThisRegion + ':' + setCentralAccount + ':opsitem:'+str(OISeverity)+'#CATEGORY='+OICategory
        if setSNSGeneral != '':
            if ec2Action != '':
                AAAction = [setSNSHelpDesk, WarningOpsAlert,setSNSGeneral,ec2Action]
            else:
                AAAction = [setSNSHelpDesk, WarningOpsAlert,setSNSGeneral]
        else:
            if ec2Action != '':
                AAAction = [setSNSHelpDesk, WarningOpsAlert,ec2Action]
            else:
                AAAction = [setSNSHelpDesk, WarningOpsAlert]
    
    if ThisResponseType != '':
        centralSNS = 'arn:' + setPartition + ':sns:' + ThisRegion + ':' + setCentralAccount + ':' + setTopics['PlatformAutomation']
        AAAction.append(centralSNS)

    return AAAction

### Used by SQS Processor
def update_cwagent_configuration(ThisMessage):
    """dynamically create CW Agent configuration JSON from CloudWatch profile and push it to parameter for target AWS account and region

    Args:
        table (_type_): DynamoDB connection
        Tenant (_type_): HCOM Tenant that owns this profile
        Account (_type_): AWS Account within Tenant
        Region (_type_): AWS Region for CW Profile
        resourcetype (_type_): _description_
        ProfileId (_type_): Unique CloudWatch Profile ID
        namespace (_type_): CloudWatch metric namespace, standard is CWAgent and Custom for all custom metrics
        profiletype (_type_): Profile type is specific to the type of profile. Ex. CloudWatch has: EC2 Linux, OnPrem Linux, EC2 Windows, OnPrem Windows
    """
    Account = ThisMessage.get('Account')
    region = ThisMessage.get('Region')
    ProfileId = ThisMessage.get('Profile')
    profiletype = ThisMessage.get('ProfileType')
    BaseARN = setIAM.get("Cross-Account")
    ThisARN = BaseARN.replace('tenantaccount', Account)
    ThisARN = ThisARN.replace("partition", setPartition)
    table = boto3.resource('dynamodb', region_name=setCentralRegion).Table(setDBcon)
    
    ### get alarms for profile
    alarms = table.get_item(Key={'msptype': 'cw-profile', 'mspname': str(ProfileId)})
    alarmdef1 = alarms['Item']['alarms']
    #regions = alarms['Item']['Region']
    alarmdef = dict(sorted(alarmdef1.items()))
    #metriccategories = hcom.setCWResourceTypes['resourcetypes'][resourcetype]['namespace'][namespace][profiletype]
    #print(__name__,'--- metric categories: {}'.format(metriccategories))
    #categories = {'Default': [], 'cpu': [], 'mem': [],'disk': [],'diskio': [],'swap': [],'procstat': [],'LogicalDisk': [],'PhysicalDisk': [],'Memory': [], 'Paging File': [],'Processor': [],'net': [],'Network Interface': []}
    categories = {}
    procstat = []
    isprocstat = 0
    setup = 0

    ## set JSON start
    if profiletype in ['EC2 Linux','EC2 Windows'] and setup == 0: # set starting JSON config for EC2 types
        instancetype = 'EC2'
        setup = 1
        if profiletype == 'EC2 Linux':
            ostype = 'Linux'
            configtemplate = {"agent": {"metrics_collection_interval": 60,"run_as_user": "root"},"metrics":{"append_dimensions": {
            "AutoScalingGroupName": "${aws:AutoScalingGroupName}","ImageId": "${aws:ImageId}","InstanceId": "${aws:InstanceId}","InstanceType": "${aws:InstanceType}"},
            "metrics_collected": {}}}
        else:
            ostype = 'Win'
            configtemplate = {"metrics":{"append_dimensions": {
            "AutoScalingGroupName": "${aws:AutoScalingGroupName}","ImageId": "${aws:ImageId}","InstanceId": "${aws:InstanceId}","InstanceType": "${aws:InstanceType}"},
            "metrics_collected": {}}}
    elif setup == 0: # set onprem/hybrid config
        instancetype = 'OnPrem'
        if profiletype == 'OnPrem Linux':
            ostype = 'Linux'
        else:
            ostype = 'Win'
        configtemplate = {"agent": {"metrics_collection_interval": 60,"run_as_user": "root"},"metrics":{"metrics_collected": {}}}
        setup = 1

    for key, value in alarmdef.items(): # loop through alarm definitions and populate metric categories used
        if value.get('metriccategory') == 'Default': # default metrics don't require CW Agent and thus do not belong in CW agent configuration file
            continue # skip to next

        ### loop through and add metric JSON
        #if value.get('metriccategory') == 'procstat': # if monitoring a process
        print(__name__,' curent response setting: {} | {} | {} | {}'.format(value.get('metriccategory'),value.get('metricname'),value.get('name'),value.get('ResponseName')))

        if value.get('metriccategory') == 'procstat': # if monitoring a process
            if isprocstat == 0:
                print(__name__,' set metriccategory List, metric:{}'.format(value.get('name')) )
                configtemplate['metrics']['metrics_collected'][value.get('metriccategory')] = []
                isprocstat = 1
            if ostype == 'Linux':
                pattern = 'pattern'
            else: # windows
                pattern = 'exe'
            thisprocstat = {"append_dimensions": {"InstanceId": "${aws:InstanceId}" },"measurement": ["pid_count"], "metrics_collection_interval": 60, pattern: value.get('name')}
            if value.get('ResponseType'): # if alarm has a response defined add dimension
                thisprocstat['append_dimensions']['AlarmId'] = key

            print(__name__,'current template before appending: {}'.format(configtemplate))
            configtemplate['metrics']['metrics_collected'][value.get('metriccategory')].append(thisprocstat)
        else: # not monitoring a process
            if instancetype == 'EC2':
                #if value.get('metriccategory') == 'disk' and profiletype == 'EC2 Linux':
                #    thisprocstat = {"measurement": ['used_percent'], "metrics_collection_interval": 60}
                #else:
                thisprocstat = {"measurement": [value.get('metricname')], "metrics_collection_interval": 60}
                
            else:
                thisprocstat = {"append_dimensions": {"InstanceId": "${aws:InstanceId}"},"measurement": [value.get('metricname')], "metrics_collection_interval": 60}
                if value.get('metriccategory') == 'cpu': thisprocstat['totalcpu'] = 'true'
                
            #### add additional portions based on category
            if value.get('metriccategory') in ['disk', 'LogicalDisk','Paging File', 'cpu', 'diskio', 'Processor','PhysicalDisk']: thisprocstat['resources'] = ["*"]
            if value.get('metriccategory') in configtemplate['metrics']['metrics_collected']: # does this section already exist
                if value.get('metricname') not in configtemplate['metrics']['metrics_collected'][value.get('metriccategory')]['measurement']: # metric is not already in list
                    #if value.get('metricname') != 'disk_used_percent': # don't add for this as the measurement is used_percent and already set
                    configtemplate['metrics']['metrics_collected'][value.get('metriccategory')]['measurement'].append(value.get('metricname'))
                else: # skip to next metric
                    continue
            else:
                configtemplate['metrics']['metrics_collected'][value.get('metriccategory')] = thisprocstat

        print(__name__,'finished this metric: {} | template: {}'.format(value.get('metricname'),configtemplate))

    paramname = 'CloudWatch-Profile-'+ str(ProfileId)
    finaltemplate = str(configtemplate).replace("'", '"')
    finaltemplate = json.dumps(json.loads(finaltemplate), indent=4)
    finaltemplate = str(finaltemplate).replace('"true"', 'true')
    
    #print(finaltemplate)
    #for region in regions:
    # can not loop through regions because aws requires parameters to be written from api call within same region. no cross region api is supported
    print(__name__,'show me the template: {}'.format(finaltemplate))
    try:
        print(__name__,'-- updating config {} in region: {} | ThisARN: {}'.format(paramname,region, ThisARN))
        response = assume_role(ThisARN, region)
        ssm = boto3.client('ssm',aws_access_key_id=response['Credentials']['AccessKeyId'],aws_secret_access_key=response['Credentials']['SecretAccessKey'],aws_session_token=response['Credentials']['SessionToken'])
        #print(__name__,' update response: {}'.format(response['HTTPStatusCode']))
        response2 = ssm.put_parameter(Name=paramname, Value = str(finaltemplate), Description=profiletype, Type = 'String', Overwrite=True)
        print(__name__,' update param update response: {}'.format(response2))
        
    except ClientError as error:
        print(__name__, 'Could not create connection. {}'.format(error))
        response3 = error
        #ssm.close()

    #print(__name__,' final configuration: {} | procstat: {}'.format(configtemplate,procstat))
    return response2

### Used by SQS Processor
def delete_cwagent_configuration(ThisMessage):
    """Delete CloudWatch Agent Configuration in SSM Parameter Store in all targeted AWS regions and Accounts

    Args:
        ThisMessage (dict): target AWS account, region and cloudwatch profile number passed in
    """    
    Account = ThisMessage.get('Account')
    region = ThisMessage.get('Region')
    ProfileId = ThisMessage.get('Profile')
    
    BaseARN = setIAM.get("Cross-Account")
    ThisARN = BaseARN.replace('tenantaccount', Account)
    ThisARN = ThisARN.replace("partition", setPartition)
    print(__name__,'deleting cwagent conf parameter: {}'.format(ThisMessage))
    try:
        response = assume_role(ThisARN, region)
        ssm = boto3.client('ssm',aws_access_key_id=response['Credentials']['AccessKeyId'],aws_secret_access_key=response['Credentials']['SecretAccessKey'],aws_session_token=response['Credentials']['SessionToken'])
    except ClientError as error:
        print(__name__, 'Could not create SSM connection. {}'.format(error))
        response = error
    paramname = 'CloudWatch-Profile-'+ str(ProfileId)
    print(__name__,'-- deleting CW configuration from parameter store {}'.format(paramname))
    try:
        ssm.delete_parameter(Name=paramname)
    except Exception as e:
        print(__name__,'There was an error deleting the paramater. It may not have been there or other issue.')
        pass
    return
#-- Functions used to manage alarms & Metrics --#

### Used by: HCOM-Control-CW-Alarms, HCOM-CloudWatch-Alarm-Lifecycle-Automation.py
def disable_alarms(cloudwatch, response): 
    """pass a list of alarms to disable alarm actions

    Args:
        cloudwatch (_type_): Cloudwatch connection
        response (_type_): list of alarm names

    Returns:
        _type_: _description_
    """    
    try:
        #names = [['alarm[AlarmName'] for alarm in response['MetricAlarms']]
        #print(__name__, 'Names', names)
        disable_response = cloudwatch.disable_alarm_actions(AlarmNames=response)
        return disable_response

    except ClientError as error:
        print(__name__, 'Unexpected error occurred trying to disable alarm actions.', error)
        return error

### Used by: HCOM-CloudWatch-Custom-Metrics.py
def publish_metric(ssm1, ThisInstanceID, ThisCommand): 
    """use SSM agent to run powershell script on managed instance to send custom CloudWatch metric

    Args:
        ssm1 (conn): Systems Manager connection
        ThisInstanceID (String): target instance to run script
        ThisCommand (_type_): 

    Returns:
        _type_: _description_
    """    
    # may also try AWS-RunPowerShellScript for windows and AWS-RunShellScript for Linux
    print(__name__, 'function instance', ThisInstanceID)
    try:
        cwresponse = ssm1.send_command(
            InstanceIds=[ThisInstanceID],
            DocumentName='AWS-RunPowerShellScript',
            DocumentVersion='$LATEST',
            Parameters={'commands': [ThisCommand]},
        )
        print(__name__, 'raw response:', cwresponse)
        
    except ClientError as error:
        print(__name__, 'Run Command to Push Config file ran into an error.', error)

        return error

### Used by: HCOM-Control-CW-Alarms, HCOM-CloudWatch-Alarm-Lifecycle-Automation.py
def get_alarms(cloudwatch, ThisSearch):
    """Find all the alarms with the provided alarm name prefix

    Args:
        cloudwatch (conn): CW connection
        ThisSearch (string): alarm name prefix

    Returns:
        list: return list of alarm names
    """    
    try:
        response = cloudwatch.describe_alarms(
            AlarmNamePrefix = ThisSearch,
            MaxRecords = 100
        )
        #print(__name__, 'Response:', response)
        names = [alarm['AlarmName'] for alarm in response['MetricAlarms']]
        #print(__name__, 'queried for alarms', names)
        return names

    except ClientError as error:
        print(__name__, 'Disable alarms into an error', error)
        return error

### Used by: HCOM-Control-CW-Alarms, HCOM-CloudWatch-Alarm-Lifecycle-Automation.py
def enable_alarms(cloudwatch, response):
    """Enable CloudWatch alarm actions

    Args:
        cloudwatch (conn): CloudWatch API connection
        response (_type_): list of CloudWatch alarm names to re-enable alarm actions

    Returns:
        _type_: _description_
    """    
    try:
        #names = [['alarm[AlarmName'] for alarm in response['MetricAlarms']]
        #print(__name__, 'Names', names)
        enable_response = cloudwatch.enable_alarm_actions(AlarmNames=response)
        return enable_response
    except ClientError as error:
        print(__name__, 'Unexpected error occurred trying to enable alarm actions.', error)
        return error

### Used by: HCOM-Control-CW-Alarms
def change_alarm_state(cloudwatch, alarm, stateValue):
    """Change CloudWatch alarm state - this is only temporary as it switches back to actual state and used for testing HCOM automations

    Args:
        cloudwatch (conn): CW connection
        alarm (String): CW Alarm name to change the alarm state
        stateValue (String): pass a predefined value from form. Sets alarm state to this value

    Returns:
        _type_: _description_
    """    
    try:
        response = cloudwatch.set_alarm_state(
        AlarmName=alarm,
        StateValue=stateValue,
        StateReason='HCOM-CW-automation'
        )
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not change alarm state', error)
        return error

### Used by: HCOM-Control-CW-Alarms, HCOM-CloudWatch-Alarm-Lifecycle-Automation.py        
def delete_alarms(cloudwatch, response):
    """Bulk Delete Alarms for a specific Instance

    Args:
        cloudwatch (Conn): connection
        response (List): List of Alarms from previous query for specific instance base alarm name

    Returns:
        _type_: _description_
    """    
    try:
        print(__name__, '---- Deleting Alarms ----\n', response)
        delete_response = cloudwatch.delete_alarms(AlarmNames=response)
        return delete_response
    except ClientError as error:
        print(__name__, 'Unexpected error occurred trying to disable alarm actions.', error)
        return error

### HCOM-Backup-Audit, HCOM-CloudWatch-Alarm-Creator, cw.py
def get_rds_client_connection(ThisRegion, ThisARN): # standard sts connection
    """_summary_

    Args:
        Account (_type_): _description_
        ThisRegion (_type_): _description_
        ThisARN (_type_): _description_

    Returns:
        _type_: _description_
    """    
    #################### Start: create client connections ##############################
    ## Assume cross account role
    #print(__name__,': assume role info for ec2 resource:', ThisARN, ThisRegion)
    crossCreds = assume_role(ThisARN, ThisRegion)
    try:
        ec3 = boto3.client('rds', 
                                  region_name=ThisRegion,
                                  aws_access_key_id=crossCreds['Credentials']['AccessKeyId'],
                                  aws_secret_access_key=crossCreds['Credentials']['SecretAccessKey'],
                                  aws_session_token=crossCreds['Credentials']['SessionToken']
                                  )
        
    except ClientError as error:
        print(__name__,': Unexpected error occurred... could not create DynamoDB cross acount client on trusting account. ', error)
        return error
    return ec3

    """_summary_

    Args:
        metricname (_type_): _description_
        config (_type_): _description_

    Returns:
        _type_: _description_
    """    
    ssm0 = boto3.client('ssm')
    theseTenants = []
    #config = setCWConfigurations.get('CustomMetricsConfiguration')
    ####### Start: Get CWAgent Configuration ###############
    configuration = ssm0.get_parameter(Name=config)
    ThisConfig = configuration['Parameter']['Value']
    split_config = ThisConfig.split(';')
    #print(__name__, 'param count:',len(split_config), range(len(split_config)), ThisConfig) # used for testing
    rows = len(split_config) - 1 # skip eof row
    for i in range(rows):
        thisListItem = split_config[i].split('|')
        varName = thisListItem[0].strip()
        varValue = thisListItem[1].strip()
        #print(__name__, 'varName:', varName)
        if varName == metricname:
            tenants = ast.literal_eval(varValue)
            #print(__name__, 'tenants-pre:', tenants)
            theseTenants = list(tenants.get('Tenants').split(','))
            #print(__name__, 'configuration1['Items'][j]:', theseTenants, len(theseTenants))
            return theseTenants
        else:
            return None

#-- Functions to manage SSM Agent --#

### Used by: HCOM-CloudWatch-Alarm-Lifecycle-Automation.py 
def update_ssm_agent(ssm1, ThisInstanceID, ssmAgent):
    """Invoke Run Doc to update the SSM Agent

    Args:
        ssm1 (_type_): ssm connection
        ThisInstanceID (_type_): id of instance that is target to update SSM agent
        ssmAgent (_type_): sets the target version to update
    """    
    try:
        cwresponse = ssm1.send_command(
            InstanceIds=[ThisInstanceID],
            DocumentName="AWS-UpdateSSMAgent",
            Parameters={'version': [ssmAgent]},
        )
        cmdId = cwresponse['Command']['CommandId']
    except Exception as e:
        print(e)

#### Begin state 

# This file contains systems manager state functions. Filename: state.py Used by all SSM State Mananager automations.
# v.17 Last modified on 6/16/2023 Author tom.moore@gdit.com

#-- initialize SSM State Manager Features and Functions --#
global setStateTags, setStateConfigurations
#@lru_cache(maxsize=None)
def state_initializer():
    """Initializes SSM State Manager configuration settings to leverage shared code/module

    Args:
        config (String): Passes the name of the parameter for the SSM State Manager configuration settings
    """    
    #ssm0 = boto3.client('ssm')
    dbcon = boto3.client('dynamodb', region_name=setCentralRegion)
    print(__name__, 'initializing State configuration: {}'.format(setDBTable))
    global setStateTags, setStateConfigurations
    ####### Start: Get CWAgent Configuration ###############
    try:
        configuration1 = dbcon.query(
            TableName=setDBTable,
            Select='ALL_ATTRIBUTES',
            ConsistentRead=True, 
            ExpressionAttributeValues={':cores':{'S': 'state'}},
            KeyConditionExpression='msptype = :cores')
        print(__name__,' state initilazation query results: {}'.format(configuration1))
        for j in range(configuration1['Count']): # loop through configuration items
            #print(configuration1['Items'][j]['msptype']['S'], varName = configuration1['Items'][j]['mspname']['S'], configuration1['Items'][j]['mspvalue']['M'])
            varName = varName = configuration1['Items'][j]['mspname']['S']
            print(__name__,'config: {}'.format(varName))
            if varName == 'tags': ## have not replaced yet
                setStateTags = {} 
                setStateTags['profile'] = configuration1['Items'][j]['profile']['S'] 
            elif varName == 'configurations':
                setStateConfigurations = {}
                setStateConfigurations['PlaybooksURL'] = configuration1['Items'][j]['PlaybooksURL']['S']
                setStateConfigurations['AuditReportPath'] = configuration1['Items'][j]['AuditReportPath']['S']
                setStateConfigurations['StateReport'] = configuration1['Items'][j]['StateReport']['S']
            
    except ClientError as e:
        print(__name__,'error initializing state: {} '.format(e))
        return
    print(__name__,'finished initializing state: {} | tags: {} | config: {}'.format(configuration1['Count'],setStateTags,setStateConfigurations))
    return

@lru_cache(maxsize=None)
def is_valid_state(Tenant,Account,Profile):
    """Given Tenant, Account and State Profile, validate that the profile belongs to Tenant Account

    Args:
        Tenant (_type_): Tenant name
        Account (_type_): AWS account number
        Profile (_type_): state profile number

    Returns:
        bool: does this state profile belong to this tenant/account? True or False
    """
    table = boto3.resource('dynamodb', region_name=setCentralRegion).Table(setDBcon)
    try:
        #table = dbcon.Table(configTable)
        response = table.get_item(Key={'msptype': 'state-profile', 'mspname': Profile},)
        print(__name__, 'results', response)
        if response['Item']['Account'] == Account:
            return True
        else:
            return False

    except ClientError as error:
        print(error)
        pass

### Used by: HCOM-CloudWatch-Lifecycle-Automation
def run_state(ThisInstanceID, ThisRegion, account, tenant):
    """Invoke Run Document for STIG and State mgmt at boot-time

    Args:
        ssm0 (_type_): SSM connection
        ec3 (_type_): EC2 connection
        ThisInstanceID (_type_): target Instance Id 
        ThisRegion (_type_): AWS Region target instance is in
        StateConfig (_type_): _description_
        PlaybookURL (_type_): URL to playbook file to use for state in S3

    Returns:
        _type_: _description_
    """
    ec3 = get_ec2_resource_connection(account, ThisRegion, setIAM.get("Cross-Account"))
    ssm0 = get_ssm_connection(account, ThisRegion, setIAM.get("Cross-Account"))
    print(__name__,'--- Begin Running State configurations')
    dbcon = boto3.client('dynamodb')
    alarmResponseDetails = {} # set return variable to dictionary
    ResponseExecutionRole = '' # set execution role to null in case its not a Run Document
    ResponseParameter = '' # set parameters to null in case there are no parameters
    ##### Start: Get Alarm Definition from Parameter Store ########################################
    ##### Get State Manager Tag to find out which profile this instance uses
    if ThisInstanceID != '' and ThisInstanceID.find("mi-") > -1:
        onprem = 'yes'
    else:
        onprem = 'no'
    print(__name__, 'incoming params:',ThisInstanceID)
    profilenum = '' # reset before checking and assigning state profile
    if onprem == 'no':
        try:
            ec2instance = ec3.Instance(ThisInstanceID)
            profilenum = ''
            print(__name__, 'results:', ec2instance)
            if ec2instance != '':
                for tags in ec2instance.tags:
                    if tags["Key"] == 'State-Profile': #setStateTags['profile']: # get the assigned State profile
                        profilenum = tags["Value"]
        except ClientError as error:
            print(__name__, 'Unexpected error occurred... could not create EC2 cross account query', error)
            return error
        print(__name__, 'raw response:', ec2instance)
    else: # OnPrem instance
        tags = ssm0.list_tags_for_resource(ResourceType='ManagedInstance',ResourceId=ThisInstanceID)
        print(__name__, 'tags', tags)
        for tag in tags['TagList']:
            print(__name__, 'tag',tag)
            if tag['Key'] == 'State-Profile': #setStateTags.get['profile']:
                profilenum = tag['Value'] 
    isvalidstate = is_valid_state(tenant,account,profilenum) # check if profile is valid for target account
    if profilenum != '' and isvalidstate == True:
        skip = 0
        #### Get State Manager Profiles
        try:
            profiletype = 'state-profile'
            #configstate = get_profile(configTable, profiletype, profilenum) deprecated since changing profile to support multiple configurations
            configstates = get_state_profile_configs(profiletype,profilenum,tenant,account,ThisRegion,True)
            print(__name__, '--- found: {} configstates{}'.format(len(configstates),configstates))
            if len(configstates) > 0: # we found a profile
                for config in configstates:
                    parameters = ast.literal_eval(config['parameters'])
                    staterunbook = config['Type']
                    response = invoke_rundoc(ThisInstanceID, staterunbook, parameters, ThisRegion,account)
                    print(__name__,' results for SSM RunDoc: {} | {}'.format(staterunbook, response))
                    alarmResponseDetails[staterunbook] = response


        except ClientError as error:
            print(__name__, 'Error trying to invoke state assocations', error)
            return error
    else:
        if profilenum != '':
            print(__name__,'*** The target profile {} is not valid for account {} so skipping it.'.format(profilenum, account))
        else:
            print(__name__,'*** This instance {} has no State Profile tag.'.format(ThisInstanceID))
        alarmResponseDetails['results'] = ''
    return alarmResponseDetails

### Used by CloudWatch-Dashboard-Widget
def get_association_name(num, ConfigId, ThisType, doc, Tenant, Account,TargetType,TargetName, TargetValue):
    """Creates a named to be used when creating a SSM state association based on the defined state profile configuration.

    Args:
        num (_type_): _description_
        ConfigId (_type_): _description_
        ThisType (_type_): _description_
        doc (_type_): _description_
        Tenant (_type_): _description_
        Account (_type_): _description_
        TargetType (_type_): _description_
        TargetName (_type_): _description_
        TargetValue (_type_): _description_

    Returns:
        string: retur name to be used when creating a state association for state profile configuration
    """    
    print(__name__, 'Create Assocation Name, ThisType:', ThisType, 'num:', num, 'Tenant:',Tenant,'Account:', Account,'doc:', doc, 'TargetType:', TargetType,'TargetName:', TargetName, 'TargetValue:',TargetValue)
    assoc_name = ''
    ThisType = ThisType.replace('s','S')
    ThisType = ThisType.replace('p','P')
    try:
        if TargetType == 'tag:':
            assoc_name = "HCOM-" + ThisType + '-' + str(num) + '-' + str(ConfigId) + '-' + Tenant + '-' + Account + '-' + doc + '-' + TargetType + '-' + str(TargetName) + '-' + str(TargetValue)
        elif TargetType == 'tag-key' or TargetType == 'InstanceIds':
            assoc_name = "HCOM-" + ThisType + '-' + str(num) + '-' + str(ConfigId) + '-' + Tenant + '-' + Account + '-' + doc + '-' + TargetType + '-' + str(TargetValue)
        elif TargetType == 'resource-groups:':
            assoc_name = "HCOM-" + ThisType + '-' + str(num) + '-' + str(ConfigId) + '-' + Tenant + '-' + Account + '-' + doc + '-' + TargetType + '-' + str(TargetName)
    except ClientError as error:
        if error.find("NoneType") > -1:
            print(__name__, 'One or more of your form values are missing.', error)
    print(__name__, 'Association Name:',assoc_name)
    return assoc_name
    
#@lru_cache(maxsize=None)
def get_profiles(dbcon, profiletype):
    """Queries and returns a list of profiles from DynamoDB based on passed profile type value

    Args:
        dbcon (conn): _description_
        profiletype (string): profile type to query

    Returns:
        list: list of profiles defined within HCOM platform
    """    
    configuration = dbcon.query(
        TableName=setDBcon,
        Select='ALL_ATTRIBUTES',
        ConsistentRead=True, 
        ExpressionAttributeValues={':cores':{'S': profiletype}},
        KeyConditionExpression='msptype = :cores')
    return configuration

### Used by Alarm Creator
#@lru_cache(maxsize=None)
def get_profile(configTable,profiletype, profilenum):
    """Get specific profile based on parameters passed

    Args:
        configTable (string): DynamoDB table name
        profiletype (string): profile typ (ec2, RDS, DynamoDB)
        profilenum (string): profile number

    Returns:
        dict: profile details
    """    
    #dbcon = boto3.resource('dynamodb')
    table = boto3.resource('dynamodb').Table(configTable)
    print(__name__, 'type:', profiletype, 'num:', profilenum)
    try:
        #table = dbcon.Table(configTable)
        response = table.get_item(Key={'msptype': profiletype, 'mspname': profilenum},
            )
        print(__name__, 'results', response)
    except ClientError as error:
        print(error)
    if response['Item']:
        print(__name__, 'found profile')
        return response['Item']
    else:
        print(__name__, 'did not find profile')
    #returnval = response['Items']

def get_change_calendars(Account,Region,arn):
    """query and return list of change calendars based on account and region

    Args:
        Account (_type_): AWS Account Number
        Region (_type_): AWS Region
        arn (_type_): template arn for cross-account queries

    Returns:
        dict: list of change calendar names
    """    
    print(__name__,'--- begin get_change_calendar')
    ssm0 = get_ssm_connection(Account,Region, arn)
    change_list = []
    try:
        response = ssm0.list_documents(DocumentFilterList=[{'key': 'DocumentType', 'value': 'ChangeCalendar'},{'key': 'Owner', 'value': 'Self'}])
        response2 = ssm0.list_documents(DocumentFilterList=[{'key': 'DocumentType', 'value': 'ChangeCalendar'},{'key': 'Owner', 'value': 'Private'}])
        if response['DocumentIdentifiers'] and response2['DocumentIdentifiers']:
            change_list = response['DocumentIdentifiers'] 
            for cal in response2['DocumentIdentifiers']:
                change_list.append(cal)
            print(__name__,' both have results{} | {} | {}'.format(response['DocumentIdentifiers'],response2['DocumentIdentifiers'],change_list))
        elif response['DocumentIdentifiers']:
            change_list = response['DocumentIdentifiers']
            print(__name__,' self has results')
        elif response2['DocumentIdentifiers']:
            change_list = response2['DocumentIdentifiers']
            print(__name__,' private has results')
        else:
            change_list = ''
            print(__name__,' no results')
        print(__name__,'len change_list:{}'.format(len(change_list)))
        if len(change_list) > 0:
            #change_list = response['DocumentIdentifiers']
            print(__name__,'--- Found change calendars: {}'.format(change_list))
        else: 
            change_list = 'exit 1'
    except ClientError as error:
        print(__name__,'There were no calendars. Error:{}'.format(error))
        change_list = ''
        pass
    print(__name__,' results: {}'.format(change_list))
    return change_list

def create_association(ProfileId, ThisType, pprofile2, arn):
    """Formerly add_profile
    Create Assocation within target Tenant Account and region

    Args:
        ThisType (String): Value contains "Patch" or "State" to define which is being created
        pprofile (Dict): All the form variables from web-form
    """    
    print(__name__,'---- begin create assocation --- {}'.format(type(pprofile2.get('Region'))))

    Region = pprofile2.get('Region')
    ChangeCal = []
    if pprofile2.get('ChangeCal') != '': # if not null assign change calendar
        ChangeCal.append(pprofile2.get('ChangeCal'))

    try:
        params = ast.literal_eval(pprofile2.get("parameters"))
        if pprofile2.get("RunDoc") == 'AWS-ApplyAnsiblePlaybooks': # detect and implement workaround for ansible parameter formatting. has nested json that must be string.
            path = 'https://' + pprofile2.get("ansiblebucket") + pprofile2.get("ansiblepath")
            ansiblepath = '{"path": "' + path + '"}'
            params["SourceInfo"] = [ansiblepath]
        print(__name__,'new param value: {}'.format(params))
    except Exception as error:
        print(__name__,'There was an error with the parameters. Please check the format for parameters. Its not currently in valid JSON format. {}'.format(error))
        statusMessage = 'There was an error with the parameters. Please check the format for parameters. Its not currently in valid JSON format. ' + str(error)
        return {'statusCode': 400, 'statusMessage': statusMessage}
    ssm0 = get_ssm_connection(pprofile2.get('Account'),Region, arn)
    
    #table = dbcon.Table('hcom-configuration-test1')
    profile = ThisType + '-' + ProfileId
    ThisMessage = ''

    ##### Create Association
    if pprofile2["TargetKeyType"] == 'tag:': # if using tag/value pair
        ThisKey = pprofile2["TargetKeyType"] + pprofile2["TargetKeyName"]
        ThisValue = [pprofile2.get("TargetKeyValue")]
    elif pprofile2["TargetKeyType"] == 'resource-groups:':
        ThisKey = pprofile2["TargetKeyType"] + 'Name'
        ThisValue = [pprofile2["TargetKeyName"]]
    elif pprofile2["TargetKeyType"] == 'InstanceIds':
        ThisKey = pprofile2["TargetKeyType"]
        ThisValue = [pprofile2.get("TargetKeyValue")]
    elif pprofile2["TargetKeyType"] == 'tag-key':
        ThisKey = pprofile2["TargetKeyType"]
        ThisValue = [pprofile2.get("TargetKeyValue")]
    try:
        if pprofile2.get('ChangeCal') != '':
            response = ssm0.create_association(
                Name=pprofile2.get("RunDoc"),
                #DocumentVersion=pprofile.get("V"),
                ScheduleExpression=pprofile2.get("Schedule"),
                Parameters = params, 
                AssociationName=pprofile2.get("Name"), #pprofile.get("Name"),
                Targets=[{'Key': ThisKey, 'Values': ThisValue}], #[{'Key': 'tag:Cloudwatch-Profile', 'Values': ['1']}],
                MaxErrors='100%',
                MaxConcurrency='100%',
                CalendarNames=ChangeCal,
                ComplianceSeverity=pprofile2.get("Severity"),
                #ApplyOnlyAtCronInterval=setCronInterval,
                        
            )
        else:
            response = ssm0.create_association(
                Name=pprofile2.get("RunDoc"),
                #DocumentVersion=pprofile.get("V"),
                ScheduleExpression=pprofile2.get("Schedule"),
                Parameters = params, 
                AssociationName=pprofile2.get("Name"), #pprofile.get("Name"),
                Targets=[{'Key': ThisKey, 'Values': ThisValue}], #[{'Key': 'tag:Cloudwatch-Profile', 'Values': ['1']}],
                MaxErrors='100%',
                MaxConcurrency='100%',
                ComplianceSeverity=pprofile2.get("Severity"),
                #ApplyOnlyAtCronInterval=setCronInterval,
                        
            )
    except ClientError as error:
        print(__name__, 'Could not create profile and SSM Association.', error)
        statusMessage = 'Failed to create association. Check the parameters values being entered.'
        if str(error).find('InvalidSchedule') > -1:
            statusMessage = 'Failed to create assocation. You provided an invalid schedule. ' + str(error)
        elif str(error).find('InvalidParameters') > -1:
            statusMessage = 'Failed to create assocation. You provided parameters not in proper JSON format or missing required components. ' + str(error)
        return {'statusCode': 400, 'statusMessage': statusMessage }
    #print(__name__, 'var type for response:{}'.format(type(response)))

    responsed = response.get("AssociationDescription")
    AssociationId = responsed.get("AssociationId")
    print(__name__,'--- end create assocation with new id:{}'.format(AssociationId))
    return AssociationId

def delete_assocation(AssociationId,RunDoc,Account,Region, arn):
    """Delete state manager assocation

    Args:
        AssociationId (String): state manager association id for existing association to be deleted
        RunDoc (String): the ssm rundoc for the association
        Account (String): AWS Account number
        Region (String): AWS Region for Account number
        arn (String): ARN for cross account invocation

    Returns:
        dict: response to delete action
    """    
    print(__name__,'--- Begin delete Association ---')
    print(__name__,'check params: id:{} doc:{} Account:{} Region:{} arn:{}'.format(AssociationId,RunDoc,Account,Region, arn))
    try:
        ssm0 = get_ssm_connection(Account,Region, arn)
    
        response = ssm0.delete_association(Name=RunDoc,AssociationId=AssociationId)
    except ClientError as error:
        if str(error).find("AssocationDoesNotExist") > -1:
            print(__name__, 'The target assocation does not exist to delete. It was already deleted.', error)
            response = {'statusCode': 400, 'statusmessage': 'Assocation was already deleted.'}
        else:
            print(__name__, 'Could not delete association.', error)
            response = {'statusCode': 400, 'statusmessage': error }
        pass
        
    return response 


def update_configuration(mytable,pprofile2,AssociationId):
    """Delete state manager association settings stored in DynamoDB

    Args:
        mytable (String): DynamoDB table name
        pprofile2 (dict): all configuration settings for assocation stored in DynamoDB
        AssociationId (String): AWS SSM State Manager assocation ID if exists

    Returns:
        Dict or String: results from update action
    """    
    print(__name__,'----- begin updating configuration -----')
    dbcon = boto3.resource('dynamodb')
    table = dbcon.Table(mytable)
    print(__name__, 'assoc id:', AssociationId)
    #ThisMessage = 'id:' + AssociationId + ' Name: ' + pprofile2.get("Name") + ' - created\n'
    if pprofile2.get("Interval") == 'True':
        thisInterval = True
    else:
        thisInterval = False
    if pprofile2.get("Active") == 'True':
        thisActive = True
    else:
        thisActive = False
    ChangeCal = ''
    if pprofile2.get('ChangeCal') != '': # if not null assign change calendar
        ChangeCal = pprofile2.get('ChangeCal')
    ##### Create Association
    print(__name__,'param check:{}'.format(pprofile2))
    #ThisKey = pprofile2["TargetKeyType"] + pprofile2["TargetKeyName"]
    profile = pprofile2.get("ProfileType") + '-' + pprofile2.get("ProfileId") 
    
    #print(__name__,'formatted param check:{}'.format(str(ThisKey)))
    try:
        if pprofile2.get("RunDoc") != 'AWS-ApplyAnsiblePlaybooks':
            response = table.update_item(Key={'msptype': profile, 'mspname': str(pprofile2.get("ConfigId"))},
                UpdateExpression='SET #id = :id, #int = :int, #name = :name, #tenant = :tenant, #account = :account, #sch = :sch, #type = :type, #v = :v, #tkt = :tkt, #tkn = :tkn,#tkv = :tkv, #region = :region, #sev = :sev, #param = :param, #active = :active, #changecal = :changecal',
                ExpressionAttributeNames={'#id': 'id','#int': 'Interval', '#name': 'Name','#tenant': 'Tenant', '#account': 'Account', '#sch': 'Schedule', '#type': 'Type', '#v': 'V', '#tkt': 'TargetKey', '#tkn': 'TargetKeyName', '#tkv': 'TargetValue', '#region': 'Region', '#sev': 'Severity', '#param': 'parameters', '#active': 'Active','#changecal': 'ChangeCalendar'  },
                ExpressionAttributeValues={':id': AssociationId, ":int": thisInterval, ':name':pprofile2.get("Name"), ':tenant': pprofile2.get("Tenant"), ':account': pprofile2.get("Account"), ':sch': pprofile2.get("Schedule"),':type': pprofile2.get("RunDoc"), ':v': 'DEFAULT', ':tkt': pprofile2.get("TargetKeyType"), ':tkn': pprofile2.get("TargetKeyName"),':tkv': pprofile2.get("TargetKeyValue"),':region': pprofile2.get("Region"), ':sev': pprofile2.get("Severity"), ':param': pprofile2.get("parameters"), ':active': thisActive, ':changecal': ChangeCal})
        else:
            response = table.update_item(Key={'msptype': profile, 'mspname': str(pprofile2.get("ConfigId"))},
                UpdateExpression='SET #id = :id, #int = :int, #name = :name, #tenant = :tenant, #account = :account, #sch = :sch, #type = :type, #v = :v, #tkt = :tkt, #tkn = :tkn,#tkv = :tkv, #region = :region, #sev = :sev, #param = :param, #active = :active, #changecal = :changecal, #ansiblebucket = :ansiblebucket, #ansiblepath = :ansiblepath',
                ExpressionAttributeNames={'#id': 'id','#int': 'Interval', '#name': 'Name','#tenant': 'Tenant', '#account': 'Account', '#sch': 'Schedule', '#type': 'Type', '#v': 'V', '#tkt': 'TargetKey', '#tkn': 'TargetKeyName', '#tkv': 'TargetValue', '#region': 'Region', '#sev': 'Severity', '#param': 'parameters', '#active': 'Active','#changecal': 'ChangeCalendar', '#ansiblepath': 'ansiblepath', '#ansiblebucket': 'ansiblebucket' },
                ExpressionAttributeValues={':id': AssociationId, ":int": thisInterval, ':name':pprofile2.get("Name"), ':tenant': pprofile2.get("Tenant"), ':account': pprofile2.get("Account"), ':sch': pprofile2.get("Schedule"),':type': pprofile2.get("RunDoc"), ':v': 'DEFAULT', ':tkt': pprofile2.get("TargetKeyType"), ':tkn': pprofile2.get("TargetKeyName"),':tkv': pprofile2.get("TargetKeyValue"),':region': pprofile2.get("Region"), ':sev': pprofile2.get("Severity"), ':param': pprofile2.get("parameters"), ':active': thisActive, ':changecal': ChangeCal, ':ansiblebucket': pprofile2.get("ansiblebucket"), ':ansiblepath': pprofile2.get("ansiblepath")})
    except ClientError as error:
        print(__name__, 'Could not update HCOM-State-Associations in Parameter Store.', error)
        response = 'error'
    print(__name__,'----- ending updating configuration ----')
    return response

def get_params(runDoc, runDocs):
    """Passing in dictionary of rundocs with possible parameters and target rundoc, return params for target rundoc

    Args:
        runDoc (String): target rundoc to get parameters
        runDocs (dict): list of rundocs with parameters

    Returns:
        Dict: returns parameters for target rundoc
    """    
    for doc, param in runDocs.items():
        if doc == runDoc:
            return param['parameters']

def delete_profile(thisId, ThisType, profile):
    """Delete state/patch profile and Assocation. These are not previously defined and submitted through web-based 
    SSM Automation Playbook doc  

    Args:
        ThisType (String): Value contains "Patch" or "State" to define which is being added
        pprofile (Dict): All the form variables from SSM Automation Playbook web-form
    """    
    ssm0 = boto3.client('ssm')
    dbcon = boto3.client('dynamodb')
    ThisMessage = ''
    profiletype = ThisType + '-profile'
    ##### delete Association
    try:
        response = ssm0.delete_association(
        AssociationId= str(thisId)
        )
        ThisMessage = ThisMessage + 'id:' + thisId + ' - deleted\n'
    except ClientError as error:
        print(__name__, 'Could not update profile definitions in the Parameter Store.', error)
        if str(error).find('AssociationDoesNotExist') > -1:
            print(__name__, 'Assocition already deleted.', error)
            ThisMessage = ThisMessage + 'id:' + thisId + ' - already deleted\n'
        pass
        
    #print(__name__, 'response', response)
    print(__name__, 'assoc id:', thisId)
    
    #TargetRow = varName # set which profile needs to be updated
    #myupdate = myupdate + 'last modified by SSM Automation Playbook'
    ##### Create profile for Association
    try:
        response2 = dbcon.delete_item(
            TableName=setDBcon,
            Key={'msptype': {'S': profiletype}, 'mspname': {'S': profile}}
        )
        #response2 = ssm0.put_parameter(Name=ThisType,Value=str(myupdate), Overwrite=True)
        print(__name__, 'profile ' + profile + ' deleted')
    except ClientError as error:
        print(__name__, 'Could not delete profile ' + profile + ' definition', error)

## deprecated - confirm once state manager lambda is not needed
def manage_state_associations(ssm0,varName, pprofile, ThisPartition, notdef):
    """
    DEPRECATED: For Each row in either State Profile or Patch Profile definition, either update or create.

    Args:
        ssm0 (connection): Systems Manager Connection
        varName (String): Profile number
        pprofile (Dict): Current Row of data thats already in the file
        ThisPartition (_type_): _description_
        notdef (_type_): Is this row in the file or not. Not = notdef = True

    Returns:
        String: _Message to include in report
    """    
    TheseTargetValues = []
    TheseAccounts = []
    TheseRegions = []
    TheseParameters = {}
    TheseTargets = []
    ssm = boto3.client('ssm')
    stateReport = ''
    #print(__name__, 'params:',pprofile.get("parameters"))
    #TheseParameters = ast.literal_eval(pprofile.get("parameters"))
    TheseParameters = pprofile.get("parameters")
    #targetPlaybook = state.setConfigurations.get("PlaybooksURL") + TheseParameters.get("stateurl")
    
    # check/set TargetValue
    rows = len(pprofile.get("TargetValue").split(','))
    print(__name__, 'TargetValue rows:',len(pprofile.get("TargetValue").split(',')))
    if rows > 1: #more than one value
         for i in range(rows):
            TheseTargetValues.append(i)
    else:
        TheseTargetValues.append(pprofile.get("TargetValue"))
     # check/set Accounts
    print(pprofile.get("Accounts"),'rows:',len(pprofile.get("Accounts").split(',')))
    if pprofile.get("Accounts") != 'all' and len(pprofile.get("Accounts").split(',')) > 1: #more than one value
        rows3 = len(pprofile.get("Accounts").split(','))
        for k in range(rows3):
            TheseAccounts.append(k)
    elif pprofile.get("Accounts") == 'all':
        TheseAccounts = core.setTenants
    else:
        TheseAccounts.append(pprofile.get("Accounts"))
    # check/set Regions
    print(__name__, 'regions:',pprofile.get("Regions"))
    if pprofile.get("Regions") != 'all' and len(pprofile.get("Regions").split(',')) > 1: #more than one value
        rows2 = len(pprofile.get("Regions").split(','))
        for j in range(rows2):
            TheseRegions.append(j)
    else:
        TheseRegions.append(pprofile.get("Regions"))   
    #TheseTargets.append('Key=' + pprofile.get("TargetKey"))
    #TheseTargets.append('Values=' + TheseTargetValues[0])
    print(__name__, 'final params', TheseAccounts, TheseRegions, pprofile.get("TargetKey"), TheseTargetValues)
    
    ###### start processing 
    tenants = TheseAccounts
    #tenants = targets.split(',')
    rows = len(tenants)
    for i in TheseAccounts: # loop through Tenants
        tenant  = i # assigne tenant name
        #Account = core.setTenants.get(tenants[i])
        #environments = core.get_environs(environs, tenants[i])
        for rname in TheseRegions: # Loop through each region
            AccountNum = core.name_to_account(i, core.setTenants)
            #ssm = boto3.client('ssm', region_name=ThisRegion)
            try:
                    #print(__name__, 'environment:', len(environments), environments)
                    #sys.exit()
                #if environments != '': # make sure we have environments to loop through
                    #for env in environments: # loop through each environment
                            #env = env.replace(' ', '')
                            #filterAlarms = tenant + '-' + rname + '-'  + env
                results = update_state_assocations(varName, pprofile, AccountNum,notdef)
                            #print(__name__, 'filter:', filterAlarms)
                stateReport = stateReport + str(results)
                print(__name__, 'report:', stateReport)
            except ClientError as error:
                print(__name__, 'Unexpected error occurred... could not parse environments. ', error)
                continue
                pass
    return stateReport
# also deprecated
def update_state_assocations(varName,pprofile,AccountNum,notdef):
    """Update existing association

    Args:
        varName (_type_): profile number
        pprofile (_type_): profile details from DynamoDB
        notdef (_type_): Was this previously defined in profile definition or sent from SSM Automation Form

    Returns:
        String: Results for email message
    """    
    stateReport = ''
    
    ThisARN = core.setIAM.get("Cross-Account") # used to assume role in cross accounts
    ThisARN = ThisARN.replace("tenantaccount", AccountNum)
    ThisSSMConnect = core.get_ssm_connection(AccountNum,pprofile["Region"], core.setIAM.get("Cross-Account"))
    ThisKey = pprofile["TargetKeyType"] + pprofile["TargetKeyName"]
    if pprofile.get("Schedule").find('rate') > -1:
        setCronInterval = None
    else:
        setCronInterval = True
    if pprofile.get("id") != '': # already created, just need to update
         # check association status
        if pprofile.get("Accounts") == 'all':
            print()
        else:
            
            try:
                response = ThisSSMConnect.update_association(
                    AssociationId=pprofile.get("id"),
                    Parameters = pprofile.get("parameters"),
                    #DocumentVersion=pprofile.get("V"),
                    ScheduleExpression=pprofile.get("Schedule"),
                    Name=pprofile.get("Type"),
                    AssociationName=pprofile.get("Name"),
                    Targets = [{'Key': ThisKey, 'Values': [pprofile.get("TargetValue")]}],
                    MaxErrors='100%',
                    MaxConcurrency='100%',
                    ComplianceSeverity=pprofile.get("Severity"),
                    #ApplyOnlyAtCronInterval=setCronInterval,
                    SyncCompliance = 'AUTO',

                )
                stateReport = stateReport + 'Assocation Id: ' + pprofile.get("id") + ' Name: ' + pprofile.get("Name") + ' - updated\n'
                print(__name__, '---- Update ' + pprofile.get("id") + ' Name: ' + pprofile.get("Name") + ' ----\n')
                return stateReport
            except ClientError as error:
                print(__name__, 'Unexpected error occurred creating state association ', pprofile.get("Name"), ' | ',error)
                pass
                if str(error).find("AssociationDoesNotExist") > -1: ### if the assocation no longer exists, recreate it.
                    try:
                        testTarget = []
                        ThisName = get_association_name(varName,Type, pprofile.get("Type"),pprofile.get("Tenant"), pprofile.get("AccountName"),ThisKey,pprofile.get("TargetValue"))
                        ThisName = ThisName.replace(":","-")
                        testTarget.append('Key=tag:Cloudwatch-Profile,Values=1')
                        #testTarget["Targets"] = ['Key=tag:Cloudwatch-Profile,Values=1']
                        response = ThisSSMConnect.create_association(
                            Name=pprofile.get("Type"),
                            #DocumentVersion=pprofile.get("V"),
                            ScheduleExpression=pprofile.get("Schedule"),
                            Parameters = pprofile.get("parameters"), 
                            AssociationName=ThisName,
                            Targets=[{'Key': ThisKey, 'Values': [pprofile.get("TargetValue")]}], #[{'Key': 'tag:Cloudwatch-Profile', 'Values': ['1']}],
                            MaxErrors='100%',
                            MaxConcurrency='100%',
                            ComplianceSeverity=pprofile.get("Severity"),
                            #ApplyOnlyAtCronInterval=setCronInterval,
                            
                        )
                        #stateReport = stateReport + ' Name: ' + pprofile.get("Name") + ' Assocation:'+ ThisName +' - created\n'
                        stateReport = stateReport + 'Assocation Id: ' + pprofile.get("id") + ' Name: ' + pprofile.get("Name") + ' - recreated\n'
                        print(__name__, 'response', response)
                        responsed = response.get("AssociationDescription")
                        AssociationId = responsed.get("AssociationId")
                        print(__name__, 'assoc id:', AssociationId)
                        TargetRow = varName # set which profile needs to be updated
                        ssm1 = boto3.client('ssm')
                        try:
                            response3 = state.update_AssocationId(ssm1, ThisType,TargetRow, AssociationId, ThisName)
                        except ClientError as error:
                            print(__name__, 'Unexpected error occurred adding state association Id', pprofile.get("Name"), ' | ',error)
                            pass
                        return stateReport
                    except ClientError as error:
                        print(__name__, 'Unexpected error occurred creating state association ', pprofile.get("Name"), ' | ',error)
                        pass

def get_next_profile_number(ThisType, num):
    """Query and parse through to determine the next profile number to be used

    Args:
        ThisType (String): Value contains the SSM Parameter name for Patch or State profile definitions

    Returns:
        int: next profile number
    """    
    #ssm0 = boto3.client('ssm')
    dbcon = boto3.client('dynamodb')
    profile = ThisType
    if num != 0:
        profile += '-' + str(num)
    configuration1 = dbcon.query(
        TableName=setDBTable,
        Select='ALL_ATTRIBUTES',
        ConsistentRead=True, 
        ExpressionAttributeValues={':cores':{'S': profile}},
        KeyConditionExpression='msptype = :cores')
    num = 0   
    for j in range(configuration1['Count']): # loop through configuration items
        #print(configuration1['Items'][j]['msptype']['S'], varName = configuration1['Items'][j]['mspname']['S'], configuration1['Items'][j]['mspvalue']['M'])
        varName = varName = configuration1['Items'][j]['mspname']['S']
        #varValue = configuration1['Items'][j]['mspvalue']['S']
        print(__name__, 'value:',varName)
        num = int(varName)
    num = num + 1 # increment by one
    return num

def create_state_profile(ProfileId, ProfileType, Tenant, Account):
    """Create State Profile in DynamoDB. Profiles are initially created as inactive/disabled until fully configured and enabled, then the association gets created.

    Args:
        ThisType (String): Value contains "Patch" or "State" to define which is being added
        pprofile (Dict): All the form variables from SSM Automation Playbook web-form
    """    
    #ssm0 = core.get_ssm_connection(pprofile2.get('Account'),pprofile2.get('Region'), arn)
    dbcon = boto3.client('dynamodb')

    ThisMessage = ''
    ##### Create Association
    #ThisKey = pprofile2["TargetKeyType"] + pprofile2["TargetKeyName"]
    #ThisMessage = ThisMessage + 'id:' + AssociationId + ' Name: ' + pprofile2.get("Name") + ' - created\n'

    ##### Create Profile
    print(__name__,'param check:{}'.format(ProfileId))
    #mspvalue = {"msptype": {"S": profile }, "mspname": {"S": str(nextNum) },"id":{"S":"" },"Name":{"S": pprofile2.get("Name") },"Tenant":{"S": pprofile2.get("Tenant") },"Schedule":{"S":"Rate(Daily)"},"Type":{"S":pprofile2.get("Type")},"V":{"S":"DEFAULT"},"Interval":{"BOOL": True},"Active":{"BOOL": False},"TargetKey":{"S":pprofile2.get("TargetKeyType") + pprofile2.get("TargetKeyName")},"TargetValue":{"S":pprofile2.get("TargetValue")},"Account":{"L":[{"S": pprofile2.get("Account") }]},"Regions":{"L":[{"S": pprofile2.get("Region") }]},"Severity":{"S": "Low" },"parameters":{"S": str(pprofile2.get("parameters"))}}
    mspvalue = {"msptype": {"S": ProfileType }, "mspname": {"S": str(ProfileId) },"Tenant":{"S": Tenant },"Account":{"S": Account }}
    print(__name__,'formatted create profile:{}'.format(str(mspvalue)))
    
    try:
        response = dbcon.put_item(TableName=setDBTable,Item=mspvalue)
        print(__name__,'New Profile Created!')
        """
        try:
            print(__name__,'--- Begin attempt to create configuration ---')
            profile = ThisType + '-' + ProfileId
            #mspvalue = {"msptype": {"S": profile }, "mspname": {"S": str(pprofile2.get("ConfigId")) },"id":{"S":"" },"Interval":{"BOOL":True },"Active":{"BOOL":False },"Name":{"S": pprofile2.get("Name") },"Tenant":{"S": pprofile2.get("Tenant") },"Schedule":{"S":pprofile2.get("Schedule")},"Type":{"S":pprofile2.get("RunDoc")},"V":{"S":"DEFAULT"},"TargetKey":{"S":pprofile2.get("TargetKeyType") + pprofile2.get("TargetKeyName")},"TargetValue":{"S":pprofile2.get("TargetKeyValue")},"Account":{"S": pprofile2.get("Account") },"Region":{"S": pprofile2.get("Region")},"Severity":{"S":pprofile2.get("Severity") },"parameters":{"M": pprofile2.get("parameters")}}
            response2 = create_configuration(ProfileId, ThisType)
            #response2 = dbcon.put_item(TableName=table,Item=mspvalue)
        except ClientError as error:
            print(__name__, 'Could not create Configuration in DynamoDB', error)
            response2 = 'error' 
        """
    except ClientError as error:
        print(__name__, 'Could not create Profile in DynamoDB.', error)
        response = 'error'
    return response

def delete_state_profile(ProfileId, ProfileType, Tenant,Account):
    """
        Given State profile ID, delete all existing State Assocations, configurations and finally the profile

    Args:
        ProfileId (_type_): _description_
        ProfileType (_type_): _description_
        Tenant (_type_): _description_
        Account (_type_): _description_
    """    
    table = boto3.resource('dynamodb', region_name=setCentralRegion).Table(setDBcon)
    region = 'all'
    profilelist = get_state_profile_configs(ProfileType,ProfileId,Tenant,Account,region,'all')
    if len(profilelist) > 0: # we have configs
        for profile in profilelist:
            if profile['Active'] == True: # need to delete assocation
                try:
                    print(__name__,'deleting association: {}'.format(profile['id']))
                    responsea = delete_assocation(profile['id'],profile['Type'],profile['Account'],profile['Region'], setIAM.get('Cross-Account'))
                    try:
                        print(__name__,'deleting configuration: {}'.format(str(profile['mspname'])))
                        responsec = delete_configuration(ProfileId, ProfileType, profile['mspname'])
                    except Exception as e:
                        print(e)
                except Exception as e:
                    print(e)
            else: # go directly to deleting the configuration
                try:
                    print(__name__,'deleting configuration: {}'.format(str(profile['mspname'])))
                    responsec = delete_configuration(ProfileId, ProfileType, profile['mspname'])
                except Exception as e:
                    print(e)
    try: # now delete the profile
        print(__name__,'deleting state profile: {}'.format(str(ProfileId)))
        mspvalue = {'msptype':  ProfileType, 'mspname': ProfileId }
        #responsep = table.delete_item(Key=mspvalue) # removing the final delete so the profile can be reused within tenant
    except Exception as e:
        print(e)
    return

def delete_configuration(ProfileId, ProfileType, ConfigId):
    """Delete configuration in DynamoDB (all the specifications for an assocation stored in the database)

    Args:
        table (String): dynamoDB table name
        ProfileId (String): which state profile number
        ProfileType (String): profile type: state configuration
        ConfigId (_type_): configuration id (unique id for config associated with state/patch profile)
    """    
    table = boto3.resource('dynamodb', region_name=setCentralRegion).Table(setDBcon)
    profile = ProfileType + '-' + ProfileId
    try:
        profile = ProfileType + '-' + ProfileId
        print(__name__,'--- Begin attempt to delete configuration --- {} | {} | {} | {}'.format(profile, ProfileId, ProfileType, ConfigId))
        
        mspvalue = {'msptype':  profile, 'mspname': str(ConfigId) }
        response = table.delete_item(Key=mspvalue)
    except ClientError as error:
        print(__name__, 'Could not delete Configuration in DynamoDB', error)
        response = 'error'
    return response
    
def create_configuration(ProfileId, ThisType, pprofile):
    """Create configuration in DynamoDB (all the specifications for an assocation stored in the database)

    Args:
        table (String): dynamoDB table name
        ProfileId (String): which state profile number
        ThisType (String): is this patch or state configuration
        pprofile (dict): all the assocation and configuration settings
    """    
    dbcon = boto3.client('dynamodb')
    try:
        print(__name__,'--- Begin attempt to create configuration ---')
        profile = ThisType + '-' + ProfileId
        mspvalue = {"msptype": {"S": profile }, "mspname": {"S": str(pprofile.get("ConfigId")) },"id":{"S":"" },"Interval":{"BOOL":True },"Active":{"BOOL":False },"Name":{"S": pprofile.get("Name") },"Tenant":{"S": pprofile.get("Tenant") },"Schedule":{"S":pprofile.get("Schedule")},"Type":{"S":pprofile.get("RunDoc")},"V":{"S":"DEFAULT"},"TargetKey":{"S":pprofile.get("TargetKeyType")}, "TargetKeyName":{"S": pprofile.get("TargetKeyName")},"TargetValue":{"S":pprofile.get("TargetKeyValue")},"Account":{"S": pprofile.get("Account") },"Region":{"S": pprofile.get("Region")},"Severity":{"S":pprofile.get("Severity") },"parameters":{"M": pprofile.get("parameters")}}
        response = dbcon.put_item(TableName=setDBTable,Item=mspvalue)
    except ClientError as error:
        print(__name__, 'Could not create Configuration in DynamoDB', error)
        response = 'error' 

    return response

def get_state_profile_configs(profiletype,profileid,tenant,account,region,active):
    """Get a list of configs/assocations for a specific profile with filters: active and region

    Args:
        table (String): DynamoDB Table
        profiletype (_type_): Is this state or patch profile
        profileid (_type_): Profile number
        tenant (_type_): Tenant name
        account (_type_): AWS Account number
        region (string): AWS region

    Returns:
        dict: list of configs
     """  
    table = boto3.resource('dynamodb', region_name=setCentralRegion).Table(setDBcon)
    profile = profiletype + '-' + str(profileid)
    print(__name__,'finding configs for: {}'.format(profile))
    print(__name__,'pre-query msptype = {} and Tenant = {} and Account = {} and Active = {}'.format(profile,tenant,account,active))
    if active == 'all' and region == 'all':
        configuration = table.query(
            KeyConditionExpression=Key('msptype').eq(profile),
            FilterExpression=Attr('Tenant').eq(tenant) & Attr('Account').contains(account))
        print(__name__,'configs found: {}'.format(configuration['Items']))
    else:
        configuration = table.query(
            KeyConditionExpression=Key('msptype').eq(profile),
            FilterExpression=Attr('Tenant').eq(tenant) & Attr('Account').contains(account) & Attr('Active').eq(active) & Attr('Region').eq(region))
        print(__name__,'configs found: {}'.format(configuration['Items']))
    return configuration['Items']


#### begin backup section
#-- initialize AWS Backup Features and Funttions --#

### Used by: All AWS Backup automations 
def backup_initializer(config):
    """initialize backup feature settings from DynamoDB

    Args:
        config (string): dynamodb table name
    """    
    #ssm0 = boto3.client('ssm')
    dbcon = boto3.client('dynamodb')
    print(__name__, 'initializing Backup configuration')
    global setBKConfigurations, setBKTags

    configuration1 = dbcon.query(
        TableName=config,
        Select='ALL_ATTRIBUTES',
        ConsistentRead=True, 
        ExpressionAttributeValues={':cores':{'S': 'backup'}},
        KeyConditionExpression='msptype = :cores')

    for j in range(configuration1['Count']):

        varName = varName = varName = configuration1['Items'][j]['mspname']['S']
        
        if varName == 'configurations':
            setBKConfigurations = {} 
            setBKConfigurations['Profiles'] = configuration1['Items'][j]['Profiles']['S'] 
            setBKConfigurations['Audit EC2'] = configuration1['Items'][j]['Audit EC2']['S'] 
            setBKConfigurations['Audit EFS'] = configuration1['Items'][j]['Audit EFS']['S'] 
            setBKConfigurations['Audit OnPrem'] = configuration1['Items'][j]['Audit OnPrem']['S']
            setBKConfigurations['Audit DynamoDB'] = configuration1['Items'][j]['Audit DynamoDB']['S']
            setBKConfigurations['Audit RDS'] = configuration1['Items'][j]['Audit RDS']['S']
            setBKConfigurations['AuditReportPath'] = configuration1['Items'][j]['AuditReportPath']['S'] 
            setBKConfigurations['AuditReport'] = configuration1['Items'][j]['AuditReport']['S'] 
            setBKConfigurations['BackupEventsPath'] = configuration1['Items'][j]['BackupEventsPath']['S'] 
            setBKConfigurations['RestoreEventsPath'] = configuration1['Items'][j]['RestoreEventsPath']['S'] 
        elif varName == 'tags':
            setBKTags = {}
            setBKTags["EC2ExemptTag"] = configuration1['Items'][j]['EC2ExemptTag']['S'] 
            setBKTags["EC2ExemptTagValue"] = configuration1['Items'][j]['EC2ExemptTagValue']['S']
    print(__name__,'--- global vars, setBKConfigurations: {} | setBKTags: {}'.format(setBKConfigurations, setBKTags))
    return {'statusCode': 200}