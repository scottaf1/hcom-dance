## Main Shared library code for HCOM
