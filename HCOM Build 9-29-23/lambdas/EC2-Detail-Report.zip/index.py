## This automation creates and audit report of EC2 configurations.  
# v.21 Last modified on 8/30/2023. Developed by tom.moore@gdit.com
import boto3
import ast, datetime, os, sys
import hcom
import json
from botocore.exceptions import ClientError
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

vpcs = {} # store VPC ID and Name
sgs = {} # store security group ID and Name
subnets = {} # store subnet ID and Name

def lambda_handler(event, context):
    auditReport = ''
    detailReport = 'Account, InstanceId, Hostname, Environment,Description, Product,Product-Role,VPC-ID, AZ,SubnetId,IP,SGs,Platform,Type, State, Patch Group,CW Profile, Region\n'
    print(__name__, 'event:', event)
    #event = ast.literal_eval(event)
    if(type(event) != dict):
        print(__name__, 'reformatting')
        event = ast.literal_eval(event)
    ThisRegion = event.get("region", os.environ['AWS_REGION'])
    TargetTenant = event.get("tenants", "")
    sendReport = event.get('report', 'no')
    #ThisRegion = 'us-gov-west-1'
    ThisRegion1 = hcom.get_region_name(ThisRegion)
    EastRegion = 'us-gov-east-1'
    ThisTime =  datetime.datetime.now()
    # Create SNS Client connect
    #Create SNS resource connection 
    sns = boto3.client('sns', region_name=ThisRegion)
    ses = boto3.client('ses', region_name=ThisRegion)
    ##### end create SNS client connection ######
    ssm0 = boto3.client('ssm', region_name=ThisRegion)
    ##### end create SNS client connection ######
    #################### End: create client connections ##############################
    ####### Initialize Configuration #######
    hcom.core_initializer(ThisRegion) # Initilaize platform configuration
    table = boto3.resource('dynamodb', region_name=hcom.setCentralRegion).Table(hcom.setDBcon)
    hcom.cw_initializer(hcom.setDBcon,table)

    ####### End: Get CWAgent Configuration #################

    #sys.exit()
    processevent = 0
    setCrossAccountARN = hcom.setIAM.get("Cross-Account") # used to assume role in cross accounts
    if TargetTenant == '':
        print(__name__,'TargetTenant is none')
        #for key, value in hcom.setTenants.items(): # loop through all tenants pulled from config file
        for thisTenant, accounts in hcom.setTenants.items(): # loop through all tenants pulled from config file
            print(__name__, ' key:', thisTenant, ' value:', accounts) # value is now a list
            #for accountnum in accounts:
            for settings in accounts:
                print(__name__, ' active account:', settings)
                accountnum = settings['account']
                tenantRegions = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Regions')
                activestatus = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Active')
                isvalid = hcom.is_valid_account(accountnum)
                print(__name__,'account active: {} is valid account: {}'.format(activestatus,isvalid))
                if activestatus == False or isvalid == False: # if not active or fake account
                    print(__name__,'---- skipping invalid account: {} ----'.format(accountnum))
                    continue
                msg_body = str({ "Function": 'ec2_audit', "account": accountnum, "tenant": thisTenant, "report": 'yes'})
                hcom.update_central_queque(msg_body,hcom.setSQS.get("HCOM-PlatformAutomation"))
                """
                for region in tenantRegions: # Loop through each region
                    rname = hcom.get_region_name(region)
                    ThisRegion = region
                    print(__name__, ' Region:', region)
                    ## begin count response
        
                    
                    try:
                        #environments = hcom.get_environs(environs, key)
                        environments = hcom.get_tenant_account_attribute(thisTenant,settings['account'],'Environments')
                        #environments = environs.get(thisTenant)
                        #print(__name__, 'environment:', len(environments), environments)
                        if len(environments) > 0: # make sure we have environments to loop through
                            for env in environments: # loop through each environment
                                ThisARN = setCrossAccountARN.replace('tenantaccount', accountnum) # replace value for accountnum
                                auditReport = auditReport + '------------ Start ' + thisTenant + ' ' + ThisRegion + ' Section -------------\n'
                                print(__name__, '--- begin ', thisTenant, ' ' + region + ' Region ---')
                                report = get_ec2_count(accountnum, ThisARN, thisTenant, rname, ThisRegion, env)
                                auditReport = auditReport + report.get("report1")
                                detailReport = detailReport + report.get("report2")
                                setting = 'Features'
                                print(__name__,'OnPrem:',hcom.get_tenant_account_setting(thisTenant,accountnum,setting,'OnPrem'))
                                if hcom.get_tenant_account_setting(thisTenant,accountnum,setting, 'OnPrem') == True:
                                    report = get_onprem_count(accountnum, ThisARN, thisTenant, rname, ThisRegion, env)
                                    auditReport = auditReport + report.get("report1")
                                    detailReport = detailReport + report.get("report2")
                    except ClientError as error:
                        print(__name__, 'Unexpected error occurred... could not parse environments. ', error)
                        continue
                        pass
                """    
    else: # target tenant passed so process only one tenant
        print(__name__,'TargetTenant is ', TargetTenant)
        processevent = 1
        thisTenant = TargetTenant
        #value = hcom.name_to_account(key,  hcom.setTenants)
        theseAccounts = hcom.get_tenant_accounts(thisTenant,True)#only audit Active Accounts
        if len(theseAccounts) > 0: # we have at least one account to loop through
            for accountnum in theseAccounts:
                tenantRegions = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Regions')
                activestatus = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Active')
                isvalid = hcom.is_valid_account(accountnum)
                print(__name__,'account active: {} is valid account: {}'.format(activestatus,isvalid))
                if activestatus == False or isvalid == False: # if not active or fake account
                    print(__name__,'---- skipping invalid account: {} ----'.format(accountnum))
                    continue
                for region in tenantRegions: # Loop through each region
                    ThisRegion = region
                    rname = hcom.get_region_name(region)
                    
                    
                    try:
                        #environments = hcom.get_environs(environs, key)
                        environments = hcom.get_tenant_account_attribute(thisTenant,accountnum,'Environments')
                        #environments = environs.get(thisTenant)
                        #print(__name__, 'environment:', len(environments), environments)
                        if len(environments) > 0: # make sure we have environments to loop through
                            for env in environments: # loop through each environment
                                ThisARN = setCrossAccountARN.replace('tenantaccount', accountnum)
                                auditReport = auditReport + '------------ Start ' + thisTenant + ' ' + ThisRegion + ' Section -------------\n'
                                print(__name__, '--- begin ', thisTenant, ' ' + region + ' Region ---')
                                report = get_ec2_count(accountnum, ThisARN, thisTenant, rname, ThisRegion, env)
                                auditReport = auditReport + report.get("report1")
                                detailReport = detailReport + report.get("report2")
                                setting = 'Features'
                                print(__name__,'OnPrem:',hcom.get_tenant_account_setting(thisTenant,accountnum,setting,'OnPrem'))
                                #if hcom.setFeatures.get('OnPrem') == 'Yes':
                                if hcom.get_tenant_account_setting(thisTenant,accountnum,setting,'OnPrem') == True:
                                    report = get_onprem_count(accountnum, ThisARN, thisTenant, rname, ThisRegion, env)
                                    auditReport = auditReport + report.get("report1")
                                    detailReport = detailReport + report.get("report2")
                    except ClientError as error:
                        print(__name__, 'Unexpected error occurred... could not parse environments. ', error)
                        continue
                        pass
                    
        print(__name__, 'Region', os.environ['AWS_REGION'])
        path = 'EC2-Reports/' + str(ThisTime.year) + '/' + ThisTime.strftime("%B") + '/'
        ThisMessage = auditReport + '\n This message was generated by the HCOM-EC2-Audit-Report Lambda automation. The Detailed Audit report can be found in S3 bucket ' + hcom.setBucket +'/' + path + '.\n'
    
        ThisSubject = 'EC2 Audit Report has been generated'
        #csvFile = tmp_file.name

        print(__name__, ' sendReport:', sendReport)
        if sendReport == 'yes':
            print(__name__, ' Now attempting to email and upload file')
            nothing = '' #actual value not needed
            #nothing2= '' #actual value not needed
            centralAlerts = hcom.convert_arn(hcom.setCentralSNS,hcom.setCentralRegion,hcom.setCentralAccount,hcom.setPartition,nothing,nothing)
            print(__name__,'central alert topic:{}'.format(centralAlerts))
            try:
                #send_sns_message(sns, ThisSNSHelpDesk, ThisSubject, ThisMessage )
                hcom.send_sns_message(sns, centralAlerts, ThisSubject, ThisMessage )
                #hcom.send_sns_message(sns, hcom.setTestARN, ThisSubject, ThisMessage )
                #send_sns_message2(sns, ses, DevARN, ThisSubject, ThisMessage, csvFile )
                print(__name__, 'Successfully emailed Alarm Report.')
            except ClientError as error:
                print(__name__, 'Error trying to send email to topic', error)
                pass
            
            filename = 'EC2-Detail-Report.csv'
            results = hcom.upload_report(detailReport, hcom.setBucket, hcom.setBucketReg, path, filename)
            print(__name__, ' upload results:',results)
        else:
            print(__name__, ' Do nothing and end.')
        #os.remove(tmp_file.name)
        ###### End Audit Report #######
        ### create HCOM Event in AWS EB
        if processevent == 1:
            etype = 'cw-event'
            ename = 'audit'
            etarget = 'StateChange'
            eventFormat = hcom.get_hcom_event(etype,ename,etarget)

            #### log event in EventBridge
            eventFormat['Detail']['tenant'] = TargetTenant
            eventFormat['Detail']['account'] = theseAccounts
            eventFormat['Detail']['state'] = 'completed'
            eventFormat['Detail']['category'] = 'ec2'
            source = 'hcom.audit'
            eventresponse = hcom.put_hcom_event(source,json.dumps(eventFormat['Detail']),'Audit-Report-Ran-Notification')  
        return {
            'statusCode': 200,
            'Audit Report': ThisMessage,
        }

def get_ec2_count(Account, ThisARN, AccountName, rname, ThisRegion, env):
    """Update the Dashboard Ops counters for EC2 instances

    Args:
        Account (_type_): AWS Account
        ThisARN (_type_): cross account role ARN
        AccountName (_type_): friendly tenant name for account
        rname (_type_): _description_
        ThisRegion (_type_): target region for account to audit
        env (_type_): specifies env to audit like DEV, TEST, PROD, etc.

    Returns:
        _type_: _description_
    """    
    ounter = 0
    Instances_Stopped = 0
    Instances_Stopped_details = []
    Instances_Running = 0
    Instances_Running_details = []
    report = {}
    global vpcs, subnets, sgs
    report1 = ''
    report2 = ''
    #################### Start: create client connections ##############################
    ## Assume cross account role
    ec2 = hcom.get_ec2_client_connection(Account, ThisRegion, ThisARN)
    setting = 'Tags'
    setEnvTag = hcom.get_account_setting(Account,setting,'environment')
    setProductTag = hcom.get_account_setting(Account,setting,'product')
    setRoleTag = hcom.get_account_setting(Account,setting,'role')
    setDescriptionTag = hcom.get_account_setting(Account,setting,'description')
    setPatchTag = hcom.get_account_setting(Account,setting,'patch')
    envtag = 'tag:' + setEnvTag
    ############# query EC2
    try:
        responses = ec2.describe_instances(
            Filters = [{'Name': envtag,'Values': [env]}
            ,{'Name':'instance-state-name', 'Values':['running','stopped','stopping']}]
        ) # Find instances 
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create EC2 cross account query', error)
        return error
   
    report2 = ''
    counter = 0
 
    ### begin count
    for r in responses['Reservations']:
        #print(__name__, 'how many ec2s:', len(r['Instances']))
        for i in r['Instances']:
            print(__name__,'--- current instance: {}'.format(i))
            counter = counter + 1
            iProfile = ''
            iName = ''
            iProfile = 'none'
            iName = ''
            iPR = ''
            iProduct = ''
            iPlatform = 'Windows'
            Thissgs = ''
            iEnv = ''
            iDescription = ''
            iPatch = ''
            iName = 'unknown'
            for tag in i['Tags']:
                print(__name__,'instance: {} | tag name: {} | tag value: {}'.format(i['InstanceId'],tag['Key'],tag['Value']))
                if tag['Key'] == "Name":
                    iName = tag['Value']
                    print('--- instance name is: {}'.format(iName))
                    break
            try:
                iPlatform = i['Platform']
            except KeyError as  error:
                #print(__name__, 'This is not a Window instance', error)
                iPlatform = 'Linux'
                pass
            RunningState = i['State']['Name']
            thisName = i['InstanceId'] + ' | ' + iName # join instance id and hostname for identifying the instance
            if RunningState =='stopped' or RunningState == 'stopping':
                Instances_Stopped = Instances_Stopped +1
                Instances_Stopped_details.append(thisName)
            elif RunningState == 'running':
                Instances_Running = Instances_Running +1
                Instances_Running_details.append(thisName)
            try:
                for k in i['Tags']: ## parse tags
                    if k['Key'] == 'Name':
                        iName = k['Value']
                    elif k['Key'] == hcom.setCWTags.get("profile") :
                        iProfile = k['Value']
                    elif k['Key'] == setEnvTag:
                        iEnv = k['Value']
                    elif k['Key'] == setProductTag:
                        iProduct = k['Value']
                    elif k['Key'] == setRoleTag:
                        iPR = k['Value']
                    elif k['Key'] == setDescriptionTag:
                        iDescription = str(k['Value'])
                    elif k['Key'] == setPatchTag:
                        iPatch = str(k['Value'])
            except KeyError as error:
                print(__name__, 'No tags for instance', error)
                pass
            for l in i['NetworkInterfaces']: ## parse NIC
                iIP = l['PrivateIpAddress']
            ### get/lookup vpc name
            if i['VpcId'] not in vpcs:
                vpcName = get_vpc(ec2,i['VpcId'])
                vpcs.update({i['VpcId']:vpcName})
            else:
                vpcName = vpcs.get(i['VpcId'])
            ### get/lookup subnet name
            if i['SubnetId'] not in subnets:
                subName = get_subnet(ec2,i['SubnetId'])
                subnets.update({i['SubnetId']:subName})
            else:
                subName = subnets.get(i['SubnetId'])
            ## get/ lookup security groups
            for m in i['SecurityGroups']:
                Thissgs = Thissgs + m['GroupId'] + ' ' + m['GroupName'] + ';  '
            
            # Format:'Account, InstanceId, Hostname, Environment,Description, Product,Product-Role,VPC-ID, AZ,SubnetId,IP,SGs,Platform,Type, State, Patch Group, CW Profile\n'
            report2 = report2 + AccountName + ',' + i['InstanceId'] + ',' + iName + ',' + iEnv + ',' + iDescription + ',' + iProduct + ',' + iPR + ',' + i['VpcId'] + ' ' + vpcName + ',' + i['Placement']['AvailabilityZone'] + ',' + i['SubnetId'] + ' ' + subName + ','  + iIP + ',' + Thissgs + ',' + iPlatform + ','  + str(i['InstanceType']) + ',' + str(i['State']['Name']) + ',' + iPatch + ',' + iProfile + ',' + ThisRegion +'\n'
    results = hcom.update_ops_stats(AccountName, Account, rname, env, "running", Instances_Running, Instances_Running_details,mode=1) # update ops stats in DynamoDB
    results = hcom.update_ops_stats(AccountName, Account, rname, env, "stopped", Instances_Stopped, Instances_Stopped_details,mode=1) # update ops stats in DynamoDB
    print(__name__, 'Account', Account, AccountName, env, 'Running Instances:', Instances_Running, 'Stopped Instances:', Instances_Stopped, 'Total:', counter)
    #print(__name__, 'vpcs:', vpcs)
    #print(__name__, 'subnets:', subnets)
    report1 = 'Account: ' + str(Account) + ' / ' + env + ' / ' + ThisRegion + ' / ' + AccountName + ' Running Instances: ' + str(Instances_Running) + ' Stopped Instances: ' + str(Instances_Stopped) + ' Total: '+ str(counter) + '\n'
    report.update({"report1": report1})
    report.update({"report2": report2})
    #print(report2)
    return report


    """Get running and stopped count for on-prem instances and updated DynamoDB. These stats will be used for Dashboard

    Args:
        Account (_type_): AWS Account
        ThisARN (_type_): cross account role ARN
        AccountName (_type_): friendly tenant name for account
        rname (_type_): _description_
        ThisRegion (_type_): target region for account to audit
        env (_type_): specifies env to audit like DEV, TEST, PROD, etc.

    Returns:
        _type_: _description_
    """    
    counter = 0
    Instances_ConnectionLost = 0
    Instances_ConnectionLost_details = []
    Instances_Online = 0
    Instances_Online_details = []
    Instances_Inactive = 0
    Instances_Inactive_details = []
    report = {}
    report1 = ''
    report2 = ''
    #################### Start: create client connections ##############################
    ## Assume cross account role
    ssm1 = hcom.get_ssm_connection(Account, ThisRegion, ThisARN)
    setting = 'Tags'
    setEnvTag = hcom.get_account_setting(Account,setting,'environment')
    setProductTag = hcom.get_account_setting(Account,setting,'product')
    setRoleTag = hcom.get_account_setting(Account,setting,'role')
    setDescriptionTag = hcom.get_account_setting(Account,setting,'description')
    setPatchTag = hcom.get_account_setting(Account,setting,'patch')
    envtag = 'tag:' + setEnvTag
    ############# query onprem managed instances
    try:
        responses = ssm1.describe_instance_information(Filters=[{'Key': 'ResourceType', 'Values': ['ManagedInstance']}]) # get all managed instances that are not  EC2
        print(__name__, 'Found onprem/non-EC2 Instances:', responses)
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create onprem cross account query', error)
        return error
    
    report2 = ''
    counter = 0
 
    ### begin count
    print(__name__, ' how many found:{} | {}'.format( len(responses['InstanceInformationList']),responses['InstanceInformationList']))
    if len(responses['InstanceInformationList']) > 0: # validate we have one
        try: # check if results are valid with all attributes that should be in results. Skip if missing. There is a problem usually with OnPrem Managed Instances.
        
            for i in responses['InstanceInformationList']: # loop through managed instances
                try:
                    if i['PlatformType']: isthere = 'yes' # detect if SSM agent is successfully communicating and skip if its not as it will be missing attributes.
                except KeyError as error:    
                    isthere = 'no'
                    print(__name__,'check for platform: {} | {}'.format(isthere,i['InstanceId']))
                    continue
                    pass
                print(__name__,'check for platform: {} | {}'.format(isthere,i['InstanceId']))
                if isthere == 'yes':
                    counter = counter + 1
                    iProfile = ''
                    iName = ''
                    iProfile = 'none'
                    iName = ''
                    iPR = ''
                    iProduct = ''
                    iPlatform = i['PlatformType']
                    Thissgs = ''
                    iEnv = ''
                    #iDescription = i['Name']
                    iPatch = ''
                    iIP = i['IPAddress']
                    RunningState = i['PingStatus']
                    ThisHostName1 = i["ComputerName"].split('.')
                    ThisHostName = ThisHostName1[0] # set the hostname
                    iName = ThisHostName
                    tags = ssm1.list_tags_for_resource(ResourceType='ManagedInstance',ResourceId=i['InstanceId'])
                    print(__name__, env, 'tags', tags)
                    for tag in tags['TagList']:
                        print(__name__, 'tag',tag)
                        if tag['Key'] == setEnvTag:
                            Thisenv = tag['Value'] # set the Environment name from tag value
                            iEnv = tag['Value']
                            thisName = i['InstanceId'] + ' | ' + iName # join instance id and hostname for identifying the instance
                            if Thisenv == env: # target env for count
                                if RunningState =='ConnectionLost':
                                    Instances_ConnectionLost = Instances_ConnectionLost + 1 # count it
                                    Instances_ConnectionLost_details.append(thisName) # add details
                                elif RunningState == 'Online':
                                    Instances_Online = Instances_Online + 1 # count it
                                    Instances_Online_details.append(thisName) # add details
                                elif RunningState == 'Inactive':
                                    Instances_Inactive = Instances_Inactive + 1 # count it
                                    Instances_Inactive_details.append(thisName) # add details
                            if tag['Key'] == hcom.setCWTags.get("profile") :
                                iProfile = k['Value']
                            elif tag['Key'] == setEnvTag:
                                iEnv = tag['Value']
                            elif tag['Key'] == setProductTag:
                                iProduct = tag['Value']
                            elif tag['Key'] == setRoleTag:
                                iPR = k['Value']
                            elif tag['Key'] == setDescriptionTag:
                                iDescription = str(tag['Value'])
                            elif tag['Key'] == setPatchTag:
                                iPatch = str(tag['Value'])

                    # Format:'Account, InstanceId, Hostname, Environment,Description, Product,Product-Role,VPC-ID, AZ,SubnetId,IP,SGs,Platform,Type, State, Patch Group, CW Profile\n'
                    report2 = report2 + AccountName + ',' + i['InstanceId'] + ',' + '' + ',' + iEnv + ',' + '' + ',' + iProduct + ',' + iPR + ',' + ',' +  ',' +  ' ' +  ','  + iIP + ',' + Thissgs + ',' + iPlatform + ','  + ',' + RunningState + ',' + iPatch + ',' + iProfile + ',' + ThisRegion +'\n'
                else:
                    print(__name__, 'Missing Platform data. Skipping to next instance.')
                    continue
        except KeyError as error:
            print(__name__, 'Something is wrong with results set. Usually issue with OnPrem registered instances.', error)
            pass

    results = hcom.update_ops_stats(AccountName, Account, rname, env, "Online", Instances_Online, Instances_Online_details, mode=1) # update ops stats in DynamoDB
    results = hcom.update_ops_stats(AccountName, Account, rname, env, "ConnectionLost", Instances_ConnectionLost, Instances_ConnectionLost_details,mode=1) # update ops stats in DynamoDB
    results = hcom.update_ops_stats(AccountName, Account, rname, env, "Inactive", Instances_Inactive, Instances_Inactive_details,mode=1) # update ops stats in DynamoDB
    print(__name__, 'Account', Account, AccountName, env, 'Online Instances:', Instances_Online, 'ConnectionLost Instances:', Instances_ConnectionLost, 'Inactive Instances:', Instances_Inactive,'Total:', counter)
    #print(__name__, 'vpcs:', vpcs)
    #print(__name__, 'subnets:', subnets)
    report1 = 'Account: ' + str(Account) + ' / ' + env + ' / ' + ThisRegion + ' / ' + AccountName + ' Running Instances: ' + str(Instances_Online) + ' ConnectionLost Instances: ' + str(Instances_ConnectionLost) + ' Inactive Instances: ' + str(Instances_Inactive) +' Total: '+ str(counter) + '\n'
    report.update({"report1": report1})
    report.update({"report2": report2})
    #print(report2)
    return report

def get_vpc(ec2,vpcId):
    try:
        response = ec2.describe_vpcs(
            VpcIds=[vpcId]
        )
        for i in response['Vpcs']:
            for k in i['Tags']: ## parse tags
                if k['Key'] == 'Name':
                    vpcname = k['Value']
    except ClientError as error:
        vpcname = ''
        pass
    return vpcname

def get_subnet(ec2,subnetId):
    try:
        response = ec2.describe_subnets(
            SubnetIds=[subnetId]
        )
        for i in response['Subnets']:
            for k in i['Tags']: ## parse tags
                if k['Key'] == 'Name':
                    subname = k['Value']
    except ClientError as error:
        subname = ''
        pass
    return subname

def get_onprem_count(Account, ThisARN, AccountName, rname, ThisRegion, env):
    """Get running and stopped count for on-prem instances and updated DynamoDB. These stats will be used for Dashboard

    Args:
        Account (_type_): AWS Account
        ThisARN (_type_): cross account role ARN
        AccountName (_type_): friendly tenant name for account
        rname (_type_): _description_
        ThisRegion (_type_): target region for account to audit
        env (_type_): specifies env to audit like DEV, TEST, PROD, etc.

    Returns:
        _type_: _description_
    """    
    counter = 0
    Instances_ConnectionLost = 0
    Instances_ConnectionLost_details = []
    Instances_Online = 0
    Instances_Online_details = []
    Instances_Inactive = 0
    Instances_Inactive_details = []
    report = {}
    report1 = ''
    report2 = ''
    #################### Start: create client connections ##############################
    ## Assume cross account role
    ssm1 = hcom.get_ssm_connection(Account, ThisRegion, ThisARN)
    setting = 'Tags'
    setEnvTag = hcom.get_account_setting(Account,setting,'environment')
    setProductTag = hcom.get_account_setting(Account,setting,'product')
    setRoleTag = hcom.get_account_setting(Account,setting,'role')
    setDescriptionTag = hcom.get_account_setting(Account,setting,'description')
    setPatchTag = hcom.get_account_setting(Account,setting,'patch')
    envtag = 'tag:' + setEnvTag
    ############# query onprem managed instances
    try:
        responses = ssm1.describe_instance_information(Filters=[{'Key': 'ResourceType', 'Values': ['ManagedInstance']}]) # get all managed instances that are not  EC2
        print(__name__, 'Found onprem/non-EC2 Instances:', responses)
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create onprem cross account query', error)
        return error
    
    report2 = ''
    counter = 0
 
    ### begin count
    print(__name__, ' how many found:{} | {}'.format( len(responses['InstanceInformationList']),responses['InstanceInformationList']))
    if len(responses['InstanceInformationList']) > 0: # validate we have one
        try: # check if results are valid with all attributes that should be in results. Skip if missing. There is a problem usually with OnPrem Managed Instances.
        
            for i in responses['InstanceInformationList']: # loop through managed instances
                try:
                    if i['PlatformType']: isthere = 'yes' # detect if SSM agent is successfully communicating and skip if its not as it will be missing attributes.
                except KeyError as error:    
                    isthere = 'no'
                    print(__name__,'check for platform: {} | {}'.format(isthere,i['InstanceId']))
                    continue
                    pass
                print(__name__,'check for platform: {} | {}'.format(isthere,i['InstanceId']))
                if isthere == 'yes':
                    counter = counter + 1
                    iProfile = ''
                    iName = ''
                    iProfile = 'none'
                    iName = ''
                    iPR = ''
                    iProduct = ''
                    iPlatform = i['PlatformType']
                    Thissgs = ''
                    iEnv = ''
                    #iDescription = i['Name']
                    iPatch = ''
                    iIP = i['IPAddress']
                    RunningState = i['PingStatus']
                    ThisHostName1 = i["ComputerName"].split('.')
                    ThisHostName = ThisHostName1[0] # set the hostname
                    iName = ThisHostName
                    tags = ssm1.list_tags_for_resource(ResourceType='ManagedInstance',ResourceId=i['InstanceId'])
                    print(__name__, env, 'tags', tags)
                    for tag in tags['TagList']:
                        print(__name__, 'tag',tag)
                        if tag['Key'] == setEnvTag:
                            Thisenv = tag['Value'] # set the Environment name from tag value
                            iEnv = tag['Value']
                            thisName = i['InstanceId'] + ' | ' + iName # join instance id and hostname for identifying the instance
                            if Thisenv == env: # target env for count
                                if RunningState =='ConnectionLost':
                                    Instances_ConnectionLost = Instances_ConnectionLost + 1 # count it
                                    Instances_ConnectionLost_details.append(thisName) # add details
                                elif RunningState == 'Online':
                                    Instances_Online = Instances_Online + 1 # count it
                                    Instances_Online_details.append(thisName) # add details
                                elif RunningState == 'Inactive':
                                    Instances_Inactive = Instances_Inactive + 1 # count it
                                    Instances_Inactive_details.append(thisName) # add details
                            if tag['Key'] == hcom.setCWTags.get("profile") :
                                iProfile = k['Value']
                            elif tag['Key'] == setEnvTag:
                                iEnv = tag['Value']
                            elif tag['Key'] == setProductTag:
                                iProduct = tag['Value']
                            elif tag['Key'] == setRoleTag:
                                iPR = k['Value']
                            elif tag['Key'] == setDescriptionTag:
                                iDescription = str(tag['Value'])
                            elif tag['Key'] == setPatchTag:
                                iPatch = str(tag['Value'])

                    # Format:'Account, InstanceId, Hostname, Environment,Description, Product,Product-Role,VPC-ID, AZ,SubnetId,IP,SGs,Platform,Type, State, Patch Group, CW Profile\n'
                    report2 = report2 + AccountName + ',' + i['InstanceId'] + ',' + '' + ',' + iEnv + ',' + '' + ',' + iProduct + ',' + iPR + ',' + ',' +  ',' +  ' ' +  ','  + iIP + ',' + Thissgs + ',' + iPlatform + ','  + ',' + RunningState + ',' + iPatch + ',' + iProfile + ',' + ThisRegion +'\n'
                else:
                    print(__name__, 'Missing Platform data. Skipping to next instance.')
                    continue
        except KeyError as error:
            print(__name__, 'Something is wrong with results set. Usually issue with OnPrem registered instances.', error)
            pass

    results = hcom.update_ops_stats(AccountName, Account, rname, env, "Online", Instances_Online, Instances_Online_details, mode=1) # update ops stats in DynamoDB
    results = hcom.update_ops_stats(AccountName, Account, rname, env, "ConnectionLost", Instances_ConnectionLost, Instances_ConnectionLost_details,mode=1) # update ops stats in DynamoDB
    results = hcom.update_ops_stats(AccountName, Account, rname, env, "Inactive", Instances_Inactive, Instances_Inactive_details,mode=1) # update ops stats in DynamoDB
    print(__name__, 'Account', Account, AccountName, env, 'Online Instances:', Instances_Online, 'ConnectionLost Instances:', Instances_ConnectionLost, 'Inactive Instances:', Instances_Inactive,'Total:', counter)
    #print(__name__, 'vpcs:', vpcs)
    #print(__name__, 'subnets:', subnets)
    report1 = 'Account: ' + str(Account) + ' / ' + env + ' / ' + ThisRegion + ' / ' + AccountName + ' Running Instances: ' + str(Instances_Online) + ' ConnectionLost Instances: ' + str(Instances_ConnectionLost) + ' Inactive Instances: ' + str(Instances_Inactive) +' Total: '+ str(counter) + '\n'
    report.update({"report1": report1})
    report.update({"report2": report2})
    #print(report2)
    return report

def get_dynamodb_count(Account, ThisARN, AccountName, rname, ThisRegion, env):
    """Get running and stopped count for on-prem instances and updated DynamoDB. These stats will be used for Dashboard

    Args:
        Account (_type_): AWS Account
        ThisARN (_type_): cross account role ARN
        AccountName (_type_): friendly tenant name for account
        rname (_type_): _description_
        ThisRegion (_type_): target region for account to audit
        env (_type_): specifies env to audit like DEV, TEST, PROD, etc.

    Returns:
        _type_: _description_
    """    
    counter = 0
    Instances_ConnectionLost = 0
    Instances_ConnectionLost_details = []
    Instances_Online = 0
    Instances_Online_details = []
    Instances_Inactive = 0
    Instances_Inactive_details = []
    report = {}
    report1 = ''
    report2 = ''
    #################### Start: create client connections ##############################
    ## Assume cross account role
    ssm1 = hcom.get_ssm_connection(Account, ThisRegion, ThisARN)
    setting = 'Tags'
    setEnvTag = hcom.get_account_setting(Account,setting,'environment')
    setProductTag = hcom.get_account_setting(Account,setting,'product')
    setRoleTag = hcom.get_account_setting(Account,setting,'role')
    setDescriptionTag = hcom.get_account_setting(Account,setting,'description')
    setPatchTag = hcom.get_account_setting(Account,setting,'patch')
    envtag = 'tag:' + setEnvTag
    ############# query onprem managed instances
    try:
        responses = ssm1.describe_instance_information(Filters=[{'Key': 'ResourceType', 'Values': ['ManagedInstance']}]) # get all managed instances that are not  EC2
        print(__name__, 'Found onprem/non-EC2 Instances:', responses)
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create onprem cross account query', error)
        return error
    
    report2 = ''
    counter = 0
 
    ### begin count
    print(__name__, ' how many found:{} | {}'.format( len(responses['InstanceInformationList']),responses['InstanceInformationList']))
    if len(responses['InstanceInformationList']) > 0: # validate we have one
        try: # check if results are valid with all attributes that should be in results. Skip if missing. There is a problem usually with OnPrem Managed Instances.
        
            for i in responses['InstanceInformationList']: # loop through managed instances
                try:
                    if i['PlatformType']: isthere = 'yes' # detect if SSM agent is successfully communicating and skip if its not as it will be missing attributes.
                except KeyError as error:    
                    isthere = 'no'
                    print(__name__,'check for platform: {} | {}'.format(isthere,i['InstanceId']))
                    continue
                    pass
                print(__name__,'check for platform: {} | {}'.format(isthere,i['InstanceId']))
                if isthere == 'yes':
                    counter = counter + 1
                    iProfile = ''
                    iName = ''
                    iProfile = 'none'
                    iName = ''
                    iPR = ''
                    iProduct = ''
                    iPlatform = i['PlatformType']
                    Thissgs = ''
                    iEnv = ''
                    #iDescription = i['Name']
                    iPatch = ''
                    iIP = i['IPAddress']
                    RunningState = i['PingStatus']
                    ThisHostName1 = i["ComputerName"].split('.')
                    ThisHostName = ThisHostName1[0] # set the hostname
                    iName = ThisHostName
                    tags = ssm1.list_tags_for_resource(ResourceType='ManagedInstance',ResourceId=i['InstanceId'])
                    print(__name__, env, 'tags', tags)
                    for tag in tags['TagList']:
                        print(__name__, 'tag',tag)
                        if tag['Key'] == setEnvTag:
                            Thisenv = tag['Value'] # set the Environment name from tag value
                            iEnv = tag['Value']
                            thisName = i['InstanceId'] + ' | ' + iName # join instance id and hostname for identifying the instance
                            if Thisenv == env: # target env for count
                                if RunningState =='ConnectionLost':
                                    Instances_ConnectionLost = Instances_ConnectionLost + 1 # count it
                                    Instances_ConnectionLost_details.append(thisName) # add details
                                elif RunningState == 'Online':
                                    Instances_Online = Instances_Online + 1 # count it
                                    Instances_Online_details.append(thisName) # add details
                                elif RunningState == 'Inactive':
                                    Instances_Inactive = Instances_Inactive + 1 # count it
                                    Instances_Inactive_details.append(thisName) # add details
                            if tag['Key'] == hcom.setCWTags.get("profile") :
                                iProfile = k['Value']
                            elif tag['Key'] == setEnvTag:
                                iEnv = tag['Value']
                            elif tag['Key'] == setProductTag:
                                iProduct = tag['Value']
                            elif tag['Key'] == setRoleTag:
                                iPR = k['Value']
                            elif tag['Key'] == setDescriptionTag:
                                iDescription = str(tag['Value'])
                            elif tag['Key'] == setPatchTag:
                                iPatch = str(tag['Value'])

                    # Format:'Account, InstanceId, Hostname, Environment,Description, Product,Product-Role,VPC-ID, AZ,SubnetId,IP,SGs,Platform,Type, State, Patch Group, CW Profile\n'
                    report2 = report2 + AccountName + ',' + i['InstanceId'] + ',' + '' + ',' + iEnv + ',' + '' + ',' + iProduct + ',' + iPR + ',' + ',' +  ',' +  ' ' +  ','  + iIP + ',' + Thissgs + ',' + iPlatform + ','  + ',' + RunningState + ',' + iPatch + ',' + iProfile + ',' + ThisRegion +'\n'
                else:
                    print(__name__, 'Missing Platform data. Skipping to next instance.')
                    continue
        except KeyError as error:
            print(__name__, 'Something is wrong with results set. Usually issue with OnPrem registered instances.', error)
            pass

    results = hcom.update_ops_stats(AccountName, Account, rname, env, "Online", Instances_Online, Instances_Online_details, mode=1) # update ops stats in DynamoDB
    results = hcom.update_ops_stats(AccountName, Account, rname, env, "ConnectionLost", Instances_ConnectionLost, Instances_ConnectionLost_details,mode=1) # update ops stats in DynamoDB
    results = hcom.update_ops_stats(AccountName, Account, rname, env, "Inactive", Instances_Inactive, Instances_Inactive_details,mode=1) # update ops stats in DynamoDB
    print(__name__, 'Account', Account, AccountName, env, 'Online Instances:', Instances_Online, 'ConnectionLost Instances:', Instances_ConnectionLost, 'Inactive Instances:', Instances_Inactive,'Total:', counter)
    #print(__name__, 'vpcs:', vpcs)
    #print(__name__, 'subnets:', subnets)
    report1 = 'Account: ' + str(Account) + ' / ' + env + ' / ' + ThisRegion + ' / ' + AccountName + ' Running Instances: ' + str(Instances_Online) + ' ConnectionLost Instances: ' + str(Instances_ConnectionLost) + ' Inactive Instances: ' + str(Instances_Inactive) +' Total: '+ str(counter) + '\n'
    report.update({"report1": report1})
    report.update({"report2": report2})
    #print(report2)
    return report

def get_rds_count(Account, ThisARN, AccountName, rname, ThisRegion, env):
    """Get running and stopped count for rds and aurora and update DynamoDB. These stats will be used for Dashboard

    Args:
        Account (_type_): AWS Account
        ThisARN (_type_): cross account role ARN
        AccountName (_type_): friendly tenant name for account
        rname (_type_): _description_
        ThisRegion (_type_): target region for account to audit
        env (_type_): specifies env to audit like DEV, TEST, PROD, etc.

    Returns:
        _type_: _description_
    """    
    counter = 0
    Instances_ConnectionLost = 0
    Instances_ConnectionLost_details = []
    Instances_Online = 0
    Instances_Online_details = []
    Instances_Inactive = 0
    Instances_Inactive_details = []
    report = {}
    report1 = ''
    report2 = ''
    #################### Start: create client connections ##############################
    ## Assume cross account role
    ssm1 = hcom.get_ssm_connection(Account, ThisRegion, ThisARN)
    setting = 'Tags'
    setEnvTag = hcom.get_account_setting(Account,setting,'environment')
    setProductTag = hcom.get_account_setting(Account,setting,'product')
    setRoleTag = hcom.get_account_setting(Account,setting,'role')
    setDescriptionTag = hcom.get_account_setting(Account,setting,'description')
    setPatchTag = hcom.get_account_setting(Account,setting,'patch')
    envtag = 'tag:' + setEnvTag
    ############# query onprem managed instances
    try:
        responses = ssm1.describe_instance_information(Filters=[{'Key': 'ResourceType', 'Values': ['ManagedInstance']}]) # get all managed instances that are not  EC2
        print(__name__, 'Found onprem/non-EC2 Instances:', responses)
    except ClientError as error:
        print(__name__, 'Unexpected error occurred... could not create onprem cross account query', error)
        return error

    report2 = ''
    counter = 0

    ### begin count
    print(__name__, ' how many found:{} | {}'.format( len(responses['InstanceInformationList']),responses['InstanceInformationList']))
    if len(responses['InstanceInformationList']) > 0: # validate we have one
        try: # check if results are valid with all attributes that should be in results. Skip if missing. There is a problem usually with OnPrem Managed Instances.
        
            for i in responses['InstanceInformationList']: # loop through managed instances
                try:
                    if i['PlatformType']: isthere = 'yes' # detect if SSM agent is successfully communicating and skip if its not as it will be missing attributes.
                except KeyError as error:    
                    isthere = 'no'
                    print(__name__,'check for platform: {} | {}'.format(isthere,i['InstanceId']))
                    continue
                    pass
                print(__name__,'check for platform: {} | {}'.format(isthere,i['InstanceId']))
                if isthere == 'yes':
                    counter = counter + 1
                    iProfile = ''
                    iName = ''
                    iProfile = 'none'
                    iName = ''
                    iPR = ''
                    iProduct = ''
                    iPlatform = i['PlatformType']
                    Thissgs = ''
                    iEnv = ''
                    #iDescription = i['Name']
                    iPatch = ''
                    iIP = i['IPAddress']
                    RunningState = i['PingStatus']
                    ThisHostName1 = i["ComputerName"].split('.')
                    ThisHostName = ThisHostName1[0] # set the hostname
                    iName = ThisHostName
                    tags = ssm1.list_tags_for_resource(ResourceType='ManagedInstance',ResourceId=i['InstanceId'])
                    print(__name__, env, 'tags', tags)
                    for tag in tags['TagList']:
                        print(__name__, 'tag',tag)
                        if tag['Key'] == setEnvTag:
                            Thisenv = tag['Value'] # set the Environment name from tag value
                            iEnv = tag['Value']
                            thisName = i['InstanceId'] + ' | ' + iName # join instance id and hostname for identifying the instance
                            if Thisenv == env: # target env for count
                                if RunningState =='ConnectionLost':
                                    Instances_ConnectionLost = Instances_ConnectionLost + 1 # count it
                                    Instances_ConnectionLost_details.append(thisName) # add details
                                elif RunningState == 'Online':
                                    Instances_Online = Instances_Online + 1 # count it
                                    Instances_Online_details.append(thisName) # add details
                                elif RunningState == 'Inactive':
                                    Instances_Inactive = Instances_Inactive + 1 # count it
                                    Instances_Inactive_details.append(thisName) # add details
                            if tag['Key'] == hcom.setCWTags.get("profile") :
                                iProfile = k['Value']
                            elif tag['Key'] == setEnvTag:
                                iEnv = tag['Value']
                            elif tag['Key'] == setProductTag:
                                iProduct = tag['Value']
                            elif tag['Key'] == setRoleTag:
                                iPR = k['Value']
                            elif tag['Key'] == setDescriptionTag:
                                iDescription = str(tag['Value'])
                            elif tag['Key'] == setPatchTag:
                                iPatch = str(tag['Value'])

                    # Format:'Account, InstanceId, Hostname, Environment,Description, Product,Product-Role,VPC-ID, AZ,SubnetId,IP,SGs,Platform,Type, State, Patch Group, CW Profile\n'
                    report2 = report2 + AccountName + ',' + i['InstanceId'] + ',' + '' + ',' + iEnv + ',' + '' + ',' + iProduct + ',' + iPR + ',' + ',' +  ',' +  ' ' +  ','  + iIP + ',' + Thissgs + ',' + iPlatform + ','  + ',' + RunningState + ',' + iPatch + ',' + iProfile + ',' + ThisRegion +'\n'
                else:
                    print(__name__, 'Missing Platform data. Skipping to next instance.')
                    continue
        except KeyError as error:
            print(__name__, 'Something is wrong with results set. Usually issue with OnPrem registered instances.', error)
            pass

    results = hcom.update_ops_stats(AccountName, Account, rname, env, "Online", Instances_Online, Instances_Online_details, mode=1) # update ops stats in DynamoDB
    results = hcom.update_ops_stats(AccountName, Account, rname, env, "ConnectionLost", Instances_ConnectionLost, Instances_ConnectionLost_details,mode=1) # update ops stats in DynamoDB
    results = hcom.update_ops_stats(AccountName, Account, rname, env, "Inactive", Instances_Inactive, Instances_Inactive_details,mode=1) # update ops stats in DynamoDB
    print(__name__, 'Account', Account, AccountName, env, 'Online Instances:', Instances_Online, 'ConnectionLost Instances:', Instances_ConnectionLost, 'Inactive Instances:', Instances_Inactive,'Total:', counter)
    #print(__name__, 'vpcs:', vpcs)
    #print(__name__, 'subnets:', subnets)
    report1 = 'Account: ' + str(Account) + ' / ' + env + ' / ' + ThisRegion + ' / ' + AccountName + ' Running Instances: ' + str(Instances_Online) + ' ConnectionLost Instances: ' + str(Instances_ConnectionLost) + ' Inactive Instances: ' + str(Instances_Inactive) +' Total: '+ str(counter) + '\n'
    report.update({"report1": report1})
    report.update({"report2": report2})
    #print(report2)
    return report